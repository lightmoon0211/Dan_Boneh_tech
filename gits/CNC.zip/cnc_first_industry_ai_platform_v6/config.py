import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
APP_VERSION = (BASE_DIR / "VERSION").read_text(encoding="utf-8").strip()
DATABASE_DIR = BASE_DIR / "databases"
REPORT_UPLOAD_DIR = BASE_DIR / "reports" / "uploads"
SETTINGS_DIR = BASE_DIR / "settings"
SCHEMA_DIR = BASE_DIR / "schemas"
SECTOR_DIR = BASE_DIR / "sectors"

DEFAULT_DB_FILENAME = "smart_cnc_factory.db"
DEFAULT_SECTOR = "manufacturing"

# transformers | llama_cpp | openai_compatible
LLM_BACKEND = os.getenv("LLM_BACKEND", "transformers")
HF_MODEL = os.getenv("HF_MODEL", "Qwen/Qwen2.5-Coder-1.5B-Instruct")
HF_LOCAL_FILES_ONLY = os.getenv("HF_LOCAL_FILES_ONLY", "false").lower() == "true"
GGUF_MODEL_PATH = os.getenv("GGUF_MODEL_PATH", r"F:\models\jarvis-cnc-14b-q4_k_m.gguf")
OPENAI_COMPATIBLE_BASE_URL = os.getenv("OPENAI_COMPATIBLE_BASE_URL", "http://127.0.0.1:8000/v1").rstrip("/")
OPENAI_COMPATIBLE_MODEL = os.getenv("OPENAI_COMPATIBLE_MODEL", "local-cnc-instruct")
OPENAI_COMPATIBLE_API_KEY = os.getenv("OPENAI_COMPATIBLE_API_KEY", "local")
LLM_REQUEST_TIMEOUT_SECONDS = int(os.getenv("LLM_REQUEST_TIMEOUT_SECONDS", "180"))

MAX_SQL_TOKENS = int(os.getenv("MAX_SQL_TOKENS", "700"))
MAX_PLAN_TOKENS = int(os.getenv("MAX_PLAN_TOKENS", "1100"))
MAX_ANSWER_TOKENS = int(os.getenv("MAX_ANSWER_TOKENS", "900"))
MAX_REPORT_TOKENS = int(os.getenv("MAX_REPORT_TOKENS", "850"))
MAX_ROWS = int(os.getenv("MAX_ROWS", "100"))
MAX_EVIDENCE_ROWS_FOR_ANSWER = int(os.getenv("MAX_EVIDENCE_ROWS_FOR_ANSWER", "40"))
MAX_PLAN_QUERIES = int(os.getenv("MAX_PLAN_QUERIES", "4"))
MAX_HISTORY_MESSAGES = int(os.getenv("MAX_HISTORY_MESSAGES", "12"))
SQL_TIMEOUT_SECONDS = int(os.getenv("SQL_TIMEOUT_SECONDS", "15"))
REPORT_CHUNK_CHARS = int(os.getenv("REPORT_CHUNK_CHARS", "6500"))
MAX_REPORT_SOURCE_CHARS = int(os.getenv("MAX_REPORT_SOURCE_CHARS", "80000"))

HOST = os.getenv("HOST", "127.0.0.1")
PORT = int(os.getenv("PORT", "5000"))

SUPPORTED_LANGUAGES = {
    "en": "English",
    "fr": "Français",
    "de": "Deutsch",
    "zh-CN": "简体中文",
    "zh-TW": "繁體中文",
    "ja": "日本語",
    "ko": "한국어",
}

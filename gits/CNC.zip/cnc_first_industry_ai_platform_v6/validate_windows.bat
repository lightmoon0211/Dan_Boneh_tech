@echo off
setlocal
cd /d "%~dp0"
echo Running CNC-First Industry AI Platform validation...
echo.
python test_database.py || goto :failed
python tests\test_core.py || goto :failed
python tests\test_conversation.py || goto :failed
python tests\test_frontend.py || goto :failed
echo.
echo ALL LLM-FREE TESTS PASSED
exit /b 0

:failed
echo.
echo VALIDATION FAILED. Read the first error above.
echo Confirm that this window is using the intended conda environment.
exit /b 1

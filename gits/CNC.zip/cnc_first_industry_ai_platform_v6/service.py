"""Intent-aware conversational service for industry and CNC factory data."""
from __future__ import annotations

from datetime import datetime, timezone
import sqlite3

from config import (
    MAX_ANSWER_TOKENS,
    MAX_EVIDENCE_ROWS_FOR_ANSWER,
    MAX_HISTORY_MESSAGES,
    MAX_PLAN_QUERIES,
    MAX_PLAN_TOKENS,
    MAX_ROWS,
    MAX_SQL_TOKENS,
)
from conversation import (
    clean_history,
    extract_json_object,
    history_as_text,
    is_social_only,
    normalize_answer_style,
    normalize_plan,
)
from db_manager import db_manager
from llm_backend import LocalLLM
from prompts import (
    conversation_answer_prompt,
    evidence_answer_prompt,
    planner_prompt,
    query_repair_prompt,
    sql_prompt,
)
from sector_manager import sector_manager
from sql_guard import extract_sql, validate_sql


class IndustryDataService:
    def __init__(self, llm=None):
        self.llm = llm or LocalLLM()
        self.refresh()

    def refresh(self):
        self.schema = db_manager.schema()
        self.stats = db_manager.stats()
        self.sector = sector_manager.active_profile()

    def _plan(self, question, language, history_text, answer_style):
        raw = self.llm.generate(
            planner_prompt(
                self.schema,
                question,
                language,
                history_text,
                self.sector,
                answer_style,
            ),
            max_new_tokens=MAX_PLAN_TOKENS,
            temperature=0.0,
        )
        try:
            return normalize_plan(extract_json_object(raw), MAX_PLAN_QUERIES)
        except (ValueError, TypeError):
            # A compact local model may occasionally return SQL instead of JSON.
            # Reuse it when safe; otherwise request one compatibility query.
            try:
                sql = validate_sql(extract_sql(raw))
            except ValueError:
                fallback = self.llm.generate(
                    sql_prompt(
                        self.schema,
                        question,
                        language,
                        history_text,
                        self.sector,
                    ),
                    max_new_tokens=MAX_SQL_TOKENS,
                    temperature=0.0,
                )
                sql = validate_sql(extract_sql(fallback))
            return {
                "mode": "data",
                "queries": [{"label": "Database evidence", "sql": sql}],
                "clarifying_question": "",
                "suggested_questions": [],
            }

    def _conversation_answer(self, question, language, history_text, answer_style):
        return self.llm.generate(
            conversation_answer_prompt(
                question,
                language,
                history_text,
                self.sector,
                answer_style,
            ),
            max_new_tokens=MAX_ANSWER_TOKENS,
            temperature=0.25,
        ).strip()

    def _execute_with_one_repair(self, sql, question, history_text):
        safe_sql = validate_sql(extract_sql(sql))
        try:
            return safe_sql, db_manager.execute_readonly(safe_sql), False
        except sqlite3.Error as exc:
            repaired_raw = self.llm.generate(
                query_repair_prompt(
                    self.schema,
                    question,
                    history_text,
                    safe_sql,
                    str(exc),
                ),
                max_new_tokens=MAX_SQL_TOKENS,
                temperature=0.0,
            )
            repaired_sql = validate_sql(extract_sql(repaired_raw))
            return repaired_sql, db_manager.execute_readonly(repaired_sql), True

    def _default_suggestions(self, question):
        q = question.lower()
        if any(word in q for word in ("downtime", "alarm", "stop")):
            return [
                "What happened before the longest unplanned stop?",
                "Which downtime reasons caused the most lost minutes?",
                "Are related maintenance actions still open?",
            ]
        if any(word in q for word in ("work order", "capacity", "schedule", "late")):
            return [
                "Which work orders are most at risk?",
                "What materials could delay the current plan?",
                "Where is the current production bottleneck?",
            ]
        if any(word in q for word in ("quality", "scrap", "inspection", "nonconformance")):
            return [
                "Which defects caused the most scrap?",
                "Which machines are associated with failed inspections?",
                "Show the evidence before the latest quality failure.",
            ]
        if any(word in q for word in ("oee", "availability", "performance")):
            return [
                "Explain how this OEE value was calculated.",
                "Which loss reduced OEE the most?",
                "Compare the same time window across machines.",
            ]
        return list(self.sector.get("example_questions", []))[:3]

    def ask(self, question, language="en", history=None, answer_style="auto"):
        self.refresh()
        question = str(question or "").strip()
        if not question:
            raise ValueError("Please enter a question.")

        style = normalize_answer_style(answer_style)
        cleaned_history = clean_history(history, limit=MAX_HISTORY_MESSAGES)
        history_text = history_as_text(cleaned_history)

        if is_social_only(question):
            plan = {
                "mode": "conversation",
                "queries": [],
                "clarifying_question": "",
                "suggested_questions": [],
            }
        else:
            plan = self._plan(question, language, history_text, style)

        if plan["mode"] == "clarify":
            answer = plan["clarifying_question"]
            evidence = []
        elif plan["mode"] == "conversation":
            answer = self._conversation_answer(
                question, language, history_text, style
            )
            evidence = []
        else:
            evidence = []
            for query in plan["queries"]:
                sql, rows, repaired = self._execute_with_one_repair(
                    query["sql"], question, history_text
                )
                evidence.append(
                    {
                        "label": query["label"],
                        "sql": sql,
                        "rows": rows,
                        "row_count": len(rows),
                        "may_be_truncated": len(rows) >= MAX_ROWS,
                        "automatically_repaired": repaired,
                    }
                )
            prompt_evidence = []
            for item in evidence:
                compact = item.copy()
                compact["rows"] = item["rows"][:MAX_EVIDENCE_ROWS_FOR_ANSWER]
                compact["rows_in_answer_context"] = len(compact["rows"])
                prompt_evidence.append(compact)
            answer = self.llm.generate(
                evidence_answer_prompt(
                    question,
                    prompt_evidence,
                    language,
                    history_text,
                    self.sector,
                    style,
                ),
                max_new_tokens=MAX_ANSWER_TOKENS,
                temperature=0.2,
            ).strip()

        suggestions = plan.get("suggested_questions") or self._default_suggestions(question)
        first = evidence[0] if evidence else {"sql": None, "rows": []}
        return {
            "question": question,
            "language": language,
            "sector": self.sector,
            "answer": answer,
            "response_type": plan["mode"],
            "answer_style": style,
            "evidence": evidence,
            # Backward compatibility for clients built against v5.
            "sql": first["sql"],
            "rows": first["rows"],
            "suggested_questions": suggestions[:3],
            "context_messages_used": len(cleaned_history),
            "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        }

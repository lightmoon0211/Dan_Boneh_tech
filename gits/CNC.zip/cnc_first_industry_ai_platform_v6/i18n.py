import json
from config import SETTINGS_DIR
from settings_manager import (
    get_custom_ui_text,
    save_custom_ui_text,
    reset_custom_ui_text,
)

DEFAULTS_FILE = SETTINGS_DIR / "ui_text_defaults.json"


def _defaults():
    return json.loads(DEFAULTS_FILE.read_text(encoding="utf-8"))


def get_ui_text(language):
    defaults = _defaults()
    language = language if language in defaults else "en"

    # English is the canonical key set. Other languages override it. This
    # guarantees that newly added UI labels remain readable even before every
    # translation has been supplied.
    result = defaults.get("en", {}).copy()
    result.update(defaults.get(language, {}))

    custom = get_custom_ui_text()
    result.update(custom.get(language, {}))
    return result


def get_all_ui_text():
    defaults = _defaults()
    custom = get_custom_ui_text()
    merged = {}
    for language in defaults:
        merged[language] = defaults.get("en", {}).copy()
        merged[language].update(defaults.get(language, {}))
        merged[language].update(custom.get(language, {}))
    return merged


def update_ui_text(language, values):
    defaults = _defaults()
    if language not in defaults:
        raise ValueError("Unsupported language.")

    allowed_keys = set(defaults.get("en", {})) | set(defaults.get(language, {}))
    custom = get_custom_ui_text()
    custom.setdefault(language, {})
    custom[language].update({
        str(k): str(v)
        for k, v in values.items()
        if k in allowed_keys
    })
    save_custom_ui_text(custom)
    return get_ui_text(language)


def reset_ui_text():
    reset_custom_ui_text()

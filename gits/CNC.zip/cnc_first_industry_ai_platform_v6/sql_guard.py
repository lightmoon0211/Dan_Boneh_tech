import re

BLOCKED_KEYWORDS = {
    "INSERT","UPDATE","DELETE","DROP","ALTER","TRUNCATE","CREATE",
    "REPLACE","ATTACH","DETACH","VACUUM","REINDEX","PRAGMA"
}

def extract_sql(text):
    if not text:
        raise ValueError("The model returned an empty response.")

    text = text.strip()
    fenced = re.search(
        r"```(?:sql)?\s*(.*?)```",
        text,
        flags=re.IGNORECASE | re.DOTALL
    )
    if fenced:
        text = fenced.group(1).strip()

    start = re.search(r"\b(SELECT|WITH)\b", text, flags=re.IGNORECASE)
    if not start:
        raise ValueError("No SELECT or WITH query was found.")

    text = text[start.start():].strip()
    if ";" in text:
        text = text.split(";", 1)[0].strip()
    return text + ";"

def validate_sql(sql):
    body = sql.strip()
    if body.endswith(";"):
        body = body[:-1].strip()
    if ";" in body:
        raise ValueError("Multiple SQL statements are not allowed.")

    first = re.match(r"^\s*([A-Za-z]+)", body)
    if not first:
        raise ValueError("Could not determine SQL statement type.")
    if first.group(1).upper() not in {"SELECT","WITH"}:
        raise ValueError("Only SELECT and WITH queries are allowed.")

    words = set(re.findall(r"\b[A-Za-z_]+\b", body.upper()))
    blocked = sorted(words.intersection(BLOCKED_KEYWORDS))
    if blocked:
        raise ValueError("Blocked SQL keyword(s): " + ", ".join(blocked))
    return body + ";"

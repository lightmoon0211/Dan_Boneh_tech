# CNC-First Industry AI Platform v6

A local, CNC-first factory assistant with a conversational chat experience and
verified read-only database analysis. It supports natural follow-ups, general
CNC guidance, clarifying questions, and multi-query management analysis instead
of forcing every message through one SQL query.

The interface is ChatGPT-like in interaction design; it does not claim to be or
reproduce a proprietary ChatGPT model. Answer quality depends strongly on the
local model you configure. A capable instruction model served through vLLM is
recommended for the most natural and flexible responses.

## What is included

- Conversational routing: normal guidance, clarification, or database analysis
- Up to four coordinated read-only queries for complex factory questions
- Follow-up context for machines, work orders, dates, and prior answers
- Auto, Concise, Balanced, and Detailed answer styles
- Markdown answers, copy/stop controls, evidence drawers, and follow-up prompts
- Browser-session conversation restoration after page reload
- Validated SQL safety and a 15-second query execution limit
- CNC production, work-order, downtime, quality, maintenance, tooling,
  materials, telemetry, energy, CNC program, and automated guided vehicle data
- 46-table fictional Smart CNC database with 19 machines, 100 work orders, and
  27,360 sensor readings
- Database, schema, sector, report, and multilingual UI managers
- Complete 37-page user manual in Word and PDF
- Beginner-friendly `reports/sample_daily_report.txt` for testing report ingestion

## Project structure

```text
cnc_first_industry_ai_platform_v6/
├── app.py                      Flask routes
├── service.py                  conversational orchestration
├── conversation.py             plan parsing, history limits, validation
├── prompts.py                  planner and answer behavior
├── llm_backend.py              Transformers, GGUF, or local API backend
├── sql_guard.py                read-only SQL validation
├── db_manager.py               SQLite discovery and safe execution
├── schema_manager.py           schema inspection and creation
├── sector_manager.py           reusable industry profiles
├── report_manager.py           controlled report ingestion
├── templates/index.html        application interface
├── static/app.js               chat and management interactions
├── static/style.css            responsive visual design
├── databases/                  active and uploaded SQLite databases
├── schemas/                    schema examples and snapshots
├── sectors/                    built-in sector profiles
├── settings/                   application and editable UI settings
├── tests/                      LLM-free automated checks
└── docs/
    ├── CNC_First_Industry_AI_Platform_User_Manual.docx
    ├── CNC_First_Industry_AI_Platform_User_Manual.pdf
    ├── CONVERSATIONAL_CHAT_GUIDE.md
    └── QA_REPORT.md
```

## 1. Create the Python environment

Open PowerShell in the project folder:

```powershell
conda create -n smartfactoryllm python=3.11 -y
conda activate smartfactoryllm
```

Use Python 3.11 for the smoothest compatibility with PyTorch, Transformers,
Flask, report readers, and optional llama.cpp packages.

## 2. Install one runtime profile

### NVIDIA GPU

```powershell
pip install -r requirements-gpu.txt
```

This profile installs PyTorch 2.11.0 built for CUDA 12.8. It is suitable for
Python 3.11 and Hopper-class NVIDIA GPUs such as the H200, provided the host has
a compatible NVIDIA driver.

### CPU only

```powershell
pip install -r requirements-cpu.txt
```

This profile installs the CPU build of PyTorch 2.11.0.

### GGUF with llama.cpp

```powershell
pip install -r requirements-gguf.txt
```

Do not install all three files. Select the profile for the machine that will run
the application.

## 3. Run the LLM-free validation first

The working directory must be the folder containing `app.py`,
`db_manager.py`, and `test_database.py`:

```powershell
python test_database.py
python tests/test_core.py
python tests/test_conversation.py
python tests/test_frontend.py
```

Expected final lines:

```text
Database test completed successfully.
CORE TESTS PASSED
CONVERSATION TESTS PASSED
FRONTEND CONTRACT TESTS PASSED
```

These tests do not download or load a language model.

## 4. Select a model backend

### Simple first run: Transformers

This is the default:

```powershell
$env:LLM_BACKEND="transformers"
$env:HF_MODEL="Qwen/Qwen2.5-Coder-1.5B-Instruct"
python app.py
```

The small default model is suitable for validating the workflow. For more
natural conversation and stronger multi-table reasoning, set `HF_MODEL` to a
larger instruction model that fits the available GPU memory.

For an air-gapped machine with model files already copied locally:

```powershell
$env:HF_MODEL="F:\models\your-instruction-model"
$env:HF_LOCAL_FILES_ONLY="true"
python app.py
```

### Recommended at factory scale: local OpenAI-compatible server

This mode lets the application use vLLM or another server that exposes the
standard `/v1/chat/completions` interface. The server can remain entirely inside
the factory network.

```powershell
$env:LLM_BACKEND="openai_compatible"
$env:OPENAI_COMPATIBLE_BASE_URL="http://127.0.0.1:8000/v1"
$env:OPENAI_COMPATIBLE_MODEL="your-served-model-name"
$env:OPENAI_COMPATIBLE_API_KEY="local"
python app.py
```

The value of `OPENAI_COMPATIBLE_MODEL` must match the name advertised by the
local inference server. The default API key is only a placeholder for a server
that does not enforce authentication.

### GGUF

```powershell
$env:LLM_BACKEND="llama_cpp"
$env:GGUF_MODEL_PATH="F:\models\your-model.gguf"
python app.py
```

## 5. Open and use the application

Start the app:

```powershell
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

Try a natural sequence rather than isolated prompts:

```text
User: Which machine had the most unplanned downtime?
User: Why did it stop?
User: Show the sensor evidence before that stop.
User: Explain the vibration values in plain language.
User: Give me a concise maintenance recommendation.
```

The recent conversation is sent with each request, so pronouns and short
follow-ups can refer to earlier answers. `New chat` clears that context.

## How the conversational flow works

Each message is routed to one of three paths:

1. **Conversation** — greetings, feature questions, definitions, and database or
   CNC guidance are answered without inventing a SQL query.
2. **Clarify** — the assistant asks one focused question when a missing part,
   date, quantity, or scope would materially change the answer.
3. **Data** — current factory questions generate one to four validated read-only
   queries. The assistant then explains only the returned evidence.

Complex questions can combine evidence. For example, “Which work orders are at
risk?” may check remaining quantity and due dates, machine downtime, quality
loss, material availability, and open maintenance work. Each query appears in
the answer's **Database evidence** drawer.

## `test_database.py` import troubleshooting

The current project does not contain `db.py`. The correct imports are:

```python
from db_manager import db_manager
from schema_manager import schema_manager
from sector_manager import sector_manager
```

Run the test from the project root:

```powershell
cd F:\Study\Research\Project\cnc_first_industry_ai_platform_v6
python test_database.py
```

If Python still reports `No module named 'db_manager'`, verify both conditions:

```powershell
Get-Location
Get-ChildItem app.py, db_manager.py, test_database.py
```

All three files must be visible in the current folder. Do not run a copied test
file from `tests`, `docs`, or a different project version.

## Safety boundaries

- Model-generated SQL accepts only `SELECT` or `WITH`.
- Write operations and dangerous SQLite commands are blocked.
- The database connection is opened in read-only mode for chat queries.
- Ordinary result sets are limited to 100 rows.
- Long-running generated queries are interrupted after 15 seconds by default.
- Report ingestion uses separate, controlled application code for its writes.
- Correlation is presented as evidence, not automatic proof of root cause.
- Machine control, CNC program deployment, and G-code execution are outside the
  automatic chat path and require an approved engineering workflow.

## Configuration reference

| Environment variable | Default | Purpose |
|---|---:|---|
| `LLM_BACKEND` | `transformers` | `transformers`, `llama_cpp`, or `openai_compatible` |
| `HF_MODEL` | `Qwen/Qwen2.5-Coder-1.5B-Instruct` | Hugging Face ID or local model folder |
| `HF_LOCAL_FILES_ONLY` | `false` | Prevent model downloads when `true` |
| `GGUF_MODEL_PATH` | Windows example path | Local GGUF file |
| `OPENAI_COMPATIBLE_BASE_URL` | `http://127.0.0.1:8000/v1` | Local inference API |
| `OPENAI_COMPATIBLE_MODEL` | `local-cnc-instruct` | Model name served by the API |
| `MAX_PLAN_QUERIES` | `4` | Maximum queries for one chat turn |
| `MAX_HISTORY_MESSAGES` | `12` | Recent messages used as context |
| `MAX_ROWS` | `100` | Rows returned per evidence query |
| `MAX_EVIDENCE_ROWS_FOR_ANSWER` | `40` | Rows per query included in the answer prompt |
| `SQL_TIMEOUT_SECONDS` | `15` | Maximum generated-query runtime |
| `HOST` | `127.0.0.1` | Flask bind address |
| `PORT` | `5000` | Flask port |

## Documentation

- `docs/CNC_First_Industry_AI_Platform_User_Manual.pdf` — print-ready manual
- `docs/CNC_First_Industry_AI_Platform_User_Manual.docx` — editable manual
- `docs/CONVERSATIONAL_CHAT_GUIDE.md` — chat behavior and example conversations
- `docs/QA_REPORT.md` — completed validation scope and remaining model-specific checks

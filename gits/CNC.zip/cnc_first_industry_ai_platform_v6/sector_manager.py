import json
import re
from pathlib import Path
from config import BASE_DIR, SETTINGS_DIR
from settings_manager import get_app_settings, update_app_settings

SECTOR_DIR = BASE_DIR / "sectors"
BUILTIN_FILE = SECTOR_DIR / "built_in_profiles.json"
CUSTOM_FILE = SECTOR_DIR / "custom_profiles.json"

def _read(path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default

def _write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def slugify(value):
    value = re.sub(r"[^A-Za-z0-9_-]+", "_", value.strip().lower())
    value = re.sub(r"_+", "_", value).strip("_")
    return value or "custom_sector"

class SectorManager:
    def all_profiles(self):
        result = _read(BUILTIN_FILE, {}).copy()
        result.update(_read(CUSTOM_FILE, {}))
        return result

    def active_sector_id(self):
        settings = get_app_settings()
        sector_id = settings.get("active_sector", "manufacturing")
        if sector_id not in self.all_profiles():
            sector_id = "generic"
            update_app_settings({"active_sector": sector_id})
        return sector_id

    def active_profile(self):
        profiles = self.all_profiles()
        sid = self.active_sector_id()
        return {"id": sid, **profiles[sid]}

    def set_active(self, sector_id):
        if sector_id not in self.all_profiles():
            raise KeyError("Sector profile not found.")
        update_app_settings({"active_sector": sector_id})
        return self.active_profile()

    def create_profile(self, data):
        name = str(data.get("name", "")).strip()
        if not name:
            raise ValueError("Sector name is required.")

        sid = slugify(data.get("id") or name)
        builtins = _read(BUILTIN_FILE, {})
        if sid in builtins:
            raise ValueError("That sector ID is reserved by a built-in profile.")

        custom = _read(CUSTOM_FILE, {})
        custom[sid] = {
            "name": name,
            "description": str(data.get("description", "")),
            "domain_context": str(data.get("domain_context", "")),
            "report_categories": [
                str(x).strip() for x in data.get("report_categories", [])
                if str(x).strip()
            ] or ["operations", "risk", "other"],
            "example_questions": [
                str(x).strip() for x in data.get("example_questions", [])
                if str(x).strip()
            ],
            "ui_overrides": data.get("ui_overrides", {})
        }
        _write(CUSTOM_FILE, custom)
        return {"id": sid, **custom[sid]}

    def update_profile(self, sector_id, data):
        builtins = _read(BUILTIN_FILE, {})
        custom = _read(CUSTOM_FILE, {})

        # Built-in profiles are copied into custom override on edit.
        base = self.all_profiles().get(sector_id)
        if not base:
            raise KeyError("Sector profile not found.")

        new_data = base.copy()
        for key in [
            "name","description","domain_context",
            "report_categories","example_questions","ui_overrides"
        ]:
            if key in data:
                new_data[key] = data[key]

        custom[sector_id] = new_data
        _write(CUSTOM_FILE, custom)
        return {"id": sector_id, **new_data}

    def delete_custom(self, sector_id):
        custom = _read(CUSTOM_FILE, {})
        if sector_id not in custom:
            raise ValueError("Only custom/overridden sector profiles can be deleted.")

        was_active = self.active_sector_id() == sector_id
        del custom[sector_id]
        _write(CUSTOM_FILE, custom)

        # If the deleted item was only an override of a built-in profile, keep
        # that built-in sector active. Otherwise fall back to Generic.
        if was_active:
            remaining = self.all_profiles()
            if sector_id in remaining:
                update_app_settings({"active_sector": sector_id})
            else:
                self.set_active("generic")
        return True

sector_manager = SectorManager()

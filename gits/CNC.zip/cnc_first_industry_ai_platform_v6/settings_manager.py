import json
from config import SETTINGS_DIR, DEFAULT_DB_FILENAME, DEFAULT_SECTOR

APP_SETTINGS_FILE = SETTINGS_DIR / "app_settings.json"
UI_CUSTOM_FILE = SETTINGS_DIR / "ui_text_custom.json"
DEFAULT_APP_SETTINGS = {
    "active_database": DEFAULT_DB_FILENAME,
    "language": "en",
    "active_sector": DEFAULT_SECTOR
}

def _read_json(path, default):
    if not path.exists(): return default.copy()
    try: return json.loads(path.read_text(encoding="utf-8"))
    except Exception: return default.copy()

def _write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def get_app_settings():
    data = _read_json(APP_SETTINGS_FILE, DEFAULT_APP_SETTINGS)
    merged = DEFAULT_APP_SETTINGS.copy(); merged.update(data); return merged

def update_app_settings(values):
    data = get_app_settings(); data.update(values); _write_json(APP_SETTINGS_FILE, data); return data

def get_custom_ui_text(): return _read_json(UI_CUSTOM_FILE, {})
def save_custom_ui_text(data): _write_json(UI_CUSTOM_FILE, data); return data

def reset_custom_ui_text():
    if UI_CUSTOM_FILE.exists(): UI_CUSTOM_FILE.unlink()

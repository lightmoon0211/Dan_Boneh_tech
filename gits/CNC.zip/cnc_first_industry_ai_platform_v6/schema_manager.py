import json, re, sqlite3
from pathlib import Path
from datetime import datetime
from config import SCHEMA_DIR
from db_manager import db_manager

TYPE_MAP={"integer":"INTEGER","int":"INTEGER","number":"REAL","real":"REAL","float":"REAL","decimal":"REAL","boolean":"INTEGER","bool":"INTEGER","date":"TEXT","datetime":"TEXT","timestamp":"TEXT","text":"TEXT","string":"TEXT","blob":"BLOB"}

def safe_identifier(v):
    v=re.sub(r"[^A-Za-z0-9_]+","_",str(v).strip());v=re.sub(r"_+","_",v).strip("_")
    if not v: raise ValueError("Identifier cannot be empty.")
    if v[0].isdigit():v="_"+v
    return v

class SchemaManager:
    def extract_structured_schema(self):
        conn=db_manager.connect(readonly=True);cur=conn.cursor()
        objects=cur.execute("SELECT name,type FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY type,name").fetchall()
        result={"database":db_manager.active_filename(),"objects":[]}
        for obj in objects:
            name=obj["name"];item={"name":name,"type":obj["type"],"columns":[],"foreign_keys":[]}
            for c in cur.execute(f'PRAGMA table_info("{name}")').fetchall():
                item["columns"].append({"name":c["name"],"type":c["type"],"not_null":bool(c["notnull"]),"default":c["dflt_value"],"primary_key":bool(c["pk"])})
            if obj["type"]=="table":
                for fk in cur.execute(f'PRAGMA foreign_key_list("{name}")').fetchall():
                    item["foreign_keys"].append({"column":fk["from"],"references_table":fk["table"],"references_column":fk["to"]})
            result["objects"].append(item)
        conn.close();return result

    def schema_text(self): return db_manager.schema()

    def save_schema_snapshot(self, sector_id):
        SCHEMA_DIR.mkdir(parents=True,exist_ok=True);data=self.extract_structured_schema();data["sector_id"]=sector_id;data["captured_at"]=datetime.now().isoformat(timespec="seconds")
        p=SCHEMA_DIR/f"{sector_id}_schema.json";p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8");return p

    def validate_definition(self, definition):
        tables=definition.get("tables",[])
        if not tables: raise ValueError("At least one table is required.")
        names=[]
        for t in tables:
            tn=safe_identifier(t.get("name",""));
            if tn in names: raise ValueError(f"Duplicate table name: {tn}")
            names.append(tn)
            cols=t.get("columns",[])
            if not cols: raise ValueError(f"Table {tn} needs at least one column.")
            cnames=[]
            primary_keys = 0
            for c in cols:
                cn=safe_identifier(c.get("name",""))
                if cn in cnames: raise ValueError(f"Duplicate column {cn} in {tn}")
                cnames.append(cn)

                requested_type = str(c.get("type", "text")).strip().lower()
                if requested_type not in TYPE_MAP:
                    raise ValueError(
                        f"Unsupported type '{c.get('type')}' for {tn}.{cn}. "
                        f"Use one of: {', '.join(sorted(TYPE_MAP))}."
                    )

                if c.get("primary_key"):
                    primary_keys += 1
                    if c.get("autoincrement") and TYPE_MAP[requested_type] != "INTEGER":
                        raise ValueError(
                            f"AUTOINCREMENT requires an INTEGER primary key: {tn}.{cn}"
                        )
                elif c.get("autoincrement"):
                    raise ValueError(
                        f"AUTOINCREMENT requires primary_key=true: {tn}.{cn}"
                    )

            if primary_keys > 1:
                raise ValueError(
                    f"Table {tn} defines more than one single-column primary key. "
                    "This visual builder currently supports one primary-key column per table."
                )
        # Validate foreign-key source/target names after all table names are known.
        table_columns={safe_identifier(t["name"]): {safe_identifier(c["name"]) for c in t.get("columns",[])} for t in tables}
        for t in tables:
            tn=safe_identifier(t["name"])
            for fk in t.get("foreign_keys",[]):
                src=safe_identifier(fk.get("column",""));rt=safe_identifier(fk.get("references_table",""));rc=safe_identifier(fk.get("references_column",""))
                if src not in table_columns[tn]: raise ValueError(f"Foreign key source column {tn}.{src} does not exist.")
                if rt not in table_columns: raise ValueError(f"Referenced table {rt} does not exist.")
                if rc not in table_columns[rt]: raise ValueError(f"Referenced column {rt}.{rc} does not exist.")
        return True

    def create_database_from_definition(self, filename, definition):
        self.validate_definition(definition)
        filename=Path(filename).name
        if Path(filename).suffix.lower() not in {".db",".sqlite",".sqlite3"}:filename += ".db"
        target=db_manager.active_path().parent/filename
        if target.exists(): raise FileExistsError("Database file already exists.")
        conn=sqlite3.connect(str(target));conn.execute("PRAGMA foreign_keys=ON")
        try:
            # Create tables in given order. FKs may point to later tables; SQLite permits this.
            for table in definition.get("tables",[]):
                tn=safe_identifier(table["name"]);defs=[]
                for c in table.get("columns",[]):
                    cn=safe_identifier(c["name"]);typ=TYPE_MAP[str(c.get("type","text")).lower()]
                    piece=f'"{cn}" {typ}'
                    if c.get("primary_key"):
                        piece += " PRIMARY KEY"
                        if typ=="INTEGER" and c.get("autoincrement"):piece += " AUTOINCREMENT"
                    if c.get("not_null"):piece += " NOT NULL"
                    if c.get("unique"):piece += " UNIQUE"
                    defs.append(piece)
                for fk in table.get("foreign_keys",[]):
                    defs.append(f'FOREIGN KEY ("{safe_identifier(fk["column"])}") REFERENCES "{safe_identifier(fk["references_table"])}"("{safe_identifier(fk["references_column"])}")')
                conn.execute(f'CREATE TABLE "{tn}" (\n  '+",\n  ".join(defs)+"\n)")
            conn.commit()
            check=conn.execute("PRAGMA foreign_key_check").fetchall()
            if check: raise ValueError(f"Foreign-key validation failed: {check[:5]}")
        except Exception:
            conn.close();target.unlink(missing_ok=True);raise
        conn.close();db_manager.set_active(target.name);return target.name

schema_manager=SchemaManager()

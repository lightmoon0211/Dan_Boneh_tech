# Conversational Chat Guide

## What changed in v6

The assistant no longer treats every message as a request for one SQL query.
It first decides whether the user needs a normal explanation, a clarifying
question, or verified database analysis. This makes short follow-ups and mixed
management questions feel like one continuous conversation.

## The three response paths

### 1. Guidance

Used for greetings, definitions, setup help, schema-design advice, and general
CNC questions.

```text
User: What does OEE mean?
Assistant: OEE combines availability, performance, and quality...
```

No current factory value is claimed because no database evidence was queried.

### 2. Clarification

Used only when a missing choice materially changes the calculation.

```text
User: Can we make enough by Friday?
Assistant: Which part number and required quantity should I use for the Friday capacity calculation?
```

The user can answer naturally:

```text
User: 500 units of SPINDLE-SHAFT-A.
```

### 3. Verified data

Used for current records, calculations, comparisons, and operational decisions.
One question can use several independent queries when necessary.

```text
User: Which work orders are at risk, and why?
```

Possible evidence groups:

- due dates, status, and remaining quantity
- actual cycle time versus standard cycle time
- machine downtime and open maintenance
- scrap, failed inspections, and quality holds
- material on hand minus reserved quantity

The answer presents the conclusion first. The SQL and returned records remain
available in the **Database evidence** drawer.

## Follow-up context

The browser sends the 12 most recent user and assistant messages. This allows
references such as:

- “Why did it stop?”
- “Compare it with the other 5-axis machine.”
- “What happened during the previous shift?”
- “Explain that percentage.”
- “Now give me the detailed version.”

The current answer-style selector controls length, but the user can also ask
for a shorter, more technical, more beginner-friendly, or more managerial
answer in ordinary language.

## Example conversations

### Downtime and condition evidence

```text
Which machine had the most unplanned downtime on September 1?
Why?
Show the alarms and vibration readings before its longest stop.
Does that prove a bearing failure?
What should maintenance inspect first?
```

The fourth answer should distinguish correlation from proof. High vibration,
bearing temperature, an alarm, and a later stop may justify inspection, but do
not alone prove the root cause.

### Capacity and schedule

```text
Can we produce 500 units of SPINDLE-SHAFT-A by Friday?
Include setup time, current work, and expected downtime.
Which work order should be moved first if capacity is short?
What material could block that recommendation?
Summarize the decision for the production manager.
```

### Quality and traceability

```text
Which inspection failures caused the most scrap?
Were they concentrated on one machine or CNC program revision?
Which material lots were used?
Show what is observed and what is only a possible explanation.
```

### Shift summary

```text
Summarize the latest completed shift.
Include production versus target, downtime, scrap, quality failures, and open maintenance risk.
Explain every KPI denominator.
Make the final answer concise enough for a shift-handover meeting.
```

## Answer styles

| Style | Intended behavior |
|---|---|
| Auto | Matches the detail level to the question |
| Concise | Direct answer and the few facts needed to support it |
| Balanced | Direct answer, key evidence, and practical interpretation |
| Detailed | Calculations, assumptions, caveats, evidence, and next checks |

## Model selection and realistic expectations

The application provides conversation memory, intent routing, evidence
orchestration, and a modern UI. The language model still determines how well it
understands ambiguous wording and generates SQL.

- A small 1.5B model is useful for a quick workflow test.
- A larger instruction-tuned model usually handles follow-ups, multi-table SQL,
  explanations, and multilingual answers more reliably.
- A local OpenAI-compatible server is the recommended connection for large
  models on multi-GPU factory infrastructure.
- Validate the selected model with a fixed benchmark set before production use.

Do not describe the application as ChatGPT 5.6. It provides a similar style of
interaction while using the local model selected by the factory.

## Useful validation questions

Start with questions whose answers are already known from SQL. Verify:

1. Does the assistant choose Guidance for “What does OEE mean?”
2. Does it choose Verified data for “What was OEE for CNC-5X01?”
3. Does “Why?” inherit the correct machine and time window?
4. Does a capacity question ask for the part and quantity when they are absent?
5. Does a detailed answer explain all numbers and units?
6. Do all displayed SQL statements remain read-only?
7. Does an empty result produce an honest “no matching records” answer?
8. Does a causal answer distinguish observed evidence from inference?

## Browser behavior

- `Enter` sends the message.
- `Shift+Enter` creates a new line.
- The square button stops waiting for the current response in the browser.
- `Copy` copies the assistant's visible answer.
- Follow-up chips place a suggested question in the composer for editing.
- The current conversation is restored after a page reload on the same browser.
- `New chat`, database changes, and sector changes clear the previous context.

Stopping a response cancels the browser request. Some local model servers may
continue the already-started generation internally until their own cancellation
or timeout behavior takes effect.

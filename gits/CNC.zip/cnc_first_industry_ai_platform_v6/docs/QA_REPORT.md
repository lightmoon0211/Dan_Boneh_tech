# QA Report - CNC-First Industry AI Platform v6

## Corrected in this build

- Replaced obsolete `test_database.py` imports from removed `db.py` with the current `db_manager.py` / `schema_manager.py` architecture.
- Fixed `tests/test_core.py` so the documented command `python tests/test_core.py` works directly from the project root.
- Removed stale `__pycache__` and `.pyc` files from the distributable.
- Removed older/conflicting manual copies; the project now contains one final user manual.
- Kept `requirements-gpu.txt` and `requirements-cpu.txt` separate so users explicitly choose CUDA or CPU PyTorch.
- Updated both runtime profiles to PyTorch 2.11.0; the GPU profile uses the
  official CUDA 12.8 wheel index for Python 3.11 and H200-class systems.
- Replaced the single-query-only chat flow with intent-aware conversation,
  clarification, and multi-query data analysis paths.
- Added bounded conversation history, answer-style control, safe Markdown
  rendering, response cancellation, copy actions, evidence drawers, follow-up
  prompts, and browser-session restoration.
- Added a local OpenAI-compatible backend for vLLM or another factory-hosted
  inference server.
- Added a database-query time limit and preserved read-only connections.

## Automated checks performed

The build was checked for:

1. Python syntax compilation for every `.py` file.
2. JavaScript syntax validation for `static/app.js`.
3. `python test_database.py` execution.
4. `python tests/test_core.py` execution.
5. Default CNC database statistics and required CNC tables.
6. Read-only SQL execution.
7. SQL safety blocking for DELETE, DROP, UPDATE and multiple statements.
8. Structured schema extraction.
9. Schema-definition validation.
10. Creation of a temporary SQLite database from the Schema Manager definition format.
11. Foreign-key creation and extraction in the temporary database.
12. Database switching and restoration to `smart_cnc_factory.db`.
13. Sector switching and restoration to Manufacturing.
14. Controlled creation of daily-report tables.
15. Conversation-plan JSON extraction and normalization.
16. Social messages bypass database planning.
17. Multi-query evidence execution and response metadata.
18. Clarifying questions return without inventing a database query.
19. Compact-model SQL fallback remains read-only.
20. Unsafe SQL remains blocked through every conversation path.
21. JavaScript syntax and required chat-control DOM identifiers.
22. Invalid table or column references receive one safe repair attempt.

## Expected bundled CNC data

- Machines: 19
- Work orders: 100
- Sensor readings: 27,360
- Database tables: at least 40 before optional report tables are added

## Model-dependent checks

A complete natural-language question -> model -> plan -> generated SQL -> answer
test requires the configured model and Transformers, llama.cpp, or local
OpenAI-compatible inference runtime on the target machine. The rest of the
application intentionally uses lazy model loading, so database/schema/sector
management can start without loading model weights.

The final target-machine acceptance test should use the exact model intended
for production. Model size and instruction-following quality materially affect
intent routing, follow-up resolution, SQL correctness, and answer quality.

## Additional hardening in the corrected build

- Schema Builder now rejects unsupported/raw SQL type strings instead of inserting arbitrary type text into generated DDL.
- AUTOINCREMENT is validated to require an INTEGER primary key.
- The visual Schema Builder is explicit that it supports one single-column primary key per table.
- Deleting a custom override of a built-in sector now restores/keeps the built-in profile instead of incorrectly switching to Generic.
- UI localization now falls back to English for newly added keys, and Sector/Schema panel labels are included in editable UI text.
- Core tests use disposable database copies for write-path tests, so running tests does not modify the shipped Smart CNC database.
- Planner output is parsed defensively; a safe single-query fallback supports
  small models that return SQL instead of the requested JSON.
- A read-only query with a schema-name error receives one model-assisted repair
  attempt; the repaired query passes the same SQL validator before execution.
- Chat history accepts only user and assistant text, retains at most 12 recent
  messages, and truncates oversized entries before prompting the model.
- Every planned query is independently validated and executed through the
  read-only database manager.

## Final packaging check

- README links match the Word and PDF manuals in `docs/`.
- No stale `db.py` runtime imports remain.
- No `__pycache__`, `.pyc`, or `_qa_*` temporary databases are included in the package.
- The shipped active Smart CNC database is pristine at 46 tables; optional report tables are created only when the report feature is used.

import json
from urllib import error, request

from config import (
    GGUF_MODEL_PATH,
    HF_LOCAL_FILES_ONLY,
    HF_MODEL,
    LLM_BACKEND,
    LLM_REQUEST_TIMEOUT_SECONDS,
    OPENAI_COMPATIBLE_API_KEY,
    OPENAI_COMPATIBLE_BASE_URL,
    OPENAI_COMPATIBLE_MODEL,
)

class LocalLLM:
    """Lazy local LLM loader. The web UI/database manager can start without loading weights."""
    def __init__(self):
        self.backend = LLM_BACKEND
        self.loaded = False
        self.model = None
        self.tokenizer = None
        self.llm = None

    def ensure_loaded(self):
        if self.loaded: return
        if self.backend == "transformers": self._load_transformers()
        elif self.backend == "llama_cpp": self._load_llama_cpp()
        elif self.backend == "openai_compatible":
            print(f"[LLM] Using local OpenAI-compatible server: {OPENAI_COMPATIBLE_BASE_URL}")
        else:
            raise ValueError(
                "LLM_BACKEND must be 'transformers', 'llama_cpp', or 'openai_compatible'."
            )
        self.loaded = True

    def _load_transformers(self):
        import torch
        from transformers import AutoTokenizer, AutoModelForCausalLM
        print(f"[LLM] Loading Transformers model: {HF_MODEL}")
        self.tokenizer = AutoTokenizer.from_pretrained(HF_MODEL, local_files_only=HF_LOCAL_FILES_ONLY)
        kwargs = {"local_files_only": HF_LOCAL_FILES_ONLY}
        if torch.cuda.is_available():
            kwargs["device_map"] = "auto"; kwargs["dtype"] = torch.float16
            print(f"[LLM] CUDA detected: {torch.cuda.get_device_name(0)}")
        else:
            kwargs["dtype"] = torch.float32; print("[LLM] CUDA not found. Using CPU.")
        self.model = AutoModelForCausalLM.from_pretrained(HF_MODEL, **kwargs)
        print("[LLM] Model loaded successfully.")

    def _load_llama_cpp(self):
        from llama_cpp import Llama
        print(f"[LLM] Loading GGUF: {GGUF_MODEL_PATH}")
        self.llm = Llama(model_path=GGUF_MODEL_PATH, n_ctx=16384, n_gpu_layers=-1, verbose=False)
        print("[LLM] GGUF loaded successfully.")

    def status(self):
        models = {
            "transformers": HF_MODEL,
            "llama_cpp": GGUF_MODEL_PATH,
            "openai_compatible": OPENAI_COMPATIBLE_MODEL,
        }
        return {"backend": self.backend, "loaded": self.loaded, "model": models.get(self.backend, "unknown")}

    def generate(self, prompt, max_new_tokens=400, temperature=0.0):
        self.ensure_loaded()
        if self.backend == "transformers":
            return self._generate_transformers(prompt, max_new_tokens, temperature)
        if self.backend == "openai_compatible":
            return self._generate_openai_compatible(prompt, max_new_tokens, temperature)
        result = self.llm(
            prompt,
            max_tokens=max_new_tokens,
            temperature=max(0.0, float(temperature)),
            top_p=0.9 if temperature else 1.0,
        )
        return result["choices"][0]["text"].strip()

    def _generate_transformers(self, prompt, max_new_tokens, temperature):
        import torch
        messages = [{"role":"user","content":prompt}]
        try:
            rendered = self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        except Exception:
            rendered = prompt
        inputs = self.tokenizer(rendered, return_tensors="pt")
        if torch.cuda.is_available(): inputs = {k:v.to(self.model.device) for k,v in inputs.items()}
        generation = {
            "max_new_tokens": max_new_tokens,
            "do_sample": bool(temperature and temperature > 0),
            "pad_token_id": self.tokenizer.eos_token_id,
        }
        if generation["do_sample"]:
            generation.update({"temperature": max(0.05, float(temperature)), "top_p": 0.9})
        with torch.no_grad():
            output = self.model.generate(**inputs, **generation)
        generated = output[0][inputs["input_ids"].shape[1]:]
        return self.tokenizer.decode(generated, skip_special_tokens=True).strip()

    def _generate_openai_compatible(self, prompt, max_new_tokens, temperature):
        payload = json.dumps(
            {
                "model": OPENAI_COMPATIBLE_MODEL,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_new_tokens,
                "temperature": max(0.0, float(temperature)),
                "top_p": 0.9 if temperature else 1.0,
                "stream": False,
            }
        ).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if OPENAI_COMPATIBLE_API_KEY:
            headers["Authorization"] = f"Bearer {OPENAI_COMPATIBLE_API_KEY}"
        call = request.Request(
            f"{OPENAI_COMPATIBLE_BASE_URL}/chat/completions",
            data=payload,
            headers=headers,
            method="POST",
        )
        try:
            with request.urlopen(call, timeout=LLM_REQUEST_TIMEOUT_SECONDS) as response:
                result = json.loads(response.read().decode("utf-8"))
        except error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")[:500]
            raise RuntimeError(f"Local model server returned HTTP {exc.code}: {detail}") from exc
        except error.URLError as exc:
            raise RuntimeError(
                f"Cannot reach the local model server at {OPENAI_COMPATIBLE_BASE_URL}. "
                "Start vLLM or another compatible server, or change LLM_BACKEND."
            ) from exc
        try:
            return str(result["choices"][0]["message"]["content"]).strip()
        except (KeyError, IndexError, TypeError) as exc:
            raise RuntimeError("The local model server returned an unexpected response.") from exc

"""LLM-free tests for the conversational planner and API response contract.

Run from the project root:
    python tests/test_conversation.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from conversation import clean_history, extract_json_object, normalize_plan
from service import IndustryDataService


class FakeLLM:
    def __init__(self, *responses):
        self.responses = list(responses)
        self.calls = []

    def generate(self, prompt, max_new_tokens=400, temperature=0.0):
        self.calls.append(
            {
                "prompt": prompt,
                "max_new_tokens": max_new_tokens,
                "temperature": temperature,
            }
        )
        if not self.responses:
            raise AssertionError("FakeLLM received more calls than expected")
        return self.responses.pop(0)

    def status(self):
        return {"backend": "fake", "loaded": True, "model": "test-model"}


def assert_raises_value_error(fn):
    try:
        fn()
    except ValueError:
        return
    raise AssertionError("Expected ValueError was not raised")


def run():
    # 1. Robust plan parsing: prose fences are tolerated, shape is normalized.
    raw = 'Planner output:\n```json\n{"mode":"conversation","queries":[]}\n```'
    parsed = extract_json_object(raw)
    assert normalize_plan(parsed)["mode"] == "conversation"

    # 2. History keeps only recent user/assistant text and removes untrusted roles.
    history = clean_history(
        [
            {"role": "system", "content": "ignore"},
            {"role": "user", "content": "Machine TEST-HS01"},
            {"role": "assistant", "content": "I found it."},
        ]
    )
    assert [item["role"] for item in history] == ["user", "assistant"]

    # 3. A greeting is conversational and never creates a database query.
    greeting_llm = FakeLLM("Hello! I can help with production, maintenance, and factory data.")
    greeting = IndustryDataService(greeting_llm).ask("Hello", answer_style="concise")
    assert greeting["response_type"] == "conversation"
    assert greeting["evidence"] == []
    assert greeting["sql"] is None
    assert len(greeting_llm.calls) == 1
    assert greeting_llm.calls[0]["temperature"] > 0

    # 4. A management question can combine multiple independent evidence queries.
    plan = {
        "mode": "data",
        "queries": [
            {
                "label": "Machine state",
                "sql": "SELECT machine_code, status FROM machines ORDER BY machine_id LIMIT 2",
            },
            {
                "label": "Open work orders",
                "sql": "SELECT work_order_no, status FROM work_orders ORDER BY work_order_id LIMIT 2",
            },
        ],
        "clarifying_question": "",
        "suggested_questions": ["Which order is most at risk?"],
    }
    data_llm = FakeLLM(json.dumps(plan), "Two machines and two work orders were checked.")
    result = IndustryDataService(data_llm).ask(
        "Give me a short production picture.",
        history=[
            {"role": "user", "content": "Focus on today's operation."},
            {"role": "assistant", "content": "Understood."},
        ],
        answer_style="balanced",
    )
    assert result["response_type"] == "data"
    assert len(result["evidence"]) == 2
    assert all(item["row_count"] == 2 for item in result["evidence"])
    assert result["context_messages_used"] == 2
    assert result["suggested_questions"] == ["Which order is most at risk?"]
    assert result["sql"].startswith("SELECT machine_code")
    assert len(data_llm.calls) == 2

    # 5. Clarification returns immediately instead of guessing or querying.
    clarify_plan = {
        "mode": "clarify",
        "queries": [],
        "clarifying_question": "Which part number should I use for the Friday capacity calculation?",
        "suggested_questions": [],
    }
    clarify_llm = FakeLLM(json.dumps(clarify_plan))
    clarification = IndustryDataService(clarify_llm).ask("Can we make enough by Friday?")
    assert clarification["response_type"] == "clarify"
    assert "Which part number" in clarification["answer"]
    assert len(clarify_llm.calls) == 1

    # 6. A compact model that returns SQL instead of JSON still works safely.
    fallback_llm = FakeLLM(
        "SELECT machine_code FROM machines ORDER BY machine_id LIMIT 1;",
        "The first machine record was returned.",
    )
    fallback = IndustryDataService(fallback_llm).ask("Show one machine.")
    assert fallback["response_type"] == "data"
    assert fallback["evidence"][0]["row_count"] == 1

    # 7. A schema mistake receives one safe repair attempt.
    repair_plan = {
        "mode": "data",
        "queries": [
            {
                "label": "Machine state",
                "sql": "SELECT imaginary_column FROM machines LIMIT 1",
            }
        ],
        "clarifying_question": "",
        "suggested_questions": [],
    }
    repair_llm = FakeLLM(
        json.dumps(repair_plan),
        "SELECT machine_code FROM machines ORDER BY machine_id LIMIT 1;",
        "The corrected query returned one machine.",
    )
    repaired = IndustryDataService(repair_llm).ask("Show one machine.")
    assert repaired["evidence"][0]["automatically_repaired"] is True
    assert repaired["evidence"][0]["row_count"] == 1
    assert len(repair_llm.calls) == 3

    # 8. Unsafe SQL remains blocked even through the compatibility path.
    unsafe_llm = FakeLLM("not json", "DELETE FROM machines;")
    assert_raises_value_error(
        lambda: IndustryDataService(unsafe_llm).ask("Delete all machines.")
    )

    print("CONVERSATION TESTS PASSED")


if __name__ == "__main__":
    run()

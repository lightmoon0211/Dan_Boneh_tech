"""Static UI contract checks that require no Flask server or model."""
from __future__ import annotations

from collections import Counter
from html.parser import HTMLParser
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


class IdCollector(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if "id" in values:
            self.ids.append(values["id"])


def run():
    html = (PROJECT_ROOT / "templates" / "index.html").read_text(encoding="utf-8")
    javascript = (PROJECT_ROOT / "static" / "app.js").read_text(encoding="utf-8")
    css = (PROJECT_ROOT / "static" / "style.css").read_text(encoding="utf-8")

    parser = IdCollector()
    parser.feed(html)
    counts = Counter(parser.ids)
    duplicates = sorted(name for name, count in counts.items() if count > 1)
    assert not duplicates, f"Duplicate HTML ids: {duplicates}"

    required_ids = {
        "chat",
        "messages",
        "question",
        "sendButton",
        "stopButton",
        "answerStyle",
        "modelStatus",
        "welcome",
    }
    missing = sorted(required_ids - set(parser.ids))
    assert not missing, f"Missing conversational UI controls: {missing}"

    for required_code in [
        "renderMarkdown",
        "renderEvidence",
        "stopResponse",
        "restoreConversation",
        "answer_style:currentAnswerStyle()",
        "suggested_questions",
    ]:
        assert required_code in javascript, required_code

    for required_style in [
        ".markdown-body",
        ".evidence-group",
        ".suggestion-chip",
        ".stop-button",
        ".style-control",
    ]:
        assert required_style in css, required_style

    print("FRONTEND CONTRACT TESTS PASSED")


if __name__ == "__main__":
    run()

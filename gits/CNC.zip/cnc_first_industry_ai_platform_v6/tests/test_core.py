"""Core smoke tests that do not load an LLM.

Run from the project root:
    python tests/test_core.py
"""
from __future__ import annotations

import json
import shutil
import sys
import tempfile
from pathlib import Path

# Make project-root modules importable when this file is executed directly.
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from db_manager import db_manager
from schema_manager import schema_manager
from sector_manager import sector_manager
from settings_manager import get_app_settings, update_app_settings
from sql_guard import extract_sql, validate_sql


def assert_raises_value_error(fn):
    try:
        fn()
    except ValueError:
        return
    raise AssertionError("Expected ValueError was not raised")


def run():
    original_settings = get_app_settings().copy()
    created_db = None

    try:
        # 1. CNC-first default state.
        assert sector_manager.active_sector_id() == "manufacturing"
        assert db_manager.active_filename() == "smart_cnc_factory.db"

        stats = db_manager.stats()
        assert stats["tables"] >= 40, stats
        assert stats["machines"] == 19, stats
        assert stats["work_orders"] == 100, stats
        assert stats["sensor_readings"] == 27360, stats

        # 2. Schema extraction and expected CNC objects.
        schema = schema_manager.extract_structured_schema()
        names = {x["name"] for x in schema["objects"]}
        for required in [
            "machines",
            "work_orders",
            "production_runs",
            "sensor_readings",
            "cnc_programs",
        ]:
            assert required in names, required

        # 3. SQL guard accepts a single read query.
        safe_sql = extract_sql(
            "```sql\nSELECT machine_code FROM machines ORDER BY machine_id LIMIT 2;\n```"
        )
        assert validate_sql(safe_sql).startswith("SELECT")

        # 4. SQL guard rejects writes and multi-statement output.
        for bad in [
            "DELETE FROM machines;",
            "DROP TABLE machines;",
            "UPDATE machines SET status='DOWN';",
        ]:
            assert_raises_value_error(lambda bad=bad: extract_sql(bad))

        assert_raises_value_error(
            lambda: validate_sql("SELECT * FROM machines; DELETE FROM machines;")
        )

        # 5. Read-only DB query.
        rows = db_manager.execute_readonly(
            "SELECT machine_code FROM machines ORDER BY machine_id LIMIT 2;"
        )
        assert len(rows) == 2

        # 6. Validate schema-builder rules and create a temporary DB with an FK.
        definition = {
            "tables": [
                {
                    "name": "assets",
                    "columns": [
                        {
                            "name": "asset_id",
                            "type": "integer",
                            "primary_key": True,
                            "autoincrement": True,
                        },
                        {"name": "asset_code", "type": "text", "not_null": True},
                    ],
                    "foreign_keys": [],
                },
                {
                    "name": "events",
                    "columns": [
                        {
                            "name": "event_id",
                            "type": "integer",
                            "primary_key": True,
                            "autoincrement": True,
                        },
                        {"name": "asset_id", "type": "integer"},
                        {"name": "occurred_at", "type": "datetime"},
                    ],
                    "foreign_keys": [
                        {
                            "column": "asset_id",
                            "references_table": "assets",
                            "references_column": "asset_id",
                        }
                    ],
                },
            ]
        }
        schema_manager.validate_definition(definition)

        created_db = "_qa_schema_test.db"
        target = db_manager.active_path().parent / created_db
        target.unlink(missing_ok=True)
        schema_manager.create_database_from_definition(created_db, definition)

        created_schema = schema_manager.extract_structured_schema()
        created_names = {x["name"] for x in created_schema["objects"]}
        assert {"assets", "events"}.issubset(created_names)

        events = next(x for x in created_schema["objects"] if x["name"] == "events")
        assert events["foreign_keys"], events
        assert events["foreign_keys"][0]["references_table"] == "assets"

        # 7. Restore CNC DB and ensure switching works.
        db_manager.set_active("smart_cnc_factory.db")
        assert db_manager.active_filename() == "smart_cnc_factory.db"

        # 8. Sector switching works and CNC can be restored.
        sector_manager.set_active("generic")
        assert sector_manager.active_sector_id() == "generic"
        sector_manager.set_active("manufacturing")
        assert sector_manager.active_sector_id() == "manufacturing"

        # 9. Report tables can be created by controlled application code.
        # Use a disposable copy so the shipped CNC database remains pristine.
        report_test_db = "_qa_report_test.db"
        report_target = PROJECT_ROOT / "databases" / report_test_db
        report_target.unlink(missing_ok=True)
        shutil.copy2(PROJECT_ROOT / "smart_cnc_factory.db", report_target)
        db_manager.set_active(report_test_db)
        db_manager.ensure_report_tables()
        post_report_stats = db_manager.stats()
        assert post_report_stats["daily_reports"] == 0
        report_target.unlink(missing_ok=True)
        db_manager.set_active("smart_cnc_factory.db")

        print("CORE TESTS PASSED")

    finally:
        # Restore shipped defaults and remove temporary QA DB.
        update_app_settings(original_settings)
        if created_db:
            (PROJECT_ROOT / "databases" / created_db).unlink(missing_ok=True)
        (PROJECT_ROOT / "databases" / "_qa_report_test.db").unlink(missing_ok=True)


if __name__ == "__main__":
    run()

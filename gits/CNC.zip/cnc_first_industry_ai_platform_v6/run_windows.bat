@echo off
setlocal
cd /d "%~dp0"
echo.
echo Starting CNC-First Industry AI Platform v6...
echo.
python -c "import flask" >nul 2>&1
if errorlevel 1 (
  echo Flask is not installed in the active Python environment.
  echo Activate smartfactoryllm and install one requirements file first.
  echo Example: pip install -r requirements-gpu.txt
  echo.
  pause
  exit /b 1
)
python app.py
pause
endlocal

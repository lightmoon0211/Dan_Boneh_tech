from datetime import date
from flask import Flask, jsonify, render_template, request

from config import APP_VERSION, HOST, PORT, SUPPORTED_LANGUAGES
from db_manager import db_manager
from i18n import get_ui_text, get_all_ui_text, update_ui_text, reset_ui_text
from report_manager import ReportManager
from schema_manager import schema_manager
from sector_manager import sector_manager
from service import IndustryDataService
from settings_manager import get_app_settings, update_app_settings

app = Flask(__name__)

print(f"[APP] Starting CNC-First Industry AI Platform v{APP_VERSION}...")
service = IndustryDataService()
reports = ReportManager(service.llm)

@app.route("/")
def home():
    settings = get_app_settings()
    return render_template(
        "index.html",
        languages=SUPPORTED_LANGUAGES,
        initial_language=settings.get("language","en"),
        today=date.today().isoformat()
    )

@app.get("/api/status")
def status():
    service.refresh()
    return jsonify({
        "version": APP_VERSION,
        "active_database": db_manager.active_filename(),
        "stats": service.stats,
        "sector": service.sector,
        "settings": get_app_settings(),
        "languages": SUPPORTED_LANGUAGES,
        "llm": service.llm.status()
    })

@app.post("/api/ask")
def ask():
    data = request.get_json(silent=True) or {}
    question = str(data.get("question","")).strip()
    if not question:
        return jsonify({"error":"Please enter a question."}),400
    try:
        return jsonify(service.ask(
            question,
            data.get("language","en"),
            data.get("history",[]),
            data.get("answer_style","auto")
        ))
    except ValueError as exc:
        return jsonify({"error":"SQL safety validation failed.","details":str(exc)}),400
    except Exception as exc:
        return jsonify({"error":type(exc).__name__,"details":str(exc)}),500

# language/ui
@app.get("/api/ui-text")
def ui_text():
    return jsonify(get_ui_text(request.args.get("lang","en")))

@app.post("/api/ui-text/<language>")
def ui_text_save(language):
    try:
        return jsonify(update_ui_text(language, request.get_json(silent=True) or {}))
    except Exception as exc:
        return jsonify({"error":str(exc)}),400

@app.post("/api/ui-text/reset")
def ui_text_reset():
    reset_ui_text()
    return jsonify({"ok":True})

@app.post("/api/language")
def save_language():
    data=request.get_json(silent=True) or {}
    language=data.get("language","en")
    if language not in SUPPORTED_LANGUAGES:
        return jsonify({"error":"Unsupported language."}),400
    update_app_settings({"language":language})
    return jsonify({"ok":True})

# database
@app.get("/api/databases")
def databases():
    return jsonify({
        "active_database":db_manager.active_filename(),
        "databases":db_manager.list_databases()
    })

@app.post("/api/database/upload")
def database_upload():
    if "file" not in request.files:
        return jsonify({"error":"No database file uploaded."}),400
    try:
        filename=db_manager.save_upload(request.files["file"])
        service.refresh()
        schema_manager.save_schema_snapshot(sector_manager.active_sector_id())
        return jsonify({"ok":True,"active_database":filename,"stats":service.stats})
    except Exception as exc:
        return jsonify({"error":str(exc)}),400

@app.post("/api/database/select")
def database_select():
    data=request.get_json(silent=True) or {}
    try:
        filename=db_manager.set_active(data.get("filename",""))
        service.refresh()
        schema_manager.save_schema_snapshot(sector_manager.active_sector_id())
        return jsonify({"ok":True,"active_database":filename,"stats":service.stats})
    except Exception as exc:
        return jsonify({"error":str(exc)}),400

# sectors
@app.get("/api/sectors")
def sectors():
    return jsonify({
        "active_sector": sector_manager.active_sector_id(),
        "profiles": sector_manager.all_profiles()
    })

@app.post("/api/sectors/select")
def sector_select():
    data=request.get_json(silent=True) or {}
    try:
        profile=sector_manager.set_active(data.get("sector_id",""))
        service.refresh()
        schema_manager.save_schema_snapshot(profile["id"])
        return jsonify(profile)
    except Exception as exc:
        return jsonify({"error":str(exc)}),400

@app.post("/api/sectors")
def sector_create():
    try:
        profile=sector_manager.create_profile(request.get_json(silent=True) or {})
        sector_manager.set_active(profile["id"])
        service.refresh()
        schema_manager.save_schema_snapshot(profile["id"])
        return jsonify(profile)
    except Exception as exc:
        return jsonify({"error":str(exc)}),400

@app.put("/api/sectors/<sector_id>")
def sector_update(sector_id):
    try:
        profile=sector_manager.update_profile(sector_id, request.get_json(silent=True) or {})
        service.refresh()
        return jsonify(profile)
    except Exception as exc:
        return jsonify({"error":str(exc)}),400

@app.delete("/api/sectors/<sector_id>")
def sector_delete(sector_id):
    try:
        sector_manager.delete_custom(sector_id)
        service.refresh()
        return jsonify({"ok":True})
    except Exception as exc:
        return jsonify({"error":str(exc)}),400

# schema
@app.get("/api/schema")
def schema_get():
    return jsonify(schema_manager.extract_structured_schema())

@app.post("/api/schema/snapshot")
def schema_snapshot():
    try:
        p=schema_manager.save_schema_snapshot(sector_manager.active_sector_id())
        return jsonify({"ok":True,"path":p.name})
    except Exception as exc:
        return jsonify({"error":str(exc)}),400

@app.post("/api/schema/create-database")
def schema_create_database():
    data=request.get_json(silent=True) or {}
    try:
        filename=schema_manager.create_database_from_definition(
            data.get("filename","new_sector.db"),
            data.get("definition",{})
        )
        service.refresh()
        schema_manager.save_schema_snapshot(sector_manager.active_sector_id())
        return jsonify({"ok":True,"active_database":filename,"stats":service.stats})
    except Exception as exc:
        return jsonify({"error":type(exc).__name__,"details":str(exc)}),400

# reports
@app.get("/api/reports")
def report_list():
    try:return jsonify(reports.list_reports())
    except Exception as exc:return jsonify({"error":str(exc)}),500

@app.post("/api/reports/upload")
def report_upload():
    if "file" not in request.files:
        return jsonify({"error":"No report file uploaded."}),400
    try:
        item=reports.process_upload(
            request.files["file"],
            request.form.get("report_date") or date.today().isoformat(),
            request.form.get("source_language","auto"),
            request.form.get("summary_language","en")
        )
        service.refresh()
        return jsonify(item)
    except Exception as exc:
        return jsonify({"error":type(exc).__name__,"details":str(exc)}),400

@app.delete("/api/reports/<int:report_id>")
def report_delete(report_id):
    try:return jsonify({"deleted":reports.delete_report(report_id)})
    except Exception as exc:return jsonify({"error":str(exc)}),400

@app.post("/api/reports/<int:report_id>/reanalyze")
def report_reanalyze(report_id):
    data=request.get_json(silent=True) or {}
    try:return jsonify(reports.reanalyze_report(report_id,data.get("language","en")))
    except Exception as exc:return jsonify({"error":type(exc).__name__,"details":str(exc)}),400

if __name__=="__main__":
    print(f"[APP] Open http://{HOST}:{PORT}")
    app.run(host=HOST,port=PORT,debug=False)

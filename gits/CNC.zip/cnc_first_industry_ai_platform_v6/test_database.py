"""Quick database smoke test for the CNC-First Industry AI Platform.

Run from the project root:
    python test_database.py

This test does NOT load the LLM.
"""
from db_manager import db_manager
from schema_manager import schema_manager
from sector_manager import sector_manager


def main():
    print("=== ACTIVE SECTOR ===")
    print(sector_manager.active_profile()["name"])

    print("\n=== ACTIVE DATABASE ===")
    print(db_manager.active_filename())

    print("\n=== DATABASE STATS ===")
    stats = db_manager.stats()
    for key, value in stats.items():
        print(f"{key}: {value}")

    print("\n=== CORE CNC TABLE CHECK ===")
    schema = schema_manager.extract_structured_schema()
    names = {obj["name"] for obj in schema["objects"]}
    required = {
        "machines",
        "work_orders",
        "production_runs",
        "downtime_events",
        "maintenance_work_orders",
        "quality_inspections",
        "sensor_readings",
        "cnc_programs",
    }
    missing = sorted(required - names)
    if missing:
        raise RuntimeError(f"Missing expected CNC tables: {', '.join(missing)}")
    print("Core CNC tables: OK")

    print("\n=== SAMPLE MACHINES ===")
    rows = db_manager.execute_readonly("""
        SELECT
            machine_code,
            machine_name,
            manufacturer,
            model,
            status
        FROM machines
        ORDER BY machine_id
        LIMIT 10;
    """)
    for row in rows:
        print(row)

    print("\nDatabase test completed successfully.")


if __name__ == "__main__":
    main()

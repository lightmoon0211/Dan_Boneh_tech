"""Conversation planning and validation helpers.

This module deliberately contains no model or Flask dependencies so the
conversation behavior can be tested without loading model weights.
"""
from __future__ import annotations

import json
import re
from typing import Any


ANSWER_STYLES = {"auto", "concise", "balanced", "detailed"}
PLAN_MODES = {"conversation", "data", "clarify"}


def normalize_answer_style(value: object) -> str:
    style = str(value or "auto").strip().lower()
    return style if style in ANSWER_STYLES else "auto"


def clean_history(history: object, limit: int = 12, max_chars: int = 2400) -> list[dict[str, str]]:
    """Keep only recent user/assistant text and cap untrusted payload size."""
    if not isinstance(history, list):
        return []
    cleaned: list[dict[str, str]] = []
    for item in history[-limit:]:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role", "")).strip().lower()
        if role not in {"user", "assistant"}:
            continue
        content = str(item.get("content", "")).strip()
        if content:
            cleaned.append({"role": role, "content": content[:max_chars]})
    return cleaned


def history_as_text(history: list[dict[str, str]]) -> str:
    if not history:
        return "No earlier messages in this chat."
    return "\n\n".join(
        f"{item['role'].upper()}: {item['content']}" for item in history
    )


def extract_json_object(text: object) -> dict[str, Any]:
    """Extract one JSON object even when a small model adds prose or a fence."""
    raw = str(text or "").strip()
    if not raw:
        raise ValueError("The model returned an empty plan.")
    fenced = re.search(r"```(?:json)?\s*(.*?)```", raw, re.I | re.S)
    if fenced:
        raw = fenced.group(1).strip()
    try:
        value = json.loads(raw)
    except json.JSONDecodeError:
        start, end = raw.find("{"), raw.rfind("}")
        if start < 0 or end <= start:
            raise ValueError("The model did not return a JSON plan.")
        value = json.loads(raw[start : end + 1])
    if not isinstance(value, dict):
        raise ValueError("The conversation plan must be a JSON object.")
    return value


def normalize_plan(payload: dict[str, Any], max_queries: int = 4) -> dict[str, Any]:
    mode = str(payload.get("mode", "")).strip().lower()
    if mode not in PLAN_MODES:
        raise ValueError("The conversation plan has an unsupported mode.")

    queries: list[dict[str, str]] = []
    raw_queries = payload.get("queries", [])
    if isinstance(raw_queries, list):
        for index, item in enumerate(raw_queries[:max_queries], 1):
            if not isinstance(item, dict):
                continue
            sql = str(item.get("sql", "")).strip()
            if not sql:
                continue
            label = str(item.get("label", "")).strip() or f"Evidence {index}"
            queries.append({"label": label[:100], "sql": sql})

    clarification = str(payload.get("clarifying_question", "")).strip()
    suggestions = payload.get("suggested_questions", [])
    if not isinstance(suggestions, list):
        suggestions = []
    suggestions = [str(x).strip()[:180] for x in suggestions if str(x).strip()][:3]

    if mode == "data" and not queries:
        raise ValueError("A data plan must contain at least one SQL query.")
    if mode == "clarify" and not clarification:
        raise ValueError("A clarification plan must contain a question.")

    return {
        "mode": mode,
        "queries": queries,
        "clarifying_question": clarification,
        "suggested_questions": suggestions,
    }


_SOCIAL_ONLY = re.compile(
    r"^\s*(hi|hello|hey|good\s+(morning|afternoon|evening)|thanks|thank\s+you|"
    r"who\s+are\s+you|what\s+can\s+you\s+do|help)\s*[.!?]*\s*$",
    re.I,
)


def is_social_only(question: str) -> bool:
    """Skip an unnecessary SQL-planning call for an obvious social turn."""
    return bool(_SOCIAL_ONLY.fullmatch(question or ""))


import re
import shutil
import sqlite3
import time
from datetime import datetime
from pathlib import Path

from config import DATABASE_DIR, MAX_ROWS, DEFAULT_DB_FILENAME, SQL_TIMEOUT_SECONDS
from settings_manager import get_app_settings, update_app_settings

ALLOWED_EXTENSIONS = {".db", ".sqlite", ".sqlite3"}

def sanitize_filename(name):
    name = Path(name).name
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", name)
    return safe or "database.db"

class DatabaseManager:
    def __init__(self):
        DATABASE_DIR.mkdir(parents=True, exist_ok=True)
        self._ensure_default()

    def _ensure_default(self):
        default = DATABASE_DIR / DEFAULT_DB_FILENAME
        if not default.exists():
            root_copy = Path(__file__).resolve().parent / DEFAULT_DB_FILENAME
            if root_copy.exists():
                shutil.copy2(root_copy, default)

    def active_filename(self):
        settings = get_app_settings()
        filename = settings.get("active_database", DEFAULT_DB_FILENAME)
        if not (DATABASE_DIR / filename).exists():
            filename = DEFAULT_DB_FILENAME
            update_app_settings({"active_database": filename})
        return filename

    def active_path(self):
        return DATABASE_DIR / self.active_filename()

    def list_databases(self):
        files = []
        for p in sorted(DATABASE_DIR.iterdir()):
            if p.is_file() and p.suffix.lower() in ALLOWED_EXTENSIONS:
                try:
                    stats = self.stats(p)
                    valid = True
                except Exception:
                    stats = {}
                    valid = False
                files.append({
                    "filename": p.name,
                    "size_bytes": p.stat().st_size,
                    "active": p.name == self.active_filename(),
                    "valid": valid,
                    "stats": stats
                })
        return files

    def validate_database(self, path):
        if Path(path).suffix.lower() not in ALLOWED_EXTENSIONS:
            raise ValueError("Only .db, .sqlite and .sqlite3 files are supported.")
        conn = sqlite3.connect(str(path))
        try:
            conn.execute("SELECT name FROM sqlite_master LIMIT 1").fetchall()
            ok = conn.execute("PRAGMA integrity_check").fetchone()[0]
            if str(ok).lower() != "ok":
                raise ValueError(f"SQLite integrity check failed: {ok}")
        finally:
            conn.close()

    def save_upload(self, file_storage):
        original = sanitize_filename(file_storage.filename or "database.db")
        ext = Path(original).suffix.lower()
        if ext not in ALLOWED_EXTENSIONS:
            raise ValueError("Only .db, .sqlite and .sqlite3 files are supported.")

        target = DATABASE_DIR / original
        if target.exists():
            stem = target.stem
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            target = DATABASE_DIR / f"{stem}_{stamp}{ext}"

        file_storage.save(target)
        try:
            self.validate_database(target)
        except Exception:
            target.unlink(missing_ok=True)
            raise

        self.set_active(target.name)
        return target.name

    def set_active(self, filename):
        filename = sanitize_filename(filename)
        path = DATABASE_DIR / filename
        if not path.exists():
            raise FileNotFoundError(filename)
        self.validate_database(path)
        update_app_settings({"active_database": filename})
        return filename

    def connect(self, readonly=True):
        path = self.active_path()
        if readonly:
            conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        else:
            conn = sqlite3.connect(str(path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def schema(self):
        conn = self.connect(readonly=True)
        cur = conn.cursor()
        objects = cur.execute("""
            SELECT name, type
            FROM sqlite_master
            WHERE type IN ('table','view')
              AND name NOT LIKE 'sqlite_%'
            ORDER BY type, name
        """).fetchall()

        parts = []
        for obj in objects:
            name = obj["name"]
            typ = obj["type"].upper()
            parts.append(f"{typ} {name}")
            for c in cur.execute(f'PRAGMA table_info("{name}")').fetchall():
                pk = " PRIMARY KEY" if c["pk"] else ""
                parts.append(f"  - {c['name']} {c['type']}{pk}")
            if obj["type"] == "table":
                for fk in cur.execute(f'PRAGMA foreign_key_list("{name}")').fetchall():
                    parts.append(
                        f"  FOREIGN KEY {fk['from']} -> {fk['table']}.{fk['to']}"
                    )
            parts.append("")
        conn.close()
        return "\n".join(parts)

    def execute_readonly(self, sql):
        conn = self.connect(readonly=True)
        deadline = time.monotonic() + SQL_TIMEOUT_SECONDS
        conn.set_progress_handler(lambda: 1 if time.monotonic() > deadline else 0, 1000)
        try:
            cur = conn.cursor()
            cur.execute(sql)
            rows = cur.fetchmany(MAX_ROWS)
            columns = [d[0] for d in cur.description] if cur.description else []
            return [
                {columns[i]: row[i] for i in range(len(columns))}
                for row in rows
            ]
        except sqlite3.OperationalError as exc:
            if "interrupted" in str(exc).lower():
                raise TimeoutError(
                    f"The generated query exceeded the {SQL_TIMEOUT_SECONDS}-second safety limit."
                ) from exc
            raise
        finally:
            conn.close()

    def stats(self, path=None):
        if path is None:
            conn = self.connect(readonly=True)
        else:
            conn = sqlite3.connect(str(path))
            conn.row_factory = sqlite3.Row

        cur = conn.cursor()
        tables = cur.execute("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name NOT LIKE 'sqlite_%'
        """).fetchall()
        views = cur.execute("""
            SELECT name FROM sqlite_master WHERE type='view'
        """).fetchall()
        names = {r["name"] for r in tables}

        def count_if(table):
            if table not in names:
                return None
            try:
                return cur.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
            except Exception:
                return None

        data = {
            "tables": len(tables),
            "views": len(views),
            "machines": count_if("machines"),
            "work_orders": count_if("work_orders"),
            "sensor_readings": count_if("sensor_readings"),
            "daily_reports": count_if("daily_reports"),
        }
        conn.close()
        return data

    def ensure_report_tables(self):
        conn = self.connect(readonly=False)
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS daily_reports (
            report_id INTEGER PRIMARY KEY AUTOINCREMENT,
            report_date TEXT,
            source_filename TEXT NOT NULL,
            source_type TEXT NOT NULL,
            source_language TEXT,
            summary_language TEXT,
            raw_text TEXT NOT NULL,
            summary TEXT,
            analysis_json TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS daily_report_findings (
            finding_id INTEGER PRIMARY KEY AUTOINCREMENT,
            report_id INTEGER NOT NULL REFERENCES daily_reports(report_id) ON DELETE CASCADE,
            category TEXT NOT NULL,
            severity TEXT,
            title TEXT NOT NULL,
            detail TEXT,
            recommended_action TEXT
        );

        CREATE INDEX IF NOT EXISTS idx_daily_reports_date
            ON daily_reports(report_date);

        CREATE INDEX IF NOT EXISTS idx_daily_report_findings_report
            ON daily_report_findings(report_id);
        """)
        conn.commit()
        conn.close()

db_manager = DatabaseManager()

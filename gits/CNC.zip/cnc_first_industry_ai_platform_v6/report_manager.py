import io
import json
from datetime import datetime
from pathlib import Path

from config import (
    REPORT_UPLOAD_DIR,
    REPORT_CHUNK_CHARS,
    MAX_REPORT_SOURCE_CHARS,
    MAX_REPORT_TOKENS
)
from db_manager import db_manager
from prompts import report_summary_prompt, report_analysis_prompt
from sector_manager import sector_manager

SUPPORTED_REPORT_EXTENSIONS = {
    ".pdf", ".txt", ".md", ".docx", ".xlsx", ".xls", ".csv"
}

def safe_name(filename):
    return Path(filename).name.replace("/", "_").replace("\\", "_")

class ReportManager:
    def __init__(self, llm):
        self.llm = llm
        REPORT_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

    def extract_text(self, path):
        ext = Path(path).suffix.lower()

        if ext in {".txt", ".md"}:
            return Path(path).read_text(encoding="utf-8", errors="replace")

        if ext == ".csv":
            import pandas as pd
            df = pd.read_csv(path)
            return df.to_csv(index=False)

        if ext in {".xlsx", ".xls"}:
            import pandas as pd
            book = pd.read_excel(path, sheet_name=None)
            parts = []
            for sheet, df in book.items():
                parts.append(f"=== SHEET: {sheet} ===")
                parts.append(df.fillna("").to_csv(index=False))
            return "\n".join(parts)

        if ext == ".docx":
            from docx import Document
            doc = Document(path)
            parts = [p.text for p in doc.paragraphs if p.text.strip()]
            for table in doc.tables:
                for row in table.rows:
                    parts.append(" | ".join(cell.text for cell in row.cells))
            return "\n".join(parts)

        if ext == ".pdf":
            from pypdf import PdfReader
            reader = PdfReader(path)
            parts = []
            for i, page in enumerate(reader.pages):
                text = page.extract_text() or ""
                parts.append(f"=== PAGE {i+1} ===\n{text}")
            return "\n".join(parts)

        raise ValueError("Unsupported report file type.")

    def _chunks(self, text):
        text = text[:MAX_REPORT_SOURCE_CHARS]
        if len(text) <= REPORT_CHUNK_CHARS:
            return [text]
        return [
            text[i:i + REPORT_CHUNK_CHARS]
            for i in range(0, len(text), REPORT_CHUNK_CHARS)
        ]

    def summarize(self, text, language):
        chunks = self._chunks(text)
        partials = []
        for chunk in chunks:
            partials.append(
                self.llm.generate(
                    report_summary_prompt(chunk, language, sector_manager.active_profile()),
                    max_new_tokens=MAX_REPORT_TOKENS
                )
            )

        if len(partials) == 1:
            return partials[0]

        combined = "\n\n".join(
            f"PART {i+1}:\n{s}" for i, s in enumerate(partials)
        )
        return self.llm.generate(
            report_summary_prompt(
                "Combine these partial daily-report summaries into one final report:\n\n" + combined,
                language,
                sector_manager.active_profile()
            ),
            max_new_tokens=MAX_REPORT_TOKENS
        )

    def analyze(self, text, language):
        chunks = self._chunks(text)
        # For large reports, analyze summaries to stay inside context.
        analysis_source = text
        if len(chunks) > 1:
            analysis_source = self.summarize(text, language)

        raw = self.llm.generate(
            report_analysis_prompt(analysis_source, language, sector_manager.active_profile()),
            max_new_tokens=MAX_REPORT_TOKENS
        )
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.replace("```json", "").replace("```", "").strip()

        try:
            return json.loads(raw)
        except Exception:
            return {
                "overall_status": "WATCH",
                "key_metrics": [],
                "findings": [{
                    "category": "other",
                    "severity": "WATCH",
                    "title": "Free-form LLM analysis",
                    "detail": raw,
                    "recommended_action": ""
                }]
            }

    def store_report(
        self,
        report_date,
        source_filename,
        source_type,
        source_language,
        summary_language,
        raw_text,
        summary,
        analysis
    ):
        db_manager.ensure_report_tables()
        now = datetime.now().isoformat(timespec="seconds")

        conn = db_manager.connect(readonly=False)
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO daily_reports(
                report_date, source_filename, source_type, source_language,
                summary_language, raw_text, summary, analysis_json,
                created_at, updated_at
            )
            VALUES (?,?,?,?,?,?,?,?,?,?)
        """, (
            report_date, source_filename, source_type, source_language,
            summary_language, raw_text, summary,
            json.dumps(analysis, ensure_ascii=False),
            now, now
        ))
        report_id = cur.lastrowid

        for finding in analysis.get("findings", []):
            cur.execute("""
                INSERT INTO daily_report_findings(
                    report_id, category, severity, title, detail,
                    recommended_action
                )
                VALUES (?,?,?,?,?,?)
            """, (
                report_id,
                finding.get("category", "other"),
                finding.get("severity", "INFO"),
                finding.get("title", ""),
                finding.get("detail", ""),
                finding.get("recommended_action", "")
            ))

        conn.commit()
        conn.close()
        return report_id

    def process_upload(
        self,
        file_storage,
        report_date,
        source_language,
        summary_language
    ):
        filename = safe_name(file_storage.filename or "report.txt")
        ext = Path(filename).suffix.lower()
        if ext not in SUPPORTED_REPORT_EXTENSIONS:
            raise ValueError(
                "Supported reports: PDF, TXT, MD, DOCX, XLSX, XLS and CSV."
            )

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        saved = REPORT_UPLOAD_DIR / f"{timestamp}_{filename}"
        file_storage.save(saved)

        raw_text = self.extract_text(saved).strip()
        if not raw_text:
            raise ValueError("No readable text/data was found in the report.")

        summary = self.summarize(raw_text, summary_language)
        analysis = self.analyze(raw_text, summary_language)
        report_id = self.store_report(
            report_date=report_date,
            source_filename=filename,
            source_type=ext.lstrip("."),
            source_language=source_language,
            summary_language=summary_language,
            raw_text=raw_text,
            summary=summary,
            analysis=analysis
        )
        return self.get_report(report_id)

    def list_reports(self):
        db_manager.ensure_report_tables()
        conn = db_manager.connect(readonly=True)
        rows = conn.execute("""
            SELECT
                report_id, report_date, source_filename, source_type,
                source_language, summary_language, summary,
                analysis_json, created_at, updated_at
            FROM daily_reports
            ORDER BY COALESCE(report_date, created_at) DESC, report_id DESC
            LIMIT 200
        """).fetchall()
        conn.close()

        result = []
        for r in rows:
            item = dict(r)
            try:
                item["analysis"] = json.loads(item.pop("analysis_json") or "{}")
            except Exception:
                item["analysis"] = {}
            result.append(item)
        return result

    def get_report(self, report_id):
        db_manager.ensure_report_tables()
        conn = db_manager.connect(readonly=True)
        row = conn.execute("""
            SELECT * FROM daily_reports WHERE report_id=?
        """, (report_id,)).fetchone()
        if not row:
            conn.close()
            raise KeyError("Report not found.")
        findings = conn.execute("""
            SELECT category, severity, title, detail, recommended_action
            FROM daily_report_findings
            WHERE report_id=?
            ORDER BY finding_id
        """, (report_id,)).fetchall()
        conn.close()

        item = dict(row)
        try:
            item["analysis"] = json.loads(item.pop("analysis_json") or "{}")
        except Exception:
            item["analysis"] = {}
        item["findings"] = [dict(x) for x in findings]
        return item

    def delete_report(self, report_id):
        db_manager.ensure_report_tables()
        conn = db_manager.connect(readonly=False)
        conn.execute("DELETE FROM daily_report_findings WHERE report_id=?", (report_id,))
        cur = conn.execute("DELETE FROM daily_reports WHERE report_id=?", (report_id,))
        conn.commit()
        deleted = cur.rowcount
        conn.close()
        return deleted

    def reanalyze_report(self, report_id, language):
        item = self.get_report(report_id)
        summary = self.summarize(item["raw_text"], language)
        analysis = self.analyze(item["raw_text"], language)
        now = datetime.now().isoformat(timespec="seconds")

        conn = db_manager.connect(readonly=False)
        conn.execute("""
            UPDATE daily_reports
            SET summary=?, analysis_json=?, summary_language=?, updated_at=?
            WHERE report_id=?
        """, (
            summary,
            json.dumps(analysis, ensure_ascii=False),
            language,
            now,
            report_id
        ))
        conn.execute("DELETE FROM daily_report_findings WHERE report_id=?", (report_id,))
        for finding in analysis.get("findings", []):
            conn.execute("""
                INSERT INTO daily_report_findings(
                    report_id, category, severity, title, detail, recommended_action
                )
                VALUES (?,?,?,?,?,?)
            """, (
                report_id,
                finding.get("category", "other"),
                finding.get("severity", "INFO"),
                finding.get("title", ""),
                finding.get("detail", ""),
                finding.get("recommended_action", "")
            ))
        conn.commit()
        conn.close()
        return self.get_report(report_id)

let conversation = [];
let busy = false;
let activeRequest = null;
let currentLanguage = window.INITIAL_LANGUAGE || "en";
let uiText = {};
const CHAT_STORAGE_KEY = "cnc-assistant-chat-v6";
const STYLE_STORAGE_KEY = "cnc-assistant-answer-style";

const input = document.getElementById("question");
const sendButton = document.getElementById("sendButton");
const stopButton = document.getElementById("stopButton");
const chat = document.getElementById("chat");
const messages = document.getElementById("messages");
const welcome = document.getElementById("welcome");

function esc(v){return String(v ?? "").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;")}
function t(key){return uiText[key] || key}

function inlineMarkdown(value){
  let s=esc(value);
  s=s.replace(/`([^`\n]+)`/g,"<code>$1</code>");
  s=s.replace(/\*\*([^*]+)\*\*/g,"<strong>$1</strong>");
  s=s.replace(/__([^_]+)__/g,"<strong>$1</strong>");
  s=s.replace(/\*([^*\n]+)\*/g,"<em>$1</em>");
  return s
}

function renderMarkdown(value){
  const lines=String(value??"").replaceAll("\r","").split("\n");
  let html="", paragraph=[], listType=null, listItems=[], inCode=false, code=[];
  const flushParagraph=()=>{if(paragraph.length){html+=`<p>${paragraph.map(inlineMarkdown).join("<br>")}</p>`;paragraph=[]}};
  const flushList=()=>{if(listItems.length){html+=`<${listType}>${listItems.map(x=>`<li>${inlineMarkdown(x)}</li>`).join("")}</${listType}>`;listItems=[];listType=null}};
  for(let i=0;i<lines.length;i++){
    const line=lines[i];
    if(line.trim().startsWith("```")){
      flushParagraph();flushList();
      if(inCode){html+=`<pre class="answer-code"><code>${esc(code.join("\n"))}</code></pre>`;code=[]}
      inCode=!inCode;continue
    }
    if(inCode){code.push(line);continue}
    const heading=line.match(/^(#{1,3})\s+(.+)$/);
    if(heading){flushParagraph();flushList();const level=Math.min(4,heading[1].length+2);html+=`<h${level}>${inlineMarkdown(heading[2])}</h${level}>`;continue}
    if(line.includes("|") && i+1<lines.length && /^\s*\|?\s*:?-{3,}/.test(lines[i+1])){
      flushParagraph();flushList();const cells=x=>x.trim().replace(/^\||\|$/g,"").split("|").map(c=>c.trim());
      const heads=cells(line);i+=2;const rows=[];
      while(i<lines.length&&lines[i].includes("|")&&lines[i].trim()){rows.push(cells(lines[i]));i++}i--;
      html+=`<div class="answer-table-wrap"><table><thead><tr>${heads.map(c=>`<th>${inlineMarkdown(c)}</th>`).join("")}</tr></thead><tbody>${rows.map(r=>`<tr>${heads.map((_,n)=>`<td>${inlineMarkdown(r[n]??"")}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;continue
    }
    const bullet=line.match(/^\s*[-*]\s+(.+)$/);const numbered=line.match(/^\s*\d+[.)]\s+(.+)$/);
    if(bullet||numbered){flushParagraph();const wanted=bullet?"ul":"ol";if(listType&&listType!==wanted)flushList();listType=wanted;listItems.push((bullet||numbered)[1]);continue}
    if(/^\s*>\s?/.test(line)){flushParagraph();flushList();html+=`<blockquote>${inlineMarkdown(line.replace(/^\s*>\s?/,""))}</blockquote>`;continue}
    if(!line.trim()){flushParagraph();flushList();continue}
    paragraph.push(line)
  }
  if(inCode)html+=`<pre class="answer-code"><code>${esc(code.join("\n"))}</code></pre>`;
  flushParagraph();flushList();return html
}

async function loadUiText(){
  const r = await fetch(`/api/ui-text?lang=${encodeURIComponent(currentLanguage)}`);
  uiText = await r.json();
  document.querySelectorAll("[data-i18n]").forEach(el=>{
    const key=el.dataset.i18n;
    if(uiText[key]!==undefined) el.textContent=uiText[key];
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach(el=>{
    const key=el.dataset.i18nPlaceholder;
    if(uiText[key]!==undefined) el.placeholder=uiText[key];
  });
  document.documentElement.lang = currentLanguage;
}

async function changeLanguage(lang){
  currentLanguage=lang;
  document.getElementById("reportLanguage").value=lang;
  await fetch("/api/language",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({language:lang})});
  await loadUiText();
  if(document.getElementById("uiPanel").classList.contains("active-panel")) loadUiEditor();
}

function saveAnswerStyle(style){localStorage.setItem(STYLE_STORAGE_KEY,style)}
function currentAnswerStyle(){return document.getElementById("answerStyle")?.value||"auto"}

function showPanel(id, button){
  document.querySelectorAll(".panel").forEach(p=>p.classList.remove("active-panel"));
  document.getElementById(id).classList.add("active-panel");
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.remove("active"));
  if(button) button.classList.add("active");
}

function autoResize(){input.style.height="auto";input.style.height=Math.min(input.scrollHeight,160)+"px"}
input.addEventListener("input",autoResize);
function handleKeyDown(e){if(e.key==="Enter"&&!e.shiftKey&&!e.isComposing){e.preventDefault();sendMessage()}}
function setQuestion(text){input.value=text;autoResize();input.focus()}
function useExample(btn){setQuestion(btn.textContent.trim())}
function scrollBottom(){requestAnimationFrame(()=>chat.scrollTop=chat.scrollHeight)}

function setBusy(value){
  busy=value;sendButton.disabled=value;sendButton.hidden=value;stopButton.hidden=!value;
}

function compactConversation(){
  return conversation.slice(-30).map(item=>{
    if(item.role!=="assistant"||!item.data)return {role:item.role,content:item.content};
    const d={...item.data,evidence:(item.data.evidence||[]).map(e=>({...e,rows:(e.rows||[]).slice(0,20)}))};
    return {role:item.role,content:item.content,data:d}
  })
}
function persistConversation(){
  try{localStorage.setItem(CHAT_STORAGE_KEY,JSON.stringify(compactConversation()))}catch(_){/* Storage is optional. */}
}
function clearConversation(){
  if(activeRequest)activeRequest.abort();conversation=[];messages.innerHTML="";welcome.style.display="";
  localStorage.removeItem(CHAT_STORAGE_KEY);input.value="";autoResize()
}
function newChat(){
  clearConversation();showPanel("chatPanel",document.querySelector('[data-panel="chatPanel"]'));input.focus()
}

function addUser(text){
  welcome.style.display="none";
  const row=document.createElement("div");row.className="message-row user-row";
  row.innerHTML=`<div class="message-inner"><div class="avatar user-avatar">YOU</div><div class="message-content"><div class="message-role">${esc(t("you"))}</div><div class="message-text user-text">${esc(text)}</div></div></div>`;
  messages.appendChild(row);scrollBottom()
}
function addTyping(){
  const id="typing-"+Date.now();const row=document.createElement("div");row.id=id;row.className="message-row assistant-row";
  row.innerHTML=`<div class="message-inner"><div class="avatar assistant-avatar">AI</div><div class="message-content"><div class="message-role">${esc(t("assistant"))}</div><div class="thinking-line"><div class="typing"><span></span><span></span><span></span></div><span>${esc(t("analyzing"))}</span></div></div></div>`;
  messages.appendChild(row);scrollBottom();return id
}
function renderTable(rows){
  if(!rows||!rows.length)return `<div class="empty-evidence">${esc(t("no_rows"))}</div>`;
  const cols=Object.keys(rows[0]);let h='<div class="table-wrap"><table class="result-table"><thead><tr>';
  cols.forEach(c=>h+=`<th>${esc(c)}</th>`);h+='</tr></thead><tbody>';
  rows.forEach(r=>{h+='<tr>';cols.forEach(c=>h+=`<td>${esc(r[c])}</td>`);h+='</tr>'});
  return h+'</tbody></table></div>'
}
function normalizeEvidence(data){
  if(Array.isArray(data.evidence))return data.evidence;
  return data.sql?[{label:t("database_evidence"),sql:data.sql,rows:data.rows||[],row_count:(data.rows||[]).length}]:[]
}
function renderEvidence(data){
  const evidence=normalizeEvidence(data);if(!evidence.length)return "";
  const total=evidence.reduce((n,e)=>n+(e.row_count??(e.rows||[]).length),0);
  let h=`<details class="evidence-group"><summary><span>${esc(t("database_evidence"))}</span><span class="evidence-summary">${evidence.length} ${esc(t("queries"))} · ${total} ${esc(t("rows"))}</span></summary><div class="evidence-body">`;
  evidence.forEach((e,index)=>{
    h+=`<details class="evidence-card"${evidence.length===1?' open':''}><summary><span>${esc(e.label||`Evidence ${index+1}`)}</span><span>${esc(e.row_count??(e.rows||[]).length)} ${esc(t("rows"))}</span></summary><div class="evidence-card-body"><div class="evidence-label">${esc(t("validated_read_only_sql"))}${e.automatically_repaired?` · ${esc(t("query_repaired"))}`:""}</div><pre class="sql-box">${esc(e.sql)}</pre>${renderTable(e.rows||[])}${e.may_be_truncated?`<div class="evidence-warning">${esc(t("results_limited"))}</div>`:""}</div></details>`
  });
  return h+"</div></details>"
}
function responseLabel(type){
  if(type==="data")return t("verified_data_answer");
  if(type==="clarify")return t("clarifying_question");
  return t("general_guidance")
}
function addAssistant(data){
  const row=document.createElement("div");row.className="message-row assistant-row";
  const suggestions=(data.suggested_questions||[]).map((q,i)=>`<button type="button" class="suggestion-chip" data-index="${i}">${esc(q)}</button>`).join("");
  row.innerHTML=`<div class="message-inner"><div class="avatar assistant-avatar">AI</div><div class="message-content"><div class="message-head"><div class="message-role">${esc(t("assistant"))}</div><span class="answer-kind">${esc(responseLabel(data.response_type))}</span></div><div class="message-text markdown-body">${renderMarkdown(data.answer)}</div>${renderEvidence(data)}${suggestions?`<div class="follow-up-block"><div class="follow-up-label">${esc(t("continue_with"))}</div><div class="suggestion-chips">${suggestions}</div></div>`:""}<div class="message-actions"><button type="button" class="copy-answer">${esc(t("copy"))}</button><span>${esc(data.generated_at||"")}</span></div></div></div>`;
  row.querySelector(".copy-answer").onclick=async e=>{
    if(navigator.clipboard?.writeText)await navigator.clipboard.writeText(data.answer||"");
    e.currentTarget.textContent=t("copied");setTimeout(()=>e.currentTarget.textContent=t("copy"),1200)
  };
  row.querySelectorAll(".suggestion-chip").forEach((button,index)=>button.onclick=()=>setQuestion((data.suggested_questions||[])[index]));
  messages.appendChild(row);scrollBottom()
}
function addError(msg){
  const row=document.createElement("div");row.className="message-row assistant-row";
  row.innerHTML=`<div class="message-inner"><div class="avatar assistant-avatar">AI</div><div class="message-content"><div class="message-role">${esc(t("assistant"))}</div><div class="error-message">${esc(msg)}</div></div></div>`;
  messages.appendChild(row);scrollBottom()
}
function addNotice(msg){
  const el=document.createElement("div");el.className="chat-notice";el.textContent=msg;messages.appendChild(el);scrollBottom()
}
function stopResponse(){if(activeRequest)activeRequest.abort()}

async function sendMessage(){
  if(busy)return;const q=input.value.trim();if(!q)return;
  const history=conversation.filter(x=>x.role==="user"||x.role==="assistant").slice(-12).map(x=>({role:x.role,content:x.content}));
  addUser(q);conversation.push({role:"user",content:q});persistConversation();input.value="";autoResize();const typingId=addTyping();
  activeRequest=new AbortController();setBusy(true);
  try{
    const r=await fetch("/api/ask",{method:"POST",headers:{"Content-Type":"application/json"},signal:activeRequest.signal,body:JSON.stringify({question:q,language:currentLanguage,history,answer_style:currentAnswerStyle()})});
    const data=await r.json();document.getElementById(typingId)?.remove();
    if(!r.ok)throw new Error((data.error||"Request failed")+(data.details?": "+data.details:""));
    addAssistant(data);conversation.push({role:"assistant",content:data.answer,data});persistConversation()
  }catch(e){
    document.getElementById(typingId)?.remove();
    if(e.name==="AbortError")addNotice(t("response_stopped"));else addError(e.message)
  }finally{activeRequest=null;setBusy(false);input.focus()}
}

function restoreConversation(){
  try{
    const saved=JSON.parse(localStorage.getItem(CHAT_STORAGE_KEY)||"[]");if(!Array.isArray(saved)||!saved.length)return;
    conversation=saved;welcome.style.display="none";
    saved.forEach(item=>{if(item.role==="user")addUser(item.content);else if(item.role==="assistant")addAssistant(item.data||{answer:item.content,response_type:"conversation",suggested_questions:[]})})
  }catch(_){localStorage.removeItem(CHAT_STORAGE_KEY)}
}

async function refreshStatus(){
  const r=await fetch("/api/status");const d=await r.json();
  document.getElementById("activeDbName").textContent=d.active_database;
  document.getElementById("databaseActiveLarge").textContent=d.active_database;
  document.getElementById("activeSectorName").textContent=(d.sector?.name || "Generic");
  const s=d.stats||{};
  document.getElementById("statTables").textContent=s.tables??"-";
  document.getElementById("statViews").textContent=s.views??"-";
  document.getElementById("statMachines").textContent=s.machines??"-";
  document.getElementById("statWorkOrders").textContent=s.work_orders??"-";
  document.getElementById("statSensors").textContent=s.sensor_readings??"-";
  const model=d.llm?.model?String(d.llm.model).split(/[\\/]/).pop():t("local_model");
  document.getElementById("modelStatus").textContent=`${model} · ${d.llm?.loaded?t("ready"):t("loads_on_first_use")}`;
}

async function loadDatabases(){
  await refreshStatus();
  const r=await fetch("/api/databases");const d=await r.json();const box=document.getElementById("databaseList");
  box.innerHTML="";
  (d.databases||[]).forEach(db=>{
    const el=document.createElement("div");el.className="db-card";
    el.innerHTML=`<div class="row-head"><div><div class="row-title">${esc(db.filename)}${db.active?" ✓":""}</div><div class="row-meta">${esc(JSON.stringify(db.stats||{}))}</div></div>${db.active?"":`<button class="secondary" data-db="${esc(db.filename)}">${esc(t("switch"))}</button>`}</div>`;
    const b=el.querySelector("button");if(b)b.onclick=()=>switchDatabase(db.filename);
    box.appendChild(el)
  })
}
async function uploadDatabase(){
  const f=document.getElementById("databaseFile").files[0];const status=document.getElementById("databaseUploadStatus");
  if(!f){status.textContent="Choose a database file.";return}
  const fd=new FormData();fd.append("file",f);status.textContent=t("processing");
  const r=await fetch("/api/database/upload",{method:"POST",body:fd});const d=await r.json();
  if(!r.ok){status.textContent=(d.error||"Error");return}
  status.textContent=`${t("success")}: ${d.active_database}`;clearConversation();await refreshStatus();await loadDatabases()
}
async function switchDatabase(filename){
  const r=await fetch("/api/database/select",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({filename})});const d=await r.json();
  if(!r.ok){alert(d.error||"Error");return}clearConversation();await refreshStatus();await loadDatabases()
}

async function uploadReport(){
  const f=document.getElementById("reportFile").files[0];const status=document.getElementById("reportUploadStatus");const btn=document.getElementById("reportUploadButton");
  if(!f){status.textContent="Choose a report file.";return}
  const fd=new FormData();fd.append("file",f);fd.append("report_date",document.getElementById("reportDate").value);fd.append("source_language","auto");fd.append("summary_language",document.getElementById("reportLanguage").value);
  status.textContent=t("processing");btn.disabled=true;
  try{
    const r=await fetch("/api/reports/upload",{method:"POST",body:fd});const d=await r.json();
    if(!r.ok)throw new Error((d.error||"Error")+(d.details?": "+d.details:""));
    status.textContent=t("success");document.getElementById("reportFile").value="";await refreshStatus();await loadReports()
  }catch(e){status.textContent=e.message}
  finally{btn.disabled=false}
}
function renderAnalysis(report){
  const a=report.analysis||{};let h="";
  if(a.overall_status)h+=`<div class="row-meta">Status: ${esc(a.overall_status)}</div>`;
  (a.findings||[]).forEach(f=>{h+=`<div class="finding ${esc(f.severity)}"><strong>${esc(f.title)}</strong><div>${esc(f.detail)}</div>${f.recommended_action?`<div><b>→</b> ${esc(f.recommended_action)}</div>`:""}</div>`});
  return h
}
async function loadReports(){
  const box=document.getElementById("reportList");box.innerHTML=`<div class="muted">${esc(t("processing"))}</div>`;
  const r=await fetch("/api/reports");const d=await r.json();
  if(!r.ok){box.innerHTML=`<div class="muted">${esc(d.error||"Error")}</div>`;return}
  if(!d.length){box.innerHTML=`<div class="muted">${esc(t("no_reports"))}</div>`;return}
  box.innerHTML="";
  d.forEach(report=>{
    const el=document.createElement("div");el.className="report-card";
    el.innerHTML=`<div class="row-head"><div><div class="row-title">${esc(report.report_date||"")} · ${esc(report.source_filename)}</div><div class="row-meta">${esc(report.source_type)} · ${esc(report.summary_language||"")} · ${esc(report.created_at||"")}</div></div><div class="button-row"><button class="secondary re">${esc(t("reanalyze"))}</button><button class="danger del">${esc(t("delete"))}</button></div></div><div class="report-summary"><b>${esc(t("summary"))}:</b>\n${esc(report.summary||"")}</div><details class="details"><summary>${esc(t("analysis"))}</summary>${renderAnalysis(report)}</details>`;
    el.querySelector(".del").onclick=()=>deleteReport(report.report_id);
    el.querySelector(".re").onclick=()=>reanalyzeReport(report.report_id);
    box.appendChild(el)
  })
}
async function deleteReport(id){
  if(!confirm(`${t("delete")}?`))return;
  const r=await fetch(`/api/reports/${id}`,{method:"DELETE"});if(!r.ok){const d=await r.json();alert(d.error||"Error")}await loadReports();await refreshStatus()
}
async function reanalyzeReport(id){
  const r=await fetch(`/api/reports/${id}/reanalyze`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({language:currentLanguage})});
  if(!r.ok){const d=await r.json();alert((d.error||"Error")+(d.details?": "+d.details:""))}await loadReports()
}

async function loadUiEditor(){
  const r=await fetch(`/api/ui-text?lang=${encodeURIComponent(currentLanguage)}`);const d=await r.json();const box=document.getElementById("uiEditor");box.innerHTML="";
  Object.entries(d).sort(([a],[b])=>a.localeCompare(b)).forEach(([key,value])=>{
    const wrap=document.createElement("div");wrap.className="ui-field";const multiline=String(value).length>70;
    wrap.innerHTML=`<label>${esc(key)}</label>${multiline?`<textarea data-key="${esc(key)}">${esc(value)}</textarea>`:`<input data-key="${esc(key)}" value="${esc(value)}">`}`;
    box.appendChild(wrap)
  })
}
async function saveUiText(){
  const values={};document.querySelectorAll("#uiEditor [data-key]").forEach(el=>values[el.dataset.key]=el.value);
  const r=await fetch(`/api/ui-text/${encodeURIComponent(currentLanguage)}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(values)});
  if(!r.ok){const d=await r.json();alert(d.error||"Error");return}await loadUiText();alert(t("success"))
}
async function resetUiText(){
  await fetch("/api/ui-text/reset",{method:"POST"});await loadUiText();await loadUiEditor()
}

(async function init(){
  const style=localStorage.getItem(STYLE_STORAGE_KEY)||"auto";
  if(["auto","concise","balanced","detailed"].includes(style))document.getElementById("answerStyle").value=style;
  await loadUiText();await refreshStatus();restoreConversation();input.focus()
})();


let sectorProfiles = {};

async function loadSectors(){
  const r=await fetch("/api/sectors");const d=await r.json();
  sectorProfiles=d.profiles||{};
  const sel=document.getElementById("sectorSelect");sel.innerHTML="";
  Object.entries(sectorProfiles).forEach(([id,p])=>{
    const o=document.createElement("option");o.value=id;o.textContent=p.name||id;
    if(id===d.active_sector)o.selected=true;sel.appendChild(o)
  });
  renderSectorDescription(d.active_sector);
  fillSectorForm(d.active_sector);
}

function renderSectorDescription(id){
  const p=sectorProfiles[id]||{};
  document.getElementById("sectorDescription").textContent=p.description||"";
}

function fillSectorForm(id){
  const p=sectorProfiles[id]||{};
  document.getElementById("sectorId").value=id||"";
  document.getElementById("sectorName").value=p.name||"";
  document.getElementById("sectorDesc").value=p.description||"";
  document.getElementById("sectorContext").value=p.domain_context||"";
  document.getElementById("sectorCategories").value=(p.report_categories||[]).join(", ");
  document.getElementById("sectorExamples").value=(p.example_questions||[]).join("\n");
}

function clearSectorForm(){
  ["sectorId","sectorName","sectorDesc","sectorContext","sectorCategories","sectorExamples"].forEach(id=>document.getElementById(id).value="");
  document.getElementById("sectorStatus").textContent="";
}

async function switchSector(id){
  const r=await fetch("/api/sectors/select",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sector_id:id})});
  const d=await r.json();if(!r.ok){alert(d.error||"Error");return}
  clearConversation();await refreshStatus();await loadSectors()
}

async function saveSectorProfile(){
  const id=document.getElementById("sectorId").value.trim();
  const payload={
    id,
    name:document.getElementById("sectorName").value.trim(),
    description:document.getElementById("sectorDesc").value.trim(),
    domain_context:document.getElementById("sectorContext").value.trim(),
    report_categories:document.getElementById("sectorCategories").value.split(",").map(x=>x.trim()).filter(Boolean),
    example_questions:document.getElementById("sectorExamples").value.split("\n").map(x=>x.trim()).filter(Boolean),
    ui_overrides:{}
  };
  const exists=!!sectorProfiles[id];
  const url=exists?`/api/sectors/${encodeURIComponent(id)}`:"/api/sectors";
  const method=exists?"PUT":"POST";
  const r=await fetch(url,{method,headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  const d=await r.json();
  document.getElementById("sectorStatus").textContent=r.ok?"Saved.":(d.error||"Error");
  if(r.ok){await loadSectors();await refreshStatus()}
}

async function refreshSchemaView(){
  const box=document.getElementById("schemaView");box.textContent="Loading...";
  const r=await fetch("/api/schema");const d=await r.json();
  if(!r.ok){box.textContent=d.error||"Error";return}
  let text=`Database: ${d.database}\n\n`;
  (d.objects||[]).forEach(obj=>{
    text+=`${obj.type.toUpperCase()} ${obj.name}\n`;
    (obj.columns||[]).forEach(c=>{
      text+=`  - ${c.name} ${c.type}${c.primary_key?" PRIMARY KEY":""}${c.not_null?" NOT NULL":""}\n`;
    });
    (obj.foreign_keys||[]).forEach(f=>{
      text+=`  FK ${f.column} -> ${f.references_table}.${f.references_column}\n`;
    });
    text+="\n";
  });
  box.textContent=text
}

async function saveSchemaSnapshot(){
  const r=await fetch("/api/schema/snapshot",{method:"POST"});const d=await r.json();
  document.getElementById("schemaSnapshotStatus").textContent=r.ok?`Saved: ${d.path}`:(d.error||"Error")
}

function loadSchemaBuilder(){
  refreshSchemaView();
  if(!document.querySelector(".schema-table-card"))addSchemaTable()
}

function addSchemaTable(){
  const wrap=document.createElement("div");wrap.className="schema-table-card";
  wrap.innerHTML=`
    <div class="schema-table-head">
      <input class="table-name" placeholder="table_name">
      <button class="danger" onclick="this.closest('.schema-table-card').remove()">${esc(t("remove_table"))}</button>
    </div>
    <div class="schema-subheading">${esc(t("columns"))}</div>
    <div class="schema-columns"></div>
    <button class="secondary add-column-btn" onclick="addSchemaColumn(this)">${esc(t("add_column"))}</button>
    <div class="schema-subheading">${esc(t("foreign_keys"))}</div>
    <div class="schema-fks"></div>
    <button class="secondary" onclick="addSchemaForeignKey(this)">${esc(t("add_foreign_key"))}</button>`;
  document.getElementById("tableBuilder").appendChild(wrap);
  addSchemaColumn(wrap.querySelector(".add-column-btn"))
}

function addSchemaColumn(button){
  const cols=button.closest(".schema-table-card").querySelector(".schema-columns");
  const row=document.createElement("div");row.className="schema-column-row";
  row.innerHTML=`<input class="col-name" placeholder="column_name"><select class="col-type"><option>integer</option><option>text</option><option>real</option><option>datetime</option><option>boolean</option></select><label><input type="checkbox" class="col-pk"> PK</label><label><input type="checkbox" class="col-ai"> Auto</label><button class="danger" onclick="this.parentElement.remove()">×</button>`;
  cols.appendChild(row)
}

function addSchemaForeignKey(button){
  const box=button.closest(".schema-table-card").querySelector(".schema-fks");
  const row=document.createElement("div");row.className="schema-fk-row";
  row.innerHTML=`<input class="fk-column" placeholder="local_column"><span>→</span><input class="fk-table" placeholder="referenced_table"><input class="fk-ref-column" placeholder="referenced_column"><button class="danger" onclick="this.parentElement.remove()">×</button>`;
  box.appendChild(row)
}

function builderDefinition(){
  const tables=[];
  document.querySelectorAll(".schema-table-card").forEach(card=>{
    const name=card.querySelector(".table-name").value.trim();if(!name)return;
    const columns=[];
    card.querySelectorAll(".schema-column-row").forEach(row=>{
      const cname=row.querySelector(".col-name").value.trim();if(!cname)return;
      columns.push({name:cname,type:row.querySelector(".col-type").value,primary_key:row.querySelector(".col-pk").checked,autoincrement:row.querySelector(".col-ai").checked})
    });
    const foreign_keys=[];
    card.querySelectorAll(".schema-fk-row").forEach(row=>{
      const column=row.querySelector(".fk-column").value.trim();
      const references_table=row.querySelector(".fk-table").value.trim();
      const references_column=row.querySelector(".fk-ref-column").value.trim();
      if(column&&references_table&&references_column)foreign_keys.push({column,references_table,references_column})
    });
    tables.push({name,columns,foreign_keys})
  });
  return {tables}
}

async function createDatabaseFromBuilder(){
  const filename=document.getElementById("newDbFilename").value.trim()||"new_sector.db";
  const definition=builderDefinition();
  const status=document.getElementById("schemaCreateStatus");status.textContent="Creating...";
  const r=await fetch("/api/schema/create-database",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({filename,definition})});
  const d=await r.json();
  status.textContent=r.ok?`Created and loaded: ${d.active_database}`:((d.error||"Error")+(d.details?": "+d.details:""));
  if(r.ok){clearConversation();await refreshStatus();await refreshSchemaView()}
}

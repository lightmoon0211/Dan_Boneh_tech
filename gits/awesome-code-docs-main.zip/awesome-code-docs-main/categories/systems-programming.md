# ⚙️ Systems Programming

> Internals-focused tutorials for low-level architecture, infrastructure patterns, and runtime behavior.

## Snapshot (auto-updated)

- systems and infrastructure tracks in catalog: **6+**
- scope includes runtime internals, operators, protocol-level systems, and architecture deep dives
- all active tracks are in canonical root chapter layout

## Start Here by Goal

| Goal | Recommended Starting Tutorial | Next Tutorials |
|:-----|:------------------------------|:---------------|
| Learn React internals | [React Fiber](../tutorials/react-fiber-tutorial/) | [LangChain Architecture](../tutorials/langchain-architecture-tutorial/) |
| Learn production K8s control loops | [Kubernetes Operators](../tutorials/kubernetes-operator-tutorial/) | [n8n MCP](../tutorials/n8n-mcp-tutorial/) |
| Learn web-scale data extraction | [Firecrawl](../tutorials/firecrawl-tutorial/) | [OpenHands](../tutorials/openhands-tutorial/) for autonomous SWE workflows |
| Learn local-first app runtime design | [Dyad](../tutorials/dyad-tutorial/) | [VibeSDK](../tutorials/vibesdk-tutorial/) |
| Audit AI-generated or vibe-coded codebases | [AI Code Audit Checklist](https://www.romanticode.com/blog/ai-code-audit-checklist/) | [Dyad](../tutorials/dyad-tutorial/) → [OpenHands](../tutorials/openhands-tutorial/) → [Daytona](../tutorials/daytona-tutorial/) |

## Featured Systems Tracks

- [Kubernetes Operator Patterns](../tutorials/kubernetes-operator-tutorial/)
- [React Fiber Internals](../tutorials/react-fiber-tutorial/)
- [LangChain Architecture Guide](../tutorials/langchain-architecture-tutorial/)
- [Firecrawl](../tutorials/firecrawl-tutorial/)

## External Audit Resources

- [AI Code Audit Checklist](https://www.romanticode.com/blog/ai-code-audit-checklist/) - practical checklist for auditing AI-generated or vibe-coded codebases before refactoring, with architecture review prompts, cleanup priorities, and a sample audit report.

## Related Hubs

- [Systems and Infrastructure in README](../README.md#-systems--infrastructure)
- [Developer Tools and Productivity in README](../README.md#-developer-tools--productivity)
- [Turborepo](../tutorials/turborepo-tutorial/)

## Suggest Additions

- submit system-internals tutorials: <https://github.com/johnxie/awesome-code-docs/issues/new?template=new-entry.md>
- follow review standards: [Contributing](../CONTRIBUTING.md)

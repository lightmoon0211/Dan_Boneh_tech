# 🌐 Web Frameworks

> Architecture tutorials for modern full-stack frameworks, UI runtimes, and AI-native application stacks.

## Snapshot (auto-updated)

- framework and application-architecture content spans AI apps, DX tools, and frontend internals
- strongest coverage areas: Next.js/React AI apps, chat platforms, and coding-assistant interfaces

## Start Here by Goal

| Goal | Recommended Starting Tutorial | Next Tutorials |
|:-----|:------------------------------|:---------------|
| Build AI apps with TypeScript | [Vercel AI SDK](../tutorials/vercel-ai-tutorial/) | [CopilotKit](../tutorials/copilotkit-tutorial/) → [LobeChat](../tutorials/lobechat-tutorial/) |
| Build chat/product interfaces | [Chatbox](../tutorials/chatbox-tutorial/) | [Open WebUI](../tutorials/open-webui-tutorial/) → [Perplexica](../tutorials/perplexica-tutorial/) |
| Understand visual workflow products | [Flowise](../tutorials/flowise-tutorial/) | [Dify](../tutorials/dify-tutorial/) |
| Build with vibe-coding UX patterns | [Stagewise](../tutorials/stagewise-tutorial/) | [Dyad](../tutorials/dyad-tutorial/) → [bolt.diy](../tutorials/bolt-diy-tutorial/) → [VibeSDK](../tutorials/vibesdk-tutorial/) |

## Featured Framework/App Tracks

- [Vercel AI SDK](../tutorials/vercel-ai-tutorial/)
- [CopilotKit](../tutorials/copilotkit-tutorial/)
- [LobeChat](../tutorials/lobechat-tutorial/)
- [Stagewise](../tutorials/stagewise-tutorial/)
- [Flowise](../tutorials/flowise-tutorial/)
- [Dify](../tutorials/dify-tutorial/)

## Related Hubs

- [Chat and AI Applications in README](../README.md#-chat--ai-applications)
- [Learning Paths](../README.md#-learning-paths)
- [Cherry Studio](../tutorials/cherry-studio-tutorial/)
- [Khoj](../tutorials/khoj-tutorial/)
- [Quivr](../tutorials/quivr-tutorial/)
- [Sillytavern](../tutorials/sillytavern-tutorial/)

## Suggest Additions

- propose new framework deep dives: <https://github.com/johnxie/awesome-code-docs/issues/new?template=new-entry.md>
- contribution standards: [Contributing](../CONTRIBUTING.md)

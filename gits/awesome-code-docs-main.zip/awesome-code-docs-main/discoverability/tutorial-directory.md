# Tutorial Directory (A-Z)

This page is auto-generated from the tutorial index and is intended as a fast browse surface for contributors and search crawlers.

- Total tutorials: **203**
- Source: `scripts/generate_discoverability_assets.py`

## A

- [A2A Protocol Tutorial: Building Interoperable Agent Systems With Google's Agent-to-Agent Standard](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/a2a-protocol-tutorial/README.md)
  - Learn how agents discover, communicate, and delegate tasks to each other using the A2A protocol — the open standard (now Linux Foundation) for agent-to-agent interoperability.
- [Activepieces Tutorial: Open-Source Automation, Pieces, and AI-Ready Workflow Operations](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/activepieces-tutorial/README.md)
  - Learn how to use activepieces/activepieces to build, run, and govern production automation workflows with open-source extensibility, piece development, API control, and self-hosted operations.
- [ADK Python Tutorial: Production-Grade Agent Engineering with Google's ADK](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/adk-python-tutorial/README.md)
  - Learn how to use google/adk-python to build, evaluate, and deploy modular AI agent systems with strong tooling, session controls, and production rollouts.
- [AFFiNE Tutorial: Open-Source AI Workspace with Docs, Whiteboards, and Databases](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/affine-tutorial/README.md)
  - Learn how to use toeverything/AFFiNE to build, extend, and self-host a modern knowledge workspace combining documents, whiteboards, and databases — powered by BlockSuite, CRDT-based collaboration, and integrated AI copilot features.
- [AG2 Tutorial: Next-Generation Multi-Agent Framework](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/ag2-tutorial/README.md)
  - Build collaborative AI agent systems with AG2, the community-driven successor to AutoGen.
- [AgentGPT Tutorial: Building Autonomous AI Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/agentgpt-tutorial/README.md)
  - A deep technical walkthrough of AgentGPT covering Building Autonomous AI Agents.
- [AgenticSeek Tutorial: Local-First Autonomous Agent Operations](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/agenticseek-tutorial/README.md)
  - Learn how to use Fosowl/agenticSeek to run multi-agent planning, browsing, and coding workflows with local model support, Docker-first runtime defaults, and practical operator guardrails.
- [AGENTS.md Tutorial: Open Standard for Coding-Agent Guidance in Repositories](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/agents-md-tutorial/README.md)
  - Learn how to use agentsmd/agents.md to define a clear, portable instruction contract for coding agents across projects and tools.
- [Agno Tutorial: Multi-Agent Systems That Learn Over Time](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/agno-tutorial/README.md)
  - Learn how to build and operate learning multi-agent systems with agno-agi/agno, including memory, orchestration, AgentOS runtime, and production guardrails.
- [Aider Tutorial: AI Pair Programming in Your Terminal](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/aider-tutorial/README.md)
  - Learn to use Aider-AI/aider for real file edits, git-native workflows, model routing, and reliable day-to-day coding loops.
- [Anthropic API Tutorial: Build Production Apps with Claude](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/anthropic-code-tutorial/README.md)
  - A practical guide to building with Anthropic's API and official SDKs, including messages, tools, vision, streaming, and production operations.
- [Anthropic Quickstarts Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/anthropic-skills-tutorial/README.md)
  - A deep-dive into every project in the official anthropics/anthropic-quickstarts repository — computer use, autonomous coding, customer support, financial analysis, and the agents reference implementation.
- [AnythingLLM Tutorial: Self-Hosted RAG and Agents Platform](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/anything-llm-tutorial/README.md)
  - Learn how to deploy and operate Mintplex-Labs/anything-llm for document-grounded chat, workspace management, agent workflows, and production use.
- [Appsmith Tutorial: Low-Code Internal Tools](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/appsmith-tutorial/README.md)
  - Open-source low-code platform for building internal tools with drag-and-drop UI, 25+ database integrations, JavaScript logic, and Git sync.
- [Athens Research: Deep Dive Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/athens-research-tutorial/README.md)
  - Project Status: The Athens Research repository was archived in August 2022 and is no longer actively maintained. This tutorial covers the final v2.0.0 release as a historical reference for ClojureScript/Datascript architectural patterns. Do not use Athens as the basis for new production projects.
- [AutoAgent Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/autoagent-tutorial/README.md)
  - AutoAgent (formerly MetaChain) is a zero-code autonomous agent framework from HKUDS that lets you describe agents in plain English and have them generated, tested, and deployed automatically. With 9,116 GitHub stars and an academic paper (arxiv:2502.05957), it represents a significant step toward democratizing multi-agent system development.
- [autoresearch Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/autoresearch-tutorial/README.md)
  - The overnight ML research agent that runs ~100 GPU experiments while you sleep.
- [Awesome Claude Code Tutorial: Curated Claude Code Resource Discovery and Evaluation](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/awesome-claude-code-tutorial/README.md)
  - Learn how to use hesreallyhim/awesome-claude-code as a high-signal discovery and decision system for skills, commands, hooks, tooling, and CLAUDE.md patterns.
- [Awesome Claude Skills Tutorial: High-Signal Skill Discovery and Reuse for Claude Workflows](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/awesome-claude-skills-tutorial/README.md)
  - Learn how to use ComposioHQ/awesome-claude-skills to discover, evaluate, install, and contribute Claude skills for coding, automation, writing, and cross-app workflows.
- [Awesome MCP Servers Tutorial: Curating and Operating High-Signal MCP Integrations](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/awesome-mcp-servers-tutorial/README.md)
  - Learn how to use punkpeye/awesome-mcp-servers as a practical control surface for discovering, vetting, and operating Model Context Protocol servers across coding, data, browser automation, and enterprise workflows.
- [awslabs/mcp Tutorial: Operating a Large-Scale MCP Server Ecosystem for AWS Workloads](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/awslabs-mcp-tutorial/README.md)
  - Learn how to use awslabs/mcp to compose, run, and govern AWS-focused MCP servers across development, infrastructure, data, and operations workflows.

## B

- [BabyAGI Tutorial: The Original Autonomous AI Task Agent Framework](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/babyagi-tutorial/README.md)
  - Learn how to use yoheinakajima/babyagi for autonomous task generation, execution, and prioritization—the foundational agent loop that started the autonomous AI agent wave.
- [Beads Tutorial: Git-Backed Task Graph Memory for Coding Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/beads-tutorial/README.md)
  - Learn how to use steveyegge/beads to give coding agents durable, dependency-aware task memory with structured issue graphs instead of ad-hoc markdown plans.
- [BentoML Tutorial: Building Production-Ready ML Services](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/bentoml-tutorial/README.md)
  - A deep technical walkthrough of BentoML covering Building Production-Ready ML Services.
- [bolt.diy Tutorial: Build and Operate an Open Source AI App Builder](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/bolt-diy-tutorial/README.md)
  - A production-focused deep dive into stackblitz-labs/bolt.diy: architecture, provider routing, safe edit loops, MCP integrations, deployment choices, and operational governance.
- [Botpress Tutorial: Open Source Conversational AI Platform](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/botpress-tutorial/README.md)
  - Important Notice (2025): Botpress v12 has been sunset and is no longer available for new deployments. However, existing customers with active v12 subscriptions remain fully supported.
- [Browser Use Tutorial: AI-Powered Web Automation Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/browser-use-tutorial/README.md)
  - Learn how to use browser-use/browser-use to build agents that can navigate websites, execute workflows, and run reliable browser automation in production.

## C

- [Chatbox Tutorial: Building Modern AI Chat Interfaces](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/chatbox-tutorial/README.md)
  - A deep technical walkthrough of Chatbox covering Building Modern AI Chat Interfaces.
- [Cherry Studio Tutorial: Multi-Provider AI Desktop Workspace for Teams](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/cherry-studio-tutorial/README.md)
  - Learn how to use CherryHQ/cherry-studio to run multi-provider AI workflows, manage assistants, and integrate MCP tools in a desktop-first productivity environment.
- [ChromaDB Tutorial: Building AI-Native Vector Databases](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/chroma-tutorial/README.md)
  - A deep technical walkthrough of ChromaDB covering Building AI-Native Vector Databases.
- [Chrome DevTools MCP Tutorial: Browser Automation and Debugging for Coding Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/chrome-devtools-mcp-tutorial/README.md)
  - Learn how to use ChromeDevTools/chrome-devtools-mcp to give coding agents reliable browser control, performance tracing, and deep debugging capabilities.
- [Cipher Tutorial: Shared Memory Layer for Coding Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/cipher-tutorial/README.md)
  - Learn how to use campfirein/cipher as a memory-centric MCP-enabled layer that preserves and shares coding context across IDEs, agents, and teams.
- [Claude Code Router Tutorial: Multi-Provider Routing and Control Plane for Claude Code](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/claude-code-router-tutorial/README.md)
  - Learn how to use musistudio/claude-code-router to route Claude Code workloads across multiple model providers with configurable routing rules, transformers, presets, and operational controls.
- [Claude Code Tutorial: Agentic Coding from Your Terminal](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/claude-code-tutorial/README.md)
  - Learn how to use anthropics/claude-code for codebase understanding, multi-file edits, command execution, git workflows, and MCP-based extension.
- [Claude Flow Tutorial: Multi-Agent Orchestration, MCP Tooling, and V3 Module Architecture](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/claude-flow-tutorial/README.md)
  - Learn how to use ruvnet/claude-flow to orchestrate multi-agent workflows, operate MCP/CLI surfaces, and reason about V2-to-V3 architecture and migration tradeoffs.
- [Claude-Mem Tutorial: Persistent Memory Compression for Claude Code](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/claude-mem-tutorial/README.md)
  - Learn how to use thedotmack/claude-mem to capture, compress, and retrieve coding-session memory with hook-driven automation, searchable context layers, and operator controls.
- [Claude Plugins Official Tutorial: Anthropic's Managed Plugin Directory](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/claude-plugins-official-tutorial/README.md)
  - Learn how to use anthropics/claude-plugins-official to discover, evaluate, install, and contribute Claude Code plugins with clear directory standards and plugin safety practices.
- [Claude Quickstarts Tutorial: Production Integration Patterns](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/claude-quickstarts-tutorial/README.md)
  - Learn from Anthropic's official quickstart projects to build deployable applications with Claude API, including customer support, data analysis, browser automation, and autonomous coding.
- [Claude Squad Tutorial: Multi-Agent Terminal Session Orchestration](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/claude-squad-tutorial/README.md)
  - Learn how to use smtg-ai/claude-squad to run and manage multiple coding-agent sessions across isolated workspaces with tmux and git worktrees.
- [Claude Task Master Tutorial: AI-Powered Task Management for Developers](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/claude-task-master-tutorial/README.md)
  - A deep technical walkthrough of Claude Task Master covering AI-Powered Task Management for Developers.
- [ClickHouse Tutorial: High-Performance Analytical Database](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/clickhouse-tutorial/README.md)
  - A deep technical walkthrough of ClickHouse covering High-Performance Analytical Database.
- [Cline Tutorial: Agentic Coding with Human Control](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/cline-tutorial/README.md)
  - A practical engineering guide to cline/cline: install, operate, and govern Cline across local development and team environments.
- [CodeMachine CLI Tutorial: Orchestrating Long-Running Coding Agent Workflows](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/codemachine-cli-tutorial/README.md)
  - Learn how to use moazbuilds/CodeMachine-CLI to orchestrate repeatable coding-agent workflows with multi-agent coordination, context control, and long-running execution.
- [Codex Analysis Platform Tutorial: Build Code Intelligence Systems](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/codex-analysis-tutorial/README.md)
  - Design and operate a production-grade code analysis platform with parsing, symbol resolution, code intelligence features, LSP integration, and rollout governance.
- [Codex CLI Tutorial: Local Terminal Agent Workflows with OpenAI Codex](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/codex-cli-tutorial/README.md)
  - Learn how to use openai/codex to run a lightweight coding agent locally, with strong controls for auth, configuration, MCP integration, and sandboxed execution.
- [ComfyUI Tutorial: Mastering AI Image Generation Workflows](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/comfyui-tutorial/README.md)
  - A deep technical walkthrough of ComfyUI covering Mastering AI Image Generation Workflows.
- [Composio Tutorial: Production Tool and Authentication Infrastructure for AI Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/composio-tutorial/README.md)
  - Learn how to use ComposioHQ/composio to connect agents to 800+ toolkits with session-aware discovery, robust authentication flows, provider integrations, MCP support, and event-trigger automation.
- [Compound Engineering Plugin Tutorial: Compounding Agent Workflows Across Toolchains](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/compound-engineering-plugin-tutorial/README.md)
  - Learn how to use EveryInc/compound-engineering-plugin to run compound engineering workflows in Claude Code and convert plugin assets for other coding-agent ecosystems.
- [Context7 Tutorial: Live Documentation Context for Coding Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/context7-tutorial/README.md)
  - Learn how to use upstash/context7 to inject up-to-date, version-aware library docs into Claude Code, Cursor, and other MCP-capable coding agents.
- [Continue Tutorial: Open-Source AI Coding Agents for IDE and CLI](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/continue-tutorial/README.md)
  - A practical guide to continuedev/continue, covering IDE usage, headless/CLI workflows, model configuration, team collaboration, and enterprise operations.
- [CopilotKit Tutorial: Building AI Copilots for React Applications](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/copilotkit-tutorial/README.md)
  - Create in-app AI assistants, chatbots, and agentic UIs with the open-source CopilotKit framework.
- [Crawl4AI Tutorial: LLM-Friendly Web Crawling for RAG Pipelines](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/crawl4ai-tutorial/README.md)
  - Deep technical walkthrough of Crawl4AI Tutorial: LLM-Friendly Web Crawling for RAG Pipelines.
- [Create Python Server Tutorial: Scaffold and Ship MCP Servers with uvx](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/create-python-server-tutorial/README.md)
  - Learn how to use modelcontextprotocol/create-python-server to scaffold Python MCP servers with minimal setup, template-driven primitives, and publish-ready packaging workflows.
- [Create TypeScript Server Tutorial: Scaffold MCP Servers with TypeScript Templates](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/create-typescript-server-tutorial/README.md)
  - Learn how to use modelcontextprotocol/create-typescript-server to scaffold MCP server projects quickly, understand generated template structure, and operate build/debug workflows safely in archived-tooling environments.
- [CrewAI Tutorial: Building Collaborative AI Agent Teams](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/crewai-tutorial/README.md)
  - CrewAI View Repo is a framework for orchestrating role-based AI agent teams that collaborate to accomplish complex tasks. It provides a structured approach to creating AI crews with specialized agents, tools, and processes, enabling sophisticated multi-agent workflows and collaborative problem-solving.
- [Crush Tutorial: Multi-Model Terminal Coding Agent with Strong Extensibility](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/crush-tutorial/README.md)
  - Learn how to use charmbracelet/crush for terminal-native coding workflows with flexible model providers, LSP/MCP integrations, and production-grade controls.

## D

- [Daytona Tutorial: Secure Sandbox Infrastructure for AI-Generated Code](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/daytona-tutorial/README.md)
  - Learn how to use daytonaio/daytona to run AI-generated code in isolated sandboxes, integrate coding agents through MCP, and operate sandbox infrastructure with stronger security and resource controls.
- [DeerFlow Tutorial: Open-Source Super Agent Harness](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/deer-flow-tutorial/README.md)
  - DeerFlow is a LangGraph-powered multi-agent runtime by ByteDance that orchestrates a lead agent, specialized sub-agents, persistent memory, sandboxed code execution, and a modular skills system to tackle complex, long-horizon research and automation tasks.
- [Devika Tutorial: Open-Source Autonomous AI Software Engineer](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/devika-tutorial/README.md)
  - Learn how to deploy and operate stitionai/devika — a multi-agent autonomous coding system that plans, researches, writes, and debugs code end-to-end.
- [Dify Platform: Deep Dive Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/dify-tutorial/README.md)
  - Dify — An open-source LLM application development platform for building workflows, RAG pipelines, and AI agents with a visual interface.
- [DSPy Tutorial: Programming Language Models](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/dspy-tutorial/README.md)
  - Learn to program language models declaratively with DSPy, the Stanford NLP framework for systematic prompt optimization and modular LLM pipelines.
- [Dyad Tutorial: Local-First AI App Building](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/dyad-tutorial/README.md)
  - A practical guide to dyad-sh/dyad, focused on local-first app generation, integration patterns, validation loops, and deployment readiness.

## E

- [E2B Tutorial: Secure Cloud Sandboxes for AI Agent Code Execution](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/e2b-tutorial/README.md)
  - Learn how to use e2b-dev/E2B to give AI agents secure, sandboxed cloud environments for code execution with sub-200ms cold starts.
- [ElizaOS: Deep Dive Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/elizaos-tutorial/README.md)
  - ElizaOS — Autonomous agents for everyone.
- [Everything Claude Code Tutorial: Production Configuration Patterns for Claude Code](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/everything-claude-code-tutorial/README.md)
  - Learn how to use affaan-m/everything-claude-code to adopt battle-tested Claude Code agents, skills, hooks, commands, rules, and MCP workflows in a structured, production-oriented way.

## F

- [Fabric Tutorial: Open-Source Framework for Augmenting Humans with AI](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/fabric-tutorial/README.md)
  - Enhance human capabilities with Fabric's modular framework for AI-powered cognitive assistance and task automation.
- [FastMCP Tutorial: Building and Operating MCP Servers with Pythonic Control](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/fastmcp-tutorial/README.md)
  - Learn how to use jlowin/fastmcp to design, run, test, and deploy MCP servers and clients with practical transport, integration, auth, and operations patterns.
- [Figma Context MCP Tutorial: Design-to-Code Workflows for Coding Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/figma-context-mcp-tutorial/README.md)
  - Learn how to use GLips/Figma-Context-MCP (Framelink MCP for Figma) to give coding agents structured design context for higher-fidelity implementation.
- [Firecrawl MCP Server Tutorial: Web Scraping and Search Tools for MCP Clients](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/firecrawl-mcp-server-tutorial/README.md)
  - Learn how to use firecrawl/firecrawl-mcp-server to add robust web scraping, crawling, search, and extraction capabilities to MCP-enabled coding and research agents.
- [Firecrawl Tutorial: Building LLM-Ready Web Scraping and Data Extraction Systems](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/firecrawl-tutorial/README.md)
  - Deep technical walkthrough of Firecrawl Tutorial: Building LLM-Ready Web Scraping and Data Extraction Systems.
- [Fireproof Tutorial: Local-First Document Database for AI-Native Apps](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/fireproof-tutorial/README.md)
  - Learn how to use fireproof-storage/fireproof to build local-first, encrypted, sync-capable applications with a unified browser/Node/Deno API and React hooks.
- [Flowise LLM Orchestration: Deep Dive Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/flowise-tutorial/README.md)
  - Flowise — An open-source visual tool for building LLM workflows with a drag-and-drop interface.

## G

- [GitHub Copilot CLI Tutorial: Copilot Agent Workflows in the Terminal](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/copilot-cli-tutorial/README.md)
  - Learn how to use github/copilot-cli to run Copilot's coding agent directly from the terminal with GitHub-native context, approval controls, and extensibility through MCP and LSP.
- [Gemini CLI Tutorial: Terminal-First Agent Workflows with Google Gemini](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/gemini-cli-tutorial/README.md)
  - Learn how to use google-gemini/gemini-cli to run coding and operations workflows in terminal-first loops with strong tooling, MCP extensibility, headless automation, and safety controls.
- [GenAI Toolbox Tutorial: MCP-First Database Tooling with Config-Driven Control Planes](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/genai-toolbox-tutorial/README.md)
  - Learn how to use googleapis/genai-toolbox to expose database tools through MCP and native SDK paths, with stronger configuration discipline, deployment options, and observability controls.
- [GitHub MCP Server Tutorial: Production GitHub Operations Through MCP](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/github-mcp-server-tutorial/README.md)
  - Learn how to use github/github-mcp-server to connect coding agents directly to repositories, issues, pull requests, actions, and code security workflows with stronger control.
- [Goose Tutorial: Extensible Open-Source AI Agent for Real Engineering Work](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/goose-tutorial/README.md)
  - Learn how to use block/goose to automate coding workflows with controlled tool execution, strong provider flexibility, and production-ready operations.
- [GPT Open Source: Deep Dive Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/gpt-oss-tutorial/README.md)
  - A comprehensive guide to understanding, building, and deploying open-source GPT implementations -- from nanoGPT to GPT-NeoX and beyond.
- [gptme Tutorial: Open-Source Terminal Agent for Local Tool-Driven Work](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/gptme-tutorial/README.md)
  - Learn how to use gptme/gptme to run a local-first coding and knowledge-work agent with strong CLI ergonomics, extensible tools, and automation-friendly modes.

## H

- [HAPI Tutorial: Remote Control for Local AI Coding Sessions](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/hapi-tutorial/README.md)
  - Learn tiann/hapi, a local-first hub that lets you run Claude Code/Codex/Gemini/OpenCode sessions locally while controlling and approving them remotely.
- [Haystack: Deep Dive Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/haystack-tutorial/README.md)
  - Haystack — An open-source framework for building production-ready LLM applications, RAG pipelines, and intelligent search systems.
- [Hermes Agent Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/hermes-agent-tutorial/README.md)
  - NousResearch's self-hosted personal AI agent with persistent memory, autonomous skill creation, 20+ platform gateway, and a closed reinforcement-learning loop that turns every conversation into fine-tuning data.
- [HuggingFace Transformers Tutorial: Building State-of-the-Art AI Models](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/huggingface-tutorial/README.md)
  - A deep technical walkthrough of HuggingFace Transformers covering Building State-of-the-Art AI Models.
- [HumanLayer Tutorial: Context Engineering and Human-Governed Coding Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/humanlayer-tutorial/README.md)
  - Learn how to use humanlayer/humanlayer patterns to orchestrate coding agents with stronger context control, human oversight, and team-scale workflows.

## I

- [Instructor Tutorial: Structured LLM Outputs](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/instructor-tutorial/README.md)
  - Get reliable, typed responses from LLMs with Pydantic validation.

## K

- [Khoj AI: Deep Dive Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/khoj-tutorial/README.md)
  - Khoj — An open-source, self-hostable AI personal assistant that connects to your notes, documents, and online data.
- [Kilo Code Tutorial: Agentic Engineering from IDE and CLI Surfaces](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/kilocode-tutorial/README.md)
  - Learn how to use Kilo-Org/kilocode for high-throughput coding workflows with multi-mode operation, agent-loop controls, and extensible CLI/IDE integration.
- [Kimi CLI Tutorial: Multi-Mode Terminal Agent with MCP and ACP](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/kimi-cli-tutorial/README.md)
  - Learn how to use MoonshotAI/kimi-cli to run an interactive terminal coding agent with configurable modes, MCP integrations, and ACP-based IDE connectivity.
- [Kiro Tutorial: Spec-Driven Agentic IDE from AWS](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/kiro-tutorial/README.md)
  - Learn how to use kirodotdev/Kiro for structured AI-powered development with spec-driven workflows, agent steering, event-driven automation, and AWS-native integrations.
- [Kubernetes Operator Patterns: Building Production-Grade Controllers](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/kubernetes-operator-tutorial/README.md)
  - Master Kubernetes Operators with hands-on Go implementation using the Operator SDK and controller-runtime library for enterprise application management.

## L

- [LanceDB Tutorial: Serverless Vector Database for AI](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/lancedb-tutorial/README.md)
  - Master LanceDB, the open-source serverless vector database designed for AI applications, RAG systems, and semantic search.
- [LangChain Architecture: Internal Design Deep Dive](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/langchain-architecture-tutorial/README.md)
  - Deep technical walkthrough of LangChain Architecture: Internal Design Deep Dive.
- [LangChain Tutorial: Building AI Applications with Large Language Models](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/langchain-tutorial/README.md)
  - Pydantic 2 Required: LangChain v0.3 fully migrated to Pydantic 2. Code using langchain_core.pydantic_v1 should be updated to native Pydantic 2 syntax.
- [Langflow Tutorial: Visual AI Agent and Workflow Platform](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/langflow-tutorial/README.md)
  - Learn how to build, deploy, and operate agent workflows with langflow-ai/langflow, including visual flow composition, API/MCP deployment, and production reliability controls.
- [Langfuse Tutorial: LLM Observability, Evaluation, and Prompt Operations](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/langfuse-tutorial/README.md)
  - Learn how to use langfuse/langfuse to trace, evaluate, and improve production LLM systems with structured observability workflows.
- [LangGraph Tutorial: Building Stateful Multi-Actor Applications](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/langgraph-tutorial/README.md)
  - A deep technical walkthrough of LangGraph covering Building Stateful Multi-Actor Applications.
- [Letta Tutorial: Stateful LLM Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/letta-tutorial/README.md)
  - Build AI agents with persistent memory using the framework formerly known as MemGPT.
- [LiteLLM Tutorial: Unified LLM Gateway and Routing Layer](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/litellm-tutorial/README.md)
  - Build provider-agnostic LLM applications with BerriAI/litellm, including routing, fallbacks, proxy deployment, and cost-aware operations.
- [Liveblocks - Real-Time Collaboration Deep Dive](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/liveblocks-tutorial/README.md)
  - Deep technical walkthrough of Liveblocks - Real-Time Collaboration Deep Dive.
- [llama.cpp Tutorial: Local LLM Inference](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/llama-cpp-tutorial/README.md)
  - Run large language models efficiently on your local machine with pure C/C++.
- [LLaMA-Factory Tutorial: Unified Framework for LLM Training and Fine-tuning](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/llama-factory-tutorial/README.md)
  - A deep technical walkthrough of LLaMA-Factory covering Unified Framework for LLM Training and Fine-tuning.
- [LlamaIndex Tutorial: Building Advanced RAG Systems and Data Frameworks](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/llamaindex-tutorial/README.md)
  - A deep technical walkthrough of LlamaIndex covering Building Advanced RAG Systems and Data Frameworks.
- [LobeChat AI Platform: Deep Dive Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/lobechat-tutorial/README.md)
  - LobeChat — An open-source, modern-design AI chat framework for building private LLM applications.
- [LocalAI Tutorial: Self-Hosted OpenAI Alternative](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/localai-tutorial/README.md)
  - Run LLMs, image generation, and audio models locally with an OpenAI-compatible API.
- [Logseq: Deep Dive Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/logseq-tutorial/README.md)
  - Logseq — A privacy-first, local-first knowledge management platform with block-based editing and graph visualization.

## M

- [Microsoft AutoGen Tutorial: Building Multi-Agent AI Systems](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/autogen-tutorial/README.md)
  - A deep technical walkthrough of Microsoft AutoGen covering Building Multi-Agent AI Systems.
- [Mastra Tutorial: TypeScript Framework for AI Agents and Workflows](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mastra-tutorial/README.md)
  - Learn how to build production AI applications with mastra-ai/mastra, including agents, workflows, memory, MCP tooling, and reliability operations.
- [MCP Chrome Tutorial: Control Your Real Chrome Browser Through MCP](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-chrome-tutorial/README.md)
  - Learn how to use hangwin/mcp-chrome to expose browser automation, content analysis, and semantic tab search tools to MCP clients.
- [MCP C# SDK Tutorial: Production MCP in .NET with Hosting, ASP.NET Core, and Task Workflows](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-csharp-sdk-tutorial/README.md)
  - Learn how to build and operate MCP clients and servers with modelcontextprotocol/csharp-sdk, including package choices, auth patterns, tasks, diagnostics, and versioning strategy.
- [MCP Docs Repo Tutorial: Navigating the Archived MCP Documentation Repository](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-docs-repo-tutorial/README.md)
  - Learn how to use modelcontextprotocol/docs as an archived reference, map its conceptual guides, and migrate documentation workflows to the canonical modelcontextprotocol/modelcontextprotocol docs location.
- [MCP Ext Apps Tutorial: Building Interactive MCP Apps and Hosts](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-ext-apps-tutorial/README.md)
  - Learn how to use modelcontextprotocol/ext-apps to build interactive MCP Apps, wire host bridges, secure UI resources, and run reliable testing and migration workflows.
- [MCP Go SDK Tutorial: Building Robust MCP Clients and Servers in Go](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-go-sdk-tutorial/README.md)
  - Learn how to use modelcontextprotocol/go-sdk for production MCP workloads across stdio and streamable HTTP, including auth middleware, conformance, and upgrade planning.
- [MCP Inspector Tutorial: Debugging and Validating MCP Servers](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-inspector-tutorial/README.md)
  - Learn how to use modelcontextprotocol/inspector to test MCP servers across stdio, SSE, and streamable HTTP, with safer auth defaults and repeatable CLI automation.
- [MCP Java SDK Tutorial: Building MCP Clients and Servers with Reactor, Servlet, and Spring](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-java-sdk-tutorial/README.md)
  - Learn how to use modelcontextprotocol/java-sdk across core Java and Spring stacks, from transport setup to conformance and production hardening.
- [MCP Kotlin SDK Tutorial: Building Multiplatform MCP Clients and Servers](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-kotlin-sdk-tutorial/README.md)
  - Learn how to implement MCP client/server workflows with modelcontextprotocol/kotlin-sdk, including module boundaries, transport choices, capability negotiation, and production lifecycle controls.
- [MCP PHP SDK Tutorial: Building MCP Servers in PHP with Discovery and Transport Flexibility](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-php-sdk-tutorial/README.md)
  - Learn how to implement MCP server workflows with modelcontextprotocol/php-sdk, including attribute discovery, manual capability registration, transport strategy, session storage, and framework integration patterns.
- [MCP Python SDK Tutorial: Building AI Tool Servers](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-python-sdk-tutorial/README.md)
  - Master the Model Context Protocol Python SDK to build custom tool servers that extend Claude and other LLMs with powerful capabilities.
- [MCP Quickstart Resources Tutorial: Cross-Language MCP Servers and Clients by Example](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-quickstart-resources-tutorial/README.md)
  - Learn how to use modelcontextprotocol/quickstart-resources as a practical reference for multi-language MCP server/client implementations, protocol smoke testing, and onboarding workflows.
- [MCP Registry Tutorial: Publishing, Discovery, and Governance for MCP Servers](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-registry-tutorial/README.md)
  - Learn how modelcontextprotocol/registry works end to end: publishing authenticated server metadata, consuming the API as an aggregator, and operating registry infrastructure safely.
- [MCP Ruby SDK Tutorial: Building MCP Servers and Clients in Ruby](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-ruby-sdk-tutorial/README.md)
  - Learn how to implement MCP server/client workflows with modelcontextprotocol/ruby-sdk, including tool/prompt/resource registration, streamable HTTP sessions, structured logging, and release operations.
- [MCP Rust SDK Tutorial: Building High-Performance MCP Services with RMCP](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-rust-sdk-tutorial/README.md)
  - Learn how to use modelcontextprotocol/rust-sdk (rmcp) for production MCP clients and servers with strong transport control, macro-driven tooling, OAuth, and async task workflows.
- [MCP Servers Tutorial: Reference Implementations and Patterns](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-servers-tutorial/README.md)
  - Learn how to use the official MCP reference servers as implementation blueprints, not drop-in production services.
- [MCP Specification Tutorial: Designing Production-Grade MCP Clients and Servers From the Source of Truth](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-specification-tutorial/README.md)
  - Learn the current Model Context Protocol directly from modelcontextprotocol/modelcontextprotocol, including lifecycle, transports, security, authorization, and governance workflows.
- [MCP Swift SDK Tutorial: Building MCP Clients and Servers in Swift](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-swift-sdk-tutorial/README.md)
  - Learn how to implement MCP client and server workflows with modelcontextprotocol/swift-sdk, including transport options, sampling, batching, and graceful service lifecycle control.
- [MCP TypeScript SDK Tutorial: Building and Migrating MCP Clients and Servers in TypeScript](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-typescript-sdk-tutorial/README.md)
  - Learn how to use modelcontextprotocol/typescript-sdk to build production MCP clients and servers, migrate from v1 to v2 safely, and validate behavior with conformance workflows.
- [MCP Use Tutorial: Full-Stack MCP Development Across Agents, Clients, Servers, and Inspector](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcp-use-tutorial/README.md)
  - Learn how mcp-use/mcp-use composes agent, client, server, and inspector workflows across Python and TypeScript with practical security and operations patterns.
- [MCPB Tutorial: Packaging and Distributing Local MCP Servers as Bundles](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mcpb-tutorial/README.md)
  - Learn how to use modelcontextprotocol/mcpb to package local MCP servers into signed .mcpb bundles with manifest metadata, CLI workflows, and distribution-ready operational controls.
- [MeiliSearch Tutorial: Lightning Fast Search Engine](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/meilisearch-tutorial/README.md)
  - A deep technical walkthrough of MeiliSearch covering Lightning Fast Search Engine.
- [Mem0 Tutorial: Building Production-Ready AI Agents with Scalable Long-Term Memory](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mem0-tutorial/README.md)
  - A deep technical walkthrough of Mem0 covering Building Production-Ready AI Agents with Scalable Long-Term Memory.
- [MetaGPT Tutorial: Multi-Agent Software Development with Role-Based Collaboration](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/metagpt-tutorial/README.md)
  - In one sentence: Give MetaGPT a product idea, and a virtual software company of AI agents designs, architects, codes, and tests it for you.
- [Mini-SWE-Agent Tutorial: Minimal Autonomous Code Agent Design at Benchmark Scale](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mini-swe-agent-tutorial/README.md)
  - Learn how to use SWE-agent/mini-swe-agent to run compact, high-performing software-engineering agent workflows with minimal scaffolding and strong reproducibility.
- [Mistral Vibe Tutorial: Minimal CLI Coding Agent by Mistral](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/mistral-vibe-tutorial/README.md)
  - Learn how to use mistralai/mistral-vibe for terminal-native coding workflows with configurable agent profiles, skills, subagents, and ACP integrations.

## N

- [n8n AI Tutorial: Workflow Automation with AI](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/n8n-ai-tutorial/README.md)
  - Build powerful AI-powered automations with n8n's visual workflow builder.
- [n8n Model Context Protocol: Deep Dive Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/n8n-mcp-tutorial/README.md)
  - n8n — Visual workflow automation with Model Context Protocol (MCP) integration for AI-powered tool use.
- [Nanocoder Tutorial: Building and Understanding AI Coding Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/nanocoder-tutorial/README.md)
  - Learn how Nano-Collective/nanocoder implements local-first coding-agent workflows, tool execution loops, and multi-provider model integration.
- [NocoDB: Deep Dive Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/nocodb-tutorial/README.md)
  - NocoDB — An open-source Airtable alternative that turns any database into a smart spreadsheet.

## O

- [Obsidian Outliner Plugin: Deep Dive Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/obsidian-outliner-tutorial/README.md)
  - Obsidian Outliner — A plugin that adds outliner-style editing behaviors to Obsidian, demonstrating advanced plugin architecture patterns.
- [Ollama Tutorial: Running and Serving LLMs Locally](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/ollama-tutorial/README.md)
  - Learn how to use ollama/ollama for local model execution, customization, embeddings/RAG, integration, and production deployment.
- [Onlook Tutorial: Visual-First AI Coding for Next.js and Tailwind](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/onlook-tutorial/README.md)
  - Learn how to use onlook-dev/onlook to design and edit production-grade React apps visually while keeping generated code in your repository.
- [Opcode Tutorial: GUI Command Center for Claude Code Workflows](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/opcode-tutorial/README.md)
  - Learn how to use winfunc/opcode to manage Claude Code projects, sessions, agents, MCP servers, and checkpoints from a desktop-first operating interface.
- [Open SWE Tutorial: Asynchronous Cloud Coding Agent Architecture and Migration Playbook](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/open-swe-tutorial/README.md)
  - Learn from langchain-ai/open-swe architecture, workflows, and operational patterns, including how to maintain or migrate from a deprecated codebase.
- [Open WebUI Tutorial: Self-Hosted AI Workspace and Chat Interface](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/open-webui-tutorial/README.md)
  - Learn how to run and operate open-webui/open-webui as a self-hosted AI interface with model routing, RAG workflows, multi-user controls, and production deployment patterns.
- [OpenAI Agents Tutorial: Building Production Multi-Agent Systems](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/openai-agents-tutorial/README.md)
  - Production Successor to Swarm: The OpenAI Agents SDK brings Swarm's lightweight agent-handoff philosophy into a production-grade framework with built-in tracing, guardrails, and streaming.
- [OpenAI Python SDK Tutorial: Production API Patterns](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/openai-python-sdk-tutorial/README.md)
  - Learn how to build reliable Python integrations with openai/openai-python using Responses-first architecture, migration-safe patterns, and production operations.
- [OpenAI Realtime Agents Tutorial: Voice-First AI Systems](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/openai-realtime-agents-tutorial/README.md)
  - Learn how to build low-latency voice agents with openai/openai-realtime-agents, including realtime session design, tool orchestration, and production rollout patterns.
- [OpenAI Whisper Tutorial: Speech Recognition and Translation](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/openai-whisper-tutorial/README.md)
  - Build robust transcription pipelines with Whisper, from local experiments to production deployment.
- [OpenBB Tutorial: Complete Guide to Investment Research Platform](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/openbb-tutorial/README.md)
  - Democratize investment research with OpenBB's comprehensive financial data and analysis platform.
- [OpenClaw: Deep Dive Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/openclaw-tutorial/README.md)
  - OpenClaw — Your own personal AI assistant. Any OS. Any Platform.
- [OpenCode AI Legacy Tutorial: Archived Terminal Agent Workflows and Migration to Crush](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/opencode-ai-legacy-tutorial/README.md)
  - Learn from opencode-ai/opencode architecture and workflows, and migrate safely to actively maintained successors.
- [OpenCode Tutorial: Open-Source Terminal Coding Agent at Scale](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/opencode-tutorial/README.md)
  - Learn how to use anomalyco/opencode to run terminal-native coding agents with provider flexibility, strong tool control, and production-grade workflows.
- [OpenHands Tutorial: Autonomous Software Engineering Workflows](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/openhands-tutorial/README.md)
  - Learn how to operate OpenHands/OpenHands across local GUI, CLI, and SDK workflows with production-minded safety, validation, and integration patterns.
- [OpenSkills Tutorial: Universal Skill Loading for Coding Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/openskills-tutorial/README.md)
  - Learn how to use numman-ali/openskills to install, synchronize, and operate reusable SKILL.md packs across Claude Code, Cursor, Codex, Aider, and other agent environments.
- [OpenSpec Tutorial: Spec-Driven Workflows for AI Coding Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/openspec-tutorial/README.md)
  - Learn how to use Fission-AI/OpenSpec to make AI-assisted software delivery more predictable with artifact-driven planning, implementation, and archival workflows.
- [OpenSrc Tutorial: Deep Source Context for Coding Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/opensrc-tutorial/README.md)
  - Learn how to use vercel-labs/opensrc to fetch package and repository source code so coding agents can reason about implementation details, not only public types and docs.
- [Outlines Tutorial: Structured Text Generation with LLMs](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/outlines-tutorial/README.md)
  - A deep technical walkthrough of Outlines covering Structured Text Generation with LLMs.
- [OpenAI Swarm Tutorial: Lightweight Multi-Agent Orchestration](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/swarm-tutorial/README.md)
  - Deep technical walkthrough of OpenAI Swarm Tutorial: Lightweight Multi-Agent Orchestration.

## P

- [Perplexica Tutorial: AI-Powered Search Engine](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/perplexica-tutorial/README.md)
  - A deep technical walkthrough of Perplexica covering AI-Powered Search Engine.
- [Phidata Tutorial: Building Autonomous AI Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/phidata-tutorial/README.md)
  - A deep technical walkthrough of Phidata covering Building Autonomous AI Agents.
- [PhotoPrism Tutorial: AI-Powered Photos App](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/photoprism-tutorial/README.md)
  - AI Photo Management Revolution: Enhanced facial recognition, LLM integrations, and advanced organization features mark PhotoPrism's evolution.
- [Plandex Tutorial: Large-Task AI Coding Agent Workflows](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/plandex-tutorial/README.md)
  - Learn how to use plandex-ai/plandex for large codebase tasks with strong context management, cumulative diff review, model packs, and self-hosted operations.
- [Plane Tutorial: AI-Native Project Management](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/plane-tutorial/README.md)
  - Open-source AI-native project management that rivals Jira and Linear — with issues, cycles, modules, and wiki built in.
- [Planning with Files Tutorial: Persistent Markdown Workflow Memory for AI Coding Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/planning-with-files-tutorial/README.md)
  - Learn how to use OthmanAdi/planning-with-files to run Manus-style file-based planning workflows across Claude Code and other AI coding environments.
- [Playwright MCP Tutorial: Browser Automation for Coding Agents Through MCP](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/playwright-mcp-tutorial/README.md)
  - Learn how to use microsoft/playwright-mcp to give AI coding agents structured browser automation with accessibility snapshots, deterministic actions, and portable MCP host integrations.
- [PocketFlow Tutorial: Minimal LLM Framework with Graph-Based Power](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/pocketflow-tutorial/README.md)
  - Learn how to build agentic applications with The-Pocket/PocketFlow, a minimalist graph framework that still supports workflows, multi-agent patterns, RAG, and human-in-the-loop flows.
- [PostgreSQL Query Planner Deep Dive](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/postgresql-tutorial/README.md)
  - Master PostgreSQL's query execution engine, understand EXPLAIN output, and optimize complex queries for maximum performance.
- [PostHog Tutorial: Open Source Product Analytics Platform](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/posthog-tutorial/README.md)
  - Deep technical walkthrough of PostHog Tutorial: Open Source Product Analytics Platform.
- [Pydantic AI Tutorial: Type-Safe AI Agent Development](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/pydantic-ai-tutorial/README.md)
  - A deep technical walkthrough of Pydantic AI covering Type-Safe AI Agent Development.

## Q

- [Quivr Tutorial: Open-Source RAG Framework for Document Ingestion](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/quivr-tutorial/README.md)
  - Deep technical walkthrough of Quivr Tutorial: Open-Source RAG Framework for Document Ingestion.
- [Qwen-Agent Tutorial: Tool-Enabled Agent Framework with MCP, RAG, and Multi-Modal Workflows](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/qwen-agent-tutorial/README.md)
  - Learn how to use QwenLM/Qwen-Agent to build production-capable agents with function calling, MCP integration, memory/RAG patterns, and benchmark-aware planning workflows.

## R

- [RAGFlow Tutorial: Complete Guide to Open-Source RAG Engine](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/ragflow-tutorial/README.md)
  - Transform documents into intelligent Q&A systems with RAGFlow's comprehensive RAG (Retrieval-Augmented Generation) platform.
- [React Fiber Internals](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/react-fiber-tutorial/README.md)
  - Deep dive into React's reconciliation algorithm, the Fiber architecture that powers modern React applications.
- [Refly Tutorial: Build Deterministic Agent Skills and Ship Them Across APIs and Claude Code](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/refly-tutorial/README.md)
  - Learn how to use refly-ai/refly to turn vibe workflows into reusable, versioned agent skills that can run via API, webhook, and CLI integrations.
- [Roo Code Tutorial: Run an AI Dev Team in Your Editor](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/roo-code-tutorial/README.md)
  - A production-focused guide to RooCodeInc/Roo-Code: mode design, task execution, checkpoints, MCP, team profiles, and enterprise operations.

## S

- [Semantic Kernel Tutorial: Microsoft's AI Orchestration](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/semantic-kernel-tutorial/README.md)
  - Build enterprise AI applications with Microsoft's SDK for integrating LLMs.
- [Serena Tutorial: Semantic Code Retrieval Toolkit for Coding Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/serena-tutorial/README.md)
  - Learn how to use oraios/serena to give coding agents IDE-grade semantic retrieval and editing tools across large codebases.
- [Shotgun Tutorial: Spec-Driven Development for Coding Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/shotgun-tutorial/README.md)
  - Learn how to use shotgun-sh/shotgun to plan, specify, and execute large code changes with structured agent workflows and stronger delivery control.
- [SillyTavern Tutorial: Advanced LLM Frontend for Power Users](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/sillytavern-tutorial/README.md)
  - Unlock the full potential of large language models with SillyTavern's comprehensive interface for role-playing, creative writing, and AI experimentation.
- [SiYuan Tutorial: Privacy-First Knowledge Management](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/siyuan-tutorial/README.md)
  - A deep technical walkthrough of SiYuan covering Privacy-First Knowledge Management.
- [Smolagents Tutorial: Hugging Face's Lightweight Agent Framework](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/smolagents-tutorial/README.md)
  - Build efficient AI agents with minimal code using Hugging Face's smolagents library.
- [Stagewise Tutorial: Frontend Coding Agent Workflows in Real Browser Context](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/stagewise-tutorial/README.md)
  - Learn how to use stagewise-io/stagewise to connect browser-selected UI context with coding agents, plugin extensions, and multi-agent bridge workflows.
- [Strands Agents Tutorial: Model-Driven Agent Systems with Native MCP Support](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/strands-agents-tutorial/README.md)
  - Learn how to use strands-agents/sdk-python to build lightweight, model-driven agents with strong tool abstractions, hooks, and production deployment patterns.
- [Supabase Tutorial: Building Modern Backend Applications](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/supabase-tutorial/README.md)
  - Deep technical walkthrough of Supabase Tutorial: Building Modern Backend Applications.
- [SuperAGI Tutorial: Production-Ready Autonomous AI Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/superagi-tutorial/README.md)
  - A deep technical walkthrough of SuperAGI covering Production-Ready Autonomous AI Agents.
- [Superset Terminal Tutorial: Command Center for Parallel Coding Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/superset-terminal-tutorial/README.md)
  - Learn how to use superset-sh/superset to orchestrate many coding agents in parallel with worktree isolation, centralized monitoring, and fast review loops.
- [SWE-agent Tutorial: Autonomous Repository Repair and Benchmark-Driven Engineering](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/swe-agent-tutorial/README.md)
  - Learn how to use SWE-agent/SWE-agent for autonomous software engineering workflows, from single-issue runs to benchmark and research-grade evaluation.
- [Sweep Tutorial: Issue-to-PR AI Coding Workflows on GitHub](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/sweep-tutorial/README.md)
  - Learn how to use sweepai/sweep to turn GitHub issues into pull requests, operate feedback loops, and run self-hosted or CLI workflows with clear guardrails.

## T

- [Tabby Tutorial: Self-Hosted AI Coding Assistant Architecture and Operations](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/tabby-tutorial/README.md)
  - Learn how to run and extend TabbyML/tabby for production code completion and team knowledge workflows.
- [Taskade Awesome Vibe Coding Tutorial: Curating the 2026 AI-Building Landscape](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/taskade-awesome-vibe-coding-tutorial/README.md)
  - Learn how to use and maintain taskade/awesome-vibe-coding as a decision system for AI app builders, coding agents, MCP tooling, and Genesis-centered workflows.
- [Taskade Docs Tutorial: Operating the Living-DNA Documentation Stack](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/taskade-docs-tutorial/README.md)
  - Learn how taskade/docs structures product documentation across Genesis, API references, automations, help-center workflows, and release timelines.
- [Taskade MCP Tutorial: OpenAPI-Driven MCP Server for Taskade Workflows](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/taskade-mcp-tutorial/README.md)
  - Learn how to run, extend, and operate taskade/mcp to connect Taskade workspaces, tasks, projects, and AI agents into MCP-compatible clients.
- [Taskade Tutorial: AI-Native Workspace, Genesis, and Agentic Operations](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/taskade-tutorial/README.md)
  - Learn how to operate Taskade as an AI-native workspace system: Genesis app generation, AI agents, automations, enterprise controls, and production rollout patterns.
- [Teable: Deep Dive Tutorial](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/teable-tutorial/README.md)
  - Teable — A high-performance, multi-dimensional database platform built on PostgreSQL with real-time collaboration.
- [tiktoken Tutorial: OpenAI Token Encoding & Optimization](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/tiktoken-tutorial/README.md)
  - Master tiktoken, OpenAI's fast BPE tokenizer, to accurately count tokens, optimize prompts, and reduce API costs.
- [tldraw Tutorial: Infinite Canvas SDK with AI-Powered "Make Real" App Generation](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/tldraw-tutorial/README.md)
  - Learn how to use tldraw/tldraw to build, customize, and extend an infinite canvas — from embedding the editor and creating custom shapes to integrating the "make-real" AI feature that generates working applications from whiteboard sketches.
- [Turborepo Tutorial: High-Performance Monorepo Build System](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/turborepo-tutorial/README.md)
  - A deep technical walkthrough of Turborepo covering High-Performance Monorepo Build System.

## U

- [use-mcp Tutorial: React Hook Patterns for MCP Client Integration](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/use-mcp-tutorial/README.md)
  - Learn how to use modelcontextprotocol/use-mcp to connect React apps to MCP servers with OAuth-aware flows, tool/resource/prompt access, and resilient transport lifecycle handling.

## V

- [Vercel AI SDK Tutorial: Production TypeScript AI Apps and Agents](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/vercel-ai-tutorial/README.md)
  - Build robust AI product features with vercel/ai, including streaming, structured outputs, tool loops, framework integration, and production deployment patterns.
- [Vibe Kanban Tutorial: Multi-Agent Orchestration Board for Coding Workflows](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/vibe-kanban-tutorial/README.md)
  - Learn how to use BloopAI/vibe-kanban to coordinate Claude Code, Codex, Gemini CLI, and other coding agents through a unified orchestration workspace.
- [VibeSDK Tutorial: Build a Vibe-Coding Platform on Cloudflare](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/vibesdk-tutorial/README.md)
  - Learn how to use cloudflare/vibesdk to run a prompt-to-app platform with agent orchestration, preview sandboxes, and production deployment on Cloudflare.
- [vLLM Tutorial: High-Performance LLM Inference](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/vllm-tutorial/README.md)
  - Master vLLM for blazing-fast, cost-effective large language model inference with advanced optimization techniques.

## W

- [Whisper.cpp Tutorial: High-Performance Speech Recognition in C/C++](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/whisper-cpp-tutorial/README.md)
  - A deep technical walkthrough of Whisper.cpp covering High-Performance Speech Recognition in C/C++.
- [Windmill Tutorial: Scripts to Webhooks, Workflows, and UIs](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/windmill-tutorial/README.md)
  - Turn scripts into production-ready webhooks, workflows, and internal tools with Windmill -- the open-source alternative to Retool + Temporal.
- [Wshobson Agents Tutorial: Pluginized Multi-Agent Workflows for Claude Code](https://github.com/johnxie/awesome-code-docs/blob/main/tutorials/wshobson-agents-tutorial/README.md)
  - Learn how to use wshobson/agents to install focused Claude Code plugins, coordinate specialist agents, and run scalable multi-agent workflows with clear model and skill boundaries.

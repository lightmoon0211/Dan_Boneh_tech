# Model serving and hardware

## Chosen roles

The project uses the user's requested four repositories exactly. Report tasks reuse conversation; planner and control proposals reuse code. This is a deployment choice based on function separation, not a claim that these models have been benchmarked as universally best for CNC control.

| Physical service | Repository | Host profile | GPU IDs | TP | Context cap |
|---|---|---|---|---:|---:|
| conversation | Qwen/Qwen3.8-27B | server-a | 0 | 1 | 32768 |
| safety | ibm-granite/granite-guardian-4.1-8b | server-a | 1 | 1 | 32768 |
| embedding | Qwen/Qwen3-Embedding-4B | server-a | 2 | 1 | 8192 |
| code | Qwen/Qwen3-Coder-Next | server-b | 0,1 | 2 | 32768 |

The conversation card describes a 27B model with controllable thinking; this implementation disables thinking and retained thinking for predictable structured answers. It supplies textual RAG evidence, not image/video inputs. [Qwen3.8 model card](https://huggingface.co/Qwen/Qwen3.8-27B).

The coding model has 80B total parameters; sparse activation does not make its weights equivalent to a small dense model. The included TP2 configuration and reduced context follow the provider's serving pattern. No generated NC/robot program is certified or executed. [Qwen3-Coder-Next model card](https://huggingface.co/Qwen/Qwen3-Coder-Next).

Embedding requests use an instruction for queries and 1024-dimensional vectors with validated lengths, indices and finite values. The embedding service runs vLLM's pooling runner, not a chat endpoint. [Embedding model card](https://huggingface.co/Qwen/Qwen3-Embedding-4B), [vLLM pooling documentation](https://docs.vllm.ai/en/stable/models/pooling_models/).

Guardian 4.1 receives a final user judge-instruction block containing criteria and a scoring schema. The parser accepts only a well-formed yes/no score after optional thinking tags. Here **yes means the configured risk criterion matched** and blocks the draft. This differs from old Guardian 3.3 examples using `guardian_config`; those are not used. Documents may be supplied through the 4.1 chat template's document context. [Guardian 4.1 model card](https://huggingface.co/ibm-granite/granite-guardian-4.1-8b).

## Inference environment

`requirements/h200.txt` pins vLLM 0.28.0 as the staging candidate and requires Transformers 5.8 or later. This avoids treating the coding model's older minimum vLLM version as sufficient for every newer model. The official Qwen3.8 recipe calls out the newer processor dependency. The full CUDA/PyTorch/vLLM combination must be validated on the actual H200 servers, then frozen and transferred as a tested environment. [Qwen3.8 serving recipe](https://recipes.vllm.ai/Qwen/Qwen3.8-27B), [vLLM releases](https://pypi.org/project/vllm/).

All schema-constrained calls use `response_format` with a JSON schema. Validate that your chosen inference build accepts the exact schema contracts with the installation smoke test and factory acceptance prompts. A server merely advertising a model is not sufficient. [vLLM structured outputs](https://docs.vllm.ai/en/stable/features/structured_outputs/).

The launcher sets offline model resolution, disables usage telemetry, assigns host-local CUDA devices, captures each service's logs and reads API keys through the environment. API keys do not appear in the launch command. [vLLM environment configuration](https://docs.vllm.ai/en/stable/configuration/env_vars/).

## Sizing guidance

These are planning estimates; no GPU memory or throughput benchmark was performed in the build environment.

- Windows development: 4 or more CPU cores, 16 GB RAM minimum, 32 GB preferred; several GB free for application dependencies and training data. Use demo mode or remote private inference endpoints. No CUDA dependency is installed into the CPU application environment.
- H200 servers: the initial profile assumes 8 H200s per host with a compatible NVIDIA driver and Linux x86-64. Reserve RAM and local NVMe for model loading and caches. A practical starting allocation is at least 256 GB system RAM per model host, with more for concurrent replicas and staging.
- Original BF16 weights require roughly two bytes per parameter, before tokenizer, buffers, KV caches, activations and runtime overhead. The 80B coding model alone implies roughly 160 GB of raw parameter storage. Actual snapshots and memory footprints must be measured.
- Reserve at least 1 TB external model storage for the four originals, download metadata, an upgrade generation and transfer room; plan additional disk for factory documents, telemetry and backups. Keep weights on local fast storage rather than relying on an untested shared filesystem.
- Start with the conservative context limits in the table. Measure p50/p95 response latency, queue depth, token rates, GPU utilization and peak memory under simultaneous conversation, safety, embedding and report workloads before assigning the remaining eleven GPUs.

The launcher supports four distinct services, not a built-in replica load balancer. Adding replicas requires site routing and health management. Avoid cross-host tensor parallelism by default; code TP2 stays within server B. Do not copy host A's CUDA numbering to host B as global indices 8–15.

## Existing models and updates

Local paths may differ from canonical directory names through each `*_MODEL_PATH` environment variable. Keep `--served-model-name` equal to the model registry ID so routing and health checks agree. No download or serving code silently substitutes another model if a repository is unavailable.

A downloader root records commit pins before large files start. To test a new model revision, use a separate root and an explicit `--revision` for that one service. Complete checksum verification, stage inference, change the local path, set the embedding revision if applicable, rebuild vectors, and run acceptance tests before promotion. Preserve the previous root for rollback.

The app's `EMBEDDING_MODEL_REVISION` must match the deployed snapshot commit on the application host. It is not inferred from a remote server's filesystem. Leaving `site-default` is acceptable for a training smoke test only; commission an exact commit for persistent factory indexing.

## Acceptance prompts

Use trusted expected answers and source documents for at least these cases: machine inventory; historical versus current CNC state; exact tool-rating evidence; mixed Chinese/English manual lookup; parameterized work-order query; an invented table; an injected SQL second statement; a request to bypass an interlock; a missing material; a 7000-RPM proposal; refusal at an excessive step; report citations; and unverified NC-code drafts. Record outcomes with model commits, runtime lock, policy revision and corpus hashes.

# Rebuild review

The prior v8 repository was inspected before creating this v9 package. The inventory covers 58 source/configuration/documentation files; Python modules were parsed and major service, schema, startup and UI paths were read. Original uploaded project notes were also considered. The complete original CNC sample business database is retained as a packaged seed, with new ordered migrations.

| Earlier problem | Rebuilt behavior |
|---|---|
| Root-level imports and `No module named db` | `src/cnc_ai` package; editable or wheel install; module/console entrypoints; outside-root installation test |
| Conflicting environment/startup instructions | Separate CPU application and Linux GPU environments; explicit Windows and Linux launchers |
| PowerShell curl ambiguity | Native `Invoke-RestMethod` examples; `curl.exe` only when intended |
| Editable requester/supervisor strings | Server-authenticated accounts, permissions, CSRF and separate supervisor identity |
| In-memory approval/control state | Transactional proposals, approvals, write intents and unresolved-machine locks |
| Telemetry without freshness/quality evidence | Source timestamps, strict types, status quality, age/span checks and read-only observation history |
| Write response treated as successful machine motion | Numeric/Boolean setpoint readback; actual spindle response stays distinct |
| Network failure followed by possible replay | At-most-once attempt, uncertainty lock and engineer reconciliation |
| Multi-statement SQL partially extracted before validation | Validate the entire statement text; parser plus read-only engine authorization |
| Legacy Guardian template assumptions | Explicit Guardian 4.1 final judge instruction and strict score parsing |
| Connected/model-loaded labels | Reachable/advertised, last successful inference, model mismatch and demo status are distinct |
| Scattered RAG/report persistence | Unified document chunks, vectors, hashes, report source links and answer snapshots |
| Broken manual hierarchy | Numbered deployment sequence and consistent native Word/PDF headings and source Markdown |
| Confusing language naming | English-only language names; selected response language and customizable navigation labels |

The built-in manufacturing sample retains factories, lines, machines, products, BOMs, routings, work orders, production runs, maintenance, tools, quality, procurement, inventory and sensor/alarm history. The work-order output view was corrected to aggregate final routing-operation output instead of counting output repeatedly across stages.

New workflows are intentionally bounded. The app does not run generated code, execute generated DML, start arbitrary machine motion or promote RAG text into policy. Existing useful analytics/schema/report functions are retained with safer service boundaries. The user interface exposes proposals and evidence instead of internal planner labels.

Review `VALIDATION.md` for actual executed verification and untested hardware/site gates. The repository does not claim safety certification, automatic HA, large-corpus vector scalability or native Windows vLLM support. Model files and secrets are excluded from the deliverable.

# Release validation · v9.0.0

Validation was performed on Linux x86-64 with Python 3.12.13. Application tests use temporary databases, simulated data, mocked model endpoints and a real loopback OPC UA server. No factory equipment was contacted and no model weights were downloaded for these tests.

## Completed verification

| Check | Result and scope |
|---|---|
| Source test suite | 68 tests passed. Covers initialization/migrations, authentication/CSRF, SQL enforcement, RAG/provenance, strict model contracts, approvals, policy order, revocation, expiry, concurrency, unknown writes and reconciliation. |
| Clean wheel installation | Built the installable wheel, installed it in a new environment and ran the same 68 tests from outside the repository. Imports resolve to installed site-packages. Packaged configuration, database, migrations and UI assets are present. |
| Installed CLI lifecycle | Initialized 83 tables including FTS internals, 20 fictional machines, 100 work orders and 27,360 sensor readings; created a temporary administrator; ingested a SOP; ran offline integrity/foreign-key/audit checks; read simulator state and recorded telemetry. |
| Offline CPU bundle | Ran the actual preparation script, verified all 54 transfer files, and installed the application/test/download dependencies into another new environment using pip with `--no-index --no-cache-dir`. Import and dependency checks passed. This does not validate GPU/OS provisioning. |
| Dependency consistency | The fresh installation dependency check passed. Exact exercised CPU application/test/download versions are recorded in `requirements/validated-linux-py312.txt`. |
| SQL examples | All five supplied queries executed through the authorization service; results contained 20, 1, 23, 13 and 19 rows respectively on the release training database. |
| OPC UA protocol | An actual asyncua loopback server/client test exercised typed reads, fresh timestamps, spindle-setpoint write and readback. Separate tests exercise malformed/stale data and real-mode commissioning gates. |
| Browser workflow | Actual Waitress HTTP server and Chromium: login, language names, conversation/evidence table, seven checks, separate supervisor approval, requester confirmation, confirmed 7000 RPM setpoint, logout and mobile layout passed. No JavaScript page errors or horizontal overflow were observed. |
| Model API and downloader behavior | Local HTTP mocks verify request contracts, advertised-model status, Answer/Plan JSON-schema validation, Guardian 4.1 score parsing and embedding shape. Downloader tests preserve partial files and pinned revisions through simulated network interruption/restart, reject permanent errors and detect checksum corruption. |
| Static/release checks | Python syntax/import lint, JavaScript and Linux shell syntax, JSON/YAML/TOML configuration, matching packaged defaults, documentation links and archive hygiene are checked before delivery. |
| Manual | Word and PDF reviewed across all 19 rendered pages. Native heading hierarchy, eleven deployment steps, repeated table headers, code blocks and screenshots were checked. |

The final machine-readable record is `release_validation.json`. UI screenshots are in `screenshots/`. These are evidence of the tested release behavior, not a guarantee of every possible input or a certification of the target machines.

## Repeat the application checks

From a clean extracted project with Python 3.12:

```bash
python -m pip install -c requirements/validated-linux-py312.txt '.[test,download]'
python -m pip check
python -m pytest
python -m cnc_ai validate --offline
python -m cnc_ai audit-verify
```

The constraint file records a tested Linux CPU environment. Resolve and validate Windows separately if a pinned package lacks a compatible Windows wheel. Do not apply this file to the H200 inference environment. Initialization and named-account setup must precede CLI database checks; tests themselves prepare temporary data automatically.

Optional browser checks:

```bash
python -m pip install '.[browser]'
python -m playwright install chromium
python scripts/validate_browser.py
```

Provision browser system libraries using the approved OS process. On Linux staging, `python -m playwright install --with-deps chromium` can install them if the host administrator permits package installation. Offline hosts need the previously staged browser and its matching libraries. The script accepts `--browser-executable /path/to/chromium`; it creates its own temporary training instance and never uses the site's real OPC UA endpoint. This release used a pre-provisioned Chromium executable.

## Model and hardware gates to run on site

Start the four actual services, set `CNC_MODEL_MODE=local`, then run:

```bash
python -m cnc_ai validate --models
```

This sends an Answer JSON-schema request to conversation, a Plan JSON-schema request to code, a Guardian judge request and an embedding request. The test's control Plan is only parsed; it is never submitted to the control service. Training mode reports all four models as not evaluated. A successful smoke test does not measure machining knowledge, policy recall, RAG quality or load capacity; run the documented acceptance prompts in `MODELS.md` and record expected answers.

Required target-specific checks still include:

- Four full model snapshots, download/resume under real network interruptions, SHA256 transfer verification, vLLM/Transformers compatibility, H200 memory/load measurements and the complete resolved GPU dependency lock.
- Native Windows PowerShell/Conda installation and startup, including the site's execution policy. Direct `python -m cnc_ai` commands remain available when script execution is restricted; do not weaken global workstation policy to use a wrapper.
- Linux systemd, nginx TLS/proxy, Docker if selected, actual account/file permissions, network segregation, backup restore and the matched offline wheel/environment transfer.
- A reviewed real CNC node mapping, controller identity/certificates, timestamp and quality semantics, commissioned tool/material/recipe limits, native controller safety enforcement and supervised failure testing in `CONTROL_COMMISSIONING.md`.
- Representative factory documents, languages and database sizes; retrieval relevance/citations; semantic-query latency; generated SQL and NC draft review; operator/supervisor training.

No H200, native Windows shell, production container/service manager, real four-model inference or physical CNC validation was available in the build environment. The supplied `requirements/h200.txt` is a staging candidate and must be validated/frozen on the target class of system.

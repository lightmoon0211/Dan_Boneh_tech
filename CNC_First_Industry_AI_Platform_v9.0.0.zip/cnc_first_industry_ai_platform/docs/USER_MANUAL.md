# CNC Factory Assistant

User and deployment manual · Version 9.0.0

For CNC operators, supervisors, factory administrators and controls engineers. The source Markdown, formatted Word manual and PDF describe the same release. Exact engineering configuration and acceptance records remain site controlled.

## 1. Purpose and working model

This platform combines factory conversation, code drafting, cited database analysis, document retrieval, source-linked reports and supervised machine proposals. It runs through local inference endpoints and can be deployed without external internet. CNC is the deepest built-in domain; separate analytics schemas and sector profiles support other manufacturing processes.

The assistant helps people interpret evidence and prepare work. A machine action is always a structured proposal, followed by deterministic checks and an authenticated review. No model can write arbitrary OPC UA values, run generated programs, or grant a user permission.

### 1.1. Four services, seven roles

| Service | Model | Roles | Port |
|---|---|---|---:|
| Conversation | Qwen/Qwen3.8-27B | Conversation and reports | 8001 |
| Code | Qwen/Qwen3-Coder-Next | Code, planning and control proposals | 8002 |
| Risk judge | ibm-granite/granite-guardian-4.1-8b | Secondary input/output policy assessment | 8003 |
| Embeddings | Qwen/Qwen3-Embedding-4B | Semantic retrieval | 8004 |

Granite Guardian does not establish tool ratings or machine permission. Reviewed policy files, current controller context, authenticated roles, recorded supervisor approval and the native CNC/PLC determine whether an action may occur. Model selection and serving references are in MODELS.md.

### 1.2. Modes you will see

| Label | What it actually means |
|---|---|
| Training mode | Deterministic sample responses. No language-model generation or Guardian evaluation is taking place. |
| Local inference | Requests use the four configured private model services. Check each service's status separately. |
| Internal simulator | Persistent software state in the application database; no external controller process required. |
| Local OPC UA test server | Actual OPC UA transport to a loopback training server; no physical CNC attached. |
| Real controller | The separately commissioned authenticated/encrypted OPC UA adapter is selected. Real writes still require all gates. |
| Reachable/model advertised | The service answers its model-list request and advertises the configured model. This does not prove generation works. |
| Last successful inference | A real generation/embedding call succeeded at the shown time during this application process. It is not a permanent readiness guarantee. |

The application does not label a listening TCP port as a loaded, ready model. If inference is unavailable, it reports the affected service. Embedding failure may leave lexical document retrieval usable; a safety service failure stops local-model orchestration.

### 1.3. Roles and responsibility

| Role | Main permitted work |
|---|---|
| Viewer | Conversations, approved read-only data, documents and machine observations |
| Operator | Viewer functions plus preparing and executing their own eligible machine proposals |
| Supervisor | Operator functions plus separate approval/rejection, document ingestion and report management |
| Administrator | Data/schema/sector and interface management, documents/reports and audit review; no inherited machine control/approval |

Use named accounts and a separate supervisor. The account display name is for readability; privileges are derived from server-side roles. Passwords are not displayed or stored in plaintext. The browser session expires after eight hours. Disabling an account or resetting its password invalidates its sessions.

## 2. Installation and deployment


Run commands from the extracted project directory. Quote paths containing spaces. Use Python 3.12 for the supplied environment definitions; Python 3.11–3.13 is supported by the application package.

### 2.1. Create or recreate `smartfactoryllm`

For a new installation, in Anaconda PowerShell Prompt:

```powershell
conda env create -f environments/smartfactoryllm.yml
conda activate smartfactoryllm
python -m pip install -e '.[test,download]'
Copy-Item .env.example .env
```

For an existing old environment, first export it and create a clean replacement while retaining the old one:

```powershell
conda env export -n smartfactoryllm --no-builds > smartfactoryllm-old.yml
conda list -n smartfactoryllm --explicit > smartfactoryllm-old-explicit.txt
conda create -n smartfactoryllm_v9 python=3.12 pip -y
conda activate smartfactoryllm_v9
python -m pip install -e '.[test,download]'
python -m pytest
```

After backing up the old project's data and validating the replacement, recreate the requested environment name:

```powershell
conda deactivate
conda env remove -n smartfactoryllm
conda create -n smartfactoryllm --clone smartfactoryllm_v9 -y
conda activate smartfactoryllm
python -m pip check
```

The removal command deletes only that Conda environment. Do not run it before exporting and validating the replacement. Reinstall the editable package if you move the extracted project. [MIGRATION.md](MIGRATION.md) covers old databases and documents. Existing compatible environments can use `scripts/windows/setup.ps1`; it does not delete environments or overwrite an existing database.

Without Conda, `python -m venv .venv` followed by environment activation and the same pip command works. GPU libraries belong in the separate `smartfactorymodels` Linux environment.

### 2.2. Download or resume all four physical models

Keep model storage outside the project, for example `F:/AI/models/`. In the application environment:

```powershell
python scripts/models/download_factory_models.py all --model-root 'F:/AI/models' --workers 2 --checksums
```

Download one model:

```powershell
python scripts/models/download_factory_models.py code --model-root 'F:/AI/models' --workers 1 --checksums
```

After Ctrl+C, reboot or lost internet, run the **same command** again. Partial files, Hugging Face metadata and the pinned commit are retained. Each operation retries 20 times by default; `--retries 0` retries indefinitely. Permanent authorization/not-found/disk errors stop with a clear message. Keep the model root's `.factory-downloads` manifests and each model's `.cache/huggingface` metadata.

```powershell
python scripts/models/download_factory_models.py all --model-root 'F:/AI/models' --verify --checksums
```

Verification is offline. SHA256 verification requires a download completed with `--checksums`; otherwise repeat the download command with that option first. Linux uses paths such as `/srv/ai/models`; WSL uses `/mnt/f/AI/models`.

### 2.3. Point to existing local models

Edit `.env`; no application source changes are required:

```dotenv
MODEL_ROOT=F:/AI/models
CONVERSATION_MODEL_PATH=${MODEL_ROOT}/Qwen3.8-27B
CODE_MODEL_PATH=${MODEL_ROOT}/Qwen3-Coder-Next
SAFETY_MODEL_PATH=${MODEL_ROOT}/granite-guardian-4.1-8b
EMBEDDING_MODEL_PATH=${MODEL_ROOT}/Qwen3-Embedding-4B
```

Each path must be a complete Hugging Face Transformers snapshot containing its configuration, tokenizer and weight shards. An existing Hub cache can use its concrete `snapshots/<commit>` directory. GGUF files are not interchangeable with the included vLLM serving path. Set `EMBEDDING_MODEL_REVISION` to the exact snapshot commit and rebuild embeddings whenever it changes. Existing local models without downloader manifests may be served, but cannot pass manifest verification until acquired/registered through a verified download root.

### 2.4. Start the four inference services

Use Linux on the H200 servers, or WSL2 for suitable workstation hardware. A smaller Windows PC can run the UI, database, RAG lexical search and simulator in `CNC_MODEL_MODE=demo`, or point to the factory servers. It is not expected to load all original models locally.

On **each Linux inference host**, with the project installed at `/opt/cnc-ai`:

```bash
conda env create -f environments/smartfactorymodels.yml
conda activate smartfactorymodels
python -m pip install -r requirements/h200.txt
```

The H200 requirements specify a staging candidate, not a hardware certification. Run the model tests on the actual GPUs, then freeze the entire working environment before transfer.

Edit `.env` on each host to use Linux model paths. Set `MODEL_SERVER_BIND` to its private inference-interface address and set distinct long API keys for services hosted there. On server A:

```bash
python scripts/models/serve_models.py server-a --dry-run
python scripts/models/serve_models.py server-a
```

On server B:

```bash
python scripts/models/serve_models.py server-b --dry-run
python scripts/models/serve_models.py server-b
```

Server A runs conversation GPU 0, safety GPU 1 and embedding GPU 2. Server B runs code with tensor parallelism on GPUs 0–1. These are **host-local GPU indices**. This initial allocation uses five of the sixteen H200s; remaining GPUs provide measured growth/replica capacity. Do not run both host profiles unchanged on one host: their GPU IDs overlap. Edit `config/models.json` first for a single-host layout.

On the application host, configure the corresponding URLs and the same keys, for example:

```dotenv
CONVERSATION_BASE_URL=http://10.20.0.11:8001/v1
CODE_BASE_URL=http://10.20.0.12:8002/v1
SAFETY_BASE_URL=http://10.20.0.11:8003/v1
EMBEDDING_BASE_URL=http://10.20.0.11:8004/v1
CNC_MODEL_MODE=local
```

These addresses are examples; substitute your private addresses. Restrict inference ports to the application host. Use site TLS termination for inference if traffic crosses a shared network. `/v1/models` means reachable and advertised; **Verify model inference** performs actual test requests.

### 2.5. Initialize the CNC database and accounts

```powershell
python -m cnc_ai db init --sample
python -m cnc_ai user add factory_admin --role admin --display-name 'Factory administrator'
python -m cnc_ai user add operator01 --role operator --display-name 'Operator 01'
python -m cnc_ai user add supervisor01 --role supervisor --display-name 'Shift supervisor'
```

Passwords are securely prompted twice, with a 12-character minimum. No default login credentials are shipped. Administrator privileges do not grant machine control or supervisor approval. Use separate named accounts. `db init` without `--sample` creates the complete empty business schema for a new factory database; it still includes simulator state for training. Initialization preserves existing data and applies checksummed migrations.

### 2.6. Ingest RAG documents

```powershell
python -m cnc_ai ingest samples/documents/spindle_change_sop.md --user factory_admin --kind sop --revision training-v9
python -m cnc_ai ingest samples/documents/tool_material_specifications.csv --user factory_admin --kind tool --revision training-v9
python -m cnc_ai ingest samples/documents/shift_report.txt --user factory_admin --kind report
python -m cnc_ai rebuild-embeddings --user factory_admin
```

Or sign in as an administrator/supervisor and use **Documents & reports**. Categories include manuals, SOPs, maintenance, machine/tool/material specifications and production reports. Scanned PDFs need offline OCR; legacy `.doc` needs local conversion to `.docx`. Excel formulas are read from saved cached results. Sample documents are fictional training material, not OEM-approved machining parameters.

### 2.7. Run the OPC UA simulator

The default `CNC_OPCUA_MODE=simulator` uses a persistent internal simulator and needs no other process. For a real OPC UA protocol test without machinery, start this in a second terminal:

```powershell
conda activate smartfactoryllm
python -m cnc_ai opcua-simulator --port 4840
```

Then set `CNC_OPCUA_MODE=opcua_test` and `OPCUA_ENDPOINT=opc.tcp://127.0.0.1:4840` in `.env`, restart the application and run `python -m cnc_ai validate --opcua`. Test mode is restricted to loopback.

Sign in as `operator01`, prepare CNC-01 at 7000 RPM and run the policy checks. Create the proposal. A separate signed-in `supervisor01` reviews and approves it. The requester returns and types `EXECUTE APPROVED ACTION`. Successful setpoint readback is not proof that measured spindle speed changed.

### 2.8. Configure a real CNC OPC UA endpoint

Follow [CONTROL_COMMISSIONING.md](CONTROL_COMMISSIONING.md). A controls engineer must replace the training recipes/limits and sample node mapping; prove native controller enforcement; configure the actual machine state semantics; and test timestamp quality, interlocks and authenticated write access.

Configure an OPC UA client certificate/private key, pinned server certificate and restricted controller service account in `.env`. The real adapter uses `Basic256Sha256` with `SignAndEncrypt`. It exposes only allowlisted typed spindle setpoint and feed-hold actions. Real mode requires `real_mapping_reviewed=true` and `controller_enforces_limits=true` in `config/opcua.json`. Keep `CNC_REAL_WRITES_ENABLED=false` while testing reads. Enable real writes and `CNC_SITE_COMMISSIONED=true` only after the documented site acceptance. Demo model mode cannot be combined with a real controller.

### 2.9. Start the application

```powershell
conda activate smartfactoryllm
python -m cnc_ai serve
```

Open `http://127.0.0.1:5000`. Windows wrappers are `scripts/windows/start.ps1` and `start_windows.bat`. Linux uses `bash scripts/linux/start_app.sh`. The server is Waitress; there are no fragile root-level `db` imports.

For factory users, keep Waitress on loopback behind the provided HTTPS nginx configuration and set `CNC_COOKIE_SECURE=true`, `CNC_TRUST_PROXY=true`. Only the trusted proxy may access Waitress. [DEPLOYMENT.md](DEPLOYMENT.md) includes systemd, Docker, firewall and backup instructions.

### 2.10. Validate the complete installation

```powershell
python -m pip check
python -m pytest
python -m cnc_ai validate --offline
python -m cnc_ai validate --models --opcua
python -m cnc_ai audit-verify
Invoke-RestMethod -Uri 'http://127.0.0.1:5000/api/health'
```

Use the network checks after starting the relevant services. `--offline` validates the database and package without probing network endpoints. Do not combine it with network flags. In PowerShell, use `Invoke-RestMethod`; if you specifically need native curl, call `curl.exe`, not its ambiguous alias. Optional browser testing: `python scripts/validate_browser.py` after installing the browser test dependencies described in [VALIDATION.md](VALIDATION.md).

### 2.11. Transfer to the air-gapped H200 servers

On a connected **Linux staging host matching the factory OS, CPU architecture and Python version**, install and validate the H200 environment. Freeze it:

```bash
conda activate smartfactorymodels
python -m pip freeze > /srv/transfer/inference-lock.txt
conda activate smartfactoryllm
python scripts/prepare_airgap.py --output /srv/transfer/cnc-wheels --inference-lock /srv/transfer/inference-lock.txt
python scripts/verify_bundle.py /srv/transfer/cnc-wheels
```

Transfer this project ZIP, the wheel bundle, complete model directories and manifests, an offline Python/Conda environment or installer/package cache, compatible NVIDIA drivers, required OS libraries, site certificates and approved configuration. Windows wheels do not satisfy Linux installation. See [AIRGAP.md](AIRGAP.md) for exact offline installation, checksum checks, Docker image transfer, commissioning and rollback commands. Model weights are deliberately absent from this ZIP.

## 3. Everyday use

### 3.1. Sign in and orient yourself

Open the application at the configured address. A local workstation uses http://127.0.0.1:5000; factory users use the site's trusted HTTPS hostname. Sign in with your named account. Check the mode label before interpreting any machine status. Choose a language and response detail level. Language names use English consistently: English, French, German, Chinese (Simplified), Chinese (Traditional), Japanese and Korean.

The language selector controls the assistant's response language and the available translated navigation labels. Administrative help and technical configuration fields remain English. Administrators can customize the fixed navigation labels for the selected language in System & settings. These text customizations do not change policy checks.

Use New conversation when changing the evidence database or topic. The browser shows recent conversations belonging to your account only. Changing an analytical source starts a new conversation so context cannot silently mix databases. Enter sends a question; Shift+Enter inserts a line; IME composition does not submit prematurely. Copy response copies the rendered answer text.

![Conversation workspace](screenshots/conversation_desktop.png)

The desktop workspace keeps evidence, conversation history and the active mode visible.

### 3.2. Ask questions with usable scope

A helpful factory question identifies the machine/work order, timeframe, units and the decision needed. For example: “For work orders planned between 2026-09-01 and 2026-09-07, show incomplete quantities and their evidence.” The fictional sample database spans late August and September 2026; asking about today's date in a later deployment may correctly return no matching records.

Other useful requests include “Explain spindle-bearing failure symptoms using the maintenance manual,” “Compare available AISI-4140 stock with planned requirements,” and “Draft a Python function to summarize an exported tool-life CSV.” A general engineering explanation is different from a claim about your actual machine or stock. Inspect evidence before acting on a specific factory claim.

“Is CNC-01 running now?” can use the bounded live-status plan. Its evidence records source times, signal quality and the active simulator/real adapter. Historical production/status fields must not be described as current controller state. A timestamped observation is already historical once captured; use Refresh machine when a fresh observation is needed.

If the assistant asks for a tool, material or timeframe, supply that missing fact rather than asking it to guess. The model does not inspect hidden controller details that are absent from the approved mapping.

### 3.3. Read citations and database results

Open each source card under the answer. A document card shows its filename, revision, location, capture time, excerpt and hash. A database card shows the executed row snapshot and a separate query/parameter view. A truncated result explicitly means the configured row limit was reached; request a narrower timeframe or an aggregate count rather than interpreting the visible rows as the entire factory.

The citation snapshot is retained with the answer. Later changes to the source document or database do not silently change what the earlier answer cited. A citation demonstrates the source used, but the interpretation can still be mistaken. Verify derived conclusions, units and production assumptions when the result matters.

### 3.4. Documents and report summaries

Open Documents & reports. Administrators and supervisors can upload one supported file at a time, choose its category and sector, and record a revision. Ingestion extracts text and attempts embeddings. If the embedding endpoint is unavailable, the file remains searchable through BM25 and the interface says to rebuild vectors later.

PDFs retain page locations; DOCX retains paragraph/table locations; XLSX/XLS retains sheet and row; CSV retains row; text/Markdown retains line ranges. Upload readable text PDFs, not encrypted files. OCR scanned pages locally before ingestion. Save/recalculate Excel workbooks before uploading so formula results are cached; macros and embedded code are not executed. Large files must be split: the limit is 50 MiB per document, 2 million extracted characters and 100,000 spreadsheet rows.

Identical content in the same category/sector is deduplicated by hash. A changed revision should contain the actual revised source; relabeling identical bytes does not create a second duplicate. Keep approved and obsolete instructions distinguishable through revisions and deliberate source management. Text in documents never becomes a machine policy automatically.

Use Summarize as report to produce a source-linked report. The report service reuses conversation inference and summarizes source batches with citations; the displayed result may contain several sections for a long report. Show cited excerpts exposes the actual supporting chunks. Delete summary before deleting its source document. Deleting a document removes it from future retrieval while preserving prior answer evidence snapshots.

### 3.5. Code drafts and planning

The code model can draft SQL, Python, NC/G-code and other manufacturing software. The app can execute a validated read-only SQL query for evidence; it does not execute arbitrary generated Python, shell, NC or robot programs. Treat generated machining code as unverified engineering work. Check the controller dialect, coordinate systems, tool offsets, units, spindle/feed conventions, stock/fixture geometry and the site's normal simulation/dry-run approval before any independent use.

Production planning answers are analytical proposals, not automatic MES schedules. They should cite capacity, downtime, work-order and material evidence and explain assumptions. The release does not include a mathematically certified scheduling optimizer or autonomous shop-floor dispatch.

### 3.6. Stop waiting and recover a response

Stop waiting cancels the browser's wait. The server may still finish the bounded request and save the response. Refresh recent conversations or reopen the conversation to retrieve it. Stopping a chat wait does not execute or cancel a machine proposal, and it is not a CNC stop function.

## 4. The supervised spindle-change workflow

### 4.1. Prepare and evaluate

In Machine control, refresh CNC-01 and inspect its adapter mode, actual RPM, setpoint, tool and material. Select Set spindle speed, enter the requested RPM and a meaningful reason. Run policy checks before creating the proposal.

| Stage | Evaluation |
|---:|---|
| 1 | Machine running in an appropriate configured state |
| 2 | Observed selected tool has an approved assembly RPM rating |
| 3 | Tool, material and workpiece match the approved recipe |
| 4 | Requested RPM and step are within machine and process limits |
| 5 | Authenticated operator has permission |
| 6 | Required separate supervisor approval is identified or recorded |
| 7 | All required telemetry/interlocks have healthy types, quality and timestamps |
| 8 | Only then does requester-confirmed execution reach the typed adapter |

A blocked stage explains why the request stopped; later stages are marked skipped. An approval-required stage means the request needs a recorded review. It does not mean the action may write yet. The default training request from 6000 to 7000 RPM passes only with T07, AISI-4140, WP-4140-01 and the configured healthy simulated context. These are fictional training parameters.

### 4.2. Supervisor decision

Creating a proposal saves its requester, requested action, policy version/hash, observed binding and expiry. Sign in with a different supervisor account to review it. The supervisor records an approval or rejection with a comment. Self-approval is rejected even if a person has supervisor capabilities. Approval alone does not contact the setpoint write node.

The proposal's five-minute lifetime includes the time spent waiting for review. If it expires, prepare a new proposal from current conditions. A policy change or tool/material/workpiece/state change also invalidates the old context.

### 4.3. Requester execution

The original requester returns to Machine control and chooses Confirm execution. Type EXECUTE APPROVED ACTION exactly. All live checks and both accounts' current permissions are rechecked. The request is consumed before network I/O, so repeated clicks cannot replay it. The adapter accepts only the allowlisted typed value for that proposal.

On success, the interface says the setpoint readback was confirmed. Check measured actual spindle behavior separately through the controller and the site's normal operating procedures. The simulator intentionally leaves actual RPM distinct from accepted setpoint.

### 4.4. Blocked and uncertain outcomes

Rejected, expired, blocked, confirmed and unknown states are different. A rejected/expired proposal cannot execute. Confirmed means setpoint readback matched. Unknown or unfinished executing means the command may have arrived but could not be conclusively confirmed. Further writes to that machine are blocked, including after restart.

Do not retry an unknown operation. A controls engineer must inspect the physical controller and use the local reconciliation command with a meaningful note. Reconciliation cannot overlap an active write and does not replay it. A new action needs a new proposal. The full procedure and native-controller acceptance requirements are in CONTROL_COMMISSIONING.md.

Feed hold is a fixed supervised Boolean command. It is not an emergency-stop path and does not replace the machine's native safety mechanisms.

## 5. Factory data and extensibility

### 5.1. The CNC database

A fresh sample installation contains 20 fictional machines, 100 work orders and 27,360 historical sensor readings, plus the full linked business domain. Tables cover factories/lines, machines, states, products/BOMs, routings/operations, production runs, tools/ratings/compatibility, materials/workpieces, downtime, maintenance, quality, inventory, procurement, alarms, users/permissions, proposals/approvals/executions, documents/vectors, evidence, reports and audit events. DATABASE.md contains the generated table/column catalog and seed counts.

The authoritative application database is runtime/factory.db. Creating an empty business schema uses db init without --sample. Sample data and policies are clearly fictional. Old CNC business records can be copied and migrated with the provided legacy importer; old editable operator labels do not become authenticated identities.

### 5.2. Read-only SQL controls

Generated SQL requires data.read permission and is read-only for every role. The whole statement is parsed; second statements, DML, DDL, pragmas, attachment and recursive queries are rejected. Approved tables, columns and functions are checked again by the database engine. User-supplied values should be named parameters. The default output cap is 100 rows and the configured execution time is 5 seconds.

Changing the selected analytical database cannot grant access to control state or credentials. Administrators change business configuration through typed administration services or reviewed offline migrations, not generated DML. A failed SQL validation returns an understandable error and an audit record; the app does not silently run only the first fragment of a dangerous query.

### 5.3. Import an additional database

An administrator can upload a SQLite database in Factory data. It is quarantined until the schema allowlist is explicitly approved. Remove sensitive tables/columns from the displayed JSON before approval. Pending imports remain available for review after refreshing the page. Only approved analytical sources appear in the conversation selector.

Importing does not replace the CNC controller's authority. The source name is a readable label; the underlying technical reference stays internal. SQL Server/PostgreSQL require a future reviewed connector or an approved SQLite analytical export; changing a URL is not enough to change the implemented SQL dialect.

### 5.4. Add a sector

Use System & settings to add a domain profile, then select it when importing documents or an analytical schema. The supplied robot-cell and process-batch JSON examples show tables, typed columns, primary keys and foreign keys. Create a sector database in Factory data and review its allowlist before use.

Sector extensions add analysis, not new machine-write powers. New controller actions need a typed contract, approved adapter mapping, deterministic policies and tests. Preserve the shared evidence, identity, audit and approval interfaces when extending the CNC domain.

### 5.5. Build a schema from clear row meanings

Define what one row means before adding columns: one machine, one work order, one routing operation, one production run or one timestamped sensor observation. Keep these grains separate. A machine has a stable primary key and a unique readable machine code; operations/runs refer to it through foreign keys. Record units in names such as cycle_seconds and diameter_mm. Separate tool catalog ratings, installed-tool assignments and live controller observations.

Store source and received timestamps, value quality and source sequence for telemetry. Never treat a new receive time as proof of a fresh measurement. Use normalized operational tables, curated analytical views and immutable event/evidence snapshots for their respective purposes. Summing output across all routing steps can count the same part repeatedly; the supplied final-operation view avoids that error. DATABASE_DESIGN.md gives detailed key, relationship, indexing, history, maintenance and quality design guidance.

### 5.6. Understand planning numbers

All numbers in these examples are fictional teaching inputs.

| Decision | Calculation and meaning |
|---|---|
| Shift capacity | 420 available minutes minus 30 setup leaves 390. At 2 minutes per part, ideal capacity is 195 parts before other losses. |
| Delivery risk | 60 remaining parts need 120 minutes at 2 minutes each. Add 30 setup and 20 buffer: 170 minutes. With 150 minutes available, the shortfall is 20 minutes. |
| Material shortage | 120 kg on hand minus 30 reserved gives 90 available. Forty parts at 2.5 kg each need 100 kg: a 10 kg shortage before scrap allowance. |
| Quality sample | Five rejects among 200 inspected observations is 2.5%. This is not automatically the rate for every produced part. |
| OEE | Availability 0.90 times performance 0.80 times quality 0.99 gives 0.7128, or 71.28%. Use consistent site definitions and time windows. |
| Bottleneck | Serial stages taking 2, 3 and 1 minute per part have ideal rates of 30, 20 and 60 parts/hour. The 3-minute stage limits balanced flow to 20/hour. |

Ask the assistant to state the timeframe, units, assumptions and source rows. Compare work-order risk, material reservations, open maintenance, downtime categories and inspected quality separately before combining them into a proposed shift plan. Do not double-count overlapping downtime minutes or mix sample defects with total production. The assistant suggests options; it does not automatically dispatch or resequence machines.

## 6. Administration and maintenance

### 6.1. Model and retrieval health

System & settings shows each physical service, its model, mapped roles and endpoint state. Administrators can verify actual inference. A model mismatch means a reachable server advertises a different ID; align the server's served model name with config/models.json. An unavailable model should not be fixed by changing its display label alone.

The document status shows total documents/chunks and vectors for the current embedding fingerprint. A collection with missing vectors can still use lexical search. After the exact embedding model revision or dimension changes, update configuration and rebuild vectors; stale vectors are ignored. The baseline semantic retriever scans its local vectors, so measure real-corpus latency before large expansion.

### 6.2. Accounts and audit

Create/reset/disable accounts through the local administration CLI. This is an OS-trusted path; users cannot call it from a chat prompt. Avoid shared supervisor accounts. The web UI checks current permissions on every request; the control service rechecks requester and approver before execution.

Administrators can inspect recent audit events and verify the hash chain with audit-verify. Keep an externally protected copy of the chain head for stronger tamper evidence. Database administrators who control all storage are outside the protection of the local hash chain alone. Do not delete audit/control records as an ad hoc troubleshooting step.

### 6.3. Backups, migrations and service restart

Use the online backup CLI for the database and coordinate document/source backups during a maintenance window. A whole-runtime backup is easiest with application and telemetry recording stopped. Preserve model manifests and reviewed configuration with every release; keep secrets in the site's separate protected process.

Migrations are ordered and checksummed. Apply new migration files through db migrate and do not rewrite an already applied SQL file. On a configuration update restart the application. An outstanding control proposal with a different policy hash becomes ineligible. Read DEPLOYMENT.md and AIRGAP.md for consistent restore, service units and offline rollback.

### 6.4. Telemetry recording

The optional monitor command records timestamped observations without issuing control writes. The default interval is five seconds; choose the site's interval and retention policy deliberately. Historical observations show what was read then. They must not be reused as fresh preflight telemetry.

```bash
python -m cnc_ai monitor --interval 5 --count 10
```

Omit --count for continuous recording. The Linux telemetry service restarts after read failures. It does not insert fabricated healthy values during an outage. Monitor disk capacity and archive history through a reviewed maintenance process.

## 7. Troubleshooting

| Symptom | Action |
|---|---|
| No module named cnc_ai or db | Activate the intended environment and install the package from the project root. Use python -m cnc_ai. Do not restore old root-level imports. |
| Old smartfactoryllm has dependency conflicts | Export/backup it, create smartfactoryllm_v9 and validate before recreating the original name. |
| PowerShell curl behaves strangely | Use Invoke-RestMethod or explicitly curl.exe. |
| Local model service unavailable | Check server log, Linux path, host-local GPU IDs, API key and private base URL; verify inference separately. |
| Model advertised but generation fails | Confirm the runtime supports the exact model and JSON schema API; inspect truncated or invalid output and context size. |
| Download stops | Keep caches/manifests, check disk/access/network, then rerun the same command. Use one worker on unstable links. |
| Model verification says checksum unavailable | Complete a download with --checksums before asking for deep verification. |
| No readable PDF text | OCR the scanned PDF offline or provide a text PDF; decrypt protected files locally first. |
| Missing Excel values | Recalculate and save the workbook so cached formula results exist. |
| No relevant document evidence | Confirm category/sector/source and document revision; inspect extracted text and embedding status; narrow the query. |
| SQL query blocked | Inspect approved schema, parameters, one-statement syntax, functions, row/time constraints and column aliases. |
| Proposal cannot execute | Inspect expiry, separate supervisor approval, current permissions, policy hash, context binding and live telemetry. |
| Unknown controller write | Stop retrying and arrange engineering inspection/reconciliation. |
| HTTPS login/session failure | Check secure cookies, trusted hostname, proxy headers, CNC_TRUST_PROXY and browser time/certificate trust. |
| Changed .env appears ignored | Existing process environment variables take precedence; restart with the intended environment and configuration home. |

API errors include a request reference so administrators can correlate application logs. Do not share full credential-bearing environment files while troubleshooting. Model IDs appear in system status for diagnostics; normal conversation and approval cards use readable source/action labels.

## 8. Validation and release boundaries

The source tests exercise database initialization/migration, SQL authorization, authentication/CSRF, persistent approvals, policy failures, concurrent attempts, uncertain readback, RAG extraction/provenance, mocked local-model contracts, resumable downloader behavior and actual loopback OPC UA transport. Browser validation uses temporary demo data and checks the real UI through Waitress. VALIDATION.md records the completed run and its scope.

The build environment did not load the four model weights or run H200 inference, native Windows/PowerShell, Docker/systemd or a physical CNC. Perform those provided installation and site gates on the intended systems. No simulation result establishes real-machine safety or cutting compatibility.

This release uses one active application authority, local SQLite and a curated local vector index. It does not provide automatic high availability, SSO, OCR, generic external SQL dialects, arbitrary robot motion or million-document performance guarantees. These boundaries keep current behavior explicit and make future extensions reviewable.

Keep the release ZIP, dependency lock, model commit manifests, policy/node-map revision, corpus hashes and site acceptance record together. Use the native CNC/PLC safety mechanisms and approved factory procedures throughout commissioning and production operation.

# Architecture

## Design decision

Use a bounded application orchestrator, four independent local inference services and a separate deterministic machine-control boundary. Reuse the conversation service for reports and the code service for planning/control proposals. This avoids duplicate model loads while allowing safety and embedding traffic to run independently. The LLM has no credentials, SQL connection, filesystem execution tool or OPC UA node-write function.

A single authoritative application/database host owns control state. Server B hosts the larger coding service. The deployment deliberately starts with one application instance and four model services; it is not a multi-master control system. Remaining H200 GPUs can support measured capacity growth. SQL analytical sources and sector profiles are replaceable without replacing the machine-policy authority.

```mermaid
flowchart TD
    UI["Authenticated browser"] --> API["Application and role checks"]
    API --> ORCH["Bounded orchestration"]
    ORCH --> ROUTER["Local model router"]
    ROUTER --> CONV["Conversation and reports · 8001"]
    ROUTER --> CODE["Code, plans and proposals · 8002"]
    ROUTER --> GUARD["Secondary risk judge · 8003"]
    ORCH --> EVID["Evidence retrieval"]
    EVID --> SQL["Validated read-only SQL"]
    EVID --> RAG["BM25 and semantic retrieval"]
    RAG --> EMB["Embeddings · 8004"]
    ORCH --> PROP["Persistent proposal"]
    API --> REVIEW["Supervisor decision and requester confirmation"]
    PROP --> REVIEW
    REVIEW --> POLICY["Ordered deterministic checks"]
    POLICY --> ADAPTER["Typed OPC UA adapter"]
    ADAPTER --> CNC["Native CNC and PLC enforcement"]
    POLICY --> AUDIT["Write intent, readback and audit"]
```

The arrows from the router do not grant direct access to machines or databases. Only server code validates and executes permitted operations. RAG documents are untrusted evidence, not instructions or permission sources.

## Package boundaries

| Module | Responsibility |
|---|---|
| `config.py`, `contracts.py` | Explicit environment loading; strict request, plan, answer and event schemas |
| `database.py`, resource migrations | Fixed factory storage, seeded business domain, checksummed migrations, backup, audit chain |
| `auth.py` | Password hashes, server-side sessions, CSRF tokens, fresh role/permission checks |
| `models.py` | Seven-role routing, four local HTTP services, structured decoding, Guardian 4.1 and embedding compatibility |
| `sql.py`, `catalog.py` | Approved analytical sources, schema management and read-only SQL execution |
| `rag.py`, `reports.py` | Document extraction, provenance, hybrid retrieval and source-linked report summaries |
| `assistant.py` | Bounded plan/retrieve/answer/judge flow; no open-ended agent loop |
| `control/policy.py` | Ordered decisions without any language-model dependency |
| `control/service.py` | Persistent approval lifecycle, exactly one write attempt per proposal, reconciliation |
| `control/adapters.py` | Adapter selection facade |
| `control/simulator.py`, `control/opcua.py`, `control/types.py` | Separate simulator, gated real OPC UA transport and shared typed observations |
| `control/telemetry.py` | Read-only observation recording with quality/timestamps |
| `web/app.py`, `cli.py` | Application factory, HTTP/session boundary, Waitress and administration commands |

Imports have no startup side effects. `python -m cnc_ai`, `cnc-ai` and installed scripts work from outside the repository when `--home` or `CNC_HOME` identifies the configuration directory. Site files override packaged defaults by filename; models and runtime data stay outside source control.

## Conversational request lifecycle

1. Authenticate the browser session and check the CSRF token on a mutation. Resolve the server-owned conversation and its analytical source.
2. Judge the current user input with Guardian. The factory-domain criterion permits supporting greetings and general manufacturing guidance while judging bypasses, invented live state and unrelated requests.
3. Ask the code/planner service for a strict `Plan`. Modes are conversation, data, code, status, control and clarify. A plan has at most four queries, or one allowlisted proposal, never arbitrary tools.
4. Retrieve sector-scoped document excerpts. Execute SQL only through the validated query service. A live CNC-01 status request obtains fresh read-only controller evidence, including simulator/real mode, timestamps and quality.
5. Produce a strict answer using the conversation or code role. Evidence aliases are validated and translated into immutable evidence references. Missing data-answer citations or unknown references block the answer.
6. Judge the draft output. A control proposal is persisted only after the output judge passes; creating it does not execute it. Record the answer, its evidence links and audit event.

Failures do not silently substitute an unrelated cloud model. In local mode a failed conversation, planner or safety service stops the affected task. Embedding failure degrades only retrieval to BM25. Demo mode has deterministic training responses and explicitly labels Guardian as not evaluated.

## RAG and provenance

PDF page locations, DOCX paragraph/table positions, Excel sheet/row positions and text line ranges survive extraction. The store retains source-file SHA256, revision, category, sector and chunk SHA256. Up to 1,500-character chunks overlap by 300 characters. Retrieval fuses the top BM25 and cosine-similarity candidates using reciprocal-rank fusion and returns at most six excerpts.

Qwen query embeddings include a retrieval instruction; document embeddings contain document text. Vectors are keyed by model ID, configured revision and dimension. This release uses 1,024 dimensions. Reindex after any embedding snapshot or dimension change. A partially embedded collection is valid: lexical search covers all chunks while semantic search covers the indexed portion.

Each cited answer gets an independent evidence snapshot. Deleting or reindexing a source does not rewrite prior answer evidence. Database evidence records the actual SQL, bound parameters, source label, row snapshot, truncation, capture time and SHA256. Evidence establishes what was consulted; it does not guarantee every generated statement is correct. A secondary judge and human review remain useful for interpretation.

## Deterministic control boundary

Control fields are limited to machine, action, RPM and reason. Actor identity comes from the session. Proposal state, policy hash and machine/tool/material/workpiece binding are persisted. Approval must come from a different currently authorized supervisor. Execution rechecks both identities, TTL, proposal state, all seven policy stages and live binding.

A cross-process operating-system file lock prevents concurrent execution/reconciliation. A transactional machine lock and durable write-intent record are committed before network I/O. A crash or unexpected readback leaves the proposal `executing` or `unknown`, blocks further machine writes and requires an engineer's documented reconciliation. The application never automatically retries a possibly delivered machine write. It cannot promise exactly-once delivery across a network; it provides at-most-once attempts and explicit uncertainty.

The wire adapter re-reads coherent telemetry immediately before writing in the same authenticated session. Native PLC/CNC enforcement must handle races that cannot be made atomic by a Python preflight. The adapter reads the setpoint back and compares it; measured spindle response is a separate observation. Feed hold is an ordinary supervised command, not an E-stop channel.

## SQL, roles and trust

Generated SQL is analytical and read-only for all roles. Syntax validation rejects multiple statements, DDL, DML, attachment, pragmas, recursive CTEs and other non-query constructs. SQLite read-only URI mode, `query_only`, disabled extensions and an authorizer enforce allowed tables, columns and functions even through aliases, CTEs and views. A progress handler limits runtime and result wrapping caps rows. Named values are bound through the driver.

Users cannot grant themselves permission by changing a prompt or submitting a requester field. Accounts have local password hashes; sessions are stored by token hash, expire after eight hours and are invalidated on account disable/reset. Administrators manage data/configuration but do not inherit control privileges. Authentication precedes all API work; permission stage five is additionally part of the factory policy evaluation.

Imported SQLite databases are quarantined until an administrator selects an explicit allowlist. The fixed `factory` source is separate. Generated SQL can never access credentials, sessions, proposals or audit tables. Raw imported schemas are visible only to data administrators.

## Production scope and scale

SQLite in WAL mode is an intentional single-host deployment choice with transactional control state and portable Windows development. Do not put its files on NFS/SMB or start independent application hosts against copied control state. Use one active controller authority and tested backups. This release includes no automatic HA failover; a second control authority would require a fenced leader design.

Semantic search currently scans the local vector collection in Python. It is appropriate for an initial curated corpus, not a claim of million-document throughput. Benchmark your corpus and concurrency; a later vector-store adapter should preserve the evidence contract and sector filtering. Large historian imports should use approved analytical replicas and retention management. The 16 H200s do not remove database or retrieval bottlenecks.

There is no SSO/OIDC, OCR service, controller-vendor discovery, job scheduling optimizer, direct SQL Server/PostgreSQL connector, Kubernetes operator or general robot-motion executor in this release. SQL dialect is SQLite. Those are explicit extension points rather than hidden partially implemented modes.

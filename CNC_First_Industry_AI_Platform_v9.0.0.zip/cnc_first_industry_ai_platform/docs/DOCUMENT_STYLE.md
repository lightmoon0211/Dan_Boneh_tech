# Manual source and layout

`USER_MANUAL.md` is the editable content source. `CNC_Factory_Assistant_User_Manual.docx` and the matching PDF are release exports. The supplied Word document uses native heading numbering and a clickable chapter list. The PDF is the fixed-layout reference.

To regenerate Word after editing Markdown, install the application dependencies and run:

```bash
python scripts/docs/build_manual.py
```

Open the resulting Word document in Word or LibreOffice, update fields, and export PDF. Review every page after changes. The release was rendered with LibreOffice and all 19 pages were visually checked. Fonts installed on another workstation can change pagination; the included PDF retains the reviewed result.

The layout follows a compact reference guide: US Letter; 1-inch margins; Calibri 11-point body text with 1.25 line spacing and 6-point paragraph spacing. Heading levels use 16/13/12-point blue text, native multilevel numbering, and keep-with-next. Named editorial overrides are a 32-point navy cover title, a 15-point subtitle, 9-point DejaVu Sans Mono code, and 10-point table text. Tables use a fixed 9360-twip grid, repeated header rows and unsplit rows. The builder asserts matching grid/cell widths. Commands remain executable single lines in the Markdown source even when they wrap visually in Word/PDF.

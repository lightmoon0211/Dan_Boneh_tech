# Air-gapped transfer runbook

## Build a matched staging environment

Use an internet-connected Linux x86-64 staging system matching the factory Linux distribution, Python minor version and NVIDIA driver/CUDA compatibility. The application CPU environment and the inference environment remain separate. Windows can download portable model snapshots, but its installed packages/wheels do not replace Linux GPU wheels.

Create the application and inference environments as shown in README steps 1 and 4. The `smartfactorymodels` environment installs `requirements/h200.txt`; use the staging candidate first, validate on the target H200 class, then freeze the **entire resolved environment**. Pin model commits, the policy revision and corpus revision in the site acceptance record.

Do not assume a pip wheelhouse includes the OS, Python interpreter, GPU driver or container runtime. Include approved offline installers/package mirrors for those separately. The factory needs no Hugging Face account or internet connectivity to run a fully staged installation.

## Prepare the transfer set

1. Download the four physical models on a connected machine, using `--checksums`. Verify the completed snapshots. Keep root-level download manifests and per-model cache metadata for restart/resume and auditability. Copy the full snapshots; symlink-based Hub cache layouts require their referenced blobs too, so the downloader's ordinary local directories are simpler to transfer.
2. Freeze the validated inference environment and build the wheel bundle from a matching Linux application environment:

```bash
mkdir -p /srv/transfer
conda activate smartfactorymodels
python -m pip check
python -m pip freeze > /srv/transfer/inference-lock.txt
conda activate smartfactoryllm
python scripts/prepare_airgap.py --output /srv/transfer/cnc-wheels --inference-lock /srv/transfer/inference-lock.txt
python scripts/verify_bundle.py /srv/transfer/cnc-wheels
```

3. Export the actual application environment record for traceability:

```bash
conda env export -n smartfactoryllm --no-builds > /srv/transfer/smartfactoryllm.yml
conda list -n smartfactoryllm --explicit > /srv/transfer/conda-explicit.txt
python -m pip freeze > /srv/transfer/application-freeze.txt
```

Conda export files alone are not offline installers. Use the factory's approved Conda package mirror/cache, or pack the fully installed matched environments with `conda-pack` on staging and test unpacking on a clean matching host. For a conda-pack route, install that utility on staging and run:

```bash
conda pack -n smartfactoryllm -o /srv/transfer/smartfactoryllm-linux.tar.gz
conda pack -n smartfactorymodels -o /srv/transfer/smartfactorymodels-linux.tar.gz
```

An editable application install cannot be reliably relocated by an environment pack. Before packing `smartfactoryllm`, install the built application wheel as a regular package using the wheelhouse; leave source/configuration separately in `/opt/cnc-ai`.

4. Include the clean project ZIP; dependency/wheel manifests; model directories; tested configuration without shared passwords; driver and OS prerequisites; site TLS/OPC UA certificates through the approved secret channel; and a consistent factory-data backup if migrating data. The sample DB is already in the project for a fresh training installation.
5. Verify hashes before and after the physical transfer. SHA256 protects transfer integrity against accidental corruption; verify the provenance of the original release/transfer medium through the site's trusted process.

## Install without network

With a pre-provisioned Python 3.12/Conda runtime on the factory hosts, extract the project to `/opt/cnc-ai` and transfer wheels to `/srv/transfer/cnc-wheels`. Create the application environment from the approved offline Conda cache:

```bash
conda create --offline -n smartfactoryllm python=3.12 pip -y
conda activate smartfactoryllm
python -m pip install --no-index --find-links /srv/transfer/cnc-wheels/app-wheelhouse cnc-first-ai==9.0.0 pytest pytest-cov huggingface-hub
```

`conda create --offline` requires those exact packages already present in the cache. If using packed environments instead, extract each into its chosen directory and run its `bin/conda-unpack`; use that interpreter path in systemd. Test relocation during staging, not for the first time on the factory.

On each inference host, using a separately provisioned compatible Python environment:

```bash
conda activate smartfactorymodels
python -m pip install --no-index --find-links /srv/transfer/cnc-wheels/inference-wheelhouse -r /srv/transfer/cnc-wheels/inference-lock.txt
python -m pip check
```

Do not install the inference requirements into the application environment. A complete wheel lock may include locally built or vendor packages that `pip download` cannot resolve; the preparation script fails in that case. Add the actual approved wheels to the wheelhouse and rerun verification/staging rather than deleting requirements to make installation appear successful.

## Place and verify models

Set `MODEL_ROOT=/srv/ai/models` and the four service path fields to local Linux paths. Copy `F:/AI/models` from Windows as files into that directory; Windows drive syntax must not remain in a Linux `.env`. On the application host set its four private endpoint URLs and matching API keys. Set `EMBEDDING_MODEL_REVISION` to the copied model's commit.

```bash
python scripts/models/download_factory_models.py all --model-root /srv/ai/models --verify --checksums
python scripts/verify_bundle.py /srv/transfer/cnc-wheels
```

The serving launcher forces offline Hugging Face/Transformers resolution and disables vLLM usage telemetry. It supplies an existing local directory to `vllm serve`, not a repository name that could trigger a fetch. A missing tokenizer, processor or shard must be corrected on staging and retransferred.

## Factory acceptance sequence

- Start with the two server profiles and real-write flags false. Verify all four inference services from the application environment, including structured output and the factory prompt acceptance set in `MODELS.md`.
- Initialize an empty business database for real data or restore the approved legacy migration. Keep training records distinguishable; sample policies are never promoted as real OEM ratings.
- Create named accounts, ingest approved documents, rebuild embeddings and inspect retrieved citations in the main factory languages.
- Run `python -m pytest` in the source checkout against temporary data, `python -m cnc_ai validate --offline`, then `python -m cnc_ai validate --models --opcua` with the selected simulator/read-only adapter. The tests never require factory model weights.
- Complete browser and role tests through the actual HTTPS entrypoint. Test approved, rejected, expired, stale-telemetry, bad-quality, permission-revocation and network-loss scenarios under controlled conditions.
- Follow `CONTROL_COMMISSIONING.md` for real machine acceptance. Only then enable the two site write flags. Record controller firmware, node mapping, policy hash, account roles, model commits and dependency lock with the release.

## Docker transfer alternative

Build on matched staging and save the application image:

```bash
docker compose -f deployment/docker/compose.yml build
docker save -o /srv/transfer/cnc-first-ai-9.0.0-image.tar cnc-first-ai:9.0.0
```

Transfer and verify the image archive, then on factory Linux:

```bash
docker load -i /srv/transfer/cnc-first-ai-9.0.0-image.tar
docker compose -f deployment/docker/compose.yml up -d --no-build
```

The site must already have the approved container runtime. Configure persistent mounts/UID and initialize the database before starting, as described in `DEPLOYMENT.md`. The host inference stack and models remain separately staged; this image does not contain vLLM or weights.

## Rollback

Preserve the previous code artifact, dependency/environment pack, model snapshot and configuration. Before upgrade stop control traffic and take consistent backups. If rollback is necessary, keep real writes disabled, reconcile physical controller state and any uncertain attempt, restore compatible data/configuration and rerun validation. Do not replay historical proposals after restoring a backup. Applied database migrations are forward-only; a code rollback must use a tested compatible database backup, not edit migration checksums.

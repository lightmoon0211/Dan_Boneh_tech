# Deployment and operations

## Supported topology

Server A owns the application, its local SQLite database, document/vector storage and the conversation/safety/embedding services. Server B hosts code/planner/control-proposal inference. Both have eight H200s; CUDA indices in `models.json` are local to each host. Controllers reside on an approved OT interface. Users connect through the site's HTTPS proxy. The Windows development installation uses the same Python package with demo mode or private model URLs.

Only the application service can reach the reviewed OPC UA endpoint. Inference services do not receive OPC UA credentials and should have no route to controller write interfaces. Restrict ports 8001/8003/8004 on A and 8002 on B to the application host. Restrict port 5000 to the local reverse proxy. DNS/NTP can be supplied by the factory's internal infrastructure.

## Files and permissions

Extract code to `/opt/cnc-ai`; store models at `/srv/ai/models`; create a dedicated `cncai` OS account and local runtime directory. Edit paths to suit site conventions. Keep `.env` and certificates readable only by the service account and authorized administrators. Configuration is reviewed code-adjacent input; only the runtime directory needs application write access.

```bash
sudo install -d -o cncai -g cncai -m 700 /opt/cnc-ai/runtime
sudo chown cncai:cncai /opt/cnc-ai/.env
sudo chmod 600 /opt/cnc-ai/.env
```

Prepare the account and Conda environments using the site's normal OS provisioning. Do not blindly apply recursive ownership changes to existing factory data. On Linux replace every `F:/...` model path in `.env`, and set `MODEL_ROOT=/srv/ai/models`. Restart services after configuration changes.

## systemd

The supplied unit files are examples with `/opt/conda/envs/...` interpreter paths. Resolve the actual environment path with `conda run -n smartfactoryllm python -c 'import sys; print(sys.executable)'` and update the units before installation. Models use `smartfactorymodels`.

```bash
sudo cp deployment/systemd/cnc-ai.service /etc/systemd/system/
sudo cp deployment/systemd/cnc-models@.service /etc/systemd/system/
sudo cp deployment/systemd/cnc-telemetry.service /etc/systemd/system/
sudo systemctl daemon-reload
```

On A, after initialization and configuration:

```bash
sudo systemctl enable --now cnc-models@server-a.service
sudo systemctl enable --now cnc-ai.service
```

On B:

```bash
sudo systemctl enable --now cnc-models@server-b.service
```

Start the optional read-only telemetry recorder on the authoritative application host after validating the adapter:

```bash
sudo systemctl enable --now cnc-telemetry.service
journalctl -u cnc-ai.service -n 100 --no-pager
journalctl -u cnc-models@server-a.service -n 100 --no-pager
```

Model child logs are under `runtime/model_logs`. Configure log rotation and monitor free disk. The service launcher stops its sibling children if one fails; systemd restarts that host profile. This is startup supervision, not model-level HA routing. For maintenance stop the profile explicitly.

## HTTPS browser access

Install `deployment/nginx.conf` into the site's nginx HTTP configuration, set the actual hostname and certificate/key paths and test it using `nginx -t`. Waitress stays at `127.0.0.1:5000`. Set:

```dotenv
CNC_COOKIE_SECURE=true
CNC_TRUST_PROXY=true
CNC_HOST=127.0.0.1
```

The proxy replaces forwarded headers. `CNC_TRUST_PROXY=true` trusts exactly one proxy hop, so direct untrusted access to Waitress must be blocked. It allows correct HTTPS origin checks and secure cookies. Use the site's trusted CA; do not disable browser certificate validation. Local workstation HTTP uses both flags false.

## Docker option

The Linux-only Compose example uses host networking so local and private model/controller endpoints resolve as configured. It runs the application as UID/GID 10001 with a read-only container filesystem and writable runtime mount. Model serving remains a separate host environment. Review the environment and mount paths first.

```bash
docker compose -f deployment/docker/compose.yml build
mkdir -p runtime
sudo chown 10001:10001 runtime
docker compose -f deployment/docker/compose.yml run --rm app python -m cnc_ai db init --sample
docker compose -f deployment/docker/compose.yml run --rm app python -m cnc_ai user add factory_admin --role admin
docker compose -f deployment/docker/compose.yml up -d
```

For real OPC UA, add read-only mounts for the site's client key/certificates and configure the container-visible paths. Do not mount the Docker socket. This image requires build-time dependency access; build on staging and use image save/load for air-gapped use. The example is not a Windows Docker Desktop networking profile. Keep the host HTTPS proxy and loopback application bind.

## Backups and restore

`python -m cnc_ai db backup /srv/backups/cnc-YYYYMMDD.db` uses SQLite's online backup API and refuses to overwrite an existing backup. Back up runtime documents, imported source databases, configuration, model manifests and audit-chain checkpoints as well. Stop ingestion/report activity when taking a coordinated filesystem/database backup so references align. Encrypt/protect backups using the site's standard tooling.

For a consistent whole-runtime backup, stop the application and telemetry services, take the database backup, copy the documents/sources/configuration, then restart. Do not copy a live SQLite main file without its WAL. During restore keep the application stopped, restore a consistent set, run `db migrate`, `validate --offline` and `audit-verify`, and reconcile actual controller state before accepting control actions. Never use a rollback to replay a delivered proposal.

The SHA256 audit chain and append-only triggers detect ordinary tampering but do not defeat an administrator who rewrites an entire database and its anchors. Export the chain head to a separately protected log/archive as part of operations. Retention and immutable external anchoring are site responsibilities.

## Capacity and maintenance

The telemetry recorder defaults to one observation every five seconds. Set a site retention/archival policy based on actual row growth; no background deletion of evidence/audit/control records is performed. SQLite is not a high-rate multi-server historian. Use curated analytical replicas for bulk history, and never share the live file over SMB/NFS.

RAG ingestion is synchronous with bounded document size. Schedule large ingestion and report jobs outside peak interactive periods. Benchmark semantic retrieval on the actual corpus before expanding it substantially. Back up before upgrades, apply migrations through the CLI, refresh a reviewed SQL allowlist with `db refresh-policy`, and restart the service. Applied migration files must not be edited.

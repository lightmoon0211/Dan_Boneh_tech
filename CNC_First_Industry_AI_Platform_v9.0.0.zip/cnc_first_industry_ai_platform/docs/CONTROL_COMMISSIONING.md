# CNC control and site commissioning

## Authority and permitted actions

The machine-control authority is the reviewed deterministic policy plus authenticated factory permissions and native CNC/PLC mechanisms. Guardian is a secondary text-risk judge. Retrieved manuals, imported databases and model outputs never change the control policy automatically.

The delivered machine panel targets CNC-01. Two actions exist: `set_spindle_rpm` with a finite numeric RPM and `feed_hold` with a fixed Boolean true. There is no axis jog, start-cycle, reset, raw node-ID field, G-code upload or arbitrary OPC UA value route. A broader controller integration requires code, configuration and tests for each new typed action.

## Ordered evaluation

| Order | Question | Required evidence or decision |
|---:|---|---|
| 1 | Is CNC-01 running and in an appropriate state? | Fresh controller state must match a reviewed allowed state; missing/unsupported states block. |
| 2 | Is the selected tool rated for the requested RPM? | The observed tool must have an approved assembly rating; include the holder/fixture restrictions in that commissioned rating. |
| 3 | Is the tool/material/workpiece combination compatible? | Observed tool, material and workpiece must match an approved recipe and material compatibility. |
| 4 | Is the value inside configured limits? | Machine and recipe bounds intersect; the permitted step from current setpoint also applies. |
| 5 | Does the authenticated operator have permission? | The server resolves the current account and its permitted action; a model cannot supply identity. |
| 6 | Is supervisor approval required? | Default: every delivered action requires a different currently authorized supervisor. |
| 7 | Are interlocks and telemetry healthy? | All required aliases, exact types, good OPC UA status, source timestamps, coherent ages, door, E-stop and write-permitted signals. |
| 8 | May the write occur? | Only an eligible persisted proposal, requester confirmation and passing live recheck reach the typed adapter. |

The evaluation records every stage in order, marking later checks skipped after a failure. Authentication and API authorization also occur before factory evaluation. Approval-required is a waiting state, not a permission to write. A proposal expires after five minutes by default.

The **fictional training configuration** starts at setpoint 6000 RPM, T07 assembly rating 8000 RPM, material AISI-4140 and workpiece WP-4140-01. The recipe allows 800–7500 RPM; the machine allows 500–9000 RPM and a maximum 1500-RPM step. Thus a supervised 7000-RPM proposal may pass. These numbers are not recommendations for cutting AISI-4140 or for any physical machine.

## Internal simulator and protocol simulator

`simulator` keeps state in the application database. It returns fresh simulated timestamps and records that the values are simulated. Updating its requested setpoint does not fabricate measured actual spindle response.

`opcua_test` connects only to loopback. The separate training server exposes OPC UA variables with writable setpoint/feed-hold nodes and heartbeat timestamps. It has no physical machine connection and intentionally uses no-security transport on loopback. It exercises the actual asyncua client, typed writes and readback.

`real` uses the same typed client boundary with commissioning gates, authenticated encryption and a pinned server certificate. Test mode and real mode are not interchangeable connectivity labels.

## Engineer's mapping procedure

1. Inventory the controller model/firmware, OPC UA namespace URIs and current node IDs, variable types, engineering units, source timestamp behavior and writable command semantics. The sample namespace index `ns=2` is not portable between controllers. Export a site mapping and record its version.
2. Map `state`, `tool`, `material`, `workpiece`, `actual_rpm`, `setpoint`, `door_closed`, `estop_ok`, `write_permitted` and `feed_hold` in `config/opcua.json`. The final write aliases require `writable: true` and exactly `Double` or `Boolean`. The adapter rejects a type mismatch.
3. Confirm that tool and workpiece identifiers come from trusted controller/PLC production context, not a free-text operator note. If these signals are unavailable, provide an engineered authoritative integration; do not substitute a model guess.
4. Replace `config/policy.json` with approved machine, tool-assembly and process recipes. Define allowed state semantics per controller. The delivered RUNNING/AUTO values are examples. An operating state alone does not establish safe machining conditions.
5. Prove that the native controller atomically rejects invalid commands based on its active state, job/tool/material, range and interlocks. The application checks are not atomic with the physical process. A direct writable setpoint without native enforcement does not meet this design's commissioning requirement.
6. Configure the controller to expose trustworthy, sufficiently fresh source timestamps with consistent clock synchronization. Default maximum age is 5 seconds, allowed spread 2 seconds and future tolerance 1 second. Missing/bad/stale values block actions. Configure limits to match actual controller publishing behavior after review, not to hide a fault.
7. Establish a dedicated service account limited to the reviewed variables. Install its client certificate/private key and the pinned server certificate outside the repository. Restrict file permissions and network access. Check controller trust lists and certificate expiration. Set the `.env` certificate and credential fields; the real client uses Basic256Sha256/SignAndEncrypt.
8. Mark `real_mapping_reviewed` and `controller_enforces_limits` true only when supported by recorded commissioning evidence. Set `CNC_OPCUA_MODE=real`, `CNC_MODEL_MODE=local`, and leave `CNC_REAL_WRITES_ENABLED=false` and `CNC_SITE_COMMISSIONED=false` while testing read-only connectivity.
9. Run `python -m cnc_ai validate --opcua`. Observe bad-quality, stale, disconnected, mismatched tool/material and interlock-open cases. Verify that no write occurs. Test every rejection path against an isolated controller test program under the site's machinery procedures.
10. Perform the site's controlled write acceptance with the authorized operator/supervisor and controls engineer. Only after this gate set both real-write environment flags true. Restart the application. Keep commissioned configuration and model/corpus revisions in the release record.

The service account's permission is not a replacement for the human operator's permission. An emergency response must use the native machine's E-stop and established operating procedures; the supervised feed-hold action may depend on network and approvals.

## Execution and uncertainty

Before I/O, the service persists the proposal consumption, execution record and machine lock in one transaction. The adapter then rechecks telemetry/binding in its active session, writes exactly one typed setpoint and reads it back. A spindle readback must be finite and within the configured 1-RPM default tolerance. It confirms accepted setpoint only; actual speed is independently observed.

If an exception, timeout, mismatch or process crash occurs after write intent, assume the action may have arrived. The application never retries it automatically. A stored `unknown` or unfinished `executing` record blocks later proposals from writing to that machine, including after a reboot.

An engineer inspects the native controller and determines the actual state. Use the execution reference from the audit/administrative database and record that inspection:

```bash
python -m cnc_ai reconcile EXECUTION_REFERENCE --note 'Inspected CNC-01 locally; setpoint and physical state verified; no replay authorized.'
```

This local CLI requires operating-system administration access. It cannot overlap an active adapter operation because both acquire the same OS file lock. It closes the old proposal as blocked, records observed setpoint and the note, and releases the uncertainty lock. It does not replay the command. Make a new proposal if a new action is required. Do not remove lock rows, edit proposal state or restore an old database to bypass uncertainty.

## Configuration changes and recovery

Changing policy contents invalidates outstanding proposals through the stored policy hash. Changing the observed tool, material, workpiece or machine state invalidates the proposal binding. Revoking the requester or approver's permissions also blocks execution. The final check and native controller remain necessary because conditions can change after approval.

Store the application database on local persistent storage. Restore backups only with the application stopped and the physical controller state reconciled. A restored database may predate a delivered write. No active/active controller authority or unattended failover is configured in this release.

# Local application API

The browser uses the same-origin JSON API below. It is an authenticated application boundary, not a public inference endpoint. Inference ports 8001–8004 are separate services. Do not expose the application or inference API directly to the internet.

Sign in with `POST /api/login` and a JSON object containing `username` and `password`. The response sets an HttpOnly session cookie and returns a CSRF token. Send that cookie on authenticated requests and the returned token as `X-CSRF-Token` on every mutation. `GET /api/session` refreshes the client's view of identity, permissions and the token. Login uses same-origin checks; site HTTPS deployments require the configured trusted proxy and secure cookies.

| Method and path | Purpose |
|---|---|
| GET `/api/health` | Unauthenticated application liveness/version only |
| GET `/api/status` | Database/RAG status, model advertisement probes and configured controller mode |
| POST `/api/models/verify` | Administrator-triggered real model request checks |
| GET `/api/conversations` | Current user's recent conversations |
| GET `/api/conversations/<key>` | Current user's messages and evidence |
| POST `/api/chat` | Strict `ChatRequest`: bounded planning, RAG/SQL evidence and answer, or a control proposal |
| GET/POST `/api/documents` | List or ingest a multipart file with kind, sector and revision |
| DELETE `/api/documents/<key>` | Delete a source and its linked reports; prior answer evidence remains |
| POST `/api/documents/rebuild` | Rebuild document vectors for the current embedding fingerprint |
| GET/POST `/api/reports` | List reports or summarize a document |
| GET `/api/reports/<key>/evidence` | Source chunks cited by a report |
| DELETE `/api/reports/<key>` | Remove the summary while retaining the document |
| GET `/api/control/status` | Read current configured CNC-01 snapshot and telemetry health |
| POST `/api/control/preflight` | Evaluate a strict `ControlRequest` without issuing a write |
| GET/POST `/api/control/proposals` | List visible proposals or create a persistent proposal |
| POST `/api/control/proposals/<key>/decision` | Separate supervisor `Approval` decision |
| POST `/api/control/proposals/<key>/execute` | Requester confirmation and live deterministic recheck before a typed write |
| GET/POST `/api/sources` | List approved/visible sources or quarantine an uploaded SQLite file |
| GET `/api/schema?source=factory` | Approved query schema |
| GET `/api/sources/<key>/schema` | Administrative import-schema review |
| POST `/api/sources/<key>/approve` | Approve a reviewed table/column mapping |
| POST `/api/sources/create` | Create an analytical database from a validated definition |
| POST `/api/query` | Execute a strict `Query` inside `{query, source}` through read-only authorization |
| GET/POST `/api/sectors` | Read profiles or administer an analytical sector profile |
| GET/POST `/api/ui-text` | Read or administer translated fixed navigation labels |
| GET `/api/audit` | Authorized audit-event review |
| POST `/api/logout` | Invalidate the browser session |

Permissions are enforced by the web and service layers; possession of a CSRF token alone grants no role. Private conversation IDs, evidence IDs and proposal IDs are opaque references and never authorization credentials. Generated SQL cannot change users, approvals, policy or machine authority. Additional analytical sources cannot replace the CNC controller's authoritative data.

The execution request body is `{"confirmation":"EXECUTE APPROVED ACTION"}`. It contains no node ID, arbitrary OPC UA value or alternative machine action. Approved proposal fields are loaded from persistent state, checked against current identity/policy/context and consumed before network I/O.

JSON schema exports for Query, ControlRequest, Plan, Answer, Approval, Evidence, AuditEvent and ChatRequest are in `contracts/`; their authoritative Python definitions are `src/cnc_ai/contracts.py`. Pydantic rejects unknown fields and performs additional coherence checks beyond JSON Schema (for example, only a control plan may contain a control request). Never treat a model-constrained output as proof that the underlying request is permitted.

Failures return a readable `error` and a `request_id` for log correlation. Typical status codes are 400 for invalid requests, 401 for missing/expired sessions, 403 for denied permission/session verification, 409 for uncertain write outcomes, 503 for unavailable or invalid model responses and 500 for unexpected server failures. Raw backend tokens and exception bodies are not returned. `/api/health` success does not imply database, model or CNC readiness; use the authenticated status and explicit validation commands.

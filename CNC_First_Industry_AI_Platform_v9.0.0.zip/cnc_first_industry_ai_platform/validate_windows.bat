@echo off
powershell.exe -NoProfile -File "%~dp0scripts\windows\validate.ps1"
exit /b %errorlevel%

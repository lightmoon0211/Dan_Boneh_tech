"""Seven logical roles, four physical local inference services."""

from __future__ import annotations
import json
import math
import os
import re
import time
from concurrent.futures import ThreadPoolExecutor
from urllib import request, error
from urllib.parse import urlparse
from .database import encode, digest, now


class ModelUnavailable(RuntimeError):
    pass


RISK_CRITERION = (
    "The evaluated text requests or claims a bypass of CNC/PLC interlocks, E-stops, "
    "authorization, approval or deterministic limits; instructs unapproved automatic machine motion; "
    "treats NC/robot code as validated for direct execution; fabricates live machine state; "
    "or is unrelated to manufacturing, engineering, factory operations, or assistance using this application. "
    "Greetings and ordinary conversation supporting these factory tasks are permitted. "
    "Read-only analysis, diagnosis, unverified draft code, and guarded control proposals are permitted."
)


class ModelRouter:
    def __init__(self, settings):
        self.settings = settings
        self.registry = settings.read("models.json")
        self.last_success = {}
        self.last_embedding_error = ""
        self.embedding_retry_at = 0
        expected = {
            "conversation",
            "report",
            "code",
            "planner",
            "control",
            "embedding",
            "safety",
        }
        if set(self.registry["roles"]) != expected:
            raise ValueError("Model router must configure all seven logical roles.")
        for service in self.registry["roles"].values():
            if service not in self.registry["services"]:
                raise ValueError("Model role references an unknown service.")

    def spec(self, role):
        service = self.registry["roles"][role]
        spec = dict(self.registry["services"][service])
        spec["service"] = service
        spec["revision"] = os.getenv(
            service.upper() + "_MODEL_REVISION", spec.get("revision", "site-default")
        )
        spec["base_url"] = os.getenv(
            spec["url_env"], f"http://127.0.0.1:{spec['port']}/v1"
        ).rstrip("/")
        url = urlparse(spec["base_url"])
        if (
            url.scheme not in {"http", "https"}
            or not url.hostname
            or url.username
            or url.password
            or url.query
            or url.fragment
        ):
            raise ValueError("Inference URL must be a plain local HTTP(S) base URL.")
        return spec

    def call(self, role, endpoint, payload=None, timeout=None):
        spec = self.spec(role)
        headers = {"Content-Type": "application/json"}
        key = os.getenv(spec["key_env"], "")
        if key:
            headers["Authorization"] = "Bearer " + key
        req = request.Request(
            spec["base_url"] + "/" + endpoint,
            headers=headers,
            data=encode(payload).encode() if payload is not None else None,
            method="POST" if payload is not None else "GET",
        )
        try:
            opener = request.build_opener(request.ProxyHandler({}))
            with opener.open(
                req, timeout=timeout or int(os.getenv("MODEL_API_TIMEOUT", "120"))
            ) as response:
                result = json.loads(response.read(8 * 1024 * 1024))
            return result
        except (error.URLError, error.HTTPError, TimeoutError, ValueError) as exc:
            # Do not expose backend exception bodies/URLs/tokens in the user interface.
            raise ModelUnavailable(
                f"The local {spec['service']} service is unavailable or returned invalid data. Check its server log and configured endpoint."
            ) from exc

    def generate(self, role, messages, schema=None, max_tokens=1800, extra=None):
        if self.settings.model_mode == "demo":
            raise ModelUnavailable(
                "Demo mode has no language model. Use the built-in training examples or start local inference."
            )
        spec = self.spec(role)
        payload = {
            "model": spec["model"],
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": 0.1,
            "stream": False,
        }
        payload.update(spec.get("extra_body", {}))
        if schema:
            payload["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": schema.__name__,
                    "schema": schema.model_json_schema(),
                    "strict": True,
                },
            }
        if extra:
            payload.update(extra)
        result = self.call(role, "chat/completions", payload)
        try:
            choice = result["choices"][0]
            if choice.get("finish_reason") == "length":
                raise ValueError("Model output was truncated.")
            text = choice["message"]["content"]
            if not isinstance(text, str) or not text.strip():
                raise ValueError("Empty model response.")
            parsed = schema.model_validate_json(text) if schema else text.strip()
        except (KeyError, IndexError, ValueError, TypeError) as exc:
            raise ModelUnavailable(
                f"The {spec['service']} response did not satisfy the required output contract."
            ) from exc
        self.last_success[spec["service"]] = now()
        return parsed

    def judge(self, user_text, assistant_text=None, evidence=None):
        if self.settings.model_mode == "demo":
            return {"safe": True, "mode": "demo-not-evaluated", "score": None}
        messages = [{"role": "user", "content": user_text}]
        target = "user"
        criterion = RISK_CRITERION
        if assistant_text is not None:
            messages.append({"role": "assistant", "content": assistant_text})
            target = "assistant"
            if evidence:
                criterion += " The response also fails if factory-specific factual claims contradict or lack support in the supplied evidence documents."
        instruction = (
            "<no-think>As a judge agent, assess whether the provided text meets the given judging criteria using all available information, including conversations, documents, and tools. Provide your score immediately without explanation. Output empty <think>\n</think> tags followed by your score in <score></score> tags.\n\n"
            + f"### Criteria: {criterion}\n\n### Scoring Schema: If the last {target}'s text meets the criteria, return 'yes'; otherwise, return 'no'."
        )
        messages.append({"role": "user", "content": instruction})
        extra = {"temperature": 0.0}
        if evidence:
            extra["chat_template_kwargs"] = {
                "documents": [
                    {"doc_id": e["id"], "text": e["content"]} for e in evidence
                ]
            }
        raw = self.generate("safety", messages, max_tokens=128, extra=extra)
        cleaned = re.sub(r"<think>.*?</think>", "", raw, flags=re.S).strip()
        match = re.fullmatch(r"<score>\s*(yes|no)\s*</score>", cleaned, re.I)
        if not match:
            raise ModelUnavailable(
                "Guardian did not return a valid risk score. Request stopped."
            )
        return {
            "safe": match[1].lower() == "no",
            "mode": "guardian",
            "score": match[1].lower(),
        }

    @property
    def embedding_fingerprint(self):
        s = self.spec("embedding")
        return digest(
            encode(
                {
                    "model": s["model"],
                    "revision": s.get("revision", "site-default"),
                    "dimensions": s.get("dimensions", 1024),
                }
            )
        )

    def embed(self, texts, query=False):
        if self.settings.model_mode == "demo":
            raise ModelUnavailable("Semantic retrieval is disabled in demo mode.")
        if time.monotonic() < self.embedding_retry_at:
            raise ModelUnavailable(self.last_embedding_error)
        spec = self.spec("embedding")
        inputs = texts
        if query:
            inputs = [
                "Instruct: Retrieve relevant CNC manufacturing manuals and approved procedures.\nQuery: "
                + x
                for x in texts
            ]
        try:
            result = self.call(
                "embedding",
                "embeddings",
                {
                    "model": spec["model"],
                    "input": inputs,
                    "dimensions": spec.get("dimensions", 1024),
                },
                timeout=15,
            )
            data = sorted(result["data"], key=lambda x: x["index"])
            if [d["index"] for d in data] != list(range(len(texts))):
                raise ValueError("Embedding index mismatch.")
            vectors = [d["embedding"] for d in data]
            for v in vectors:
                if (
                    len(v) != spec.get("dimensions", 1024)
                    or not all(
                        isinstance(n, (float, int))
                        and not isinstance(n, bool)
                        and math.isfinite(n)
                        for n in v
                    )
                    or sum(n * n for n in v) <= 0
                ):
                    raise ValueError("Invalid embedding vector.")
        except (KeyError, ValueError, TypeError, ModelUnavailable) as exc:
            self.last_embedding_error = (
                "Embedding service is unavailable; lexical retrieval remains active."
            )
            self.embedding_retry_at = time.monotonic() + 30
            raise ModelUnavailable(self.last_embedding_error) from exc
        self.last_embedding_error = ""
        self.last_success["embedding"] = now()
        return vectors

    def status(self, probe=False):
        def health(service):
            spec = self.spec(service)
            state = "not_checked"
            detail = "Endpoint has not been probed."
            if self.settings.model_mode == "demo":
                state = "demo"
                detail = "Training mode; no model loaded."
            elif probe:
                try:
                    models = self.call(service, "models", timeout=3)
                    if not any(
                        item.get("id") == spec["model"]
                        for item in models.get("data", [])
                    ):
                        state = "model_mismatch"
                        detail = "Server is reachable but the configured model is not advertised."
                    else:
                        state = "reachable"
                        detail = (
                            "Model is advertised; generation is verified separately."
                        )
                except ModelUnavailable:
                    state = "unreachable"
                    detail = "Start this service or correct its private endpoint."
            return service, {
                "model": spec["model"],
                "port": spec["port"],
                "state": state,
                "detail": detail,
                "last_inference_success": self.last_success.get(service),
            }

        with ThreadPoolExecutor(max_workers=4) as pool:
            services = dict(pool.map(health, self.registry["services"]))
        return {
            "mode": self.settings.model_mode,
            "roles": self.registry["roles"],
            "services": services,
        }

    def smoke(self):
        from .contracts import Answer, Plan

        if self.settings.model_mode == "demo":
            return {
                service: "not evaluated (training mode)"
                for service in self.registry["services"]
            }
        results = {}
        cases = [
            (
                "conversation",
                Answer,
                "Return an Answer with answer='Factory connection test OK', empty citations and empty suggestions.",
            ),
            (
                "code",
                Plan,
                "Return a control Plan proposing set_spindle_rpm for CNC-01 at 7000 RPM, with reason='Schema validation only'. Use no queries and an empty clarification. This is an output-format test; no machine action will be performed.",
            ),
        ]
        for role, schema, prompt in cases:
            try:
                self.generate(
                    role,
                    [{"role": "user", "content": prompt}],
                    schema=schema,
                    max_tokens=512,
                )
                results[role] = "passed"
            except ModelUnavailable as exc:
                results[role] = str(exc)
        try:
            verdict = self.judge("Explain safe read-only CNC monitoring.")
            results["safety"] = "passed" if verdict["safe"] else "unexpected risk score"
        except ModelUnavailable as exc:
            results["safety"] = str(exc)
        try:
            self.embed(["CNC spindle maintenance"])
            results["embedding"] = "passed"
        except ModelUnavailable as exc:
            results["embedding"] = str(exc)
        return results

"""Positive SQL authorization at both syntax and SQLite runtime layers."""

import sqlite3
import time
import uuid
import sqlglot
from sqlglot import exp
from .database import digest, encode, now, identifier
from .contracts import Query

FUNCTIONS = {
    "count",
    "sum",
    "avg",
    "min",
    "max",
    "round",
    "coalesce",
    "ifnull",
    "nullif",
    "abs",
    "lower",
    "upper",
    "length",
    "substr",
    "substring",
    "trim",
    "ltrim",
    "rtrim",
    "replace",
    "date",
    "time",
    "datetime",
    "julianday",
    "strftime",
    "unixepoch",
    "typeof",
    "total",
    "cast",
    "row_number",
    "rank",
    "dense_rank",
    "lag",
    "lead",
    "first_value",
    "last_value",
}


class QueryService:
    def __init__(self, db):
        self.db = db

    def schema(self, source="factory"):
        info = self.db.source(source)
        with sqlite3.connect(
            info["path"].resolve().as_uri() + "?mode=ro", uri=True
        ) as c:
            result = {}
            for table, allowed in info["policy"]["tables"].items():
                cols = {
                    r[1]: r[2]
                    for r in c.execute("PRAGMA table_info(" + identifier(table) + ")")
                }
                result[table] = {col: cols[col] for col in allowed if col in cols}
        return result

    @staticmethod
    def validate(query):
        statements = sqlglot.parse(query.sql, read="sqlite")
        if len(statements) != 1 or statements[0] is None:
            raise ValueError("Exactly one SQL statement is allowed.")
        tree = statements[0]
        if not isinstance(tree, (exp.Select, exp.Union, exp.Intersect, exp.Except)):
            raise ValueError("Only a read-only SELECT query is permitted.")
        for n in tree.walk():
            if isinstance(
                n,
                (
                    exp.Insert,
                    exp.Update,
                    exp.Delete,
                    exp.Create,
                    exp.Drop,
                    exp.Command,
                    exp.Into,
                    exp.Merge,
                ),
            ):
                raise ValueError("SQL writes and administrative commands are blocked.")
        if any(w.args.get("recursive") for w in tree.find_all(exp.With)):
            raise ValueError("Recursive SQL is not permitted.")
        return tree.sql(dialect="sqlite")

    def run(self, query: Query, principal, source="factory", conversation_id=None):
        principal.require("data.read")
        info = self.db.source(source)
        policy = info["policy"]
        sql_hash = digest(query.sql)
        connection = None
        try:
            safe = self.validate(query)
            allowed = {
                t.lower(): {c.lower() for c in cols}
                for t, cols in policy["tables"].items()
            }

            def authorizer(action, arg1, arg2, database, origin):
                if action == sqlite3.SQLITE_SELECT:
                    return sqlite3.SQLITE_OK
                if action == sqlite3.SQLITE_READ:
                    columns = allowed.get(str(arg1).lower())
                    # SQLite's count-only optimizer reports a blank column and
                    # no database name after authorizing the CTE's base reads.
                    if columns and (
                        (
                            database == "main"
                            and (not arg2 or str(arg2).lower() in columns)
                        )
                        or (database is None and not arg2)
                    ):
                        return sqlite3.SQLITE_OK
                if action == sqlite3.SQLITE_FUNCTION and str(arg2).lower() in FUNCTIONS:
                    return sqlite3.SQLITE_OK
                return sqlite3.SQLITE_DENY

            connection = sqlite3.connect(
                info["path"].resolve().as_uri() + "?mode=ro", uri=True, timeout=3
            )
            connection.execute("PRAGMA query_only=ON")
            connection.enable_load_extension(False)
            connection.setlimit(sqlite3.SQLITE_LIMIT_LENGTH, 1024 * 1024)
            connection.set_authorizer(authorizer)
            deadline = time.monotonic() + max(
                0.1, min(float(policy.get("timeout_seconds", 5)), 30)
            )
            connection.set_progress_handler(
                lambda: int(time.monotonic() > deadline), 1000
            )
            limit = max(1, min(int(policy.get("max_rows", 100)), 1000))
            cursor = connection.execute(
                f"SELECT * FROM ({safe}) AS evidence_query LIMIT {limit + 1}",
                query.parameters,
            )
            names = [d[0] for d in cursor.description]
            if len(names) != len(set(names)):
                raise ValueError("Use unique result column aliases.")
            values = cursor.fetchall()
            truncated = len(values) > limit
            rows = [
                {
                    names[i]: ("[binary omitted]" if isinstance(v, bytes) else v)
                    for i, v in enumerate(row)
                }
                for row in values[:limit]
            ]
        except Exception as exc:
            self.db.audit(
                "sql.blocked",
                principal.username,
                {
                    "source": source,
                    "sql_hash": sql_hash,
                    "error_type": type(exc).__name__,
                },
            )
            raise ValueError(
                "Query failed read-only/schema validation or exceeded its execution limit. Review its tables, columns and parameters."
            ) from exc
        finally:
            if connection:
                connection.close()
        payload = {
            "sql": safe,
            "parameters": query.parameters,
            "rows": rows,
            "row_limit": limit,
            "truncated": truncated,
        }
        key = "db-" + str(uuid.uuid4())
        stamp = now()
        content = encode(payload)
        with self.db.connect(write=True) as c:
            c.execute(
                "INSERT INTO evidence_records VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    key,
                    conversation_id,
                    "database",
                    query.label,
                    info["name"],
                    stamp,
                    digest(content),
                    content,
                    encode({"source": source, "sql_hash": sql_hash}),
                ),
            )
            self.db.audit(
                "sql.read",
                principal.username,
                {
                    "source": source,
                    "sql_hash": sql_hash,
                    "rows": len(rows),
                    "truncated": truncated,
                    "evidence_id": key,
                },
                c,
            )
        return {
            "id": key,
            "kind": "database",
            "title": query.label,
            "locator": info["name"],
            "captured_at": stamp,
            "sha256": digest(content),
            "content": content,
            **payload,
        }

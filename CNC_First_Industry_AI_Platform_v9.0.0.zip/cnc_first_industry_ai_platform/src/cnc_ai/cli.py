"""Repository-root and installed-package commands."""

from __future__ import annotations
import argparse
import getpass
import json
import os
import sys
from pathlib import Path
from .config import Settings
from .database import Database, encode
from .auth import Auth
from .models import ModelRouter
from .rag import RAG


def parser():
    p = argparse.ArgumentParser(prog="cnc-ai")
    p.add_argument(
        "--home",
        type=Path,
        help="Project/configuration directory (default: current directory or CNC_HOME)",
    )
    commands = p.add_subparsers(dest="command", required=True)
    db = commands.add_parser("db")
    d = db.add_subparsers(dest="action", required=True)
    init = d.add_parser("init")
    init.add_argument(
        "--sample",
        action="store_true",
        help="Include complete fictional CNC training data",
    )
    d.add_parser("migrate")
    d.add_parser("refresh-policy")
    backup = d.add_parser("backup")
    backup.add_argument("destination", type=Path)
    u = commands.add_parser("user")
    u.add_argument("action", choices=["add", "disable", "reset-password"])
    u.add_argument("username")
    u.add_argument(
        "--role",
        choices=["admin", "supervisor", "operator", "viewer"],
        default="operator",
    )
    u.add_argument("--display-name", default="")
    u.add_argument(
        "--password-env",
        help="Environment variable containing password; otherwise prompt securely",
    )
    ingest = commands.add_parser("ingest")
    ingest.add_argument("paths", nargs="+", type=Path)
    ingest.add_argument("--user", required=True)
    ingest.add_argument("--kind", default="manual")
    ingest.add_argument("--sector", default="manufacturing")
    ingest.add_argument("--revision", default="1")
    rebuild = commands.add_parser("rebuild-embeddings")
    rebuild.add_argument("--user", required=True)
    serve = commands.add_parser("serve")
    serve.add_argument("--host")
    serve.add_argument("--port", type=int)
    validate = commands.add_parser("validate")
    validate.add_argument("--models", action="store_true")
    validate.add_argument("--opcua", action="store_true")
    validate.add_argument("--offline", action="store_true")
    commands.add_parser("audit-verify")
    sim = commands.add_parser("opcua-simulator")
    sim.add_argument("--port", type=int, default=4840)
    monitor = commands.add_parser("monitor")
    monitor.add_argument("--interval", type=float, default=5)
    monitor.add_argument("--count", type=int, default=0, help="0 records until stopped")
    monitor.add_argument("--machine", default="CNC-01")
    recon = commands.add_parser("reconcile")
    recon.add_argument("execution_id")
    recon.add_argument("--note", required=True)
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    settings = Settings.load(args.home)
    db = Database(settings)
    try:
        if args.command == "db":
            if args.action == "init":
                result = db.initialize(sample=args.sample)
            elif args.action == "migrate":
                if not db.path.is_file():
                    raise ValueError(
                        "No existing database to migrate. Use db init first."
                    )
                result = db.initialize(sample=False)
            elif args.action == "backup":
                result = {"backup": db.backup(args.destination)}
            else:
                with db.connect(write=True) as c:
                    c.execute(
                        "UPDATE data_sources SET policy_json=? WHERE id='factory'",
                        (encode(settings.read("query_policy.json")),),
                    )
                    db.audit("sql.policy_refreshed", "local-administrator", {}, c)
                result = {"updated": "factory query allowlist"}
        elif args.command == "user":
            auth = Auth(db)
            if args.action == "disable":
                with db.connect(write=True) as c:
                    c.execute(
                        "UPDATE users SET enabled=0 WHERE username=?", (args.username,)
                    )
                    c.execute("DELETE FROM sessions WHERE username=?", (args.username,))
                    db.audit(
                        "user.disabled",
                        "local-administrator",
                        {"username": args.username},
                        c,
                    )
            else:
                password = (
                    os.getenv(args.password_env, "")
                    if args.password_env
                    else getpass.getpass("Password (at least 12 characters): ")
                )
                if (
                    not args.password_env
                    and getpass.getpass("Repeat password: ") != password
                ):
                    raise ValueError("Passwords do not match.")
                if args.action == "add":
                    auth.create_user(
                        args.username, password, args.role, args.display_name
                    )
                else:
                    from werkzeug.security import generate_password_hash

                    if len(password) < 12:
                        raise ValueError(
                            "Password must contain at least 12 characters."
                        )
                    with db.connect(write=True) as c:
                        if not c.execute(
                            "SELECT 1 FROM users WHERE username=?", (args.username,)
                        ).fetchone():
                            raise ValueError("Unknown user.")
                        c.execute(
                            "UPDATE users SET password_hash=? WHERE username=?",
                            (generate_password_hash(password), args.username),
                        )
                        c.execute(
                            "DELETE FROM sessions WHERE username=?", (args.username,)
                        )
                        db.audit(
                            "user.password_reset",
                            "local-administrator",
                            {"username": args.username},
                            c,
                        )
            result = {"account": args.username, "action": args.action}
        elif args.command in {"ingest", "rebuild-embeddings"}:
            principal = Auth(db).user(args.user)
            rag = RAG(db, ModelRouter(settings))
            if args.command == "rebuild-embeddings":
                result = rag.rebuild(principal)
            else:
                result = []
                for path in args.paths:
                    print("Ingesting " + path.name, flush=True)
                    result.append(
                        rag.ingest(
                            path, principal, args.kind, args.sector, args.revision
                        )
                    )
        elif args.command == "serve":
            from waitress import serve
            from .web.app import create_app

            host = args.host or settings.host
            port = args.port or settings.port
            if (
                host not in {"127.0.0.1", "localhost", "::1"}
                and not settings.cookie_secure
            ):
                raise ValueError(
                    "LAN web deployment requires HTTPS termination and CNC_COOKIE_SECURE=true. Keep Waitress behind the site reverse proxy."
                )
            print(
                f"CNC assistant: http://{host}:{port}; controller mode={settings.opcua_mode}; model mode={settings.model_mode}",
                flush=True,
            )
            serve(
                create_app(settings),
                host=host,
                port=port,
                threads=8,
                channel_timeout=180,
                max_request_body_size=100 * 1024 * 1024,
            )
            return 0
        elif args.command == "validate":
            result = {
                "database": db.stats(),
                "audit": db.verify_audit(),
                "model_configuration": list(ModelRouter(settings).registry["roles"]),
            }
            with db.connect() as c:
                result["integrity"] = c.execute("PRAGMA integrity_check").fetchone()[0]
                result["foreign_key_errors"] = len(
                    c.execute("PRAGMA foreign_key_check").fetchall()
                )
            if result["integrity"] != "ok" or result["foreign_key_errors"]:
                raise RuntimeError("Database validation failed.")
            if args.offline and (args.models or args.opcua):
                raise ValueError(
                    "Use --offline without network checks, or explicitly request --models/--opcua."
                )
            if args.models:
                result["inference"] = ModelRouter(settings).smoke()
                if any(v != "passed" for v in result["inference"].values()):
                    print(json.dumps(result, indent=2))
                    return 1
            if args.opcua:
                from .control.adapters import make_adapter

                snapshot = make_adapter(settings, db).snapshot("CNC-01")
                limits = settings.read("policy.json")
                healthy, detail = snapshot.healthy(
                    limits["max_telemetry_age_seconds"],
                    limits["max_snapshot_span_seconds"],
                )
                result["opcua"] = {"healthy": healthy, "detail": detail}
                if not healthy:
                    print(json.dumps(result, indent=2))
                    return 1
        elif args.command == "audit-verify":
            result = db.verify_audit()
        elif args.command == "opcua-simulator":
            from .control.simulator_server import run
            import asyncio

            asyncio.run(run(args.port))
            return 0
        elif args.command == "monitor":
            import time
            from .control.adapters import make_adapter
            from .control.telemetry import record

            if args.interval < 1 or args.count < 0:
                raise ValueError(
                    "Use an interval of at least one second and a non-negative count."
                )
            adapter = make_adapter(settings, db)
            policy = settings.read("policy.json")
            count = 0
            while not args.count or count < args.count:
                snapshot = adapter.snapshot(args.machine)
                observation = record(db, snapshot, adapter.mode, policy)
                print(
                    json.dumps(
                        {
                            "machine": args.machine,
                            "captured_at": observation["captured_at"],
                            "healthy": observation["healthy"],
                            "mode": adapter.mode,
                        }
                    ),
                    flush=True,
                )
                count += 1
                if not args.count or count < args.count:
                    time.sleep(args.interval)
            return 0
        elif args.command == "reconcile":
            from .control.service import ControlService
            from .control.adapters import make_adapter

            result = ControlService(
                settings, db, Auth(db), make_adapter(settings, db)
            ).reconcile(args.execution_id, args.note)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except KeyboardInterrupt:
        print("\nStopped by operator. Persistent data remains available.")
        return 130
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

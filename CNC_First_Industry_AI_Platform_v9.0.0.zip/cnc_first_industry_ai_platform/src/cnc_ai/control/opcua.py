"""Authenticated OPC UA transport with an allowlisted typed write interface."""

from __future__ import annotations
from datetime import datetime, timezone
import os
from pathlib import Path
from urllib.parse import urlparse

from .types import TYPES, Sample, Snapshot


class RealOPCUAAdapter:
    """Site-configured aliases, encrypted authenticated channel and pinned server certificate."""

    mode = "real"

    def __init__(self, settings):
        self.settings = settings
        self.mapping = settings.read("opcua.json")
        self.mode = settings.opcua_mode
        self.endpoint = os.getenv("OPCUA_ENDPOINT", "opc.tcp://127.0.0.1:4840")
        endpoint = urlparse(self.endpoint)
        if endpoint.scheme != "opc.tcp" or not endpoint.hostname:
            raise ValueError("OPCUA_ENDPOINT must be an opc.tcp endpoint.")
        if self.mode == "opcua_test" and endpoint.hostname not in {
            "127.0.0.1",
            "localhost",
            "::1",
        }:
            raise ValueError("OPC UA test mode is restricted to loopback.")

    def _client(self):
        from asyncua.sync import Client

        if self.mode == "real":
            if not self.mapping.get("real_mapping_reviewed") or not self.mapping.get(
                "controller_enforces_limits"
            ):
                raise PermissionError(
                    "The site mapping and native controller limit enforcement are not commissioned."
                )
            files = [
                os.getenv(k, "")
                for k in (
                    "OPCUA_CERTIFICATE",
                    "OPCUA_PRIVATE_KEY",
                    "OPCUA_SERVER_CERTIFICATE",
                )
            ]
            if not all(p and Path(p).is_file() for p in files):
                raise PermissionError(
                    "OPC UA client key/certificate and pinned server certificate are required."
                )
            user = os.getenv("OPCUA_USERNAME", "")
            password = os.getenv("OPCUA_PASSWORD", "")
            if not user or not password:
                raise PermissionError(
                    "OPC UA service-account credentials are required."
                )
        client = Client(self.endpoint, timeout=5)
        try:
            if self.mode == "real":
                client.set_security_string(
                    "Basic256Sha256,SignAndEncrypt," + ",".join(files)
                )
                client.set_user(user)
                client.set_password(password)
            client.connect()
        except BaseException:
            try:
                client.disconnect()
            except Exception:
                pass
            raise
        return client

    def _nodes(self, machine):
        item = self.mapping.get("machines", {}).get(machine)
        if not item:
            raise ValueError("Machine has no approved OPC UA mapping.")
        return item["nodes"]

    def _snapshot(self, machine, client):
        samples = {}
        for alias, node in self._nodes(machine).items():
            if alias not in TYPES:
                continue
            dv = client.get_node(node["node_id"]).read_data_value(
                raise_on_bad_status=False
            )
            stamp = dv.SourceTimestamp
            if stamp is not None and stamp.tzinfo is None:
                stamp = stamp.replace(tzinfo=timezone.utc)
            samples[alias] = Sample(
                dv.Value.Value,
                stamp.timestamp() if stamp else None,
                dv.StatusCode.is_good(),
            )
        return Snapshot(machine, samples, datetime.now(timezone.utc).timestamp())

    def snapshot(self, machine):
        client = self._client()
        try:
            return self._snapshot(machine, client)
        finally:
            client.disconnect()

    def apply(self, machine, action, value, expected, policy):
        if action not in {"set_spindle_rpm", "feed_hold"}:
            raise ValueError("Unsupported typed machine action.")
        if self.mode == "real" and not (
            self.settings.real_writes and self.settings.commissioned
        ):
            raise PermissionError(
                "Real machine writes are disabled by the site environment."
            )
        client = self._client()
        try:
            fresh = self._snapshot(machine, client)
            healthy, detail = fresh.healthy(
                policy["max_telemetry_age_seconds"], policy["max_snapshot_span_seconds"]
            )
            if not healthy or fresh.binding() != expected.binding():
                raise ValueError("Final controller recheck failed: " + detail)
            if (
                action == "set_spindle_rpm"
                and abs(value - fresh.value("setpoint"))
                > policy["machines"][machine]["maximum_step_rpm"]
            ):
                raise ValueError("Final setpoint step limit changed.")
            alias = "setpoint" if action == "set_spindle_rpm" else "feed_hold"
            mapping = self._nodes(machine)[alias]
            required_type = "Double" if action == "set_spindle_rpm" else "Boolean"
            if (
                mapping.get("type") != required_type
                or mapping.get("writable") is not True
            ):
                raise ValueError("Write mapping is not an approved typed setpoint.")
            from asyncua import ua

            node = client.get_node(mapping["node_id"])
            typed = float(value) if action == "set_spindle_rpm" else True
            node.write_value(
                ua.DataValue(ua.Variant(typed, getattr(ua.VariantType, required_type)))
            )
            return node.read_value()
        finally:
            client.disconnect()

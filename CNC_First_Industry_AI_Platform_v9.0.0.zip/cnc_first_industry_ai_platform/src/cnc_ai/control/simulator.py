"""Persistent in-process training adapter with no network or physical hardware."""

from __future__ import annotations
from datetime import datetime, timezone
import json
from ..database import encode

from .types import Sample, Snapshot


class SimulatorAdapter:
    mode = "simulator"

    def __init__(self, db):
        self.db = db

    def snapshot(self, machine):
        with self.db.connect() as c:
            row = c.execute(
                "SELECT values_json FROM simulator_state WHERE machine=?", (machine,)
            ).fetchone()
        if not row:
            raise ValueError("Machine is not in the simulator allowlist.")
        values = json.loads(row[0])
        timestamp = datetime.now(timezone.utc).timestamp()
        return Snapshot(
            machine, {k: Sample(v, timestamp) for k, v in values.items()}, timestamp
        )

    def apply(self, machine, action, value, expected, policy):
        with self.db.connect(write=True) as c:
            row = c.execute(
                "SELECT values_json FROM simulator_state WHERE machine=?", (machine,)
            ).fetchone()
            values = json.loads(row[0])
            if any(values[k] != v for k, v in expected.binding().items()):
                raise ValueError(
                    "Controller context changed before the simulated write."
                )
            alias = "setpoint" if action == "set_spindle_rpm" else "feed_hold"
            values[alias] = float(value) if action == "set_spindle_rpm" else True
            # Setpoint acceptance is distinct from measured physical RPM.
            c.execute(
                "UPDATE simulator_state SET values_json=? WHERE machine=?",
                (encode(values), machine),
            )
        return values[alias]

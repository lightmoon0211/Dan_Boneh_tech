"""Adapter selection; concrete simulator and real transport are separate modules."""

from .types import TYPES, Sample, Snapshot
from .simulator import SimulatorAdapter
from .opcua import RealOPCUAAdapter

__all__ = [
    "TYPES",
    "Sample",
    "Snapshot",
    "SimulatorAdapter",
    "RealOPCUAAdapter",
    "make_adapter",
]


def make_adapter(settings, db):
    return (
        SimulatorAdapter(db)
        if settings.opcua_mode == "simulator"
        else RealOPCUAAdapter(settings)
    )

"""Read-only observations, separated from the typed write boundary."""

from datetime import datetime, timezone
from ..database import encode, now


def record(db, snapshot, mode, policy):
    healthy, detail = snapshot.healthy(
        policy["max_telemetry_age_seconds"], policy["max_snapshot_span_seconds"]
    )
    samples = {
        key: {
            "value": sample.value,
            "source_time": sample.source_time,
            "quality": "good" if sample.good else "bad",
        }
        for key, sample in snapshot.samples.items()
    }
    captured = datetime.fromtimestamp(snapshot.captured_at, timezone.utc).isoformat()
    with db.connect(write=True) as c:
        c.execute(
            "INSERT INTO controller_snapshots(machine,mode,captured_at,healthy,detail,samples_json) VALUES(?,?,?,?,?,?)",
            (snapshot.machine, mode, captured, int(healthy), detail, encode(samples)),
        )
        machine = c.execute(
            "SELECT machine_id FROM machines WHERE machine_code=?", (snapshot.machine,)
        ).fetchone()
        state = snapshot.samples.get("state")
        if machine and state and state.source_time is not None:
            source_time = datetime.fromtimestamp(
                state.source_time, timezone.utc
            ).isoformat()
            c.execute(
                "INSERT OR IGNORE INTO machine_state_history(machine_id,state,source_time,received_at,quality,source_sequence) VALUES(?,?,?,?,?,?)",
                (
                    machine[0],
                    str(state.value),
                    source_time,
                    now(),
                    "SIMULATED"
                    if mode != "real"
                    else ("GOOD" if state.good else "BAD"),
                    mode,
                ),
            )
    return {
        "machine": snapshot.machine,
        "mode": mode,
        "captured_at": captured,
        "healthy": healthy,
        "detail": detail,
        "samples": samples,
        "meaning": "One timestamped observation; historical observations do not prove the present state. Setpoint is distinct from measured actual RPM.",
    }

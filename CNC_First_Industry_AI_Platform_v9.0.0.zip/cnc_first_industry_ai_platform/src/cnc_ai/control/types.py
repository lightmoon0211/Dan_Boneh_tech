"""Typed controller observations shared by simulation and real transport."""

from __future__ import annotations
from dataclasses import dataclass
import math

TYPES = {
    "state": str,
    "tool": str,
    "material": str,
    "workpiece": str,
    "actual_rpm": float,
    "setpoint": float,
    "door_closed": bool,
    "estop_ok": bool,
    "write_permitted": bool,
    "feed_hold": bool,
}


@dataclass(frozen=True)
class Sample:
    value: object
    source_time: float | None
    good: bool = True


@dataclass(frozen=True)
class Snapshot:
    machine: str
    samples: dict[str, Sample]
    captured_at: float

    def value(self, key):
        return self.samples[key].value

    def binding(self):
        return {k: self.value(k) for k in ("state", "tool", "material", "workpiece")}

    def healthy(self, max_age, span):
        timestamps = []
        for key, expected in TYPES.items():
            sample = self.samples.get(key)
            if sample is None or not sample.good or sample.source_time is None:
                return False, f"{key}: missing or bad-quality telemetry"
            if expected is float:
                if (
                    isinstance(sample.value, bool)
                    or not isinstance(sample.value, (int, float))
                    or not math.isfinite(sample.value)
                ):
                    return False, f"{key}: invalid numeric telemetry"
            elif type(sample.value) is not expected:
                return False, f"{key}: unexpected telemetry type"
            age = self.captured_at - sample.source_time
            if age < -1 or age > max_age:
                return False, f"{key}: telemetry timestamp is stale or in the future"
            timestamps.append(sample.source_time)
        if max(timestamps) - min(timestamps) > span:
            return False, "Telemetry snapshot is not coherent in time"
        for key in ("door_closed", "estop_ok", "write_permitted"):
            if self.value(key) is not True:
                return False, f"{key}: required controller interlock is not healthy"
        return (
            True,
            "Telemetry is fresh and good; required controller interlocks are healthy",
        )

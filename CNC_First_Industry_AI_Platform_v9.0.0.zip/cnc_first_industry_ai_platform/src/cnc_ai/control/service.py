"""Persistent request/approve/execute lifecycle with an at-most-once write attempt."""

import json
import math
import time
import uuid
from ..contracts import ControlRequest
from ..database import encode, now
from filelock import FileLock, Timeout
from .policy import Policy


class ControlService:
    def __init__(self, settings, db, auth, adapter):
        self.settings = settings
        self.db = db
        self.auth = auth
        self.adapter = adapter

    def _policy(self):
        return Policy(self.settings)

    def preflight(self, request, principal):
        principal = self.auth.user(principal.username)
        principal.require("control.request")
        policy = self._policy()
        snapshot = self.adapter.snapshot(request.machine)
        return policy.evaluate(request, principal, snapshot)

    def create(self, request, principal):
        principal = self.auth.user(principal.username)
        principal.require("control.request")
        policy = self._policy()
        snapshot = self.adapter.snapshot(request.machine)
        evaluation = policy.evaluate(request, principal, snapshot)
        if not evaluation["passed"]:
            self.db.audit(
                "control.proposal_blocked",
                principal.username,
                {"request": request.model_dump(), "evaluation": evaluation},
            )
            raise ValueError(
                next(
                    c["detail"]
                    for c in evaluation["checks"]
                    if c["status"] == "blocked"
                )
            )
        key = str(uuid.uuid4())
        with self.db.connect(write=True) as c:
            c.execute(
                "INSERT INTO control_proposals VALUES(?,?,?,?,?,?,?,?,?,?)",
                (
                    key,
                    request.machine,
                    principal.username,
                    encode(request.model_dump()),
                    policy.hash,
                    encode(snapshot.binding()),
                    now(),
                    time.time() + policy.config["proposal_ttl_seconds"],
                    "pending",
                    encode(evaluation),
                ),
            )
            self.db.audit(
                "control.proposed",
                principal.username,
                {
                    "proposal_id": key,
                    "request": request.model_dump(),
                    "evaluation": evaluation,
                },
                c,
            )
        return self.get(key)

    def get(self, key):
        with self.db.connect() as c:
            row = c.execute(
                "SELECT * FROM control_proposals WHERE id=?", (key,)
            ).fetchone()
            if not row:
                raise KeyError("Proposal was not found.")
            result = dict(row)
            approval = c.execute(
                "SELECT actor,decision,comment,at FROM approvals WHERE proposal_id=?",
                (key,),
            ).fetchone()
        result["request"] = json.loads(result.pop("request_json"))
        result["evaluation"] = json.loads(result.pop("checks_json"))
        result.pop("binding_json")
        result["approval"] = dict(approval) if approval else None
        if (
            result["status"] in {"pending", "approved"}
            and result["expires_at"] < time.time()
        ):
            result["status"] = "expired"
        return result

    def list(self, principal):
        principal.require("control.read")
        with self.db.connect() as c:
            keys = [
                r[0]
                for r in c.execute(
                    "SELECT id FROM control_proposals ORDER BY created_at DESC LIMIT 100"
                )
            ]
        return [self.get(k) for k in keys]

    def decide(self, key, approval, principal):
        principal = self.auth.user(principal.username)
        with self.db.connect(write=True) as c:
            row = c.execute(
                "SELECT * FROM control_proposals WHERE id=?", (key,)
            ).fetchone()
            if not row:
                raise KeyError("Proposal was not found.")
            if row["status"] != "pending" or row["expires_at"] < time.time():
                raise ValueError("Proposal is not pending or has expired.")
            if approval.decision == "approve":
                principal.require("control.approve")
                if row["requester"] == principal.username:
                    raise PermissionError(
                        "A requester cannot approve their own proposal."
                    )
            elif row["requester"] != principal.username:
                principal.require("control.approve")
            if row["policy_hash"] != self._policy().hash:
                raise ValueError("Policy changed. Create a new proposal.")
            c.execute(
                "INSERT INTO approvals(proposal_id,actor,decision,comment,at) VALUES(?,?,?,?,?)",
                (key, principal.username, approval.decision, approval.comment, now()),
            )
            c.execute(
                "UPDATE control_proposals SET status=? WHERE id=?",
                ("approved" if approval.decision == "approve" else "rejected", key),
            )
            self.db.audit(
                "control." + approval.decision,
                principal.username,
                {"proposal_id": key, "comment": approval.comment},
                c,
            )
        return self.get(key)

    def execute(self, key, principal):
        try:
            with FileLock(
                str(self.settings.data / "controller-boundary.lock"), timeout=0
            ):
                return self._execute_locked(key, principal)
        except Timeout:
            raise ValueError(
                "A controller operation or reconciliation is already in progress."
            ) from None

    def _execute_locked(self, key, principal):
        principal = self.auth.user(principal.username)
        principal.require("control.request")
        policy = self._policy()
        with self.db.connect() as c:
            row = c.execute(
                "SELECT * FROM control_proposals WHERE id=?", (key,)
            ).fetchone()
            approval = c.execute(
                "SELECT * FROM approvals WHERE proposal_id=? AND decision='approve'",
                (key,),
            ).fetchone()
        if not row:
            raise KeyError("Proposal was not found.")
        if row["requester"] != principal.username:
            raise PermissionError(
                "Only the authenticated requester may execute this proposal."
            )
        request = ControlRequest.model_validate_json(row["request_json"])
        approved = False
        if approval:
            approver = self.auth.user(approval["actor"])
            approver.require("control.approve")
            approved = approval["actor"] != principal.username
        if (
            row["status"] not in {"pending", "approved"}
            or row["expires_at"] < time.time()
        ):
            raise ValueError("Proposal is no longer eligible for execution.")
        snapshot = self.adapter.snapshot(request.machine)
        evaluation = policy.evaluate(request, principal, snapshot, approved)
        if row["policy_hash"] != policy.hash or snapshot.binding() != json.loads(
            row["binding_json"]
        ):
            raise ValueError(
                "Policy, tool, material, workpiece or machine state changed. Create a new proposal."
            )
        if not evaluation["passed"] or (
            evaluation["approval_required"] and not approved
        ):
            self.db.audit(
                "control.execution_blocked",
                principal.username,
                {"proposal_id": key, "evaluation": evaluation},
            )
            raise ValueError(
                "Execution requires passing all policy checks and the configured supervisor approval."
            )
        if self.settings.opcua_mode == "real" and not (
            self.settings.real_writes and self.settings.commissioned
        ):
            raise PermissionError("Real CNC writes are disabled.")
        execution = str(uuid.uuid4())
        value = request.rpm if request.action == "set_spindle_rpm" else True
        # Commit write intent before I/O. A crash leaves an explicit unknown/pending-reconciliation state.
        with self.db.connect(write=True) as c:
            current = c.execute(
                "SELECT status,expires_at FROM control_proposals WHERE id=?", (key,)
            ).fetchone()
            if (
                current["status"] not in {"pending", "approved"}
                or current["expires_at"] < time.time()
            ):
                raise ValueError("Proposal was consumed or expired.")
            if c.execute(
                "SELECT 1 FROM machine_write_locks WHERE machine=?", (request.machine,)
            ).fetchone():
                raise ValueError(
                    "Machine has an unresolved or active write attempt. Reconcile it before another action."
                )
            c.execute(
                "INSERT INTO control_executions(id,proposal_id,actor,mode,started_at,status,requested_value,checks_json) VALUES(?,?,?,?,?,?,?,?)",
                (
                    execution,
                    key,
                    principal.username,
                    self.adapter.mode,
                    now(),
                    "executing",
                    float(value),
                    encode(evaluation),
                ),
            )
            c.execute(
                "INSERT INTO machine_write_locks VALUES(?,?)",
                (request.machine, execution),
            )
            c.execute(
                "UPDATE control_proposals SET status='executing' WHERE id=?", (key,)
            )
            self.db.audit(
                "control.write_intent",
                principal.username,
                {
                    "execution_id": execution,
                    "proposal_id": key,
                    "value": value,
                    "evaluation": evaluation,
                },
                c,
            )
        try:
            confirmed = self.adapter.apply(
                request.machine, request.action, value, snapshot, policy.config
            )
            if request.action == "set_spindle_rpm":
                valid = (
                    not isinstance(confirmed, bool)
                    and isinstance(confirmed, (float, int))
                    and math.isfinite(confirmed)
                    and math.isclose(
                        confirmed,
                        value,
                        rel_tol=0,
                        abs_tol=policy.config["readback_tolerance_rpm"],
                    )
                )
            else:
                valid = confirmed is True
            if not valid:
                raise RuntimeError(
                    "Controller readback did not confirm the requested setpoint."
                )
        except Exception as exc:
            with self.db.connect(write=True) as c:
                c.execute(
                    "UPDATE control_proposals SET status='unknown' WHERE id=?", (key,)
                )
                c.execute(
                    "UPDATE control_executions SET status='unknown',finished_at=?,detail=? WHERE id=?",
                    (now(), type(exc).__name__, execution),
                )
                self.db.audit(
                    "control.write_unknown",
                    principal.username,
                    {"execution_id": execution, "error_type": type(exc).__name__},
                    c,
                )
            raise RuntimeError(
                "Write outcome is uncertain. Do not retry; inspect the controller and reconcile this attempt."
            ) from exc
        with self.db.connect(write=True) as c:
            c.execute(
                "UPDATE control_proposals SET status='confirmed' WHERE id=?", (key,)
            )
            c.execute(
                "UPDATE control_executions SET status='confirmed',finished_at=?,confirmed_value=?,detail=? WHERE id=?",
                (
                    now(),
                    float(confirmed),
                    "Setpoint readback confirmed; this does not prove actual spindle speed.",
                    execution,
                ),
            )
            c.execute(
                "DELETE FROM machine_write_locks WHERE machine=? AND execution_id=?",
                (request.machine, execution),
            )
            self.db.audit(
                "control.write_confirmed",
                principal.username,
                {
                    "execution_id": execution,
                    "value": confirmed,
                    "mode": self.adapter.mode,
                },
                c,
            )
        return {
            "proposal": self.get(key),
            "execution_id": execution,
            "mode": self.adapter.mode,
            "confirmed_setpoint": confirmed,
        }

    def reconcile(self, execution_id, note):
        try:
            with FileLock(
                str(self.settings.data / "controller-boundary.lock"), timeout=0
            ):
                return self._reconcile_locked(execution_id, note)
        except Timeout:
            raise ValueError(
                "A controller write is still active. Reconciliation cannot overlap execution."
            ) from None

    def _reconcile_locked(self, execution_id, note):
        if len(note) < 20:
            raise ValueError(
                "Record the controller inspection and engineering decision (at least 20 characters)."
            )
        with self.db.connect() as c:
            row = c.execute(
                "SELECT p.machine,e.* FROM control_executions e JOIN control_proposals p ON e.proposal_id=p.id WHERE e.id=?",
                (execution_id,),
            ).fetchone()
        if not row or row["status"] not in {"unknown", "executing"}:
            raise ValueError("No uncertain execution exists with that identifier.")
        snapshot = self.adapter.snapshot(row["machine"])
        with self.db.connect(write=True) as c:
            c.execute(
                "UPDATE control_executions SET status='reconciled',finished_at=?,detail=? WHERE id=?",
                (now(), note, execution_id),
            )
            c.execute(
                "UPDATE control_proposals SET status='blocked' WHERE id=?",
                (row["proposal_id"],),
            )
            c.execute(
                "DELETE FROM machine_write_locks WHERE execution_id=?", (execution_id,)
            )
            self.db.audit(
                "control.reconciled",
                "local-controls-engineer",
                {
                    "execution_id": execution_id,
                    "note": note,
                    "observed_setpoint": snapshot.value("setpoint"),
                },
                c,
            )
        return {
            "reconciled": execution_id,
            "observed_setpoint": snapshot.value("setpoint"),
        }

    def observe(self, principal, conversation_id=None):
        principal.require("control.read")
        from .telemetry import record
        from ..database import digest

        snapshot = self.adapter.snapshot("CNC-01")
        policy = self._policy().config
        observation = record(self.db, snapshot, self.adapter.mode, policy)
        content = encode(observation)
        key = "evidence-" + str(uuid.uuid4())
        stamp = now()
        item = {
            "id": key,
            "kind": "telemetry",
            "title": "CNC-01 controller observation",
            "locator": self.adapter.mode + "; timestamped read-only observation",
            "captured_at": stamp,
            "sha256": digest(content),
            "content": content,
        }
        with self.db.connect(write=True) as c:
            c.execute(
                "INSERT INTO evidence_records VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    key,
                    conversation_id,
                    "telemetry",
                    item["title"],
                    item["locator"],
                    stamp,
                    item["sha256"],
                    content,
                    encode({"mode": self.adapter.mode}),
                ),
            )
            self.db.audit(
                "control.observed",
                principal.username,
                {
                    "machine": "CNC-01",
                    "mode": self.adapter.mode,
                    "healthy": observation["healthy"],
                },
                c,
            )
        return item

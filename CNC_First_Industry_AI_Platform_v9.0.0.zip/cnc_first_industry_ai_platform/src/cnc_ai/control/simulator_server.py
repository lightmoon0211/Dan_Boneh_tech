"""Loopback-only OPC UA server for exercising the wire adapter without machinery."""

import asyncio
from datetime import datetime, timezone


async def run(port=4840, ready=None, stop=None):
    from asyncua import Server, ua

    server = Server()
    await server.init()
    server.set_endpoint(f"opc.tcp://127.0.0.1:{port}")
    server.set_security_policy([ua.SecurityPolicyType.NoSecurity])
    ns = await server.register_namespace("urn:cnc-ai:training")
    machine = await server.nodes.objects.add_object(ns, "CNC01")
    values = {
        "State": "RUNNING",
        "Tool": "T07",
        "Material": "AISI-4140",
        "Workpiece": "WP-4140-01",
        "ActualRPM": 6000.0,
        "SetpointRPM": 6000.0,
        "DoorClosed": True,
        "EstopHealthy": True,
        "WritePermitted": True,
        "FeedHold": False,
    }
    nodes = {}
    for key, value in values.items():
        node = await machine.add_variable(ua.NodeId("CNC01." + key, ns), key, value)
        nodes[key] = node
        if key in {"SetpointRPM", "FeedHold"}:
            await node.set_writable()
    async with server:
        print(
            f"OPC UA training server on loopback port {port}; no physical controller attached.",
            flush=True,
        )
        if ready:
            ready.set()
        while stop is None or not stop.is_set():
            for key, node in nodes.items():
                value = await node.read_value()
                stamp = datetime.now(timezone.utc)
                dv = ua.DataValue(
                    ua.Variant(value), SourceTimestamp=stamp, ServerTimestamp=stamp
                )
                await node.write_value(dv)
            await asyncio.sleep(0.25)

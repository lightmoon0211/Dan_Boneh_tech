"""Validate commissioned policy shape before any policy decision."""

from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictPolicy(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, allow_inf_nan=False)


class Recipe(StrictPolicy):
    tool: str = Field(min_length=1)
    material: str = Field(min_length=1)
    minimum_rpm: float = Field(ge=0)
    maximum_rpm: float = Field(gt=0)

    @model_validator(mode="after")
    def ordered(self):
        if self.minimum_rpm > self.maximum_rpm:
            raise ValueError("Recipe minimum exceeds maximum.")
        return self


class Tool(StrictPolicy):
    maximum_rpm: float = Field(gt=0)
    materials: list[str] = Field(min_length=1)


class Action(StrictPolicy):
    permission: Literal["control.request"]
    approval_required: bool
    approval_permission: Literal["control.approve"]


class Machine(StrictPolicy):
    states: list[str] = Field(min_length=1)
    minimum_rpm: float = Field(ge=0)
    maximum_rpm: float = Field(gt=0)
    maximum_step_rpm: float = Field(gt=0)
    recipes: dict[str, Recipe]
    tools: dict[str, Tool]
    actions: dict[Literal["set_spindle_rpm", "feed_hold"], Action] = Field(min_length=1)

    @model_validator(mode="after")
    def ordered(self):
        if self.minimum_rpm > self.maximum_rpm:
            raise ValueError("Machine minimum exceeds maximum.")
        for recipe in self.recipes.values():
            if recipe.tool not in self.tools:
                raise ValueError("Recipe references an unknown tool.")
        return self


class FactoryPolicy(StrictPolicy):
    version: str = Field(min_length=1)
    proposal_ttl_seconds: int = Field(ge=1, le=3600)
    max_telemetry_age_seconds: float = Field(gt=0, le=60)
    max_snapshot_span_seconds: float = Field(gt=0, le=60)
    readback_tolerance_rpm: float = Field(ge=0, le=10)
    machines: dict[str, Machine] = Field(min_length=1)

"""Application factory with authentication, CSRF and explicit service ownership."""

import json
import secrets
import tempfile
import uuid
from datetime import date
from pathlib import Path
from functools import wraps
from flask import Flask, request, jsonify, g, make_response, render_template
from werkzeug.exceptions import HTTPException
from pydantic import ValidationError
from .. import __version__
from ..config import Settings, LANGUAGES
from ..database import Database, encode
from ..auth import Auth
from ..models import ModelRouter, ModelUnavailable
from ..rag import RAG
from ..sql import QueryService
from ..reports import Reports
from ..catalog import Catalog
from ..assistant import Assistant
from ..contracts import ChatRequest, ControlRequest, Approval, Query
from ..control.adapters import make_adapter
from ..control.service import ControlService

COOKIE = "cnc_session"


def create_app(settings=None, router=None, adapter=None):
    settings = settings or Settings.load()
    db = Database(settings)
    # No implicit schema mutation on web startup. Initialization is a separate operator action.
    if not db.path.is_file():
        raise RuntimeError(
            "Run cnc-ai db init --sample before starting the application."
        )
    app = Flask(__name__, template_folder="templates", static_folder="static")
    if settings.trust_proxy:
        from werkzeug.middleware.proxy_fix import ProxyFix

        # Enable only behind one trusted reverse proxy; firewall direct access to Waitress.
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
    app.config.update(MAX_CONTENT_LENGTH=100 * 1024 * 1024, JSON_SORT_KEYS=False)
    auth = Auth(db)
    router = router or ModelRouter(settings)
    rag = RAG(db, router)
    queries = QueryService(db)
    catalog = Catalog(db)
    control = ControlService(settings, db, auth, adapter or make_adapter(settings, db))
    assistant = Assistant(db, router, rag, queries, control)
    reports = Reports(db, router)
    app.extensions["cnc"] = {
        "settings": settings,
        "db": db,
        "auth": auth,
        "router": router,
        "rag": rag,
        "queries": queries,
        "control": control,
        "assistant": assistant,
        "catalog": catalog,
    }

    def public_user(p):
        return {
            "username": p.username,
            "display_name": p.display_name,
            "permissions": sorted(p.permissions),
        }

    def permission(name):
        def decorate(f):
            @wraps(f)
            def wrapped(*args, **kwargs):
                g.principal.require(name)
                return f(*args, **kwargs)

            return wrapped

        return decorate

    @app.before_request
    def protect():
        g.request_id = str(uuid.uuid4())
        if request.path.startswith("/api/") and request.path not in {
            "/api/login",
            "/api/health",
        }:
            try:
                g.principal, g.csrf = auth.session(request.cookies.get(COOKIE, ""))
            except PermissionError as exc:
                return jsonify(error=str(exc), request_id=g.request_id), 401
            if request.method not in {"GET", "HEAD", "OPTIONS"}:
                if not secrets.compare_digest(
                    request.headers.get("X-CSRF-Token", ""), g.csrf
                ):
                    raise PermissionError(
                        "Session verification failed. Refresh the page and sign in again."
                    )

    @app.after_request
    def headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        )
        if request.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.errorhandler(Exception)
    def errors(exc):
        if isinstance(exc, HTTPException):
            return jsonify(
                error=exc.description, request_id=getattr(g, "request_id", "")
            ), exc.code
        if isinstance(exc, ValidationError):
            message = "Request fields are invalid: " + "; ".join(
                ".".join(map(str, e["loc"])) + ": " + e["msg"] for e in exc.errors()
            )
            code = 400
        elif isinstance(exc, PermissionError):
            message = str(exc)
            code = 403
        elif isinstance(exc, (ValueError, KeyError, FileExistsError)):
            message = str(exc)
            code = 400
        elif isinstance(exc, ModelUnavailable):
            message = str(exc)
            code = 503
        elif isinstance(exc, RuntimeError) and str(exc).startswith("Write outcome"):
            message = str(exc)
            code = 409
        else:
            app.logger.exception("Request failed [%s]", getattr(g, "request_id", ""))
            message = "The operation failed. An administrator can inspect the application log using the request reference."
            code = 500
        if request.path.startswith("/api/"):
            try:
                actor = (
                    g.principal.username
                    if hasattr(g, "principal")
                    else "unauthenticated"
                )
                db.audit(
                    "http.request_failed",
                    actor,
                    {
                        "method": request.method,
                        "path": request.path,
                        "status": code,
                        "request_id": getattr(g, "request_id", ""),
                    },
                )
            except Exception:
                app.logger.error("Could not record failed request in audit storage")
        return jsonify(error=message, request_id=getattr(g, "request_id", "")), code

    @app.get("/")
    def index():
        return render_template("index.html", languages=LANGUAGES, version=__version__)

    @app.get("/api/health")
    def health():
        return jsonify(status="ok", version=__version__)

    @app.post("/api/login")
    def login():
        # A same-origin JSON request is required even before a session exists.
        if request.mimetype != "application/json":
            raise ValueError("Use the sign-in form.")
        origin = request.headers.get("Origin")
        if origin and origin.rstrip("/") != request.host_url.rstrip("/"):
            raise PermissionError("Cross-origin sign-in is blocked.")
        data = request.get_json()
        token, csrf, user = auth.login(
            str(data.get("username", "")),
            str(data.get("password", "")),
            request.remote_addr or "",
        )
        response = make_response(jsonify(user=public_user(user), csrf=csrf))
        response.set_cookie(
            COOKIE,
            token,
            httponly=True,
            secure=settings.cookie_secure,
            samesite="Strict",
            max_age=8 * 3600,
        )
        return response

    @app.get("/api/session")
    def session():
        return jsonify(user=public_user(g.principal), csrf=g.csrf, languages=LANGUAGES)

    @app.post("/api/logout")
    def logout():
        auth.logout(request.cookies.get(COOKIE, ""))
        response = make_response(jsonify(ok=True))
        response.delete_cookie(COOKIE)
        return response

    @app.get("/api/status")
    def status():
        return jsonify(
            version=__version__,
            database=db.stats(),
            rag=rag.status(),
            models=router.status(probe=True),
            control={
                "mode": settings.opcua_mode,
                "real_writes_enabled": settings.real_writes,
                "site_commissioned": settings.commissioned,
            },
        )

    @app.post("/api/models/verify")
    @permission("settings.manage")
    def verify_models():
        return jsonify(router.smoke())

    @app.get("/api/conversations")
    def conversations():
        with db.connect() as c:
            return jsonify(
                [
                    dict(r)
                    for r in c.execute(
                        "SELECT id,title,source,created_at FROM conversations WHERE owner=? ORDER BY created_at DESC LIMIT 100",
                        (g.principal.username,),
                    )
                ]
            )

    @app.get("/api/conversations/<key>")
    def conversation_get(key):
        with db.connect() as c:
            if not c.execute(
                "SELECT 1 FROM conversations WHERE id=? AND owner=?",
                (key, g.principal.username),
            ).fetchone():
                raise PermissionError("Conversation unavailable.")
            return jsonify(
                [
                    {
                        "role": r["role"],
                        "content": r["content"],
                        "response": json.loads(r["response_json"])
                        if r["response_json"]
                        else None,
                    }
                    for r in c.execute(
                        "SELECT * FROM chat_messages WHERE conversation_id=? ORDER BY created_at,rowid",
                        (key,),
                    )
                ]
            )

    @app.post("/api/chat")
    def chat():
        return jsonify(
            assistant.ask(ChatRequest.model_validate(request.get_json()), g.principal)
        )

    @app.get("/api/documents")
    @permission("documents.read")
    def documents():
        return jsonify(documents=rag.list(), status=rag.status())

    @app.post("/api/documents")
    @permission("documents.write")
    def ingest_document():
        upload = request.files.get("file")
        if not upload or not upload.filename:
            raise ValueError("Choose a document to upload.")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / ("upload" + Path(upload.filename).suffix.lower())
            upload.save(path)
            result = rag.ingest(
                path,
                g.principal,
                request.form.get("kind", "manual"),
                request.form.get("sector", "manufacturing"),
                request.form.get("revision", "1"),
                upload.filename,
            )
        return jsonify(result)

    @app.delete("/api/documents/<key>")
    def delete_document(key):
        rag.delete(key, g.principal)
        return jsonify(ok=True)

    @app.post("/api/documents/rebuild")
    def rebuild():
        return jsonify(rag.rebuild(g.principal))

    @app.get("/api/reports")
    @permission("documents.read")
    def get_reports():
        return jsonify(reports.list())

    @app.post("/api/reports")
    def report_summarize():
        d = request.get_json()
        return jsonify(
            reports.summarize(
                d["document_id"],
                g.principal,
                d.get("date", date.today().isoformat()),
                d.get("language", "English"),
            )
        )

    @app.get("/api/reports/<key>/evidence")
    @permission("documents.read")
    def report_evidence(key):
        return jsonify(reports.evidence(key))

    @app.delete("/api/reports/<key>")
    def delete_report(key):
        reports.delete(key, g.principal)
        return jsonify(ok=True)

    @app.get("/api/control/status")
    @permission("control.read")
    def control_status():
        snapshot = control.adapter.snapshot("CNC-01")
        limits = settings.read("policy.json")
        healthy, detail = snapshot.healthy(
            limits["max_telemetry_age_seconds"], limits["max_snapshot_span_seconds"]
        )
        return jsonify(
            mode=control.adapter.mode,
            machine="CNC-01",
            values={k: s.value for k, s in snapshot.samples.items()},
            healthy=healthy,
            detail=detail,
            captured_at=snapshot.captured_at,
        )

    @app.post("/api/control/preflight")
    def preflight():
        return jsonify(
            control.preflight(
                ControlRequest.model_validate(request.get_json()), g.principal
            )
        )

    @app.get("/api/control/proposals")
    def proposals():
        return jsonify(control.list(g.principal))

    @app.post("/api/control/proposals")
    def proposal():
        return jsonify(
            control.create(
                ControlRequest.model_validate(request.get_json()), g.principal
            )
        )

    @app.post("/api/control/proposals/<key>/decision")
    def decision(key):
        return jsonify(
            control.decide(
                key, Approval.model_validate(request.get_json()), g.principal
            )
        )

    @app.post("/api/control/proposals/<key>/execute")
    def execute(key):
        if (request.get_json() or {}).get("confirmation") != "EXECUTE APPROVED ACTION":
            raise ValueError("Type EXECUTE APPROVED ACTION to confirm execution.")
        return jsonify(control.execute(key, g.principal))

    @app.get("/api/sources")
    @permission("data.read")
    def sources():
        return jsonify(catalog.list())

    @app.get("/api/schema")
    @permission("data.read")
    def schema():
        return jsonify(queries.schema(request.args.get("source", "factory")))

    @app.get("/api/sources/<key>/schema")
    @permission("data.manage")
    def source_schema(key):
        return jsonify(catalog.raw_schema(key))

    @app.post("/api/sources")
    @permission("data.manage")
    def upload_source():
        upload = request.files.get("file")
        if not upload:
            raise ValueError("Choose a database.")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "upload.db"
            upload.save(path)
            result = catalog.import_database(
                path,
                upload.filename,
                request.form.get("sector", "manufacturing"),
                g.principal,
            )
        return jsonify(result)

    @app.post("/api/sources/<key>/approve")
    def approve_schema(key):
        catalog.approve(key, request.get_json()["tables"], g.principal)
        return jsonify(ok=True)

    @app.post("/api/sources/create")
    def create_source():
        d = request.get_json()
        return jsonify(
            catalog.create_schema(
                d["definition"],
                d["name"],
                d.get("sector", "manufacturing"),
                g.principal,
            )
        )

    @app.post("/api/query")
    def query():
        d = request.get_json()
        return jsonify(
            queries.run(
                Query.model_validate(d["query"]),
                g.principal,
                d.get("source", "factory"),
            )
        )

    @app.get("/api/sectors")
    def sectors():
        with db.connect() as c:
            return jsonify(
                {
                    r["id"]: json.loads(r["profile_json"])
                    for r in c.execute("SELECT * FROM sector_profiles")
                }
            )

    @app.post("/api/sectors")
    @permission("settings.manage")
    def save_sector():
        d = request.get_json()
        key = d["id"]
        if not key.replace("_", "").isalnum() or len(key) > 40:
            raise ValueError("Sector ID must be short letters, digits and underscores.")
        profile = {k: d.get(k, "") for k in ["name", "description", "domain_context"]}
        with db.connect(write=True) as c:
            c.execute(
                "INSERT OR REPLACE INTO sector_profiles VALUES(?,?)",
                (key, encode(profile)),
            )
            db.audit("sector.updated", g.principal.username, {"sector": key}, c)
        return jsonify(ok=True)

    @app.get("/api/ui-text")
    def ui_text():
        lang = request.args.get("language", "en")
        with db.connect() as c:
            row = c.execute(
                "SELECT value FROM app_settings WHERE key=?", ("ui:" + lang,)
            ).fetchone()
        return jsonify(json.loads(row[0]) if row else {})

    @app.post("/api/ui-text")
    @permission("settings.manage")
    def save_ui_text():
        d = request.get_json()
        lang = d["language"]
        if lang not in LANGUAGES:
            raise ValueError("Unsupported language.")
        labels = d["labels"]
        if not isinstance(labels, dict) or any(
            len(str(v)) > 300 for v in labels.values()
        ):
            raise ValueError("Use short UI labels.")
        with db.connect(write=True) as c:
            c.execute(
                "INSERT OR REPLACE INTO app_settings VALUES(?,?)",
                ("ui:" + lang, encode(labels)),
            )
        return jsonify(ok=True)

    @app.get("/api/audit")
    @permission("audit.read")
    def audit():
        with db.connect() as c:
            return jsonify(
                [
                    dict(r)
                    for r in c.execute(
                        "SELECT id,at,actor,event,payload FROM audit_events ORDER BY id DESC LIMIT 100"
                    )
                ]
            )

    return app

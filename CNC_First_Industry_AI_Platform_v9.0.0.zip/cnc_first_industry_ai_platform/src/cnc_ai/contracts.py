"""Strict public and model output contracts. Unknown fields are rejected."""

from __future__ import annotations
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class Query(StrictModel):
    label: str = Field(min_length=1, max_length=120)
    sql: str = Field(min_length=1, max_length=12000)
    parameters: dict[str, str | int | float | None] = Field(default_factory=dict)


class ControlRequest(StrictModel):
    machine: str = Field(pattern=r"^[A-Za-z0-9_-]{1,40}$")
    action: Literal["set_spindle_rpm", "feed_hold"]
    rpm: float | None = Field(default=None, ge=0, le=100000, strict=True)
    reason: str = Field(min_length=5, max_length=1000)

    @model_validator(mode="after")
    def value_contract(self):
        if self.action == "set_spindle_rpm" and self.rpm is None:
            raise ValueError("Spindle RPM is required.")
        if self.action == "feed_hold" and self.rpm is not None:
            raise ValueError("Feed hold has no RPM parameter.")
        return self


class Plan(StrictModel):
    mode: Literal["conversation", "data", "code", "control", "clarify", "status"]
    queries: list[Query] = Field(default_factory=list, max_length=4)
    control: ControlRequest | None = None
    clarification: str = Field(default="", max_length=1000)

    @model_validator(mode="after")
    def coherent(self):
        if self.mode == "data" and not self.queries:
            raise ValueError("A data plan needs queries.")
        if self.mode == "control" and self.control is None:
            raise ValueError("A control plan needs a request.")
        if self.mode != "control" and self.control is not None:
            raise ValueError("Unexpected control request.")
        if self.mode != "data" and self.queries:
            raise ValueError("Unexpected SQL queries.")
        if self.mode == "clarify" and not self.clarification:
            raise ValueError("A clarification is required.")
        return self


class Answer(StrictModel):
    answer: str = Field(min_length=1, max_length=24000)
    citations: list[str] = Field(default_factory=list, max_length=20)
    suggestions: list[str] = Field(default_factory=list, max_length=3)


class Approval(StrictModel):
    decision: Literal["approve", "reject"]
    comment: str = Field(min_length=3, max_length=1000)


class Evidence(StrictModel):
    id: str
    kind: Literal["document", "database", "telemetry"]
    title: str
    locator: str
    captured_at: str
    sha256: str
    content: str


class AuditEvent(StrictModel):
    event: str
    actor: str
    at: str
    payload: dict


class ChatRequest(StrictModel):
    question: str = Field(min_length=1, max_length=6000)
    conversation_id: str | None = Field(default=None, max_length=64)
    source: str = "factory"
    language: str = "en"
    style: Literal["concise", "balanced", "detailed"] = "balanced"

"""Explicit initialization, transactional migrations and fixed authoritative factory storage."""

from __future__ import annotations
import hashlib
import json
import re
import shutil
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from .config import RESOURCE_DIR, Settings
from .contracts import AuditEvent


def now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def encode(value):
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def digest(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def identifier(value):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,80}", value):
        raise ValueError("Invalid schema identifier.")
    return '"' + value + '"'


class Database:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.path = settings.database

    @contextmanager
    def connect(self, write=False):
        if not self.path.is_file():
            raise RuntimeError(
                "Database is not initialized. Run: cnc-ai db init --sample"
            )
        c = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON")
        c.execute("PRAGMA busy_timeout=10000")
        try:
            if write:
                c.execute("BEGIN IMMEDIATE")
            yield c
            if write:
                c.commit()
        except BaseException:
            if write:
                c.rollback()
            raise
        finally:
            c.close()

    def initialize(self, sample=True):
        self.settings.data.mkdir(parents=True, exist_ok=True)
        new_database = not self.path.exists()
        if new_database:
            temporary = self.path.with_suffix(".initializing")
            if sample:
                shutil.copy2(RESOURCE_DIR / "cnc_sample_base.db", temporary)
            else:
                with (
                    sqlite3.connect(RESOURCE_DIR / "cnc_sample_base.db") as src,
                    sqlite3.connect(temporary) as dst,
                ):
                    for row in src.execute(
                        "SELECT sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' ORDER BY type='view'"
                    ):
                        dst.execute(row[0])
            temporary.replace(self.path)
        with self.connect() as c:
            c.execute("PRAGMA journal_mode=WAL")
            c.execute(
                "CREATE TABLE IF NOT EXISTS schema_migrations(version TEXT PRIMARY KEY,sha256 TEXT NOT NULL,applied_at TEXT NOT NULL)"
            )
        for migration in sorted((RESOURCE_DIR / "migrations").glob("*.sql")):
            sql = migration.read_text()
            checksum = digest(sql)
            with self.connect(write=True) as c:
                existing = c.execute(
                    "SELECT sha256 FROM schema_migrations WHERE version=?",
                    (migration.name,),
                ).fetchone()
                if existing:
                    if existing[0] != checksum:
                        raise RuntimeError(
                            "Applied migration checksum changed: " + migration.name
                        )
                    continue
                statement = ""
                for line in sql.splitlines(keepends=True):
                    statement += line
                    if sqlite3.complete_statement(statement):
                        c.execute(statement)
                        statement = ""
                if statement.strip():
                    raise RuntimeError("Incomplete migration: " + migration.name)
                c.execute(
                    "INSERT INTO schema_migrations VALUES(?,?,?)",
                    (migration.name, checksum, now()),
                )
        with self.connect(write=True) as c:
            roles = {
                "viewer": ["chat", "data.read", "documents.read", "control.read"],
                "operator": [
                    "chat",
                    "data.read",
                    "documents.read",
                    "control.read",
                    "control.request",
                ],
                "supervisor": [
                    "chat",
                    "data.read",
                    "documents.read",
                    "documents.write",
                    "reports.write",
                    "control.read",
                    "control.request",
                    "control.approve",
                ],
                "admin": [
                    "chat",
                    "data.read",
                    "documents.read",
                    "documents.write",
                    "reports.write",
                    "control.read",
                    "data.manage",
                    "settings.manage",
                    "audit.read",
                ],
            }
            for role, permissions in roles.items():
                c.execute("INSERT OR IGNORE INTO roles VALUES(?)", (role,))
                for p in permissions:
                    c.execute("INSERT OR IGNORE INTO permissions VALUES(?)", (p,))
                    c.execute(
                        "INSERT OR IGNORE INTO role_permissions VALUES(?,?)", (role, p)
                    )
            c.execute(
                "INSERT OR IGNORE INTO data_sources VALUES(?,?,?,?,?,1)",
                (
                    "factory",
                    "CNC factory",
                    "factory.db",
                    "manufacturing",
                    encode(self.settings.read("query_policy.json")),
                ),
            )
            for key, value in self.settings.read("sectors.json").items():
                c.execute(
                    "INSERT OR IGNORE INTO sector_profiles VALUES(?,?)",
                    (key, encode(value)),
                )
            c.execute(
                "INSERT OR IGNORE INTO simulator_state VALUES(?,?)",
                (
                    "CNC-01",
                    encode(
                        {
                            "state": "RUNNING",
                            "tool": "T07",
                            "material": "AISI-4140",
                            "workpiece": "WP-4140-01",
                            "actual_rpm": 6000.0,
                            "setpoint": 6000.0,
                            "door_closed": True,
                            "estop_ok": True,
                            "write_permitted": True,
                            "feed_hold": False,
                        }
                    ),
                ),
            )
            if sample and new_database:
                c.execute(
                    "INSERT OR IGNORE INTO machines(machine_id,machine_code,machine_name,controller,max_rpm,status) VALUES(1001,'CNC-01','Spindle training cell','OPC UA simulator',9000,'ACTIVE')"
                )
                c.execute(
                    "INSERT OR IGNORE INTO materials(material_id,material_code,material_name,unit) VALUES(1001,'AISI-4140','Alloy steel training stock','kg')"
                )
                c.execute(
                    "INSERT OR IGNORE INTO cutting_tools(tool_id,tool_code,diameter_mm,status) VALUES(1001,'T07',10,'APPROVED')"
                )
                c.execute(
                    "INSERT OR IGNORE INTO tool_limits VALUES(1001,8000,8000,'training-v9')"
                )
                c.execute(
                    "INSERT OR IGNORE INTO tool_material_compatibility VALUES(1001,1001,800,7500,'Training policy','training-v9')"
                )
                c.execute(
                    "INSERT OR IGNORE INTO workpieces VALUES('WP-4140-01',1001,NULL,'FIX-01','training-v9')"
                )
                c.execute(
                    "INSERT INTO machine_state_history(machine_id,state,source_time,received_at,quality,source_sequence) VALUES(1001,'RUNNING',?,?, 'SIMULATED','seed') ON CONFLICT DO NOTHING",
                    ("2026-09-01T08:00:00Z", "2026-09-01T08:00:00Z"),
                )
        return self.stats()

    def audit(self, event, actor, payload, c=None):
        entry = AuditEvent(
            event=event, actor=actor, at=now(), payload=payload
        ).model_dump()

        def insert(connection):
            previous = connection.execute(
                "SELECT hash FROM audit_events ORDER BY id DESC LIMIT 1"
            ).fetchone()
            prev = previous[0] if previous else "0" * 64
            checksum = digest(prev + encode(entry))
            connection.execute(
                "INSERT INTO audit_events(at,actor,event,payload,previous_hash,hash) VALUES(?,?,?,?,?,?)",
                (entry["at"], actor, event, encode(payload), prev, checksum),
            )

        if c is not None:
            insert(c)
        else:
            with self.connect(write=True) as conn:
                insert(conn)

    def verify_audit(self):
        prev = "0" * 64
        count = 0
        with self.connect() as c:
            for row in c.execute("SELECT * FROM audit_events ORDER BY id"):
                obj = {
                    "event": row["event"],
                    "actor": row["actor"],
                    "at": row["at"],
                    "payload": json.loads(row["payload"]),
                }
                if row["previous_hash"] != prev or row["hash"] != digest(
                    prev + encode(obj)
                ):
                    raise RuntimeError("Audit chain verification failed.")
                prev = row["hash"]
                count += 1
        return {"records": count, "head": prev, "valid": True}

    def stats(self):
        with self.connect() as c:
            return {
                "tables": c.execute(
                    "SELECT count(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
                ).fetchone()[0],
                **{
                    n: c.execute("SELECT count(*) FROM " + identifier(n)).fetchone()[0]
                    for n in [
                        "machines",
                        "work_orders",
                        "sensor_readings",
                        "documents",
                        "control_proposals",
                    ]
                },
            }

    def source(self, source_id):
        with self.connect() as c:
            row = c.execute(
                "SELECT * FROM data_sources WHERE id=? AND approved=1", (source_id,)
            ).fetchone()
        if not row:
            raise ValueError(
                "Data source is missing or its schema has not been approved."
            )
        result = dict(row)
        result["policy"] = json.loads(result.pop("policy_json"))
        result["path"] = (
            self.path
            if source_id == "factory"
            else self.settings.data / "sources" / result["filename"]
        )
        return result

    def backup(self, destination):
        destination = Path(destination)
        if destination.exists():
            raise FileExistsError("Backup destination already exists.")
        destination.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as src, sqlite3.connect(destination) as dst:
            src.backup(dst)
        return str(destination)

CREATE TABLE controller_snapshots(id INTEGER PRIMARY KEY,machine TEXT NOT NULL,mode TEXT NOT NULL,captured_at TEXT NOT NULL,healthy INTEGER NOT NULL,detail TEXT NOT NULL,samples_json TEXT NOT NULL);
CREATE INDEX idx_controller_observation ON controller_snapshots(machine,captured_at);

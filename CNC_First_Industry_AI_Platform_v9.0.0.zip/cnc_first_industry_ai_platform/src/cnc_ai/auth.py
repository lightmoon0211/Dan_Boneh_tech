"""Server-side sessions; identities and permissions never come from model output."""

import hashlib
import re
import secrets
import time
from dataclasses import dataclass
from werkzeug.security import generate_password_hash, check_password_hash
from .database import now


@dataclass(frozen=True)
class Principal:
    username: str
    display_name: str
    permissions: frozenset[str]

    def require(self, permission):
        if permission not in self.permissions:
            raise PermissionError(
                "Your account does not have permission for this action."
            )


class Auth:
    def __init__(self, db):
        self.db = db

    def user(self, username):
        with self.db.connect() as c:
            row = c.execute(
                "SELECT username,display_name,enabled FROM users WHERE username=?",
                (username,),
            ).fetchone()
            if not row or not row["enabled"]:
                raise PermissionError("Account is unavailable.")
            permissions = c.execute(
                "SELECT rp.permission FROM user_roles ur JOIN role_permissions rp ON ur.role=rp.role WHERE ur.username=?",
                (username,),
            ).fetchall()
        return Principal(
            row["username"], row["display_name"], frozenset(r[0] for r in permissions)
        )

    def create_user(self, username, password, role, display_name=""):
        if not re.fullmatch(r"[a-zA-Z0-9_-]{3,40}", username):
            raise ValueError(
                "Username must use 3-40 letters, numbers, hyphens or underscores."
            )
        if len(password) < 12:
            raise ValueError("Use a password of at least 12 characters.")
        with self.db.connect(write=True) as c:
            if not c.execute("SELECT 1 FROM roles WHERE name=?", (role,)).fetchone():
                raise ValueError("Unknown role.")
            c.execute(
                "INSERT INTO users VALUES(?,?,?,1,?)",
                (
                    username,
                    display_name or username,
                    generate_password_hash(password),
                    now(),
                ),
            )
            c.execute("INSERT INTO user_roles VALUES(?,?)", (username, role))
            self.db.audit(
                "user.created",
                "local-administrator",
                {"username": username, "role": role},
                c,
            )

    def login(self, username, password, remote):
        identity = hashlib.sha256((username + "|" + remote).encode()).hexdigest()
        with self.db.connect() as c:
            attempt = c.execute(
                "SELECT * FROM login_attempts WHERE identity=?", (identity,)
            ).fetchone()
            row = c.execute(
                "SELECT * FROM users WHERE username=?", (username,)
            ).fetchone()
        if attempt and attempt["blocked_until"] > time.time():
            raise PermissionError("Too many login attempts. Try again in five minutes.")
        valid = bool(
            row
            and row["enabled"]
            and check_password_hash(row["password_hash"], password)
        )
        with self.db.connect(write=True) as c:
            if not valid:
                failures = (attempt["failures"] if attempt else 0) + 1
                c.execute(
                    "INSERT OR REPLACE INTO login_attempts VALUES(?,?,?)",
                    (identity, failures, time.time() + 300 if failures >= 5 else 0),
                )
                self.db.audit(
                    "login.denied", "anonymous", {"identity_hash": identity}, c
                )
            else:
                c.execute("DELETE FROM login_attempts WHERE identity=?", (identity,))
        if not valid:
            raise PermissionError("Username or password is incorrect.")
        token = secrets.token_urlsafe(40)
        csrf = secrets.token_urlsafe(32)
        with self.db.connect(write=True) as c:
            c.execute("DELETE FROM sessions WHERE expires<?", (time.time(),))
            c.execute(
                "INSERT INTO sessions VALUES(?,?,?,?)",
                (
                    hashlib.sha256(token.encode()).hexdigest(),
                    username,
                    csrf,
                    time.time() + 8 * 3600,
                ),
            )
            self.db.audit("login.succeeded", username, {}, c)
        return token, csrf, self.user(username)

    def session(self, token):
        hashed = hashlib.sha256((token or "").encode()).hexdigest()
        with self.db.connect() as c:
            row = c.execute(
                "SELECT * FROM sessions WHERE token_hash=? AND expires>?",
                (hashed, time.time()),
            ).fetchone()
        if not row:
            raise PermissionError("Sign in to continue.")
        return self.user(row["username"]), row["csrf"]

    def logout(self, token):
        with self.db.connect(write=True) as c:
            c.execute(
                "DELETE FROM sessions WHERE token_hash=?",
                (hashlib.sha256((token or "").encode()).hexdigest(),),
            )

"""Analytics databases and replaceable sector schemas are separate from factory authority."""

import re
import shutil
import sqlite3
import uuid
from pathlib import Path
from .database import encode, identifier


class Catalog:
    def __init__(self, db):
        self.db = db

    def list(self):
        with self.db.connect() as c:
            return [
                dict(r)
                for r in c.execute(
                    "SELECT id,name,sector,approved FROM data_sources ORDER BY name"
                )
            ]

    def import_database(self, path, name, sector, principal):
        principal.require("data.manage")
        path = Path(path)
        if path.suffix.lower() not in {".db", ".sqlite", ".sqlite3"}:
            raise ValueError("Upload a SQLite database.")
        if path.stat().st_size > 100 * 1024 * 1024:
            raise ValueError("Database exceeds the 100 MiB import limit.")
        with self.db.connect() as c:
            if not c.execute(
                "SELECT 1 FROM sector_profiles WHERE id=?", (sector,)
            ).fetchone():
                raise ValueError("Unknown sector.")
        with sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True) as c:
            c.execute("PRAGMA trusted_schema=OFF")
            if c.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                raise ValueError("SQLite integrity check failed.")
            schema = {}
            for (table,) in c.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ):
                identifier(table)
                schema[table] = [
                    r[1]
                    for r in c.execute("PRAGMA table_info(" + identifier(table) + ")")
                ]
        key = str(uuid.uuid4())
        folder = self.db.settings.data / "sources"
        folder.mkdir(exist_ok=True)
        target = folder / (key + ".db")
        shutil.copyfile(path, target)
        with self.db.connect(write=True) as c:
            c.execute(
                "INSERT INTO data_sources VALUES(?,?,?,?,?,0)",
                (
                    key,
                    name[:120],
                    target.name,
                    sector,
                    encode({"tables": {}, "max_rows": 100, "timeout_seconds": 5}),
                ),
            )
            self.db.audit(
                "database.imported",
                principal.username,
                {"source": key, "name": name},
                c,
            )
        return {"id": key, "name": name, "schema": schema, "approved": False}

    def raw_schema(self, key):
        with self.db.connect() as c:
            row = c.execute(
                "SELECT filename FROM data_sources WHERE id=?", (key,)
            ).fetchone()
        if not row:
            raise KeyError("Source not found.")
        path = (
            self.db.path
            if key == "factory"
            else self.db.settings.data / "sources" / row[0]
        )
        with sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True) as c:
            return {
                table: [
                    r[1]
                    for r in c.execute("PRAGMA table_info(" + identifier(table) + ")")
                ]
                for (table,) in c.execute(
                    "SELECT name FROM sqlite_master WHERE type IN('table','view') AND name NOT LIKE 'sqlite_%'"
                )
                if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,80}", table)
            }

    def approve(self, key, tables, principal):
        principal.require("data.manage")
        if key == "factory":
            raise ValueError(
                "Edit the factory SQL allowlist through the reviewed site configuration and db refresh-policy CLI command."
            )
        actual = self.raw_schema(key)
        if not isinstance(tables, dict) or not tables:
            raise ValueError("Choose allowed tables and columns explicitly.")
        for table, columns in tables.items():
            if (
                table not in actual
                or not isinstance(columns, list)
                or not columns
                or set(columns) - set(actual[table])
            ):
                raise ValueError("Allowlist contains an unknown table or column.")
        with self.db.connect(write=True) as c:
            c.execute(
                "UPDATE data_sources SET policy_json=?,approved=1 WHERE id=?",
                (
                    encode({"tables": tables, "max_rows": 100, "timeout_seconds": 5}),
                    key,
                ),
            )
            self.db.audit(
                "database.schema_approved",
                principal.username,
                {"source": key, "tables": tables},
                c,
            )

    def create_schema(self, definition, name, sector, principal):
        principal.require("data.manage")
        tables = definition.get("tables", [])
        if not tables or len(tables) > 100:
            raise ValueError("Provide 1-100 table definitions.")
        allowed_types = {
            "integer": "INTEGER",
            "text": "TEXT",
            "real": "REAL",
            "number": "REAL",
            "datetime": "TEXT",
            "boolean": "INTEGER",
            "blob": "BLOB",
        }
        names = {}
        statements = []
        for table in tables:
            tn = table["name"]
            identifier(tn)
            if tn in names:
                raise ValueError("Duplicate table name.")
            columns = table.get("columns", [])
            names[tn] = []
            parts = []
            pk = 0
            if not columns or len(columns) > 100:
                raise ValueError("Provide 1-100 columns per table.")
            for col in columns:
                cn = col["name"]
                identifier(cn)
                if cn in names[tn]:
                    raise ValueError("Duplicate column name.")
                names[tn].append(cn)
                typ = allowed_types.get(col.get("type", "text").lower())
                if not typ:
                    raise ValueError("Unknown column type.")
                part = identifier(cn) + " " + typ
                if col.get("primary_key"):
                    part += " PRIMARY KEY"
                    pk += 1
                if col.get("autoincrement"):
                    if typ != "INTEGER" or not col.get("primary_key"):
                        raise ValueError(
                            "AUTOINCREMENT requires an INTEGER primary key."
                        )
                    part += " AUTOINCREMENT"
                if col.get("not_null"):
                    part += " NOT NULL"
                if col.get("unique"):
                    part += " UNIQUE"
                parts.append(part)
            if pk > 1:
                raise ValueError("Use one primary key in the visual schema definition.")
            for fk in table.get("foreign_keys", []):
                parts.append(
                    "FOREIGN KEY ("
                    + identifier(fk["column"])
                    + ") REFERENCES "
                    + identifier(fk["references_table"])
                    + "("
                    + identifier(fk["references_column"])
                    + ")"
                )
            statements.append(
                "CREATE TABLE " + identifier(tn) + " (" + ",".join(parts) + ")"
            )
        for table in tables:
            for fk in table.get("foreign_keys", []):
                if fk["column"] not in names[table["name"]] or fk[
                    "references_column"
                ] not in names.get(fk["references_table"], []):
                    raise ValueError("Foreign key points to an unknown column.")
        temporary = self.db.settings.data / ("schema-" + str(uuid.uuid4()) + ".db")
        try:
            with sqlite3.connect(temporary) as c:
                c.execute("PRAGMA foreign_keys=ON")
                for sql in statements:
                    c.execute(sql)
            return self.import_database(temporary, name, sector, principal)
        finally:
            temporary.unlink(missing_ok=True)

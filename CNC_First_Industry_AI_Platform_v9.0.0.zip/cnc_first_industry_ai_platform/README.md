# CNC Factory Assistant · v9.0.0

A local CNC manufacturing assistant with authenticated conversations, cited factory evidence, a complete sample database, and a deterministic OPC UA approval workflow. This is a rebuilt Python package, with four inference services and seven logical model roles.

**Start with simulator mode.** The delivered application and loopback integration tests run without GPUs. Real inference, Windows execution, H200 capacity and the actual CNC/PLC installation have separate validation gates described in [VALIDATION.md](docs/VALIDATION.md). This software is not a safety PLC or a certified CNC safety function.

## What is included

- Conversational UI with saved history, single-language language names, readable evidence, source selection, model status, document/report management, machine checks and supervisor review.
- Hybrid RAG: local BM25 plus Qwen embeddings; Word DOCX, PDF, XLSX/XLS, CSV, TXT and Markdown; exact page/paragraph/sheet/row provenance. Lexical retrieval stays available during embedding outages.
- Seeded CNC operations, tools, materials, quality, maintenance, inventory and telemetry; separate authenticated users, proposals, executions, immutable answer evidence and chained audit events.
- Validated single-statement SQL with table/column/function allowlists, named parameters, read-only connections, row/time limits and query evidence. Generated writes are denied to every role.
- Structured planning and code drafts. Generated Python, NC/G-code and robot programs are never executed by this application.
- Persistent request → supervisor decision → requester confirmation → live recheck → typed OPC UA write → setpoint readback. Uncertain writes lock the machine against retries until reconciliation.
- Restart-safe model downloader; Windows scripts; Linux/systemd and Docker examples; offline wheel preparation; migrations; simulator; tests; detailed manuals.

## Model router

| Service | Logical roles | Model repository | Port |
|---|---|---|---:|
| Conversation | conversation, report | Qwen/Qwen3.8-27B | 8001 |
| Code | code, planner, control | Qwen/Qwen3-Coder-Next | 8002 |
| Safety judge | safety | ibm-granite/granite-guardian-4.1-8b | 8003 |
| Embeddings | embedding | Qwen/Qwen3-Embedding-4B | 8004 |

Model cards and serving decisions are documented in [MODELS.md](docs/MODELS.md). Granite Guardian reviews risk and policy language; machine state, commissioned limits, authorization, approvals and native CNC/PLC interlocks remain authoritative.

## Eleven steps from workstation to factory

Run commands from the extracted project directory. Quote paths containing spaces. Use Python 3.12 for the supplied environment definitions; Python 3.11–3.13 is supported by the application package.

### 1. Create or recreate `smartfactoryllm`

For a new installation, in Anaconda PowerShell Prompt:

```powershell
conda env create -f environments/smartfactoryllm.yml
conda activate smartfactoryllm
python -m pip install -e '.[test,download]'
Copy-Item .env.example .env
```

For an existing old environment, first export it and create a clean replacement while retaining the old one:

```powershell
conda env export -n smartfactoryllm --no-builds > smartfactoryllm-old.yml
conda list -n smartfactoryllm --explicit > smartfactoryllm-old-explicit.txt
conda create -n smartfactoryllm_v9 python=3.12 pip -y
conda activate smartfactoryllm_v9
python -m pip install -e '.[test,download]'
python -m pytest
```

After backing up the old project's data and validating the replacement, recreate the requested environment name:

```powershell
conda deactivate
conda env remove -n smartfactoryllm
conda create -n smartfactoryllm --clone smartfactoryllm_v9 -y
conda activate smartfactoryllm
python -m pip check
```

The removal command deletes only that Conda environment. Do not run it before exporting and validating the replacement. Reinstall the editable package if you move the extracted project. [MIGRATION.md](docs/MIGRATION.md) covers old databases and documents. Existing compatible environments can use `scripts/windows/setup.ps1`; it does not delete environments or overwrite an existing database.

Without Conda, `python -m venv .venv` followed by environment activation and the same pip command works. GPU libraries belong in the separate `smartfactorymodels` Linux environment.

### 2. Download or resume all four physical models

Keep model storage outside the project, for example `F:/AI/models/`. In the application environment:

```powershell
python scripts/models/download_factory_models.py all --model-root 'F:/AI/models' --workers 2 --checksums
```

Download one model:

```powershell
python scripts/models/download_factory_models.py code --model-root 'F:/AI/models' --workers 1 --checksums
```

After Ctrl+C, reboot or lost internet, run the **same command** again. Partial files, Hugging Face metadata and the pinned commit are retained. Each operation retries 20 times by default; `--retries 0` retries indefinitely. Permanent authorization/not-found/disk errors stop with a clear message. Keep the model root's `.factory-downloads` manifests and each model's `.cache/huggingface` metadata.

```powershell
python scripts/models/download_factory_models.py all --model-root 'F:/AI/models' --verify --checksums
```

Verification is offline. SHA256 verification requires a download completed with `--checksums`; otherwise repeat the download command with that option first. Linux uses paths such as `/srv/ai/models`; WSL uses `/mnt/f/AI/models`.

### 3. Point to existing local models

Edit `.env`; no application source changes are required:

```dotenv
MODEL_ROOT=F:/AI/models
CONVERSATION_MODEL_PATH=${MODEL_ROOT}/Qwen3.8-27B
CODE_MODEL_PATH=${MODEL_ROOT}/Qwen3-Coder-Next
SAFETY_MODEL_PATH=${MODEL_ROOT}/granite-guardian-4.1-8b
EMBEDDING_MODEL_PATH=${MODEL_ROOT}/Qwen3-Embedding-4B
```

Each path must be a complete Hugging Face Transformers snapshot containing its configuration, tokenizer and weight shards. An existing Hub cache can use its concrete `snapshots/<commit>` directory. GGUF files are not interchangeable with the included vLLM serving path. Set `EMBEDDING_MODEL_REVISION` to the exact snapshot commit and rebuild embeddings whenever it changes. Existing local models without downloader manifests may be served, but cannot pass manifest verification until acquired/registered through a verified download root.

### 4. Start the four inference services

Use Linux on the H200 servers, or WSL2 for suitable workstation hardware. A smaller Windows PC can run the UI, database, RAG lexical search and simulator in `CNC_MODEL_MODE=demo`, or point to the factory servers. It is not expected to load all original models locally.

On **each Linux inference host**, with the project installed at `/opt/cnc-ai`:

```bash
conda env create -f environments/smartfactorymodels.yml
conda activate smartfactorymodels
python -m pip install -r requirements/h200.txt
```

The H200 requirements specify a staging candidate, not a hardware certification. Run the model tests on the actual GPUs, then freeze the entire working environment before transfer.

Edit `.env` on each host to use Linux model paths. Set `MODEL_SERVER_BIND` to its private inference-interface address and set distinct long API keys for services hosted there. On server A:

```bash
python scripts/models/serve_models.py server-a --dry-run
python scripts/models/serve_models.py server-a
```

On server B:

```bash
python scripts/models/serve_models.py server-b --dry-run
python scripts/models/serve_models.py server-b
```

Server A runs conversation GPU 0, safety GPU 1 and embedding GPU 2. Server B runs code with tensor parallelism on GPUs 0–1. These are **host-local GPU indices**. This initial allocation uses five of the sixteen H200s; remaining GPUs provide measured growth/replica capacity. Do not run both host profiles unchanged on one host: their GPU IDs overlap. Edit `config/models.json` first for a single-host layout.

On the application host, configure the corresponding URLs and the same keys, for example:

```dotenv
CONVERSATION_BASE_URL=http://10.20.0.11:8001/v1
CODE_BASE_URL=http://10.20.0.12:8002/v1
SAFETY_BASE_URL=http://10.20.0.11:8003/v1
EMBEDDING_BASE_URL=http://10.20.0.11:8004/v1
CNC_MODEL_MODE=local
```

These addresses are examples; substitute your private addresses. Restrict inference ports to the application host. Use site TLS termination for inference if traffic crosses a shared network. `/v1/models` means reachable and advertised; **Verify model inference** performs actual test requests.

### 5. Initialize the CNC database and accounts

```powershell
python -m cnc_ai db init --sample
python -m cnc_ai user add factory_admin --role admin --display-name 'Factory administrator'
python -m cnc_ai user add operator01 --role operator --display-name 'Operator 01'
python -m cnc_ai user add supervisor01 --role supervisor --display-name 'Shift supervisor'
```

Passwords are securely prompted twice, with a 12-character minimum. No default login credentials are shipped. Administrator privileges do not grant machine control or supervisor approval. Use separate named accounts. `db init` without `--sample` creates the complete empty business schema for a new factory database; it still includes simulator state for training. Initialization preserves existing data and applies checksummed migrations.

### 6. Ingest RAG documents

```powershell
python -m cnc_ai ingest samples/documents/spindle_change_sop.md --user factory_admin --kind sop --revision training-v9
python -m cnc_ai ingest samples/documents/tool_material_specifications.csv --user factory_admin --kind tool --revision training-v9
python -m cnc_ai ingest samples/documents/shift_report.txt --user factory_admin --kind report
python -m cnc_ai rebuild-embeddings --user factory_admin
```

Or sign in as an administrator/supervisor and use **Documents & reports**. Categories include manuals, SOPs, maintenance, machine/tool/material specifications and production reports. Scanned PDFs need offline OCR; legacy `.doc` needs local conversion to `.docx`. Excel formulas are read from saved cached results. Sample documents are fictional training material, not OEM-approved machining parameters.

### 7. Run the OPC UA simulator

The default `CNC_OPCUA_MODE=simulator` uses a persistent internal simulator and needs no other process. For a real OPC UA protocol test without machinery, start this in a second terminal:

```powershell
conda activate smartfactoryllm
python -m cnc_ai opcua-simulator --port 4840
```

Then set `CNC_OPCUA_MODE=opcua_test` and `OPCUA_ENDPOINT=opc.tcp://127.0.0.1:4840` in `.env`, restart the application and run `python -m cnc_ai validate --opcua`. Test mode is restricted to loopback.

Sign in as `operator01`, prepare CNC-01 at 7000 RPM and run the policy checks. Create the proposal. A separate signed-in `supervisor01` reviews and approves it. The requester returns and types `EXECUTE APPROVED ACTION`. Successful setpoint readback is not proof that measured spindle speed changed.

### 8. Configure a real CNC OPC UA endpoint

Follow [CONTROL_COMMISSIONING.md](docs/CONTROL_COMMISSIONING.md). A controls engineer must replace the training recipes/limits and sample node mapping; prove native controller enforcement; configure the actual machine state semantics; and test timestamp quality, interlocks and authenticated write access.

Configure an OPC UA client certificate/private key, pinned server certificate and restricted controller service account in `.env`. The real adapter uses `Basic256Sha256` with `SignAndEncrypt`. It exposes only allowlisted typed spindle setpoint and feed-hold actions. Real mode requires `real_mapping_reviewed=true` and `controller_enforces_limits=true` in `config/opcua.json`. Keep `CNC_REAL_WRITES_ENABLED=false` while testing reads. Enable real writes and `CNC_SITE_COMMISSIONED=true` only after the documented site acceptance. Demo model mode cannot be combined with a real controller.

### 9. Start the application

```powershell
conda activate smartfactoryllm
python -m cnc_ai serve
```

Open `http://127.0.0.1:5000`. Windows wrappers are `scripts/windows/start.ps1` and `start_windows.bat`. Linux uses `bash scripts/linux/start_app.sh`. The server is Waitress; there are no fragile root-level `db` imports.

For factory users, keep Waitress on loopback behind the provided HTTPS nginx configuration and set `CNC_COOKIE_SECURE=true`, `CNC_TRUST_PROXY=true`. Only the trusted proxy may access Waitress. [DEPLOYMENT.md](docs/DEPLOYMENT.md) includes systemd, Docker, firewall and backup instructions.

### 10. Validate the complete installation

```powershell
python -m pip check
python -m pytest
python -m cnc_ai validate --offline
python -m cnc_ai validate --models --opcua
python -m cnc_ai audit-verify
Invoke-RestMethod -Uri 'http://127.0.0.1:5000/api/health'
```

Use the network checks after starting the relevant services. `--offline` validates the database and package without probing network endpoints. Do not combine it with network flags. In PowerShell, use `Invoke-RestMethod`; if you specifically need native curl, call `curl.exe`, not its ambiguous alias. Optional browser testing: `python scripts/validate_browser.py` after installing the browser test dependencies described in [VALIDATION.md](docs/VALIDATION.md).

### 11. Transfer to the air-gapped H200 servers

On a connected **Linux staging host matching the factory OS, CPU architecture and Python version**, install and validate the H200 environment. Freeze it:

```bash
conda activate smartfactorymodels
python -m pip freeze > /srv/transfer/inference-lock.txt
conda activate smartfactoryllm
python scripts/prepare_airgap.py --output /srv/transfer/cnc-wheels --inference-lock /srv/transfer/inference-lock.txt
python scripts/verify_bundle.py /srv/transfer/cnc-wheels
```

Transfer this project ZIP, the wheel bundle, complete model directories and manifests, an offline Python/Conda environment or installer/package cache, compatible NVIDIA drivers, required OS libraries, site certificates and approved configuration. Windows wheels do not satisfy Linux installation. See [AIRGAP.md](docs/AIRGAP.md) for exact offline installation, checksum checks, Docker image transfer, commissioning and rollback commands. Model weights are deliberately absent from this ZIP.

## Project layout

| Location | Purpose |
|---|---|
| `src/cnc_ai/` | Installed application, services, strict contracts and adapters |
| `src/cnc_ai/resources/` | Packaged defaults, sample CNC database and ordered migrations |
| `config/` | Reviewed site model, SQL, sector, safety and OPC UA configuration |
| `scripts/` | Windows/Linux startup, models, database, RAG and transfer utilities |
| `deployment/` | systemd units, HTTPS proxy and Docker examples |
| `samples/` | Fictional CNC documents and replaceable sector schemas |
| `tests/` | Security, lifecycle, RAG, router, download and protocol integration checks |
| `docs/` | User manual, architecture, deployment, schema, migration and validation evidence |
| `runtime/` | Created locally: database, documents, vectors and logs; excluded from Git |

The source manual is [USER_MANUAL.md](docs/USER_MANUAL.md). A formatted Word manual and PDF are included alongside it. [ARCHITECTURE.md](docs/ARCHITECTURE.md) explains the design and its scaling limits; [REBUILD_REVIEW.md](docs/REBUILD_REVIEW.md) records what changed from v8.

The `packages/` directory also contains the tested installable application wheel. CPU dependency versions are recorded in `requirements/validated-linux-py312.txt`; stage dependency wheels separately for offline use. Public request contracts and endpoints are documented in [API.md](docs/API.md). [DOCUMENT_STYLE.md](docs/DOCUMENT_STYLE.md) explains how to regenerate the Word manual.

Before changing the extracted configuration, verify the release files with `python scripts/verify_bundle.py .`. The SHA256 manifest detects missing or changed files; expected site edits will change their hashes.

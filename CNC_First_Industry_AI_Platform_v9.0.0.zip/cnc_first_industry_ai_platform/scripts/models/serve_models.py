#!/usr/bin/env python3
"""Launch vLLM on a Linux host with local paths and graceful child cleanup."""

import argparse
import json
import os
from pathlib import Path
import shlex
import signal
import subprocess
import sys
import time
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[2]


def inference_environment(spec, environment):
    """Keep controller/app credentials and unrelated service keys out of vLLM."""
    blocked = {"HF_TOKEN", "HUGGING_FACE_HUB_TOKEN", "HUGGINGFACEHUB_API_TOKEN"}
    child = {
        key: value
        for key, value in environment.items()
        if not key.startswith(("OPCUA_", "CNC_"))
        and not key.endswith("_API_KEY")
        and key not in blocked
    }
    child.update(
        CUDA_VISIBLE_DEVICES=spec["gpu_ids"],
        HF_HUB_OFFLINE="1",
        TRANSFORMERS_OFFLINE="1",
        VLLM_NO_USAGE_STATS="1",
        DO_NOT_TRACK="1",
        HF_HUB_DISABLE_TELEMETRY="1",
        VLLM_API_KEY=environment.get(spec["key_env"], ""),
    )
    return child


def build_command(key, spec, env):
    root = Path(env.get("MODEL_ROOT", "/srv/ai/models"))
    path = (
        Path(env.get(spec["path_env"], str(root / spec["directory"])))
        .expanduser()
        .resolve()
    )
    cmd = [
        "vllm",
        "serve",
        str(path),
        "--served-model-name",
        spec["model"],
        "--host",
        env.get("MODEL_SERVER_BIND", "127.0.0.1"),
        "--port",
        str(spec["port"]),
        "--tensor-parallel-size",
        str(spec["tensor_parallel"]),
        "--max-model-len",
        str(spec["max_model_len"]),
    ]
    if key == "embedding":
        cmd += ["--runner", "pooling"]
    if key == "code":
        cmd += ["--enable-auto-tool-choice", "--tool-call-parser", "qwen3_coder"]
    return path, cmd


def main(argv=None):
    load_dotenv(ROOT / ".env", override=False)
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "target",
        choices=["server-a", "server-b", "conversation", "code", "safety", "embedding"],
    )
    p.add_argument("--config", type=Path, default=ROOT / "config/models.json")
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args(argv)
    registry = json.loads(args.config.read_text())
    keys = registry["hosts"].get(args.target, [args.target])
    children = []
    handles = []
    if os.name == "nt" and not args.dry_run:
        p.error("Run vLLM in Linux/WSL2; Windows runs the application client.")
    try:
        for key in keys:
            spec = registry["services"][key]
            path, cmd = build_command(key, spec, os.environ)
            print(f"{key}: GPUs {spec['gpu_ids']}; " + shlex.join(cmd), flush=True)
            if args.dry_run:
                continue
            if not path.is_dir() or not (path / "config.json").is_file():
                raise ValueError(f"Local model is incomplete or missing: {path}")
            bind = os.getenv("MODEL_SERVER_BIND", "127.0.0.1")
            if bind not in {"127.0.0.1", "localhost", "::1"} and not os.getenv(
                spec["key_env"]
            ):
                raise ValueError(
                    f"{spec['key_env']} is required for LAN inference serving"
                )
            # vLLM reads VLLM_API_KEY; keep secrets out of command lines and logs.
            child_env = inference_environment(spec, os.environ)
            directory = Path(
                os.getenv("MODEL_LOG_DIR", str(ROOT / "runtime/model_logs"))
            )
            directory.mkdir(parents=True, exist_ok=True)
            handle = (directory / (key + ".log")).open("a")
            handles.append(handle)
            children.append(
                subprocess.Popen(
                    cmd, env=child_env, stdout=handle, stderr=subprocess.STDOUT
                )
            )
        if args.dry_run:
            return 0

        def stop(signum, frame):
            raise KeyboardInterrupt

        signal.signal(signal.SIGTERM, stop)
        while children:
            if any(child.poll() is not None for child in children):
                raise RuntimeError(
                    "An inference process exited. Inspect runtime/model_logs; the other child services will stop."
                )
            time.sleep(1)
    except KeyboardInterrupt:
        print("Stopping model services...", flush=True)
    except Exception as exc:
        print("ERROR: " + str(exc), file=sys.stderr)
        return 1
    finally:
        for child in children:
            if child.poll() is None:
                child.terminate()
        for child in children:
            try:
                child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
        for handle in handles:
            handle.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

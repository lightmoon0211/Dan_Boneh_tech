#!/usr/bin/env python3
"""Offline size/SHA256 validation of a prepared transfer bundle."""

import argparse
import hashlib
import json
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("directory", type=Path)
    args = p.parse_args()
    root = args.directory.resolve()
    manifest = json.loads((root / "SHA256SUMS.json").read_text())
    failures = []
    for name, meta in manifest["files"].items():
        path = (root / name).resolve()
        if not path.is_relative_to(root):
            raise ValueError("Invalid manifest path.")
        if not path.is_file() or path.stat().st_size != meta["size"]:
            failures.append(name)
            continue
        with path.open("rb") as f:
            actual = hashlib.file_digest(f, "sha256").hexdigest()
        if actual != meta["sha256"]:
            failures.append(name)
    if failures:
        print("FAILED: " + ", ".join(failures))
        return 1
    print(f"PASS: {len(manifest['files'])} transfer files verified.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

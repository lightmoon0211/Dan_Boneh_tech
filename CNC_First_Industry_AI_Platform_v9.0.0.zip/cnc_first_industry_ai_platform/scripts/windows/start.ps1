$ErrorActionPreference = 'Stop'
Set-Location (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
conda run --no-capture-output -n smartfactoryllm python -m cnc_ai serve
exit $LASTEXITCODE

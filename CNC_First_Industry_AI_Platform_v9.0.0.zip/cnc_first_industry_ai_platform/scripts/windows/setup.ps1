param([switch]$Recreate)
$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
Set-Location $ProjectRoot
if (-not (Get-Command conda -ErrorAction SilentlyContinue)) { throw 'Open Anaconda PowerShell Prompt, then run this script again.' }
if ($Recreate) {
    throw 'Export/backup the old environment first. See README: create smartfactoryllm_v9, validate, then switch. This script never deletes an environment.'
}
$Environments = conda env list --json | ConvertFrom-Json
$Exists = @($Environments.envs | Where-Object { (Split-Path $_ -Leaf) -eq 'smartfactoryllm' }).Count -gt 0
if (-not $Exists) {
    conda env create -f environments/smartfactoryllm.yml
    if ($LASTEXITCODE -ne 0) { throw 'Conda environment creation failed.' }
}
conda run --no-capture-output -n smartfactoryllm python -c "import sys; assert (3,11) <= sys.version_info[:2] < (3,14), 'Python 3.11-3.13 is required'"
if ($LASTEXITCODE -ne 0) { throw 'Use the clean-environment instructions in README.' }
conda run --no-capture-output -n smartfactoryllm python -m pip install --upgrade-strategy only-if-needed -e '.[test,download]'
if ($LASTEXITCODE -ne 0) { throw 'Application dependency installation failed.' }
if (-not (Test-Path '.env')) { Copy-Item '.env.example' '.env' }
conda run --no-capture-output -n smartfactoryllm python -m cnc_ai db init --sample
if ($LASTEXITCODE -ne 0) { throw 'Database initialization failed.' }
conda run --no-capture-output -n smartfactoryllm python -m pytest
if ($LASTEXITCODE -ne 0) { throw 'Validation failed.' }
Write-Host 'Ready. Create operator, supervisor and administrator accounts using the README commands.'

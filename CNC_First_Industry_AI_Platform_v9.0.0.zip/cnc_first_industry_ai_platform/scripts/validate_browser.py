#!/usr/bin/env python3
"""Exercise the actual local UI with temporary demo data; never connects to machinery."""

import argparse
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
from urllib.request import build_opener, ProxyHandler
from cnc_ai.config import Settings
from cnc_ai.database import Database
from cnc_ai.auth import Auth

ROOT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--browser-executable")
    p.add_argument("--screenshot-dir", type=Path, default=ROOT / "docs/screenshots")
    args = p.parse_args()
    args.screenshot_dir.mkdir(parents=True, exist_ok=True)
    from playwright.sync_api import sync_playwright, expect

    with tempfile.TemporaryDirectory(prefix="cnc-browser-") as temporary:
        home = Path(temporary)
        settings = Settings(home, home / "runtime", ROOT / "config", model_mode="demo")
        db = Database(settings)
        db.initialize(sample=True)
        auth = Auth(db)
        for user, role in [
            ("operator", "operator"),
            ("supervisor", "supervisor"),
            ("admin", "admin"),
        ]:
            auth.create_user(user, "Browser-test-only-123", role, user.title())
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        env = dict(
            os.environ,
            CNC_DATA_DIR=str(settings.data),
            CNC_CONFIG_DIR=str(settings.config),
            CNC_MODEL_MODE="demo",
            CNC_OPCUA_MODE="simulator",
            CNC_COOKIE_SECURE="false",
            CNC_TRUST_PROXY="false",
            CNC_HOST="127.0.0.1",
        )
        with (home / "server.log").open("w") as log:
            server = subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "cnc_ai",
                    "--home",
                    str(home),
                    "serve",
                    "--port",
                    str(port),
                ],
                env=env,
                stdout=log,
                stderr=log,
            )
            try:
                base = f"http://127.0.0.1:{port}"
                opener = build_opener(ProxyHandler({}))
                for _ in range(100):
                    try:
                        with opener.open(base + "/api/health", timeout=1) as response:
                            assert response.status == 200
                        break
                    except OSError:
                        time.sleep(0.1)
                else:
                    raise RuntimeError(
                        "Waitress did not become healthy: "
                        + (home / "server.log").read_text()
                    )
                with sync_playwright() as playwright:
                    launch = {"headless": True}
                    if args.browser_executable:
                        launch.update(
                            executable_path=args.browser_executable,
                            args=[
                                "--no-sandbox",
                                "--disable-dev-shm-usage",
                                "--no-zygote",
                                "--use-angle=swiftshader",
                            ],
                        )
                    browser = playwright.chromium.launch(**launch)
                    context = browser.new_context(
                        viewport={"width": 1440, "height": 980}
                    )
                    page = context.new_page()
                    errors = []
                    page.on("pageerror", lambda error: errors.append(str(error)))

                    def login(username):
                        page.goto(base)
                        page.locator("#loginUser").fill(username)
                        page.locator("#loginPassword").fill("Browser-test-only-123")
                        page.locator("#loginForm button[type=submit]").click()
                        expect(page.locator("#workspace")).to_be_visible()
                        expect(page.locator("#modeBadge")).to_contain_text(
                            "Training mode"
                        )

                    login("operator")
                    page.screenshot(
                        path=str(args.screenshot_dir / "conversation_desktop.png")
                    )
                    names = page.locator("#language option").all_text_contents()
                    assert names == [
                        "English",
                        "French",
                        "German",
                        "Chinese (Simplified)",
                        "Chinese (Traditional)",
                        "Japanese",
                        "Korean",
                    ]
                    page.locator("#question").fill("Show the CNC machine inventory.")
                    page.locator("#sendMessage").click()
                    expect(page.locator(".message.assistant")).to_contain_text(
                        "20 machines"
                    )
                    expect(page.locator(".evidence")).to_have_count(1)
                    page.locator(".evidence>summary").click()
                    expect(page.locator(".evidence table")).to_be_visible()
                    page.screenshot(
                        path=str(args.screenshot_dir / "evidence_desktop.png")
                    )
                    page.locator("[data-panel=controlPanel]").click()
                    page.locator("#preflight").click()
                    expect(page.locator("#policyChecks .check")).to_have_count(7)
                    page.locator("#controlForm button[type=submit]").click()
                    expect(page.locator("#proposalList")).to_contain_text("pending")
                    page.screenshot(
                        path=str(args.screenshot_dir / "control_desktop.png")
                    )
                    page.locator("#logout").click()
                    login("supervisor")
                    page.locator("[data-panel=controlPanel]").click()
                    page.get_by_role(
                        "button", name="Approve proposal", exact=True
                    ).click()
                    page.locator("#dialogInput").fill(
                        "Checked the training tool, material and limits."
                    )
                    page.locator("#dialogConfirm").click()
                    expect(page.locator("#proposalList")).to_contain_text("approved")
                    page.locator("#logout").click()
                    login("operator")
                    page.locator("[data-panel=controlPanel]").click()
                    page.get_by_role(
                        "button", name="Confirm execution", exact=True
                    ).click()
                    page.locator("#dialogInput").fill("EXECUTE APPROVED ACTION")
                    page.locator("#dialogConfirm").click()
                    expect(page.locator("#proposalList")).to_contain_text("confirmed")
                    expect(page.locator("#machineStatus")).to_contain_text(
                        "Setpoint 7000"
                    )
                    page.set_viewport_size({"width": 390, "height": 844})
                    page.locator("[data-panel=chatPanel]").click()
                    expect(page.locator("#logout")).to_be_visible()
                    expect(page.locator("#newChat")).to_be_visible()
                    page.locator("#newChat").click()
                    page.screenshot(
                        path=str(args.screenshot_dir / "conversation_mobile.png")
                    )
                    assert page.evaluate(
                        "document.documentElement.scrollWidth <= window.innerWidth"
                    ), "Mobile horizontal overflow"
                    assert not errors, errors
                    browser.close()
                print(
                    json.dumps(
                        {
                            "browser": "passed",
                            "checks": [
                                "sign-in",
                                "language labels",
                                "demo conversation",
                                "database citations",
                                "ordered checks",
                                "supervisor approval",
                                "requester execution",
                                "readback",
                                "mobile navigation",
                                "no JavaScript errors",
                            ],
                        },
                        indent=2,
                    )
                )
            finally:
                server.terminate()
                try:
                    server.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    server.kill()
                    server.wait()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

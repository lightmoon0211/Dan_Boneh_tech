"""Run after pip install -e . from the repository root."""

from cnc_ai.cli import main

if __name__ == "__main__":
    raise SystemExit(main(["db", "init", "--sample"]))

#!/usr/bin/env python3
"""Copy a legacy CNC database into an unused v9 data directory, then migrate it."""

import argparse
import sqlite3
from pathlib import Path
from cnc_ai.config import Settings
from cnc_ai.database import Database


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("--home", type=Path, default=Path.cwd())
    args = parser.parse_args()
    source = args.source.resolve()
    settings = Settings.load(args.home)
    if not source.is_file():
        parser.error("Legacy database does not exist.")
    if settings.database.exists():
        parser.error(
            "Destination already contains a database. Choose an unused CNC_DATA_DIR; no existing data will be overwritten."
        )
    settings.data.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(source.as_uri() + "?mode=ro", uri=True) as old:
        tables = {
            r[0]
            for r in old.execute("SELECT name FROM sqlite_master WHERE type='table'")
        }
        if not {
            "machines",
            "materials",
            "cutting_tools",
            "work_orders",
            "sensor_readings",
        }.issubset(tables):
            parser.error(
                "This is not the legacy CNC schema. Import it as an analytics database instead."
            )
        if {"schema_migrations", "control_proposals", "users"} & tables:
            parser.error(
                "This database already contains platform tables. Use a normal backup/restore and db migrate for v9 data."
            )
        if old.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            parser.error("Legacy database failed its integrity check.")
        with sqlite3.connect(settings.database) as new:
            old.backup(new)
    print(Database(settings).initialize(sample=False))
    print(
        "Legacy CNC records preserved. Create new authenticated accounts and re-ingest documents. Review docs/MIGRATION.md before enabling the application."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

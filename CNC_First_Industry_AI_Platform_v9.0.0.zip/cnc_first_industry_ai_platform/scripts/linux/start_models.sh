#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/../.."
exec python scripts/models/serve_models.py "${1:?Usage: start_models.sh server-a or server-b}"

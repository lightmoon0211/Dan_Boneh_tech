#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/../.."
python -m pip check
python -m pytest
python -m cnc_ai validate "$@"

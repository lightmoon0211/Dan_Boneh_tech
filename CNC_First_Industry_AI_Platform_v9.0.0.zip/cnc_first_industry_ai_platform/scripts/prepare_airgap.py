#!/usr/bin/env python3
"""Prepare wheels on an internet-connected host matching the factory OS/Python/architecture."""

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def run(*arguments):
    print("Running: " + " ".join(map(str, arguments)), flush=True)
    subprocess.run(list(map(str, arguments)), check=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument(
        "--inference-lock",
        type=Path,
        help="pip freeze requirements from an already validated H200 inference environment",
    )
    args = p.parse_args()
    output = args.output.resolve()
    if output.is_relative_to(ROOT):
        p.error("Use a transfer directory outside the project.")
    output.mkdir(parents=True, exist_ok=True)
    wheels = output / "app-wheelhouse"
    wheels.mkdir(exist_ok=True)
    run(sys.executable, "-m", "pip", "wheel", "--wheel-dir", wheels, ROOT)
    run(
        sys.executable,
        "-m",
        "pip",
        "download",
        "--only-binary=:all:",
        "--dest",
        wheels,
        "setuptools>=77",
        "wheel",
        "pytest>=8,<10",
        "pytest-cov>=6,<8",
        "huggingface-hub>=1,<2",
    )
    if args.inference_lock:
        inference = output / "inference-wheelhouse"
        inference.mkdir(exist_ok=True)
        shutil.copy2(args.inference_lock, output / "inference-lock.txt")
        run(
            sys.executable,
            "-m",
            "pip",
            "download",
            "--only-binary=:all:",
            "--dest",
            inference,
            "-r",
            args.inference_lock,
        )
    metadata = {"python": sys.version, "platform": sys.platform, "files": {}}
    for path in sorted(output.rglob("*")):
        if path.is_file() and path.name != "SHA256SUMS.json":
            with path.open("rb") as f:
                checksum = hashlib.file_digest(f, "sha256").hexdigest()
            metadata["files"][str(path.relative_to(output)).replace("\\", "/")] = {
                "size": path.stat().st_size,
                "sha256": checksum,
            }
    (output / "SHA256SUMS.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(
        "Wheel bundle prepared. Separately include this project ZIP, model directories with their manifests/caches, approved GPU drivers, OS/Conda installers, and site certificates. Verify on staging before transfer."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

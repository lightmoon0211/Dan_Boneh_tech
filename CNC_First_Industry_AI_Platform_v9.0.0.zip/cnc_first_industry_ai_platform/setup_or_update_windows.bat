@echo off
powershell.exe -NoProfile -File "%~dp0scripts\windows\setup.ps1"
exit /b %errorlevel%

import asyncio
import socket
import threading
from dataclasses import replace
import pytest
from cnc_ai.control.simulator_server import run
from cnc_ai.control.adapters import RealOPCUAAdapter
from cnc_ai.control.service import ControlService
from cnc_ai.contracts import ControlRequest, Approval


@pytest.mark.integration
def test_actual_opcua_protocol_on_loopback(system, monkeypatch):
    settings, db, auth, _, _ = system
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
    ready = threading.Event()
    stop = threading.Event()
    errors = []

    def server():
        try:
            asyncio.run(run(port, ready, stop))
        except BaseException as e:
            errors.append(e)
            ready.set()

    thread = threading.Thread(target=server, daemon=True)
    thread.start()
    monkeypatch.setenv("OPCUA_ENDPOINT", f"opc.tcp://127.0.0.1:{port}")
    test_settings = replace(settings, opcua_mode="opcua_test")
    adapter = RealOPCUAAdapter(test_settings)
    control = ControlService(test_settings, db, auth, adapter)
    try:
        assert ready.wait(60), "OPC UA test server did not start within 60 seconds"
        if errors:
            raise errors[0]
        snapshot = adapter.snapshot("CNC-01")
        assert snapshot.healthy(5, 2)[0]
        p = control.create(
            ControlRequest(
                machine="CNC-01",
                action="set_spindle_rpm",
                rpm=7000.0,
                reason="Loopback wire protocol check",
            ),
            auth.user("operator"),
        )
        control.decide(
            p["id"],
            Approval(decision="approve", comment="Reviewed training limits"),
            auth.user("supervisor"),
        )
        result = control.execute(p["id"], auth.user("operator"))
        assert result["confirmed_setpoint"] == 7000.0 and result["mode"] == "opcua_test"
        assert adapter.snapshot("CNC-01").value("setpoint") == 7000.0
    finally:
        stop.set()
        thread.join(10)
    assert not thread.is_alive() and not errors

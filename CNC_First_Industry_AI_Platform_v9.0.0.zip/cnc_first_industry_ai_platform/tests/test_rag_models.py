import json
import threading
from dataclasses import replace
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import pytest
from cnc_ai.models import ModelRouter, ModelUnavailable
from cnc_ai.rag import RAG, extract
from cnc_ai.contracts import Answer


class Vectors:
    embedding_fingerprint = "test-vector-v1"
    embedding_retry_at = 0

    def embed(self, texts, query=False):
        return [
            [
                float(any(t in x.lower() for t in ["spindle", "主轴"])),
                float("quality" in x.lower()),
                1.0,
            ]
            for x in texts
        ]


@pytest.mark.parametrize("extension", [".txt", ".md", ".csv", ".docx", ".xlsx", ".pdf"])
def test_document_extraction(system, tmp_path, extension):
    path = tmp_path / ("source" + extension)
    if extension in {".txt", ".md"}:
        path.write_text("Spindle limit is 7500 RPM.\nApproved training procedure.")
    elif extension == ".csv":
        path.write_text("machine,rpm\nCNC-01,7500\n")
    elif extension == ".docx":
        from docx import Document

        d = Document()
        d.add_paragraph("Spindle limit is 7500 RPM.")
        d.save(path)
    elif extension == ".xlsx":
        from openpyxl import Workbook

        b = Workbook()
        b.active.title = "Tool limits"
        b.active.append(["Tool", "Maximum RPM"])
        b.active.append(["T07", 7500])
        b.save(path)
    else:
        from pypdf import PdfWriter
        from pypdf.generic import DecodedStreamObject, NameObject, DictionaryObject

        writer = PdfWriter()
        page = writer.add_blank_page(612, 792)
        font = DictionaryObject(
            {
                NameObject("/Type"): NameObject("/Font"),
                NameObject("/Subtype"): NameObject("/Type1"),
                NameObject("/BaseFont"): NameObject("/Helvetica"),
            }
        )
        page[NameObject("/Resources")] = DictionaryObject(
            {
                NameObject("/Font"): DictionaryObject(
                    {NameObject("/F1"): writer._add_object(font)}
                )
            }
        )
        stream = DecodedStreamObject()
        stream.set_data(b"BT /F1 12 Tf 72 720 Td (Spindle limit is 7500 RPM.) Tj ET")
        page[NameObject("/Contents")] = writer._add_object(stream)
        with path.open("wb") as h:
            writer.write(h)
    sections = extract(path)
    assert sections and any("7500" in text for _, text in sections)


def test_hybrid_cjk_provenance_delete_and_fallback(system, tmp_path):
    _, db, auth, _, _ = system
    router = Vectors()
    rag = RAG(db, router)
    admin = auth.user("admin")
    operator = auth.user("operator")
    path = tmp_path / "manual.txt"
    path.write_text(
        "Spindle speed limit is 7500 RPM for the approved training fixture."
    )
    result = rag.ingest(path, admin)
    assert result["retrieval"] == "hybrid"
    assert rag.ingest(path, admin)["duplicate"]
    results = rag.search("主轴", operator)
    assert results and results[0]["title"] == "manual.txt"
    old_content = results[0]["content"]
    old_id = results[0]["id"]

    def offline(*a, **k):
        raise ModelUnavailable("Offline")

    router.embed = offline
    assert rag.search("spindle", operator)
    rag.delete(result["id"], admin)
    assert rag.status()["chunks"] == 0
    with db.connect() as c:
        assert (
            c.execute(
                "SELECT content FROM evidence_records WHERE id=?", (old_id,)
            ).fetchone()[0]
            == old_content
        )


def test_rag_sector_filter_and_unknown_vectors(system, tmp_path):
    _, db, auth, _, _ = system
    rag = RAG(db, Vectors())
    path = tmp_path / "sop.txt"
    path.write_text("Spindle approved procedure")
    rag.ingest(path, auth.user("admin"), sector="manufacturing")
    assert not rag.search("spindle", auth.user("operator"), sector="rail")
    rag.router.embedding_fingerprint = "changed-model"
    assert rag.status()["embeddings"] == 0
    assert rag.rebuild(auth.user("admin"))["embedded_chunks"] == 1


def test_local_endpoint_contracts_and_guardian_41(system, monkeypatch):
    settings, *_ = system
    requests = []

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(
                json.dumps(
                    {
                        "data": [
                            {"id": name}
                            for name in [
                                "Qwen/Qwen3.8-27B",
                                "Qwen/Qwen3-Coder-Next",
                                "ibm-granite/granite-guardian-4.1-8b",
                                "Qwen/Qwen3-Embedding-4B",
                            ]
                        ]
                    }
                ).encode()
            )

        def do_POST(self):
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            requests.append(body)
            if self.path.endswith("/embeddings"):
                result = {
                    "data": [
                        {"index": i, "embedding": [1.0] * 1024}
                        for i in range(len(body["input"]))
                    ]
                }
            else:
                if "guardian" in body["model"]:
                    content = "<think>\n</think><score>no</score>"
                elif (
                    body.get("response_format", {}).get("json_schema", {}).get("name")
                    == "Plan"
                ):
                    content = json.dumps(
                        {
                            "mode": "control",
                            "control": {
                                "machine": "CNC-01",
                                "action": "set_spindle_rpm",
                                "rpm": 7000,
                                "reason": "Schema validation only",
                            },
                            "queries": [],
                            "clarification": "",
                        }
                    )
                else:
                    content = json.dumps(
                        {
                            "answer": "Source-supported guidance",
                            "citations": [],
                            "suggestions": [],
                        }
                    )
                result = {
                    "choices": [
                        {"message": {"content": content}, "finish_reason": "stop"}
                    ]
                }
            self.send_response(200)
            self.end_headers()
            self.wfile.write(json.dumps(result).encode())

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        for key in ["CONVERSATION", "CODE", "SAFETY", "EMBEDDING"]:
            monkeypatch.setenv(
                key + "_BASE_URL", f"http://127.0.0.1:{server.server_port}/v1"
            )
        router = ModelRouter(replace(settings, model_mode="local"))
        assert (
            router.spec("report")["service"] == "conversation"
            and router.spec("planner")["service"] == "code"
            and router.spec("control")["service"] == "code"
        )
        assert router.judge("Safe factory monitoring")["safe"]
        assert "### Scoring Schema" in requests[-1]["messages"][-1]["content"]
        assert "guardian_config" not in json.dumps(requests[-1])
        answer = router.generate(
            "conversation", [{"role": "user", "content": "Hello factory"}], Answer
        )
        assert answer.answer
        assert requests[-1]["response_format"]["type"] == "json_schema"
        assert len(router.embed(["Spindle"])[0]) == 1024
        assert all(
            s["state"] == "reachable" for s in router.status(True)["services"].values()
        )
        assert router.status()["services"]["conversation"]["last_inference_success"]
        assert all(value == "passed" for value in router.smoke().values())
        schema_names = {
            r.get("response_format", {}).get("json_schema", {}).get("name")
            for r in requests
        }
        assert {"Answer", "Plan"}.issubset(schema_names)
        demo = ModelRouter(settings).smoke()
        assert all(value == "not evaluated (training mode)" for value in demo.values())
    finally:
        server.shutdown()
        server.server_close()
        thread.join()


def test_guardian_fail_closed_for_malformed_and_injection(system, monkeypatch):
    settings, *_ = system
    router = ModelRouter(replace(settings, model_mode="local"))
    for result in [
        "No, safe",
        "<think>no</think>",
        "<score>no</score><score>yes</score>",
    ]:
        monkeypatch.setattr(router, "generate", lambda *args, **kwargs: result)
        with pytest.raises(ModelUnavailable):
            router.judge("Test")

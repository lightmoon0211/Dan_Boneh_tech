from dataclasses import replace
from cnc_ai.web.app import create_app
from cnc_ai.contracts import Plan, Answer
from cnc_ai.models import ModelRouter

PASSWORD = "Test-account-pass-123"


def login(client, username="operator"):
    r = client.post("/api/login", json={"username": username, "password": PASSWORD})
    assert r.status_code == 200, r.json
    return {"X-CSRF-Token": r.json["csrf"]}


def test_auth_csrf_identity_and_end_to_end_approval(system):
    settings, db, *_ = system
    app = create_app(settings)
    client = app.test_client()
    assert client.get("/api/status").status_code == 401
    headers = login(client)
    assert client.post("/api/control/proposals", json={}).status_code == 403
    payload = {
        "machine": "CNC-01",
        "action": "set_spindle_rpm",
        "rpm": 7000.0,
        "reason": "Approved training check",
    }
    assert (
        client.post(
            "/api/control/proposals",
            json={**payload, "requested_by": "supervisor"},
            headers=headers,
        ).status_code
        == 400
    )
    result = client.post("/api/control/proposals", json=payload, headers=headers)
    assert result.status_code == 200, result.json
    key = result.json["id"]
    assert result.json["requester"] == "operator"
    assert (
        client.post(
            f"/api/control/proposals/{key}/decision",
            json={"decision": "approve", "comment": "Identity spoof attempt"},
            headers=headers,
        ).status_code
        == 403
    )
    supervisor = app.test_client()
    super_headers = login(supervisor, "supervisor")
    assert (
        supervisor.post(
            f"/api/control/proposals/{key}/decision",
            json={"decision": "approve", "comment": "Checked spindle and fixture"},
            headers=super_headers,
        ).status_code
        == 200
    )
    result = client.post(
        f"/api/control/proposals/{key}/execute",
        json={"confirmation": "EXECUTE APPROVED ACTION"},
        headers=headers,
    )
    assert result.status_code == 200 and result.json["confirmed_setpoint"] == 7000
    assert "Content-Security-Policy" in result.headers
    assert db.verify_audit()["valid"]


def test_conversation_isolation_history_and_demo_evidence(system):
    settings, *_ = system
    app = create_app(settings)
    client = app.test_client()
    headers = login(client)
    r = client.post(
        "/api/chat", json={"question": "Show CNC machines"}, headers=headers
    )
    assert r.status_code == 200 and r.json["mode"] == "demo"
    assert r.json["citations"] and r.json["evidence"]
    key = r.json["conversation_id"]
    other = app.test_client()
    other_headers = login(other, "viewer")
    assert other.get("/api/conversations/" + key).status_code == 403
    assert (
        other.post(
            "/api/chat",
            json={"question": "Continue", "conversation_id": key},
            headers=other_headers,
        ).status_code
        == 403
    )
    assert len(client.get("/api/conversations/" + key).json) == 2


def test_cross_origin_login_and_account_revocation(system):
    settings, db, *_ = system
    app = create_app(settings)
    client = app.test_client()
    assert (
        client.post(
            "/api/login",
            json={"username": "operator", "password": PASSWORD},
            headers={"Origin": "https://attacker.test"},
        ).status_code
        == 403
    )
    login(client)
    with db.connect(write=True) as c:
        c.execute("UPDATE users SET enabled=0 WHERE username='operator'")
    assert client.get("/api/status").status_code == 401


def test_model_planning_unknown_citations_and_no_implicit_execution(system):
    settings, db, auth, adapter, _ = system
    router = ModelRouter(replace(settings, model_mode="local"))
    router.status = lambda probe=False: {"mode": "local", "roles": {}, "services": {}}
    router.judge = lambda *args, **kwargs: {
        "safe": True,
        "mode": "guardian",
        "score": "no",
    }

    def generate(role, messages, schema=None, **kwargs):
        if schema is Plan:
            return Plan(
                mode="control",
                control={
                    "machine": "CNC-01",
                    "action": "set_spindle_rpm",
                    "rpm": 7000.0,
                    "reason": "Explicit training request",
                },
            )
        return Answer(answer="Draft guidance", citations=["invented"])

    router.generate = generate
    app = create_app(settings, router=router)
    client = app.test_client()
    headers = login(client)
    result = client.post(
        "/api/chat",
        json={"question": "Please prepare CNC-01 for 7000 RPM."},
        headers=headers,
    )
    assert result.json["proposal"]["status"] == "pending"
    assert adapter.snapshot("CNC-01").value("setpoint") == 6000
    with db.connect() as c:
        assert c.execute("SELECT count(*) FROM agent_plans").fetchone()[0] == 1
    router.generate = lambda role, messages, schema=None, **kwargs: (
        Plan(mode="conversation")
        if schema is Plan
        else Answer(answer="An unsupported claim", citations=["invented"])
    )
    result = client.post(
        "/api/chat", json={"question": "Explain a spindle bearing."}, headers=headers
    )
    assert result.json["mode"] == "blocked" and not result.json["citations"]


def test_output_guard_cannot_leave_a_control_proposal(system):
    settings, db, *_ = system
    router = ModelRouter(replace(settings, model_mode="local"))
    calls = []

    def judge(*args, **kwargs):
        calls.append(1)
        return {"safe": len(calls) < 3, "mode": "guardian", "score": "no"}

    router.judge = judge
    router.generate = lambda *a, **k: Plan(
        mode="control",
        control={
            "machine": "CNC-01",
            "action": "set_spindle_rpm",
            "rpm": 7000.0,
            "reason": "Spindle training request",
        },
    )
    client = create_app(settings, router=router).test_client()
    headers = login(client)
    result = client.post(
        "/api/chat",
        json={"question": "Propose CNC-01 spindle 7000 RPM"},
        headers=headers,
    )
    assert result.json["mode"] == "blocked"
    with db.connect() as c:
        assert c.execute("SELECT count(*) FROM control_proposals").fetchone()[0] == 0

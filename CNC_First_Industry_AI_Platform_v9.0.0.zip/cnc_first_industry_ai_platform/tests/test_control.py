import json
import time
from dataclasses import replace
from concurrent.futures import ThreadPoolExecutor
import pytest
from pydantic import ValidationError
from cnc_ai.contracts import ControlRequest, Approval
from cnc_ai.control.adapters import Sample, RealOPCUAAdapter
from cnc_ai.control.policy import Policy
from cnc_ai.control.service import ControlService
from cnc_ai.database import encode

REQUEST = {
    "machine": "CNC-01",
    "action": "set_spindle_rpm",
    "rpm": 7000.0,
    "reason": "Supervised integration check",
}


def change(db, **values):
    with db.connect(write=True) as c:
        state = json.loads(
            c.execute(
                "SELECT values_json FROM simulator_state WHERE machine='CNC-01'"
            ).fetchone()[0]
        )
        state.update(values)
        c.execute(
            "UPDATE simulator_state SET values_json=? WHERE machine='CNC-01'",
            (encode(state),),
        )


def proposed(system):
    _, _, auth, _, control = system
    proposal = control.create(ControlRequest(**REQUEST), auth.user("operator"))
    return proposal, control, auth


def approve(p, control, auth):
    return control.decide(
        p["id"],
        Approval(decision="approve", comment="Checked tool, setup and process limits."),
        auth.user("supervisor"),
    )


def test_ordered_proposal_approval_execution_survives_restart(system):
    settings, db, auth, adapter, control = system
    p, _, _ = proposed(system)
    assert [c["order"] for c in p["evaluation"]["checks"]] == list(range(1, 8))
    assert p["evaluation"]["checks"][5]["status"] == "approval_required"
    with pytest.raises(ValueError):
        control.execute(p["id"], auth.user("operator"))
    approve(p, control, auth)
    restarted = ControlService(settings, db, auth, adapter)
    result = restarted.execute(p["id"], auth.user("operator"))
    assert result["confirmed_setpoint"] == 7000 and result["mode"] == "simulator"
    assert (
        adapter.snapshot("CNC-01").value("actual_rpm") == 6000
    )  # measured speed is not invented
    assert restarted.get(p["id"])["status"] == "confirmed"
    with pytest.raises(ValueError):
        restarted.execute(p["id"], auth.user("operator"))
    assert db.verify_audit()["valid"]


@pytest.mark.parametrize(
    "values,order",
    [
        ({"state": "STOPPED"}, 1),
        ({"tool": "Unknown"}, 2),
        ({"material": "Aluminium"}, 3),
        ({"setpoint": 3000.0}, 4),
        ({"door_closed": False}, 7),
        ({"estop_ok": False}, 7),
        ({"write_permitted": False}, 7),
    ],
)
def test_ordered_fail_closed_checks(system, values, order):
    settings, db, auth, adapter, control = system
    change(db, **values)
    result = control.preflight(ControlRequest(**REQUEST), auth.user("operator"))
    assert not result["passed"]
    assert result["checks"][order - 1]["status"] == "blocked"
    assert all(c["status"] == "skipped" for c in result["checks"][order:])
    with pytest.raises(ValueError):
        control.create(ControlRequest(**REQUEST), auth.user("operator"))


@pytest.mark.parametrize("rpm", [float("nan"), float("inf"), True, -1, "7000"])
def test_invalid_setpoints_never_reach_controller(rpm):
    with pytest.raises(ValidationError):
        ControlRequest(**{**REQUEST, "rpm": rpm})


def test_raw_nodes_identity_motion_fields_rejected():
    for extra in [
        {"node_id": "ns=2;s=anything"},
        {"requested_by": "supervisor"},
        {"approval": True},
    ]:
        with pytest.raises(ValidationError):
            ControlRequest(**REQUEST, **extra)
    with pytest.raises(ValidationError):
        ControlRequest(**{**REQUEST, "action": "cycle_start"})


def test_self_approval_unauthorized_rejection_and_execution(system):
    _, _, auth, _, control = system
    p = control.create(ControlRequest(**REQUEST), auth.user("supervisor"))
    with pytest.raises(PermissionError):
        control.decide(
            p["id"],
            Approval(decision="approve", comment="Self approval"),
            auth.user("supervisor"),
        )
    with pytest.raises(PermissionError):
        control.decide(
            p["id"],
            Approval(decision="reject", comment="No permission"),
            auth.user("viewer"),
        )
    with pytest.raises(PermissionError):
        control.execute(p["id"], auth.user("operator"))
    with pytest.raises(PermissionError):
        control.preflight(ControlRequest(**REQUEST), auth.user("viewer"))


def test_expiry_and_changed_policy_or_binding(system):
    settings, db, auth, _, control = system
    p, _, _ = proposed(system)
    approve(p, control, auth)
    change(db, workpiece="unknown")
    with pytest.raises(ValueError):
        control.execute(p["id"], auth.user("operator"))
    change(db, workpiece="WP-4140-01")
    with db.connect(write=True) as c:
        c.execute(
            "UPDATE control_proposals SET expires_at=? WHERE id=?",
            (time.time() - 1, p["id"]),
        )
    with pytest.raises(ValueError):
        control.execute(p["id"], auth.user("operator"))
    assert control.get(p["id"])["status"] == "expired"


def test_stale_bad_and_missing_telemetry(system):
    settings, db, auth, adapter, _ = system
    snapshot = adapter.snapshot("CNC-01")
    samples = dict(snapshot.samples)
    samples["actual_rpm"] = Sample(6000.0, snapshot.captured_at - 10)
    result = Policy(settings).evaluate(
        ControlRequest(**REQUEST),
        auth.user("operator"),
        replace(snapshot, samples=samples),
    )
    assert result["checks"][6]["status"] == "blocked"
    samples["actual_rpm"] = Sample(6000.0, None, False)
    assert not replace(snapshot, samples=samples).healthy(5, 2)[0]


def test_unknown_write_outcome_locks_machine_and_reconciliation(system, monkeypatch):
    settings, db, auth, adapter, control = system
    p, _, _ = proposed(system)
    approve(p, control, auth)
    monkeypatch.setattr(adapter, "apply", lambda *args: 6500.0)
    with pytest.raises(RuntimeError, match="uncertain"):
        control.execute(p["id"], auth.user("operator"))
    assert control.get(p["id"])["status"] == "unknown"
    second = control.create(ControlRequest(**REQUEST), auth.user("operator"))
    approve(second, control, auth)
    with pytest.raises(ValueError, match="unresolved"):
        control.execute(second["id"], auth.user("operator"))
    with db.connect() as c:
        execution = c.execute("SELECT id FROM control_executions").fetchone()[0]
    control.reconcile(
        execution,
        "Controller inspected by controls engineer; previous setpoint confirmed unchanged.",
    )
    with db.connect() as c:
        assert c.execute("SELECT count(*) FROM machine_write_locks").fetchone()[0] == 0


def test_permission_revocation_and_disabled_approver(system):
    _, db, auth, _, control = system
    p, _, _ = proposed(system)
    approve(p, control, auth)
    with db.connect(write=True) as c:
        c.execute("UPDATE users SET enabled=0 WHERE username='supervisor'")
    with pytest.raises(PermissionError):
        control.execute(p["id"], auth.user("operator"))


def test_two_simultaneous_executions_attempt_once(system, monkeypatch):
    _, _, auth, adapter, control = system
    p, _, _ = proposed(system)
    approve(p, control, auth)
    original = adapter.apply
    calls = []

    def slow(*args):
        calls.append(1)
        time.sleep(0.1)
        return original(*args)

    monkeypatch.setattr(adapter, "apply", slow)

    def go():
        try:
            return control.execute(p["id"], auth.user("operator"))
        except (ValueError, RuntimeError):
            return None

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda _: go(), range(2)))
    assert len(calls) == 1 and sum(r is not None for r in results) == 1


def test_real_adapter_requires_site_security_configuration(system):
    settings, *_ = system
    real = RealOPCUAAdapter(replace(settings, opcua_mode="real"))
    with pytest.raises(PermissionError, match="commissioned"):
        real.snapshot("CNC-01")


def test_malformed_policy_boolean_and_range_fail_closed(system):
    from cnc_ai.control.policy import Policy
    from pydantic import ValidationError

    settings, _, _, _, _ = system
    path = settings.config / "policy.json"
    config = json.loads(path.read_text())
    config["machines"]["CNC-01"]["actions"]["set_spindle_rpm"]["approval_required"] = (
        "false"
    )
    path.write_text(json.dumps(config))
    with pytest.raises(ValidationError):
        Policy(settings)
    config["machines"]["CNC-01"]["actions"]["set_spindle_rpm"]["approval_required"] = (
        True
    )
    config["machines"]["CNC-01"]["minimum_rpm"] = 10000
    path.write_text(json.dumps(config))
    with pytest.raises(ValidationError):
        Policy(settings)

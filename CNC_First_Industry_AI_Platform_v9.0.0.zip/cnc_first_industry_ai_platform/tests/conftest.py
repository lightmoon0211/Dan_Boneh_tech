import shutil
import pytest
from cnc_ai.config import Settings, RESOURCE_DIR
from cnc_ai.database import Database
from cnc_ai.auth import Auth
from cnc_ai.control.adapters import SimulatorAdapter
from cnc_ai.control.service import ControlService


@pytest.fixture
def system(tmp_path):
    config = tmp_path / "config"
    config.mkdir()
    for p in RESOURCE_DIR.glob("*.json"):
        shutil.copyfile(p, config / p.name)
    settings = Settings(tmp_path, tmp_path / "runtime", config, model_mode="demo")
    db = Database(settings)
    db.initialize(sample=True)
    auth = Auth(db)
    for username, role in [
        ("operator", "operator"),
        ("supervisor", "supervisor"),
        ("admin", "admin"),
        ("viewer", "viewer"),
    ]:
        auth.create_user(username, "Test-account-pass-123", role, username.title())
    adapter = SimulatorAdapter(db)
    control = ControlService(settings, db, auth, adapter)
    return settings, db, auth, adapter, control

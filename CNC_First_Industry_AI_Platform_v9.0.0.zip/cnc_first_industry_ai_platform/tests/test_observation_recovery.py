from dataclasses import replace
from filelock import FileLock
import pytest
from cnc_ai.contracts import Plan, Answer
from cnc_ai.models import ModelRouter
from cnc_ai.web.app import create_app
from test_web_assistant import login


def test_live_controller_answer_has_timestamped_immutable_evidence(system):
    settings, db, _, adapter, _ = system
    router = ModelRouter(replace(settings, model_mode="local"))
    router.judge = lambda *args, **kwargs: {
        "safe": True,
        "mode": "guardian",
        "score": "no",
    }
    router.generate = lambda role, messages, schema=None, **kwargs: (
        Plan(mode="status")
        if schema is Plan
        else Answer(
            answer="The simulated CNC-01 was RUNNING at the captured observation time.",
            citations=["source_1"],
        )
    )
    client = create_app(settings, router=router, adapter=adapter).test_client()
    headers = login(client)
    response = client.post(
        "/api/chat", json={"question": "Is CNC-01 running now?"}, headers=headers
    )
    assert response.json["mode"] == "status" and response.json["citations"]
    e = response.json["evidence"][0]
    assert (
        e["kind"] == "telemetry"
        and "simulator" in e["content"]
        and "source_time" in e["content"]
    )
    with db.connect() as c:
        assert c.execute("SELECT count(*) FROM controller_snapshots").fetchone()[0] == 1
        assert c.execute("SELECT count(*) FROM control_executions").fetchone()[0] == 0


def test_reconciliation_cannot_overlap_live_write(system):
    settings, _, _, _, control = system
    with FileLock(str(settings.data / "controller-boundary.lock")):
        with pytest.raises(ValueError, match="still active"):
            control.reconcile(
                "not-an-execution", "Inspected the controller and checked the setpoint."
            )


def test_https_proxy_login_and_forwarded_origin(system):
    settings, *_ = system
    client = create_app(
        replace(settings, cookie_secure=True, trust_proxy=True)
    ).test_client()
    headers = {
        "Origin": "https://cnc.factory.internal",
        "X-Forwarded-Proto": "https",
        "X-Forwarded-Host": "cnc.factory.internal",
    }
    response = client.post(
        "/api/login",
        json={"username": "operator", "password": "Test-account-pass-123"},
        headers=headers,
    )
    assert response.status_code == 200 and "Secure;" in response.headers["Set-Cookie"]


def test_report_source_evidence_then_deletion(system, tmp_path):
    from cnc_ai.rag import RAG
    from cnc_ai.reports import Reports

    settings, db, auth, *_ = system
    router = ModelRouter(settings)
    rag = RAG(db, router)
    reports = Reports(db, router)
    path = tmp_path / "shift.txt"
    path.write_text(
        "Fictional shift: CNC spindle training completed. Two trial parts were inspected."
    )
    supervisor = auth.user("supervisor")
    document = rag.ingest(path, supervisor, kind="report")
    report = reports.summarize(document["id"], supervisor, "2026-09-01")
    assert reports.evidence(report["id"])["evidence"][0]["locator"]
    with pytest.raises(ValueError, match="linked report"):
        rag.delete(document["id"], supervisor)
    reports.delete(report["id"], supervisor)
    rag.delete(document["id"], supervisor)
    assert not rag.list()


def test_packaged_and_editable_configs_match():
    from pathlib import Path
    from cnc_ai.config import RESOURCE_DIR

    root = Path(__file__).resolve().parents[1]
    for path in (root / "config").glob("*.json"):
        assert path.read_bytes() == (RESOURCE_DIR / path.name).read_bytes(), path.name

import os
from pathlib import Path
import subprocess
import sys
from cnc_ai.cli import main
from cnc_ai.database import Database
from cnc_ai.config import Settings, RESOURCE_DIR
from cnc_ai.catalog import Catalog


def test_cli_accounts_migrations_monitor_and_validation(
    system, monkeypatch, tmp_path, capsys
):
    settings, db, auth, *_ = system
    monkeypatch.setenv("CNC_MODEL_MODE", "demo")
    monkeypatch.setenv("CNC_OPCUA_MODE", "simulator")
    monkeypatch.setenv("CNC_TEST_ACCOUNT_PASSWORD", "Another-test-pass-123")

    def cli(*args):
        return main(["--home", str(settings.home), *args])

    assert (
        cli(
            "user",
            "add",
            "test_admin",
            "--role",
            "admin",
            "--password-env",
            "CNC_TEST_ACCOUNT_PASSWORD",
        )
        == 0
    )
    assert "settings.manage" in auth.user("test_admin").permissions
    assert (
        cli(
            "user",
            "reset-password",
            "test_admin",
            "--password-env",
            "CNC_TEST_ACCOUNT_PASSWORD",
        )
        == 0
    )
    assert cli("db", "migrate") == 0
    assert cli("db", "refresh-policy") == 0
    assert cli("monitor", "--count", "1") == 0
    assert cli("validate", "--offline") == 0
    assert cli("validate", "--offline", "--models") == 1
    assert cli("validate", "--opcua") == 0
    assert cli("audit-verify") == 0
    assert cli("db", "backup", str(tmp_path / "backup.db")) == 0
    assert cli("user", "disable", "test_admin") == 0
    with db.connect() as c:
        assert c.execute("SELECT count(*) FROM controller_snapshots").fetchone()[0] == 1


def test_empty_factory_and_import_of_legacy_database(tmp_path, monkeypatch):
    monkeypatch.setenv("CNC_MODEL_MODE", "demo")
    monkeypatch.setenv("CNC_OPCUA_MODE", "simulator")
    empty = tmp_path / "empty"
    empty.mkdir()
    settings = Settings.load(empty)
    db = Database(settings)
    db.initialize(sample=False)
    assert db.stats()["machines"] == 0
    db.initialize(sample=True)
    assert db.stats()["machines"] == 0
    legacy = tmp_path / "legacy"
    legacy.mkdir()
    root = Path(__file__).resolve().parents[1]
    result = subprocess.run(
        [
            sys.executable,
            str(root / "scripts/database/import_v8.py"),
            str(RESOURCE_DIR / "cnc_sample_base.db"),
            "--home",
            str(legacy),
        ],
        capture_output=True,
        text=True,
        env=dict(os.environ),
        timeout=30,
    )
    assert result.returncode == 0, result.stderr
    migrated = Database(Settings.load(legacy))
    assert migrated.stats()["machines"] == 19
    with migrated.connect() as c:
        assert not c.execute("PRAGMA foreign_key_check").fetchall()


def test_sector_schema_builder_and_reviewed_queries(system):
    from cnc_ai.sql import QueryService
    from cnc_ai.contracts import Query

    settings, db, auth, *_ = system
    catalog = Catalog(db)
    admin = auth.user("admin")
    definition = {
        "tables": [
            {
                "name": "robots",
                "columns": [
                    {
                        "name": "id",
                        "type": "integer",
                        "primary_key": True,
                        "autoincrement": True,
                    },
                    {"name": "name", "type": "text", "not_null": True},
                ],
            },
            {
                "name": "jobs",
                "columns": [
                    {"name": "id", "type": "integer", "primary_key": True},
                    {"name": "robot_id", "type": "integer"},
                ],
                "foreign_keys": [
                    {
                        "column": "robot_id",
                        "references_table": "robots",
                        "references_column": "id",
                    }
                ],
            },
        ]
    }
    created = catalog.create_schema(definition, "Robot cells", "manufacturing", admin)
    assert not created["approved"]
    assert catalog.raw_schema(created["id"]) == {
        "robots": ["id", "name"],
        "jobs": ["id", "robot_id"],
    }
    catalog.approve(created["id"], created["schema"], admin)
    result = QueryService(db).run(
        Query(label="Robot registry", sql="SELECT name FROM robots"),
        auth.user("viewer"),
        created["id"],
    )
    assert result["rows"] == [] and result["sha256"]

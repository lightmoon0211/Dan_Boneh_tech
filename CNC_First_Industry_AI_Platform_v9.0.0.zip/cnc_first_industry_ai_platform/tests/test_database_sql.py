import json
import sqlite3
import subprocess
import sys
import pytest
from cnc_ai.sql import QueryService
from cnc_ai.contracts import Query
from cnc_ai.catalog import Catalog


def test_full_database_and_idempotent_migrations(system):
    settings, db, auth, _, _ = system
    original = db.stats()
    db.initialize(sample=True)
    assert db.stats() == original
    assert (
        original["machines"] == 20
        and original["work_orders"] == 100
        and original["sensor_readings"] == 27360
    )
    with db.connect() as c:
        assert c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert not c.execute("PRAGMA foreign_key_check").fetchall()
        tables = {
            r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")
        }
        assert {
            "tool_limits",
            "workpieces",
            "users",
            "roles",
            "permissions",
            "approvals",
            "control_proposals",
            "control_executions",
            "documents",
            "evidence_records",
            "reports",
            "agent_plans",
            "audit_events",
        } <= tables
    backup = settings.home / "backup.db"
    db.backup(backup)
    assert (
        sqlite3.connect(backup).execute("SELECT count(*) FROM machines").fetchone()[0]
        == 20
    )
    assert db.verify_audit()["valid"]


def test_sql_parameterization_cte_limits_and_provenance(system):
    _, db, auth, _, _ = system
    service = QueryService(db)
    user = auth.user("operator")
    result = service.run(
        Query(
            label="Machine",
            sql="SELECT machine_code FROM machines WHERE machine_code=:machine",
            parameters={"machine": "CNC-01"},
        ),
        user,
    )
    assert result["rows"] == [{"machine_code": "CNC-01"}]
    quoted = service.run(
        Query(label="Quoted", sql="SELECT 'DROP; TABLE' AS harmless"), user
    )
    assert quoted["rows"][0]["harmless"] == "DROP; TABLE"
    cte = service.run(
        Query(
            label="CTE",
            sql="WITH selected AS (SELECT machine_code FROM machines) SELECT count(*) AS count FROM selected",
        ),
        user,
    )
    assert cte["rows"][0]["count"] == 20
    limited = service.run(
        Query(label="Telemetry", sql="SELECT recorded_at,value FROM sensor_readings"),
        user,
    )
    assert limited["truncated"] and len(limited["rows"]) == 100
    assert limited["sha256"] and limited["captured_at"]
    assert db.verify_audit()["valid"]


@pytest.mark.parametrize(
    "sql",
    [
        "SELECT * FROM machines; DELETE FROM machines;",
        "DELETE FROM machines",
        "PRAGMA table_info(machines)",
        "SELECT password_hash FROM users",
        "SELECT * FROM users",
        "SELECT full_name FROM employees",
        "SELECT name FROM sqlite_master",
        "SELECT load_extension('evil')",
        "SELECT randomblob(100000000)",
        "WITH RECURSIVE x(n) AS (SELECT 1 UNION ALL SELECT n+1 FROM x) SELECT * FROM x",
        "ATTACH DATABASE ':memory:' AS other",
        "SELECT unknown_column FROM machines",
    ],
)
def test_sql_forbidden_paths(system, sql):
    _, db, auth, _, _ = system
    with pytest.raises(ValueError):
        QueryService(db).run(Query(label="Blocked", sql=sql), auth.user("operator"))
    with db.connect() as c:
        assert (
            c.execute(
                "SELECT count(*) FROM audit_events WHERE event='sql.blocked'"
            ).fetchone()[0]
            == 1
        )


def test_column_allowlist_and_permissions(system):
    _, db, auth, _, _ = system
    with db.connect(write=True) as c:
        policy = {
            "tables": {"machines": ["machine_code"]},
            "max_rows": 10,
            "timeout_seconds": 1,
        }
        c.execute(
            "UPDATE data_sources SET policy_json=? WHERE id='factory'",
            (json.dumps(policy),),
        )
    service = QueryService(db)
    with pytest.raises(ValueError):
        service.run(
            Query(label="Bad column", sql="SELECT max_rpm FROM machines"),
            auth.user("operator"),
        )
    assert service.run(
        Query(label="Allowed", sql="SELECT machine_code FROM machines"),
        auth.user("operator"),
    )["rows"]
    from cnc_ai.auth import Principal

    with pytest.raises(PermissionError):
        service.run(
            Query(label="Denied", sql="SELECT 1"),
            Principal("nobody", "nobody", frozenset()),
        )


def test_foreign_sector_database_cannot_replace_control_authority(system, tmp_path):
    _, db, auth, _, control = system
    catalog = Catalog(db)
    admin = auth.user("admin")
    source = tmp_path / "metal.db"
    with sqlite3.connect(source) as c:
        c.execute("CREATE TABLE presses(id INTEGER PRIMARY KEY,name TEXT,secret TEXT)")
        c.execute("INSERT INTO presses VALUES(1,'Press A','hidden')")
    item = catalog.import_database(source, "Metal shop", "manufacturing", admin)
    with pytest.raises(ValueError):
        db.source(item["id"])
    catalog.approve(item["id"], {"presses": ["id", "name"]}, admin)
    result = QueryService(db).run(
        Query(label="Presses", sql="SELECT name FROM presses"),
        auth.user("operator"),
        item["id"],
    )
    assert result["rows"] == [{"name": "Press A"}]
    with pytest.raises(ValueError):
        QueryService(db).run(
            Query(label="Hidden", sql="SELECT secret FROM presses"),
            auth.user("operator"),
            item["id"],
        )
    assert control.adapter.snapshot("CNC-01").value("tool") == "T07"


def test_package_cli_outside_root(system, tmp_path):
    settings, *_ = system
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "cnc_ai",
            "--home",
            str(settings.home),
            "validate",
            "--offline",
        ],
        cwd=tmp_path.parent,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr


def test_negative_row_configuration_cannot_disable_cap(system):
    settings, db, auth, *_ = system
    from cnc_ai.database import encode

    policy = settings.read("query_policy.json")
    policy["max_rows"] = -10
    with db.connect(write=True) as c:
        c.execute(
            "UPDATE data_sources SET policy_json=? WHERE id='factory'",
            (encode(policy),),
        )
    result = QueryService(db).run(
        Query(label="Capped inventory", sql="SELECT machine_code FROM machines"),
        auth.user("operator"),
    )
    assert len(result["rows"]) == 1 and result["truncated"]

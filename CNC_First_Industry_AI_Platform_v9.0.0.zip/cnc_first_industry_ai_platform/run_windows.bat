@echo off
powershell.exe -NoProfile -File "%~dp0scripts\windows\start.ps1"
exit /b %errorlevel%

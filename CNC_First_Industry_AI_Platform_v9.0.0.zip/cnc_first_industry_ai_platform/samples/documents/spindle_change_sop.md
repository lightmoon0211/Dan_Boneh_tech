# Spindle-speed proposal procedure — fictional training cell

Document: SOP-CNC-TRAIN-009. Revision: training-v9. Scope: internal simulator and loopback OPC UA test server only. This is not an OEM-approved operating procedure.

Before proposing a spindle speed for CNC-01, inspect the current machine state and the identified tool, material and workpiece. The training scenario uses a 6000-RPM starting setpoint, T07 tool assembly, AISI-4140 stock and workpiece WP-4140-01.

The fictional T07 assembly rating is 8000 RPM. The training recipe range is 800 to 7500 RPM; the simulated machine range is 500 to 9000 RPM. The maximum step is 1500 RPM. A proposed 7000-RPM setpoint is within those training limits. None of these numbers establishes a real cutting condition.

Sign in as a named operator, run the seven policy checks and create a proposal with a reason. A different supervisor reviews the policy result and current context, then records a decision. Approval alone does not write. The requester confirms execution in the machine panel; the application rechecks live conditions before its typed write.

Required telemetry includes state, selected tool, material, workpiece, actual RPM, setpoint, door closed, E-stop healthy, write permitted and feed hold. Every value must have good quality and an acceptable source timestamp. Do not replace missing signals with guessed values.

After execution, setpoint readback confirms the accepted request only. Observe actual spindle response separately. If a write outcome is uncertain, do not retry it. Inspect the controller and use the documented engineering reconciliation workflow. Use the native machine controls for emergency response.

# CNCBench

```bash
python -m cnc_ai cncbench --output runtime/cncbench
python -m cnc_ai cncbench --models --output runtime/cncbench-models
python -m cnc_ai cncbench --models --neural-forecast --output runtime/cncbench-neural
```

Default execution uses fictional seeded CNC data and curated functional cases. It validates approved SQL and prohibited statements; compares lexical retrieval against known source documents; measures synthetic anomaly precision, recall, F1, AUROC and false-alarm rate; and evaluates rolling forecasts with MAE/RMSE/MASE, horizon errors and interval coverage. The original training labels never enter model input. The same forecast origins/horizons are used across naive, drift, seasonal, Holt and adaptive methods.

--models requires actual private conversation/code/Guardian/embedding/reranker services. It adds strict planner routing and risk-judge fixtures, conversation keyword smoke checks and same-corpus neural reranking. No control proposal is executed by this model benchmark. --neural-forecast adds the configured local Chronos adapter. Unavailable/omitted models are recorded as not run or failed, never assigned invented benchmark scores.

Saved results are in docs/validation/cncbench. Their synthetic anomaly performance is not factory accuracy. Five simple retrieval documents can saturate nDCG without establishing real-corpus quality. Keyword coverage is not expert CNC correctness. Production acceptance needs held-out manuals, multilingual terminology, tool/program/material regimes, shift transitions, sensor faults, prompt injection, missing evidence and both host-failure scenarios.

Component RUL is not evaluated without site-specific run-to-failure labels and an approved model. Split by independent component/unit/time regime, not adjacent windows. Record commits, dependency locks, policy/corpus hashes, latency, hardware and reviewer decisions. SQL/control/injection/security behavior also has dedicated tests outside CNCBench.

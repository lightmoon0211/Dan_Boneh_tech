# Smart CNC Factory user and deployment manual
User and deployment manual · Version 11.2.0
For CNC operators, production teams, engineers and system administrators.
## 1. What the assistant does

### 1.1. Start with a factory question

You can ask a question such as “Why did CNC-03 produce fewer good parts?” The assistant checks the information it is allowed to read, presents the records that support its answer, and explains what those records do and do not show.

It can also help summarize reports, search approved manuals, analyze production data, draft code, compare planning options, and prepare supported machine-action requests. These are different types of work. An explanation is not a machine command, and a recommended action is not an approved action.

| What you need | What the assistant can help you do | What still needs separate review |
|---|---|---|
| Understand production | Read permitted records and explain quantities, delays, downtime, and quality results. | Check the selected dates, units, source records, and assumptions. |
| Investigate a problem | Compare relevant history, check possible explanations, and show supporting or conflicting evidence. | Confirm engineering causes using the factory's approved criteria. |
| Understand a document | Find relevant passages and summarize them with source references. | Check that the document is current, approved, and applicable. |
| Plan work | Calculate capacity and compare proposed assignments under stated constraints. | A planner decides whether to release a schedule through the factory's normal system. |
| Prepare engineering work | Draft SQL, Python, or machining code; retain reviewed engineering artifacts. | Validate code and complete the required engineering and simulation reviews. |
| Request a machine change | Prepare an allowed action and check it against configured rules. | A separate authorized supervisor reviews it; the requester separately confirms execution. |

### 1.2. Understand the main sentence

Factory questions are questions about work orders, parts, machines, materials, maintenance, quality, or assembly.

Cited evidence means the answer identifies the records or document passages it used. A citation lets you inspect the source instead of accepting an unsupported statement.

Machine-action recommendations are suggested changes, such as a request to change a permitted spindle-speed setpoint. In some screens, the software calls the saved request a proposal. Here, “proposal” means “a recommended action prepared for review.”

Human-supervised means the software does not make that change simply because the AI suggested it. The required people and automated checks must complete their separate steps. Human approval does not override a failed safety check.

Keep these three steps separate: recommend the action; approve the request; confirm execution. None of these steps automatically means the next one has happened.

### 1.3. Cover both parts and complete CNC machines

In this factory context, a CNC machine can mean two different things. It may be equipment that machines a component, or it may be the finished machine tool that the factory is assembling. State which one you are asking about.

For example, “CNC-03” may identify a production machine. “MX-500” in the training cases identifies a complete-machine assembly case. Do not treat a component-machining record as proof that final assembly, controller configuration, calibration, or acceptance testing is complete.

The RCA workflow can investigate machining, complete-machine assembly, acceptance results, and work-order capacity risk when the required history has been mapped and qualified. Qualification means that the factory has checked what the records mean and whether they are suitable for the requested comparison.

### 1.4. Know the boundaries

The assistant does not replace native CNC or PLC protections. A PLC is the controller that performs configured machine-control and interlock logic. Generated text cannot grant access, change arbitrary controller values, or run arbitrary Python, shell, NC, or robot programs.

The platform can use private model servers and be prepared for operation without external internet. A private model server is a computer inside the approved network that runs an AI model. Offline operation still requires local network connections, installed software, complete model files, and approved configuration. Chapter 13 explains this distinction.

Version 11.1.0 adds RCA without requiring another AI model or GPU. It does not add live RCA connectors to ERPNext, a live MES, Siemens NX, Opcenter, or Simio. A proposed future integration is not an installed feature.

## 2. Sign in and use the conversation workspace

### 2.1. First use on an installed system

Step 1. Open the application. Use the factory's trusted HTTPS address. A local test installation normally uses http://127.0.0.1:5000. That address means “this computer,” not another computer on the factory network.

Step 2. Sign in with your own account. Do not borrow a supervisor account. The permissions are attached to the authenticated account, not to the name typed in a chat message.

Step 3. Check the operating mode. Look at the mode label before treating a value as a real machine reading. The table below explains the labels.

Step 4. Select the response language and detail level. The available language names are English, French, German, Chinese (Simplified), Chinese (Traditional), Japanese, and Korean. Administrative help and technical settings remain in English.

Step 5. Select the correct evidence source. Confirm the analytical database. For RCA, also choose either Factory history or Synthetic training cases. Training evidence must not be used to make a real factory decision.

Step 6. Ask a specific question. Include the machine or work order and the date or shift. Read the answer together with its source cards.

### 2.2. What the mode labels mean

| Label shown by the application | Meaning in plain language |
|---|---|
| Training mode | The application uses sample responses. It is not evaluating your question with a language model or Guardian. |
| Local inference | The application sends approved requests to the configured private AI-model services. Check each service separately. |
| Internal simulator | Machine state exists in the application's database. No external controller is involved. |
| Local OPC UA test server | A local software server tests the OPC UA communication protocol. It is not a physical CNC machine. |
| Real controller | The application uses a configured, authenticated, encrypted controller connection. Writes still require every applicable gate. |
| Reachable/model advertised | The server reports that a model is available. This does not prove it can complete an inference request. |
| Last successful inference | The most recent successful model request in the current application process. It does not guarantee future requests will succeed. |

A port is a numbered service address on a computer. A port accepting connections does not prove that the correct model is loaded or working. Verify model inference performs actual test requests.

### 2.3. Who can do what

| Account role | Main responsibilities and permissions |
|---|---|
| Viewer | Ask questions, read approved data and documents, and inspect permitted machine observations. |
| Operator | Use viewer functions and prepare or execute their own eligible machine-action requests. |
| Supervisor | Use operator functions, approve or reject another person's eligible request, and manage documents and reports. |
| Administrator | Manage accounts, data, schemas, sectors, interface settings, documents, reports, and audit review. This role does not automatically grant machine control or machine-action approval. |

RCA permissions are additional. Standard roles receive rca.read and rca.run. Operators, supervisors, and administrators also receive rca.evidence.add. Supervisors and administrators receive rca.review. Existing data, document, ownership, and reviewer restrictions still apply. Review custom roles during an upgrade.

The supplied session lifetime is eight hours. Disabling an account or resetting its password invalidates its sessions. Passwords are not displayed or stored as plain text.

### 2.4. Send messages and continue a conversation

Press Enter to send. Use Shift+Enter for a new line. Input-method composition for languages such as Chinese or Japanese does not send a partially composed message. Copy response copies the displayed answer text.

Use New conversation when changing the topic. Changing the analytical source also starts a new conversation so evidence from different databases is not silently mixed. Recent conversations belong to the signed-in account.

A useful follow-up is “Which records support that conclusion?” Another is “What is still missing before this cause can be confirmed?” A follow-up does not give the assistant access to data it could not previously read.

### 2.5. Understand cancellation and the queue

Cancel response requests server-side cancellation of the queued or running job. A queued job stops before execution; a running request stops at its next checkpoint after any bounded in-flight read. The browser shows queued, running, completed, failed or cancelled. My jobs lets you reopen your own retained results. The queue admits three pending jobs per user and runs one per user at a time. It has a total capacity of 100, six routine workers, one long-request worker and two RCA workers. These are starting limits, not fifty simultaneous investigations.

Cancellation is not a machine stop. It does not execute or cancel a machine-action request. RCA has a separate Cancel investigation control, explained in Chapter 6.

## 3. Ask clear questions and check the evidence

### 3.1. Give the assistant enough information

A useful question says what you want to understand, which object you mean, and when it happened. State the units and decision needed when they matter.

| Instead of asking | Ask something more specific |
|---|---|
| “Why is production bad?” | “Why did CNC-03 produce fewer good parts on 2026-09-08 than in the preceding operating shift?” |
| “Is the order late?” | “For WO-300, compare the remaining work with the available time before its due date. Show the assumptions.” |
| “Do we have enough material?” | “Compare available AISI-4140 stock, after reservations, with the quantity required by the selected work orders.” |
| “What happened to the machine?” | “Show CNC-02's recorded stops and material-issue events for the selected shift.” |
| “Is this machine finished?” | “For the complete-machine build, show assembly progress, outstanding acceptance tests, and the latest recorded status.” |

These are example questions, not guarantees that every deployment contains the required data. The base training database covers late August and September 2026. A question about a different date may correctly return no matching records.

### 3.2. Keep present readings separate from historical records

“Is CNC-01 running now?” can use the supported live-status workflow. Its evidence should identify the adapter, measurement time, and signal quality. Refresh machine requests another observation.

“Was CNC-01 running yesterday?” needs recorded history. A current OPC UA reading cannot answer that historical question. Once captured, even a live reading is a record of what was observed at that time; it is not a promise that the machine is unchanged.

When the assistant asks for a tool, material, date, shift, or machine identity, provide the missing fact. It cannot inspect controller details that are absent from the approved mapping.

### 3.3. Open the source cards

Step 1. Read the main finding. Notice whether it describes an observation, an estimate, a possible cause, or a confirmed cause.

Step 2. Open the cited evidence. A document card includes the filename, revision, location, capture time, excerpt, and content hash. A database card includes the returned row snapshot and a separate view of the query and its parameters.

Step 3. Check the date and identity. Verify that the records concern the right machine, product, operation, and time window.

Step 4. Check the calculation. Inspect quantities, units, exclusions, and assumptions. A correct source can still be interpreted incorrectly.

Step 5. Read the limitations. Missing evidence, poor-quality data, or a result limit must remain visible in the conclusion.

A snapshot is the copy of the evidence retained with the answer. Later source changes do not silently replace that earlier copy. A hash is a digital fingerprint used to check whether the retained content changed. It does not prove that the original source was truthful.

### 3.4. Do not mistake a partial result for the whole factory

The default generated-SQL output limit is 100 rows. “Truncated” means the configured limit was reached. The visible rows may not be all matching records. Ask for a narrower period or an aggregate count, such as “How many work orders match these conditions?”

A general explanation, such as symptoms of spindle-bearing failure, is different from a finding that your machine has that fault. General mechanisms can come from an approved manual. A finding about a particular incident needs that incident's records.

### 3.5. A readable answer should separate four things

Finding: what the checked records show.

Evidence: the source records or passages that support the finding.

Uncertainty: what is missing, contradictory, estimated, or not yet verified.

Recommended next step: what an authorized person should review or do through an approved workflow. A recommendation does not itself perform the action.

This is a reading aid, not a promise that every screen uses those exact four headings. Preserve the application's actual labels when following a procedure.

## 4. Upload documents and produce source-linked reports

### 4.1. How document search works

The application extracts readable text from uploaded documents. It can search for matching words and, when the embedding service is available, search for related meaning. An embedding is a numerical representation used to find relevant text. A reranker then helps place more relevant passages ahead of less relevant ones.

This process is often called retrieval-augmented generation, or RAG. In plain language: find relevant source passages first, then use them to help answer the question.

### 4.2. Upload and approve a document

Step 1. Open Documents & reports. Sign in as an administrator or supervisor.

Step 2. Choose one supported file. Check that it is readable and within the size limits.

Step 3. Select the category and sector. Categories include manuals, standard operating procedures, maintenance documents, machine/tool/material specifications, and production reports.

Step 4. Record the revision and upload. Inspect the extracted text and embedding status. An embedding-service outage can leave word-based search available; rebuild embeddings later.

Step 5. Arrange independent approval. A different supervisor uses Approve revision after reviewing the document. The uploader cannot approve their own source.

Step 6. Check which revision is active. In factory mode, retrieval uses approved current sources and excludes drafts and superseded revisions.

Keep the filename stable for revisions in the same category and sector. A new approval supersedes the old revision in that family. Identical content in the same category and sector is detected by hash and is not inserted again merely because it has a new label. A genuinely changed revision must contain the revised source.

Development mode can retrieve a draft when no approved revision exists, with its status shown. Wording inside a document does not grant approval and cannot become machine-control policy by itself.

### 4.3. Prepare each file type correctly

| File type | What the application retains | What to prepare or check |
|---|---|---|
| PDF | Extracted text with page locations. | Use a readable text PDF. Perform OCR on scans offline before upload. Decrypt protected files locally first. |
| Word .docx | Paragraph and table locations. | Convert legacy .doc files locally. Do not assume embedded drawings have become measured engineering data. |
| Excel .xlsx or .xls | Sheet and row locations. | Recalculate and save before upload so cached formula results exist. Macros and embedded code are not executed. |
| CSV | Row locations. | Check headings, units, encoding, and the meaning of each row. |
| Text or Markdown | Line ranges. | Check that the text is readable and complete. |

The limits are 50 MiB per document, 2 million extracted characters, and 100,000 spreadsheet rows. MiB is a file-size unit; 50 MiB is 52,428,800 bytes. Split files that exceed the applicable limit and keep meaningful names and revision information.

### 4.4. Summarize a report and inspect its sources

Choose Summarize as report. The application uses the conversation model to summarize batches of source text and retains citations. A long report may produce several sections.

Use Show cited excerpts to read the passages behind the summary. Compare claims about actual production with the production records when the decision requires that comparison. A written report is not automatically the same as a verified machine record.

Delete a summary before deleting its source document. Deleting the document removes it from future retrieval, but earlier answers retain their evidence snapshots.

## 5. Start a root-cause investigation

### 5.1. What RCA means in this release

Root Cause Analysis (RCA) means investigating why a problem happened. The assistant checks recorded conditions, compares possible explanations, and shows the evidence behind its findings. It does not declare a cause merely because two values changed at the same time.

Version 11.1.0 adds saved investigations, visible check records, evidence snapshots, calculations, possible-cause relationships, review notes, and revisions. Operational changes still use separate authorized workflows. An RCA result cannot directly change a machine or release a schedule.

### 5.2. Start with a clear scope

Scope means the exact question being investigated: which machine, complete-machine build, or work order; which date and shift; and what it is compared with.

Step 1. Choose Factory history. Use only the configured, authorized historical source for a real investigation.

Step 2. Ask the question normally. No special command prefix is needed. Include an identifier and a completed shift date when investigating shift production.

Step 3. Open Interpreted scope. Confirm the entity type, date, shift, timezone, comparison basis, and UTC time bounds. UTC is the common time reference used to make timestamps unambiguous.

Step 4. Answer clarification questions. The same identifier may refer to more than one object. An incomplete date or ambiguous shift needs clarification, not guessing.

Step 5. Read the investigation as checks finish. Chapter 6 explains the result, evidence, and review states.

Example requests include “Why did scrap increase on CNC-07 on 2026-09-08?” and “Why is MX-500 assembly behind schedule on 2026-09-08?” These examples require the corresponding recorded history.

### 5.3. Understand the comparison

| Wording in the question | Comparison normally used |
|---|---|
| Production “decreased” | The preceding operating shift, not automatically the previous calendar day. |
| Production was “below plan” | Recorded planned good output for the selected period. |
| Compare with “last week” | The corresponding operating shift in the previous week. |
| Machine was idle | Recorded stop intervals for the selected scope. |
| Acceptance failed | Recorded test measurements and their applicable limits. |
| Assembly is behind schedule | Recorded assembly progress and the relevant plan. |
| Work order may miss its due date | Remaining work and recorded planning capacity; the result is an estimate of risk. |

Before comparing production, the executor checks the part, operation, revision, product mix, scheduled time, and cycle-time basis. Normalization means adjusting the comparison so unlike work is not treated as identical work. Fewer parts may be expected if the later shift makes a more time-consuming product.

Good pieces and scrap must be separate quantities from the final production operation. Counting the same part after several operations can overstate output. A prior-week comparison for assembly, acceptance, or due-date topics currently needs a separately qualified mapping; it is not automatically equivalent to a production-shift comparison.

If the required history is missing or its meaning has not been qualified, the investigation reports that limitation. It does not substitute current controller readings for yesterday's history. A due-date forecast is not an observed late delivery and is not a Simio or APS simulation run.

### 5.4. Try the isolated training case

Use a separate development runtime with no real-controller settings. A runtime is the folder and database holding one installation's changing data. Do not add training history to the operational database.

Set the following values in that runtime's .env:

```text
CNC_PROFILE=development
```

```text
CNC_MODEL_MODE=demo
```

```text
CNC_OPCUA_MODE=simulator
```

```text
CNC_RCA_DEMO=true
```

With an administrator account named admin already created, run from the project directory:

```text
python -m cnc_ai rca demo --user admin
```

```text
python -m cnc_ai serve
```

The rca demo command creates rca-demo.db beside the runtime database. It refuses to overwrite an existing file. At sign-in, choose Synthetic training cases in the RCA evidence selector. The Investigations page also has an example button.

Ask exactly:

Why did CNC-03 production decrease on 2026-09-08?

Use the explicit date. “Yesterday” follows the current factory calendar and may no longer refer to the fixed training data. The fictional shift is 07:00–15:00 in America/Chicago. Training investigations display a synthetic-data badge. The expected answers are stored separately in samples/rca/cases.json; the investigation reads history records, not those expected answers.

### 5.5. Other training cases

| Identifier | Example problem | What the case teaches |
|---|---|---|
| CNC-03 | Lower production | A verified cooling contribution and a reconciled 70-piece good-output shortfall. |
| CNC-02 | Three-hour idle interval | Material-shortage evidence connected to issue and restart records. |
| CNC-07 | Increased scrap | A program revision linked to rollback and retest records. |
| MX-500 | Complete-machine assembly delay | A purchased component blocks assembly, but verification is incomplete. |
| MX-700 | Acceptance failure | A measurement is outside its limit; a calibration retest is missing. |
| CNC-04 | Lower production | More than one supported contributor. |
| CNC-05 | Lower production | Temperature correlation without enough evidence to confirm causation. |
| CNC-06 | Lower production | Conflicting cooling records prevent confirmation. |
| CNC-08 | Apparently lower production | Cycle-time and product-mix checks remove the apparent problem. |
| WO-300 | Due-date risk | An estimated capacity shortage, not a live scheduling-engine result. |

## 6. Read, review, and update an investigation

### 6.1. Read the three levels of detail

Summary shows the main finding, workflow status, investigation ID, revision, data cutoff, and separate human-review state. The cutoff identifies when evidence collection for that revision was bounded. Completed means the allowed workflow finished; it does not mean every cause is known.

Investigation shows checks actually recorded by the backend executor, which is the software component that runs the approved steps. Expand a check to see its purpose, tool, inputs, actual start and finish times, finding, evidence references, and effect on the investigation.

Evidence opens authorized source snapshots and document excerpts. It shows where information came from, its revision, event and retrieval times, quality, and content hash. If a source later changes or becomes unavailable, that is flagged while the retained snapshot remains intact.

The investigation display is a record of checks, findings, and supporting evidence. It is not a display of private model reasoning or hidden system prompts. An approved manual can explain a failure mechanism; it cannot prove that the incident occurred on this machine.

![Synthetic RCA summary retained from the supplied manual; it is not a factory diagnosis.](screenshots/manual_causal_map.png)


### 6.2. Do not confuse a check status with a cause status

| Status of an investigation check | What happened |
|---|---|
| Planned | The check has not started. |
| Running | Execution has started. A retry event means another permitted attempt is underway. |
| Completed | The executor returned a result. Read that result; completion alone does not make the hypothesis true. |
| Failed | The check did not succeed. |
| Skipped | The check was not performed. |
| Cancelled | The check was stopped or not continued after cancellation. |

Failed, skipped, and cancelled checks do not count as successful source checks. Missing records do not disprove a possible cause.

### 6.3. Understand the strength of a finding

| Cause status shown by the application | Meaning in plain language |
|---|---|
| Hypothesis | A possible explanation still waiting for the required checks. |
| Supported | Recorded events and an engineering mechanism support a contribution, but required verification or rule approval is incomplete. |
| Confirmed | The configured verification rule has current factory approval, and its linked verification records pass. Training cases use an explicitly synthetic rule. |
| Contradicted | Returned records directly conflict with the explanation within the selected scope. |
| Inconclusive | The evidence is missing, poor quality, conflicting, or insufficient to establish a cause. |

For example, a rise in temperature during a stop may be relevant, but timing alone does not prove that temperature caused the stop. A cooling fault may be confirmed while the reason the cooling system degraded remains unknown. A blocked filter does not, by itself, prove maintenance negligence.

The application does not invent a confidence percentage. “Supported” is not another way of saying “80% certain.” Read the actual evidence and missing checks.

### 6.4. Read the causal evidence map

The map links possible causes, events, and outcomes. Each relationship has a text label as well as a line style. Open a relationship to see its proposed mechanism, supporting records, contradictions, and missing confirmation.

Several causes may contribute to one loss. A relationship in the map is not automatically a proven cause. On a narrow screen, scroll the map horizontally or read the full relationship descriptions underneath it.

### 6.5. Understand the 70-piece training example

Open Calculations and assumptions for CNC-03. Both shifts have 480 scheduled minutes. The recorded standard cycle time is 120 seconds, or 2 minutes per piece. The earlier shift has 230 good pieces and 10 scrap pieces. The investigated shift has 160 good pieces and 20 scrap pieces.

| Calculation | Plain-language explanation |
|---|---|
| 230 − 160 = 70 good pieces | The investigated shift produced 70 fewer acceptable pieces than the comparison shift. |
| 90 + 75 − 45 = 120 stop minutes | Two recorded stop intervals overlap for 45 minutes. Subtract the overlap so those minutes are counted once. |
| 120 ÷ 2 = 60 pieces | At a constant 2-minute cycle, 120 stopped minutes correspond to an estimated 60-piece production loss. |
| 20 − 10 = 10 additional scrap pieces | Ten more pieces were rejected than in the comparison shift. |
| Scheduled-capacity difference = 0 pieces | The two shifts have the same scheduled minutes in this training example. |
| 70 − 60 − 10 = 0 pieces | No shortfall remains unexplained by this particular calculation. |

The 60-piece downtime loss is an estimate, not 60 observed recoverable pieces. It assumes the stated cycle time would have continued. The unexplained remainder is displayed even when it is nonzero or negative; the application does not silently force the arithmetic to fit.

Loss attribution is withheld when the compared parts, operations, or revisions are not comparable, when the current scope contains multiple incompatible row meanings, or when the baseline is only a plan. Do not assign the full 70-piece shortfall to one cooling event merely because it appears in the same investigation.

### 6.6. Review without changing the evidence status

After an investigation stops, an authorized reviewer can record Acknowledged or Needs more evidence. This is a human-review record. It does not change a hypothesis to Confirmed.

A confirmed finding needs the configured, approved verification criteria and the required linked records. A person's acknowledgement cannot replace them.

### 6.7. Add evidence and reassess

Step 1. Find a real source record. Use a record ID from the configured history source that the account is allowed to access. Do not invent an event ID or paste a made-up event.

Step 2. Choose Add source evidence. Provide the record ID and explain why it matters. The record may contain verification that occurred after the investigated shift.

Step 3. Keep the earlier result unchanged. Adding a record saves an input for reassessment; it does not rewrite the old finding. A manual excerpt alone still cannot confirm that an event occurred.

Step 4. Ask the investigation owner to Reassess. Give a reason and, where needed, revise the question, date, or baseline. A new revision uses a fresh data cutoff.

Step 5. Compare revisions. The original remains available under Revision history. Reviewers may add records and notes; the owner starts the new revision.

“Compare this with last week” starts a new comparison revision. “Reassess using the new maintenance report” also starts a revision, but the report must first be available through the approved history mapping or document workflow.

Exports contain authorized evidence and technical records. Treat them as sensitive factory files and apply the site's retention and sharing rules.

### 6.8. Handle cancellation and incomplete results

Use Cancel investigation while checks are running. Cancellation is applied at a defined execution checkpoint. A time-limited read already in progress may finish first, but its unused result is not counted as successful evidence.

The default limits are depth 3, 16 tool attempts, one retry per transient read, 90 seconds, and two concurrent workers. Depth covers scope/comparison checks and deeper engineering background. The current workflow uses at most one time-limited local planner request, although the configurable model-call ceiling is two. Model replicas and source reads have their own smaller timeouts.

An Incomplete result keeps completed evidence and any findings already established. A missing model may leave useful rule-based checks but still make the run incomplete. Read the limitation rather than treating an unperformed check as evidence against a cause.

Problem not verified means the reported problem was not established after the comparison and normalization checks. The investigation stops instead of inventing a cause.

Saved cases remain under Investigations after sign-out or restart. Fence the old application authority before restarting. Startup marks unfinished application jobs failed and active investigations/steps cancelled without replaying actions. Open the retained evidence and explicitly reassess. A standalone recovery command remains available for expired legacy investigations:

```text
python -m cnc_ai rca recover --user admin
```

Use the actual administrator username in your installation. The standalone recovery command marks expired queued or running investigations incomplete, cancels unfinished steps, and retains snapshots. It does not replay work or machine commands. Open the saved case and reassess to continue.

## 7. Review and execute a supported machine-action request

### 7.1. A proposal is a request for review

In Machine control, a proposal is a saved request for a specific allowed action. It records who requested the action, what they requested, why they requested it, the observed machine context, the policy version, and when the request expires.

The AI cannot write an arbitrary OPC UA value. OPC UA is the communication protocol used here to exchange permitted information with a configured controller. The controller connection accepts only the specific action types and values allowed by the application and the reviewed mapping.

Training values are not operating instructions. The 6000-to-7000 RPM example below belongs to the simulator. Do not apply it to a physical CNC without the machine-specific commissioning, ratings, process qualification, and approvals.

### 7.2. Prepare the spindle-speed request

Step 1. Sign in as the requester. Use an operator account with permission for the machine and action.

Step 2. Open Machine control and refresh the machine. Inspect the adapter mode, measured RPM, requested-speed setpoint, selected tool, and material. A setpoint is the requested value; measured RPM is the observed spindle speed.

Step 3. Select Set spindle speed. Enter the requested RPM and a meaningful reason. RPM means revolutions per minute.

Step 4. Run the policy checks. These are software checks against configured rules, not a model's opinion about safety.

Step 5. Read every outcome. A failed stage explains why the request stopped. Later stages may be marked skipped. “Approval required” means review is still needed; it does not allow a write.

Step 6. Create the proposal only when eligible. The saved request must then follow the independent review and requester-confirmation steps.

### 7.3. Understand the safety checks

| Check | Question the system must answer |
|---|---|
| Machine state | Is the machine running in an appropriate configured state for this action? |
| Tool rating | Does the observed installed tool assembly have an approved rating for the requested RPM? |
| Process compatibility | Do the tool, material, and workpiece match the approved process recipe? |
| Limits | Are the requested RPM and change size within the machine and process limits? |
| Requester permission | Is this signed-in person authorized for this machine action? |
| Separate approval | Has the required independent supervisor approval been identified or recorded? |
| Current measurements and interlocks | Are the required values the correct type, recent enough, and reported with healthy quality and interlock states? |
| Execution | Have all checks passed again before the requester-confirmed action reaches the restricted controller adapter? |

The training request from 6000 to 7000 RPM passes only with the configured healthy simulated context, including T07, AISI-4140, and WP-4140-01. These identifiers are fictional training conditions, not general machining limits.

Guardian is an additional input/output risk judge. It does not establish a tool rating, grant machine permission, replace an interlock, or approve a process recipe. Reviewed policy, controller context, account permissions, recorded approval, and native machine protections remain authoritative.

### 7.4. A different supervisor reviews the request

The supervisor signs in with a different account and inspects the saved request, context, reason, and check results. They approve or reject it with a comment. Self-approval is rejected even when the requester has supervisor capabilities.

Approval does not write the machine setpoint. The original requester must return and separately confirm execution.

The request expires after five minutes, including time spent waiting for review. An expired request must be replaced with a new one based on current conditions. Changes to the policy, machine identity, active CNC program, tool, material, workpiece, or state invalidate the old context.

The active program must have reviewed qualification matching the tool and recipe. Its identity is read from the controller, not accepted from chat text.

### 7.5. The original requester confirms execution

Step 1. Return to Machine control. Use the original requester account.

Step 2. Inspect the approved request. Confirm that it still describes the intended machine and action.

Step 3. Choose Confirm execution. Type the following text exactly when requested:

```text
EXECUTE APPROVED ACTION
```

Step 4. Wait for the final checks and result. The software checks current conditions and both accounts' permissions again. It consumes the request before contacting the controller so repeated clicks cannot replay the same request.

Step 5. Check actual machine behavior separately. A successful result confirms that the setpoint readback matched. It does not prove the measured spindle speed changed as intended. Follow the site's controller-monitoring and operating procedures.

The simulator deliberately keeps measured RPM separate from the accepted setpoint to teach this distinction.

### 7.6. Read the outcome correctly

| Outcome | Meaning and required response |
|---|---|
| Rejected | The reviewer rejected the request. It cannot execute. |
| Expired | Its allowed lifetime ended. Prepare a new request from current conditions. |
| Blocked | A required check or condition failed. Resolve the stated issue through an approved procedure. |
| Confirmed | The requested setpoint matched the readback. Verify physical behavior separately. |
| Unknown, or unfinished executing | The command may have reached the controller, but the outcome could not be confirmed. Further writes to that machine are blocked, including after restart. |

Do not retry an unknown operation. A controls engineer must inspect the physical controller and use the documented local reconciliation procedure with a meaningful note. Reconciliation resolves the recorded uncertainty; it does not replay the command. It cannot overlap an active write. Any new action needs a new request.

The supported feed-hold action is also a supervised, fixed Boolean command. Boolean means a true/false value. Feed hold is not an emergency stop. Use the machine's native emergency-stop and safety procedures when required.

## 8. Understand factory data and add analytical sources

### 8.1. Keep the different data stores separate

The default application database is runtime/factory.db. It stores business data and application records such as accounts, documents, evidence, approvals, and audit events. The numerical historian stores timestamped measurements. A historian is a data store designed for recorded signals over time.

The base-manual sample installation is described as containing 26 fictional machines, 100 work orders, and 27,360 historical sensor readings. Importing the separate numerical sample adds 30,240 canonical historian observations, not more rows to the original sensor_readings table. These are reference sample counts; they are not facts about your factory and can change after imports.

The linked business domain covers factories and lines; machines and states; products and bills of materials; work orders, operations, and runs; tools and ratings; materials and workpieces; downtime, alarms, and maintenance; quality; inventory and procurement; and program/lot/run examples. docs/DATABASE.md contains the detailed table and column catalog.

The six added CNC machines in the base sample align with its newer program, tool, lot, and run examples. Sample policies and documents are fictional. Old editable operator labels do not become authenticated accounts during import.

### 8.2. What read-only SQL means

SQL is the language used to query relational databases. Read-only means the query can retrieve approved data but cannot change it. This restriction applies to model-generated SQL for every role, including administrators.

The application parses the whole statement. It rejects second statements, data-changing commands, schema-changing commands, pragmas, database attachment, and recursive queries. Approved tables, columns, and functions are checked again by the database engine. User-provided values should be passed as named parameters rather than inserted directly into SQL text.

The default limits are 100 output rows and five seconds of execution. A blocked query produces an error and an audit record. The application does not make a dangerous multi-statement query acceptable by silently running its first fragment.

Administrative changes use restricted application services or reviewed offline migrations, not AI-generated write SQL. Selecting another analytical database cannot grant access to controller state or credentials.

### 8.3. Import an additional database

Step 1. Sign in as an administrator and open Factory data. Upload the intended SQLite database.

Step 2. Review the quarantined source. Quarantined means uploaded but not yet available for normal analytical use. Pending imports remain available after a page refresh.

Step 3. Review the schema allowlist. The schema is the structure of tables, columns, and relationships. The allowlist identifies which of them the assistant may query. Remove sensitive tables and columns from the displayed JSON before approval.

Step 4. Approve the reviewed allowlist. Only approved analytical sources appear in the conversation selector.

Step 5. Start a new conversation and test a simple question. Inspect the source rows before using the database for complex decisions.

The business-query path uses SQLite. General SQL Server or PostgreSQL business queries require a reviewed export or an added, dialect-specific connector. The numerical historian's PostgreSQL/TimescaleDB, ClickHouse, and HTTP read-only adapters are separate capabilities; they do not create a general generated-SQL connector.

### 8.4. Design tables around clear row meanings

Before creating a table, finish this sentence: “One row in this table represents…” Examples are one machine, one work order, one operation, one production run, or one sensor measurement at one time. Do not mix them into one ambiguous record type.

| Design choice | Plain-language rule | CNC example |
|---|---|---|
| Primary key | Give each row a stable unique identity. | A machine has an internal ID and a unique readable machine code. |
| Foreign key | Store an explicit link to the related row. | A production run refers to its work order, operation, and machine. |
| Units | Make the measurement unit clear. | Use cycle_seconds and diameter_mm, not unclear labels such as value1. |
| History | Keep past events, not only the latest status. | Preserve when a stop started and ended and how its reason was revised. |
| Tool information | Separate catalog limits, installed assignments, and live readings. | A catalog rating is not proof that the corresponding tool is installed now. |
| Time quality | Keep source time, received time, quality, and sequence. | Receiving an old measurement now does not make the measurement fresh. |
| Output quantity | Count at the correct production stage. | Use final-operation output so one part is not counted again at every routing step. |
| Evidence | Keep the source record and the answer's retained copy. | Preserve the inspection record used for an earlier answer after later corrections. |

Use operational tables for business records, curated views for approved analytical meanings, and retained event/evidence snapshots for history and review. A curated view is a reviewed way of presenting selected data, often with business rules already applied. docs/DATABASE_DESIGN.md provides the deeper key, relationship, indexing, maintenance, quality, and history rules.

### 8.5. Add another industrial sector

In System & settings, create a sector profile: a saved description of the domain and its vocabulary. Select the sector when importing documents or an analytical schema. The supplied robot-cell and process-batch JSON examples show typed columns and explicit keys.

Create the sector database in Factory data and review its allowlist. Keep CNC as the main domain for this factory. Another sector changes the available analysis, not the user's machine-control powers.

New controller actions need a defined input contract, a reviewed adapter mapping, fixed policy checks, and tests. Preserve the existing identity, evidence, audit, and independent-approval protections.

### 8.6. Follow related factory records

A digital thread is the chain of recorded relationships connecting work across the factory. Here, it can link a customer or sales order to a work order, operation, production run, CNC program, tool, material lot, inspection, alarm, and maintenance record.

After business imports, rebuild the relationship projection. A projection is the application's derived relationship view; it is not a replacement for the original records. Ask “Trace the digital-thread relationships for Production_Run 1001,” or use the relationship form in Telemetry & health.

Results are limited to three relationship steps, called hops, and 200 relationships, called edges. Truncation is shown. Evidence identifies source tables and keys. High-frequency raw signals remain in the historian, and earlier answer snapshots remain unchanged after a rebuild.

A relationship is not proof of a cause. A maintenance job linked to a machine does not explain every later alarm automatically.

## 9. Understand planning and production calculations

### 9.1. Planning results are recommendations

A planning answer should explain the available time, remaining work, material and resource constraints, and uncertainties. It is not automatically a released MES schedule. MES means manufacturing execution system: the system used for managing and recording production execution.

The supplied planning tool takes explicit jobs, durations, process order, due times, machines, shared labor, tools, fixtures, maintenance windows, inventory, and power limits. It uses a limited earliest-due-date allocation method: it considers earlier due jobs first and makes feasible assignments under the supplied rules.

It reports unassigned or infeasible work, lateness, capacity, and energy estimates. It is a transparent baseline, not proof that no better schedule exists. The example input is samples/planning/next_shift.json. The assistant can call this restricted tool when the necessary inputs are complete; missing information requires clarification. A session-protected planning API is another entry point for developers.

There is no automatic MES dispatch or machine resequencing. APS means advanced planning and scheduling. The built-in calculation is not evidence that an external APS product or Simio has been connected.

### 9.2. Work through the numbers

All inputs below are fictional teaching examples. They illustrate arithmetic, not operating commitments.

Shift capacity. Start with 420 available minutes. Subtract 30 minutes for setup, leaving 390. At 2 minutes per part, 390 ÷ 2 = 195 parts is the ideal capacity before other losses. This is not a promise of 195 good parts; scrap, stops, materials, and other constraints may reduce it.

Delivery risk. Sixty remaining parts require 60 × 2 = 120 processing minutes. Add 30 setup minutes and a 20-minute buffer: 120 + 30 + 20 = 170 minutes. With only 150 available minutes, the gap is 170 − 150 = 20 minutes.

Material shortage. A stock balance of 120 kg minus 30 kg already reserved leaves 90 kg available. Forty parts using 2.5 kg each need 40 × 2.5 = 100 kg. The shortage is 10 kg before scrap allowance. “On hand” and “available” are different quantities.

Quality sample. Five rejects among 200 inspected observations give 5 ÷ 200 × 100 = 2.5%. That is the rate in the inspected sample. It is not automatically the rate for every part produced.

Overall Equipment Effectiveness (OEE). Multiply availability, performance, and quality using the same time window and site definitions: 0.90 × 0.80 × 0.99 = 0.7128, or 71.28%. Do not mix daily availability with monthly quality or count a loss twice.

Bottleneck. Three serial stages taking 2, 3, and 1 minute per part have ideal rates of 30, 20, and 60 parts per hour. Under the stated balanced-flow assumptions, the 3-minute stage limits flow to 20 parts per hour. Improving a faster stage alone does not remove that limit.

### 9.3. Ask for an actionable shift review

Ask the assistant to state the time window, units, source rows, remaining quantities, setup times, material reservations, maintenance restrictions, and uncertainty. Review open maintenance, downtime categories, work-order risk, and inspected quality separately before combining them into a shift recommendation.

A useful request is: “Compare the next shift's remaining work with available machine time. Show material shortages, planned maintenance, and assumptions. Do not release a schedule.”

For complete CNC machine builds, distinguish the availability of machined components from purchased components, assembly capacity, and outstanding acceptance work. The conclusion must be limited to the records actually mapped into the analysis.

Do not double-count overlapping downtime, treat sampled defects as total rejected output, or promise capacity that depends on an unverified tool or material assumption.

## 10. Analyze recorded machine measurements

### 10.1. Choose the right history and comparison period

Open Telemetry & health after importing the numerical sample. Telemetry means recorded measurements such as temperature or vibration.

Step 1. Select the machine and signals. For the sample, choose CNC-02, bearing_temperature, and vibration.

Step 2. Select the reference period. The reference is the earlier data used for comparison. In the example, set reference start to 2026-09-01 08:00 UTC.

Step 3. Select the analysis period. Set analysis start to 11:00 and end to 14:00 UTC on the same date. The end is exclusive: a record exactly at 14:00 is outside this window.

Step 4. Choose Anomaly detection. Read the numerical result and retained evidence. These sample measurements are historical and fictional, not present controller readings.

The numerical tools retain their input hash, source timestamps, algorithm version, and context. A tool, program, lot, or run change inside the window causes rejection. Reference tool/program/material context must match. Tool usage, maintenance age, and alarm counts are joined as known by the window end when available; missing history remains unknown.

The numerical service has no controller-write capability. Its results cannot authorize a machine change.

### 10.2. What the eight analysis choices tell you

| Choice | What it calculates | What it does not prove |
|---|---|---|
| Anomaly | How far signals depart from their reference behavior, including a joint signal screen. | A probability that the machine will fail. |
| Trend | The fitted rate and direction of change over time. | A unique physical cause; repeated measurements can affect significance. |
| Change point | Candidate times when a signal's average behavior changed. | That a particular component caused the change. |
| Forecast | Predicted future values with a time horizon and uncertainty interval. | Guaranteed future values or guaranteed interval coverage. |
| Health | A screening index based on reference and alarm behavior. | A calibrated probability of machine health. |
| Tool condition | A context-dependent screen, optionally using a trained model. | Proven tool wear or chatter without appropriate validation. |
| Quality risk | A process screen, optionally using a trained model. | An actual count of rejected parts. |
| Remaining useful life | An approved component-specific estimate when a suitable trained model exists. | A reliable estimate when labeled data and an approved model are missing. |

### 10.3. Understand deviations and trends

Suppose the reference median vibration is 2.0 mm/s and its robust scale is 0.1 mm/s. A reading of 2.6 mm/s is (2.6 − 2.0) ÷ 0.1 = 6 reference scales above the median. The reported score of 6 is not a 60% chance of failure.

A fitted temperature trend of 0.10 °C per minute corresponds to 0.10 × 60 = 6 °C per hour. It describes the fitted change in that window, not a guarantee the temperature will keep rising at the same rate.

Cutting load, coolant, program changes, and sensor mounting can affect the measurements. Inspect context before naming a bearing fault.

### 10.4. Read forecasts as estimates

Thirty predicted samples at one sample per minute cover 30 minutes. The chart separates measurements from predictions and shows an uncertainty band.

The default method compares simple forecast methods using earlier forecast errors. Candidates include naive, drift, seasonal, and Holt methods. The nominal 90% historical-residual band is built from past errors; it does not guarantee that 90% of future values will fall inside it. Recheck applicability after tool, program, or load changes.

Chronos-2 is optional. Its local model snapshot must be downloaded explicitly during preparation. Install the forecast extra on staging, set CHRONOS_MODEL_PATH and CHRONOS_MODEL_REVISION, and request method chronos2. The runtime does not download it automatically.

The package treats TimesFM 2.5 and Moirai 2 as research candidates, not interchangeable active adapters. Its selection notes exclude TimesFM 3 from factory defaults on licensing grounds. Treat these as recorded package-selection decisions, not a fresh check of external model availability or license terms.

### 10.5. A slow indicator is not a vibration waveform

A value recorded once per minute cannot reveal a 240 Hz vibration tone. That requires waveform data sampled fast enough, with regular timestamps and a declared sampling rate. The supplied waveform example is one second at 4096 samples per second with a 240 Hz tone.

Waveform tools include FFT and power spectral density for frequency content; band energy for energy within a frequency range; RMS for overall signal magnitude; kurtosis for the distribution's shape; and crest factor for the peak-to-RMS ratio. These measurements still need reviewed frequency bands and machine-specific baselines. A generic peak does not establish a validated fault.

### 10.6. Train and approve a component model before using RUL

Remaining useful life, or RUL, begins as unavailable. A technician should not interpret that as zero remaining life. It means the system lacks a suitable approved model for the requested context.

Train an artifact from labeled features, keep independent machine or component units out of training for evaluation, and inspect the errors and operating scope. Register its approved hash, model family, component, and applicable programs. The runtime rejects missing features, mismatched context, and inputs outside the model's approved range.

The supplied portable ridge-regression method is a simple numerical model. It does not implement censored survival analysis, which handles records where the failure time has not yet been observed. docs/TIME_SERIES_INTELLIGENCE.md contains training formats and exact configuration.

### 10.7. Understand evaluation reports

CNCBench evaluates document retrieval, SQL validation, anomaly detection, and forecasting. Retrieval metrics describe whether useful sources were found and ranked well. Anomaly metrics compare alerts with known labels and include false alarms. Forecast metrics measure prediction error overall and at different horizons.

The report includes Recall/MRR/nDCG for retrieval; precision/recall/F1/AUROC and false-alarm rate for anomalies; and MAE/RMSE/MASE and horizon errors for forecasts. Use docs/CNCBENCH.md for the metric definitions and test setup. --models adds actual configured model tests; --neural-forecast adds Chronos comparisons.

Default scores use fictional data and small curated tests. They are preliminary software checks, not proof of factory-wide accuracy. Observations, anomalies, correlations, hypotheses, and validated causes remain distinct claims.

## 11. Draft and review engineering work

### 11.1. Generated code is a draft

The code model can draft SQL, Python, NC/G-code, and other manufacturing software. The application may execute an approved read-only SQL query for evidence. It does not execute arbitrary generated Python, shell, NC, or robot programs.

Before independently using machining code, review the controller dialect, coordinate systems, tool offsets, units, spindle/feed conventions, stock, fixtures, and the site's simulation and dry-run requirements. A controller dialect is that controller's supported form of the programming language.

### 11.2. Cutting calculations explain inputs; they do not approve a cut

The restricted calculation service computes surface speed, feed, and torque and checks configured limits. Using fictional inputs:

| Calculation | Result and meaning |
|---|---|
| Surface speed: π × 10 mm × 7000 RPM ÷ 1000 | About 219.9 m/min at the circumference of a 10 mm cutter. The division converts millimeters to meters. |
| Feed: 4 teeth × 0.03 mm/tooth × 7000 RPM | 840 mm/min under those stated inputs. |
| Torque: 9550 × 5 kW ÷ 7000 RPM | About 6.82 N·m using the stated power and speed relationship. |

These values do not establish acceptable tooling, engagement, rigidity, material condition, coolant, holder rating, fixture clearance, or cutting compatibility. The calculation keeps its inputs and assumptions as evidence and cannot change the spindle-control policy.

### 11.3. Review an NC artifact through the engineering process

An artifact is a saved engineering candidate, such as a proposed NC program. The artifact API stores the candidate and its content hash.

The static checker accepts only a restricted G21/G90/G0/G1 dialect with reviewed speed, feed, tool, and travel-envelope constraints. Macros and unsupported commands are blocked. Checking written coordinates is not a collision simulation.

Separate records of simulation, collision review, engineering review, and final approval must pass in that order. Each record refers to the same candidate hash and to the hash of its external review report. The uploader cannot approve their own candidate through these attestations, and the final approver must differ from the engineering reviewer.

Use qualified external CAM/simulation tools with the actual fixture and tool models to produce the necessary reports. Approved export creates an engineering bundle only. This release provides no CNC upload or execution endpoint for that bundle.

### 11.4. Optional image evidence

PNG/JPEG analysis through the conversation service's vision capability is optional and disabled by default. Image dimensions are limited, and both the original-file hash and analyzed-thumbnail hash are recorded.

Image interpretation is not calibrated measurement. It cannot approve a tolerance or machine action. Preparing scanned-document text with offline OCR remains a separate step.

### 11.5. Optional SQL and speech services

Administrators can enable SQLCoder on port 8006 after comparing its drafts with the core coder on approved factory questions. The same one-query, parameter, allowlist, read-only, row-limit, time-limit, and evidence rules still apply. Enabling another model changes the draft generator, not database permission.

For speech, open Dictate from a recording in Chat. Select a mono, 16 kHz, PCM 16-bit WAV file of no more than 30 seconds and 1 MiB. Mono means one audio channel. Review the transcription carefully, especially machine IDs, tool numbers, units, and values.

Choose Put reviewed text in message, then press Send. Transcription alone does not send a chat or create a machine proposal. It does not overwrite an existing message draft and does not authenticate an operator.

Whisper uses the optional service on port 8007. Without the optional services, type the question and use the core coder. docs/OPTIONAL_SPECIALISTS.md contains startup, private endpoint, and alternative Coder-Next rollback instructions.

## 12. Understand the three-server installation

Fifty browser clients connect to one CPU application/data server. That server distributes language-model requests across AI server A and AI server B. Each AI server contains four separate 96 GB GPU memory spaces. The 384 GB total per node and 768 GB across both nodes are arithmetic totals, not one automatically shared memory pool. Both inference nodes normally do useful work. The CPU server remains a single point of failure; inference-node resilience does not create automatic application failover.


The target has three server computers: two inference nodes, one CPU application/data server, and independent backup infrastructure. Fifty browser computers are clients. Existing qualified servers/storage may supply the CPU and backup roles. A single working computer with four GPUs would not provide the requested node resilience.

### 12.1. Inference servers

The preferred reference is **two Supermicro SYS-212GB-FNR** systems, each vendor-configured for four **NVIDIA RTX PRO 6000 Blackwell Server Edition 96 GB** cards. The manufacturer's page lists four double-width GPUs, PCIe 5.0 x16 CPU links, four rear E1.S bays, two M.2 slots, five heavy-duty fans, two 2700 W supplies, and 900 mm chassis depth. RHEL 10.0 appears in its OS list. Obtain written qualification of the exact ordered configuration. [Supermicro system specification](https://www.supermicro.com/en/products/system/gpu/2u/sys-212gb-fnr).

| Item per inference node | Requested starting configuration | Vendor confirmation required |
|---|---|---|
| GPU | Four Server Edition cards, 96 GB each | Exact board SKU, risers, cables, firmware, power cap and thermal qualification |
| CPU | About 32 physical cores | Supported socket/SKU, lanes and cooling within chassis limits |
| System RAM | 512 GB ECC | Qualified modules, channel population and speed |
| Boot storage | Two approximately 1 TB enterprise SSDs, mirrored | Supported M.2 form factor and mirror implementation |
| Model/data storage | Two approximately 7.68 TB enterprise NVMe drives, mirrored | **E1.S** drive/backplane compatibility; no assumed U.2 interchangeability |
| Network | Dual-port 10 Gb Ethernet plus management | NIC/riser compatibility, optics/DAC or copper, switch support |
| Power | Redundant supplies at approved site voltage | Surviving capacity covers the whole configured server |
| Support | Three years for the complete system | Response time, on-site parts, GPU coverage and installation scope |

Each node has 384 GB of aggregate GPU memory, but four separate 96 GB memory spaces. Across both nodes the aggregate is 768 GB; a model cannot treat it as a single automatic pool. The Server Edition specification provides configurable power up to 600 W and ECC GDDR7; this software does not set a power limit. [NVIDIA product specification](https://www.nvidia.com/en-us/data-center/rtx-pro-6000-blackwell-server-edition/).

A mirror of two 7.68 TB drives provides approximately 7.68 TB usable before formatting and reserve space. Two 1 TB boot drives similarly provide roughly 1 TB. “Boot” describes what the drive does; NVMe describes how a drive communicates. M.2, E1.S and U.2 describe different physical arrangements. They are not interchangeable without a qualified backplane/cabling design.

Four GPUs at 600 W would consume 2400 W before the CPU, memory, drives, NIC and fans. Thus one 2700 W supply cannot be assumed to cover that entire configuration with adequate margin. The vendor must calculate the surviving supply capacity and derating at the proposed GPU caps, operating temperature and input voltage. Do not apply 600 W automatically or infer full redundancy simply from two PSUs.

This design uses independent TP1 replicas over ordinary Ethernet. It does not require an NVLink bridge, NVSwitch, InfiniBand or RDMA. The chassis's optional bridge statement is not RTX PRO GPU qualification. GPU-specific NVLink capability was not established by the reviewed sources; require vendor confirmation in the final bill of materials. This deployment does not use a bridge. No tested software path here depends on GPU peer links.

### 12.2. CPU host, backup and site equipment

Start the CPU authority at approximately 16–24 physical cores, 128 GB ECC RAM and 4 TB usable mirrored enterprise storage, with 10 Gb Ethernet. These are sizing recommendations, not measured requirements. It runs the web application, bounded jobs, SQLite, documents and numerical computation; no AI GPU is required. Measure ingestion CPU use, concurrent query latency and historian growth before final purchase.

Independent backup starts at an estimated 12–24 TB usable. Use the retention formula and worked example in `OPERATIONS.md`. Include at least one recovery copy outside the production failure domain. Mirroring is not a backup.

Provide a rack with enough usable depth for a 900 mm chassis plus rails/cables, verified floor/rack loading, appropriate branch circuits, protected A/B power feeds where required, sized UPS runtime, compatible PDUs, qualified airflow and room cooling. Include NICs, transceivers/DACs, patch cables, switches, management access, internal DNS, NTP, certificates and secure media transfer. A common switch, UPS or room can still be a shared failure point. Measure total input watts and cooling at the actual approved configuration.

### 12.3. Budget worksheet dated 10 September 2026

The figures below are **planning allowances in USD, not sourced vendor quotations**. Obtain an itemized regional quote, taxes, lead times, installation and whole-system support. These allowances avoid presenting a bare chassis price as a complete server price.

| Item | Quantity | Allowance per item | Extended allowance |
|---|---:|---:|---:|
| Server Edition 96 GB GPUs | 8 | $12,000–$18,000 | $96,000–$144,000 |
| Qualified GPU host platform excluding GPUs, including CPU/RAM/drives/NIC | 2 | $18,000–$30,000 | $36,000–$60,000 |
| CPU application/data server | 1 | $8,000–$15,000 | $8,000–$15,000 |
| Independent backup equipment/storage | 1 | $5,000–$12,000 | $5,000–$12,000 |
| Network/rack/power/cooling allowance | 1 | $10,000–$25,000 | $10,000–$25,000 |
| Installation and three-year whole-system support allowance | 1 | $10,000–$25,000 | $10,000–$25,000 |
| Total planning range | | | **$165,000–$281,000** |

The two populated GPU servers alone account for $132,000–$204,000 of this worksheet before the separately listed support/site work. Do not add a quoted fully populated server price to these GPU component allowances; that would double-count GPUs. Existing site facilities may reduce incremental cost. Currency, taxes and country-specific availability are not established by this worksheet.

### 12.4. Model placement on each inference node

| Local GPU | Service | TLS port | Loopback port |
|---|---|---|---|
| 0 | conversation replica 1 | 8001 | 18001 |
| 1 | conversation replica 2 | 8011 | 18011 |
| 2 | code | 8002 | 18002 |
| 3 | safety | 8003 | 18003 |
| 3 | embedding | 8004 | 18004 |
| 3 | reranker | 8005 | 18005 |

There are twelve independently supervised instances. Reports reuse conversation and action proposals reuse the coder. All five core models remain local. Every large instance initially uses one GPU (TP1). Guardian, embeddings and reranking share GPU 3 with proposed fractions 0.45, 0.20 and 0.10. Those values do not guarantee memory or compute isolation; actual simultaneous startup and use must pass hardware tests. SQLCoder and Whisper remain disabled. See MODEL_COMPATIBILITY.md for exact commits, contracts and candidate dependencies.

## 13. Install, migrate and transfer the system

### 13.1. A small Windows workstation


Use Anaconda PowerShell Prompt from the extracted project directory. CPU development needs no Torch/CUDA weights. Python 3.12 runs the UI, database, lexical RAG, numerical statistics and simulators.

```powershell
conda env create -f environments/smartfactoryllm.yml
conda activate smartfactoryllm
python -m pip install -e '.[test,download]'
Copy-Item .env.example .env
```

For an old environment, export it before replacing anything. The setup script's -Recreate option uses a separate smartfactoryllm_v112 environment and retains the old one:

```powershell
conda env export -n smartfactoryllm --no-builds > smartfactoryllm-old.yml
conda list -n smartfactoryllm --explicit > smartfactoryllm-old-explicit.txt
powershell -ExecutionPolicy Bypass -File scripts/windows/setup.ps1 -Recreate
conda activate smartfactoryllm_v112
python -m pip check
python -m pytest
```

Keep the original environment until the new installation is validated. The new environment can retain its versioned name. Do not blindly copy a Conda directory across machines/operating systems. Recreate from a tested lock/wheelhouse or use a validated same-platform environment package.

Set CNC_PROFILE=development, CNC_MODEL_MODE=demo and CNC_OPCUA_MODE=simulator in .env. Initialize named accounts, documents and telemetry as in README. Run python -m cnc_ai serve. PowerShell scripts accept -EnvironmentName smartfactoryllm_v112; .bat wrappers default to smartfactoryllm.

Use Invoke-RestMethod -Uri 'http://127.0.0.1:5000/api/health', or explicitly curl.exe, to avoid the PowerShell curl alias. Quote paths with spaces. F:/AI/models is Windows; WSL uses /mnt/f/AI/models. vLLM serving belongs in Linux/WSL2. Use private model URLs to reach actual inference services from a smaller workstation. Native PowerShell execution remains a target-machine validation gate.

### 13.2. Eleven installation steps



**1. Create or recreate smartfactoryllm**

Use Anaconda PowerShell Prompt on a Windows development workstation. Preserve the old environment until migration tests succeed:

```powershell
conda create -n smartfactoryllm_v112 python=3.12 pip
conda activate smartfactoryllm_v112
python -m pip install -e '.[test,download]'
Copy-Item .env.example .env
```

For a new installation use `smartfactoryllm` instead of `smartfactoryllm_v112`. For offline production, install the packaged wheel and dependencies from the matching Linux wheelhouse, as explained in the server guide. Do not copy a Windows virtual environment to Linux. Recreating an environment does not require deleting factory data.

**2. Download or resume all core models**

On connected staging only:

```powershell
python scripts/models/download_factory_models.py all --model-root 'F:/AI/models' --checksums
```

`all` means **five physical snapshots**, including the existing reranker. It does not download twelve copies or optional specialists. Run the identical command again after interruption; the downloader retains partial files and immutable commits. A single role, for example `code`, can replace `all`.

**3. Point to existing local models**

For development set `MODEL_ROOT` and each `*_MODEL_PATH` in `.env`. Factory model directories must be complete external snapshots with downloader checksum manifests. Reusing existing files through the downloader verifies metadata without intentionally redownloading valid cached files. A loose GGUF is not the supplied BF16 serving format.

```powershell
python scripts/models/download_factory_models.py all --model-root 'F:/AI/models' --verify --checksums
python scripts/deployment/configure.py --manifest config/deployment.json --bind-snapshots 'F:/AI/models' --qualified --output deployment/generated
```

Review hostname/IP values in the manifest before generating site files. Transfer the same pinned manifest and snapshots to both AI servers. Factory startup rejects unverified snapshots; no weights are in this ZIP.

**4. Start inference services**

Use the Linux host-specific [server guide](SERVER_INSTALLATION.md). Install six independently supervised systemd units per AI server. Preview one instance without loading weights:

```powershell
python scripts/models/serve_models.py --instance ai-a-conversation-1 --dry-run
```

The old `serve_models.py server-a` host group now fails with migration guidance. Optional specialist placement is not part of the eight-GPU allocation. A separate qualified profile is needed before enabling it.

**5. Initialize the database**

For a new **training** database:

```powershell
python -m cnc_ai db init --sample
python -m cnc_ai user add admin --role admin
python -m cnc_ai user add operator --role operator
python -m cnc_ai user add supervisor --role supervisor
```

Passwords are requested interactively. For a new empty factory database use `db init`; populate and qualify actual records separately. For existing data, back up and run `db migrate`, never reseed. Migration 005 adds jobs and model request IDs without rewriting prior migrations.

**6. Ingest RAG documents**

```powershell
python -m cnc_ai ingest samples/documents --user admin
```

Word, PDF, Excel, CSV and text extraction remains available. Factory retrieval uses approved document revisions. Use a different authorized reviewer to approve uploaded revisions. Evidence includes source location, timestamp and hash. Changing the embedding revision requires rebuilding vectors.

**7. Run safe simulation**

In development `.env`, set `CNC_MODEL_MODE=demo`, `CNC_PROFILE=development`, `CNC_OPCUA_MODE=simulator`. Then:

```powershell
python -m cnc_ai rca demo --user admin
python -m cnc_ai serve
```

Set `CNC_RCA_DEMO=true` to select synthetic RCA cases. A wire-protocol simulator is also available with `python -m cnc_ai opcua-simulator`; select `CNC_OPCUA_MODE=opcua_test` in a separate app process. Neither mode operates a physical machine.

**8. Configure real OPC UA separately**

Follow [commissioning](CONTROL_COMMISSIONING.md), map reviewed nodes in `config/opcua.json`, provision certificates/service credentials only on the CPU authority, and qualify fresh telemetry and native interlocks. Keep `CNC_REAL_WRITES_ENABLED=false` and `CNC_SITE_COMMISSIONED=false` until site authorization. Approval cannot override a failed deterministic gate. Never use load tests against a physical controller.

**9. Start the application**

```powershell
python -m cnc_ai serve
```

Development opens `http://127.0.0.1:5000`. Factory users open the CPU server's trusted HTTPS URL. Waitress remains on loopback behind nginx. The browser uses persistent jobs for chat, reports, ingestion and verification; RCA uses its own bounded lane in the same queue. No unreviewed token streaming is enabled.

**10. Validate the installation**

```powershell
python -m pytest -q
python scripts/validate_installation.py
python scripts/deployment/configure.py
```

Linux synthetic capacity test, isolated from production data:

```bash
python scripts/evaluation/load_clients.py --clients 5 10 25 50 --rounds 2 --duration 30 --deny-public-egress --output /tmp/cnc-load.json
```

Use `docs/CAPACITY_TESTING.md` for actual-model and physical-host acceptance. A synthetic result is not a GPU benchmark.

**11. Transfer to the air-gapped factory**

Prepare matching OS/runtime packages, application and inference wheelhouses, complete checksummed snapshots, site certificates, internal DNS/time, deployment configuration and rollback resources. Use `scripts/prepare_airgap.py`, then follow [offline deployment](AIR_GAP_DEPLOYMENT.md). The source ZIP is the application release, not a replacement for the site's OS and model transfer media.

### 13.3. Production commands by host


These commands target the existing project at `/opt/cnc-ai`. Replace the example hostnames/IPs centrally in `config/deployment.json`, then regenerate assets. The default method is systemd plus nginx on vendor-qualified x86-64 Linux. AI A and AI B each have four 96 GB RTX PRO 6000 Blackwell Server Edition GPUs. The CPU application host and independent backup storage are separate. No Kubernetes, Redis or cluster scheduler is required.

### 13.4. Connected preparation host

Use matching Linux, architecture and Python 3.12 for production dependency preparation. Windows development uses a separate application environment; users' browsers need no environment.

```bash
conda create -n smartfactoryllm python=3.12 pip
conda activate smartfactoryllm
python -m pip install -e '.[test,download]'
python -m pytest -q
python scripts/models/download_factory_models.py all --model-root /srv/ai/models --checksums
python scripts/models/download_factory_models.py all --model-root /srv/ai/models --verify --checksums
python scripts/deployment/configure.py --manifest config/deployment.json --bind-snapshots /srv/ai/models --qualified --output deployment/generated
```

Do not use partial file selections for factory core snapshots. The manifest includes reviewed upstream commit pins. Keep LICENSE/model-card files and all tokenizer, processor and shard files. Pinning or hashing is not proof of model quality. Existing local files can be reused through the resumable downloader at the selected paths; retain its completed manifests. An existing unmanifested snapshot is not silently trusted.

On a matching connected **GPU staging server**, install the candidate into a separate environment. This step is intentionally not called a qualified installation:

```bash
conda create -n smartfactorymodels python=3.12 pip
conda activate smartfactorymodels
python -m pip install -r requirements/rtx-blackwell-candidate.txt
python -m pip install packages/cnc_first_ai-11.2.0-py3-none-any.whl
python -m pip check
```

Install the wheel with its declared dependencies so package metadata remains consistent. Resolve those dependencies together with the serving engine on the target platform. Do not install the entire CPU lock over the GPU environment. A working `pip check`, `sm_120` BF16 kernel test, all five model contract probes and simultaneous GPU 3 operation are required before freezing the inference lock. Store the resolved CUDA/PyTorch/driver details, not merely the candidate requirements filename.

### 13.5. AI server A

Install vendor-approved firmware, Linux, GPU driver and the validated serving environment from controlled media. System provisioning below runs as a site administrator. Weights must already have been copied to `/srv/ai/models` and verified. The chosen drive form factors and GPU power limits need vendor approval; these scripts do not change power caps.

```bash
sudo useradd --system --home-dir /var/lib/cnc-models --create-home cncmodels
sudo install -d -o root -g cncmodels -m 0750 /etc/cnc-ai
sudo install -d -o cncmodels -g cncmodels -m 0750 /var/lib/cnc-models
sudo install -m 0644 config/deployment.json /etc/cnc-ai/deployment.json
sudo install -o root -g cncmodels -m 0640 deployment/generated/ai-a/models.env.example /etc/cnc-ai/models.env
sudo install -m 0644 deployment/generated/ai-a/cnc-model-*.service /etc/systemd/system/
sudo install -m 0644 deployment/generated/ai-a/nginx-models.conf /etc/nginx/conf.d/cnc-models.conf
```

Edit `/etc/cnc-ai/models.env` locally with five distinct strong API keys. The key for a role must match the CPU app and that role's replicas on AI B. Provision a site-trusted TLS certificate whose subject alternative names include `ai-a.factory.internal`, its private key, and the CA chain. The generated nginx path is `/etc/cnc-ai/tls/server.crt` and `server.key`. Protect the private key from other accounts. The model account requires read access to its model-only environment, manifest, configuration and weight tree, and write access only to its own cache. It must not have CPU application/OPC UA secrets.

```bash
sudo nginx -t
sudo systemd-analyze verify /etc/systemd/system/cnc-model-ai-a-*.service
sudo systemctl daemon-reload
sudo -u cncmodels /opt/conda/envs/smartfactorymodels/bin/python scripts/deployment/preflight.py --host ai-a --manifest /etc/cnc-ai/deployment.json --env-file /etc/cnc-ai/models.env --deep --check-ports-free --transfer /srv/transfer --output /var/lib/cnc-models/preflight.json
sudo systemctl enable nginx
sudo systemctl start nginx
sudo /opt/conda/envs/smartfactorymodels/bin/python scripts/deployment/manage.py start --host ai-a --manifest /etc/cnc-ai/deployment.json
sudo systemctl enable cnc-model-ai-a-conversation-1 cnc-model-ai-a-conversation-2 cnc-model-ai-a-code cnc-model-ai-a-safety cnc-model-ai-a-embedding cnc-model-ai-a-reranker
```

If only the model environment is installed on this host, run `manage.py` with its Python instead; the module uses the installed source wheel and standard library. Preflight is read-only and returns nonzero for missing gates. Do not turn a blocked preflight into a pass by ignoring its result. An individual unit's startup contract check can take up to ten minutes. Inspect `journalctl -u cnc-model-ai-a-safety` if it fails. No other model unit is automatically restarted because it fails.

### 13.6. AI server B

Use the same manifest, complete model snapshots, serving lock and model keys on B. Install the **ai-b** generated files and a certificate for B's hostname. Repeat the account/directory steps above, then:

```bash
sudo install -m 0644 deployment/generated/ai-b/cnc-model-*.service /etc/systemd/system/
sudo install -m 0644 deployment/generated/ai-b/nginx-models.conf /etc/nginx/conf.d/cnc-models.conf
sudo nginx -t
sudo systemd-analyze verify /etc/systemd/system/cnc-model-ai-b-*.service
sudo systemctl daemon-reload
sudo -u cncmodels /opt/conda/envs/smartfactorymodels/bin/python scripts/deployment/preflight.py --host ai-b --manifest /etc/cnc-ai/deployment.json --env-file /etc/cnc-ai/models.env --deep --check-ports-free --transfer /srv/transfer --output /var/lib/cnc-models/preflight.json
sudo systemctl start nginx
sudo /opt/conda/envs/smartfactorymodels/bin/python scripts/deployment/manage.py start --host ai-b --manifest /etc/cnc-ai/deployment.json
sudo systemctl enable cnc-model-ai-b-conversation-1 cnc-model-ai-b-conversation-2 cnc-model-ai-b-code cnc-model-ai-b-safety cnc-model-ai-b-embedding cnc-model-ai-b-reranker
```

For normal operation each node keeps its own weight files; it does not mount them from its peer. Allow the CPU app IP to reach only the specified TLS model ports. Allow controlled management from the administration network. Deny public egress and all inference-to-controller traffic. The nginx IP allowlist complements, rather than replaces, the host/network firewall.

### 13.7. CPU application and data server

Install the application wheelhouse offline and nginx. No GPU/CUDA is needed here. The default generated environment explicitly uses in-process numerical computation and the local SQLite historian for initial validation. Connect a larger approved historian separately if required; factory document approval restrictions remain active.

```bash
conda create -n smartfactoryllm python=3.12 pip --offline
conda activate smartfactoryllm
python -m pip install --no-index --find-links /srv/transfer/app-wheelhouse cnc-first-ai==11.2.0
sudo useradd --system --home-dir /var/lib/cnc-ai --create-home cncai
sudo install -d -o root -g cncai -m 0750 /etc/cnc-ai
sudo install -d -o cncai -g cncai -m 0700 /var/lib/cnc-ai
sudo install -m 0644 config/deployment.json /etc/cnc-ai/deployment.json
sudo install -o root -g cncai -m 0640 deployment/generated/app/app.env.example /etc/cnc-ai/app.env
sudo install -m 0644 deployment/generated/app/cnc-ai.service /etc/systemd/system/
sudo install -m 0644 deployment/generated/app/nginx-app.conf /etc/nginx/conf.d/cnc-ai.conf
```

An offline Conda command succeeds only when its interpreter packages were staged. An approved offline Python 3.12 installer plus a new `venv` is an alternative; update generated service interpreter paths consistently if using it. Populate the five service keys, CA certificate and the CPU server certificate/private key. Add real controller credentials only after separate commissioning. Never copy them to an inference host.

For **new training data only**:

```bash
sudo -u cncai env CNC_HOME=/opt/cnc-ai CNC_DATA_DIR=/var/lib/cnc-ai CNC_CONFIG_DIR=/opt/cnc-ai/config /opt/conda/envs/smartfactoryllm/bin/python -m cnc_ai db init --sample
sudo -u cncai env CNC_HOME=/opt/cnc-ai CNC_DATA_DIR=/var/lib/cnc-ai /opt/conda/envs/smartfactoryllm/bin/python -m cnc_ai user add admin --role admin
```

Create operator and supervisor accounts in the same way. For a new factory database omit `--sample`; for an existing one use `db migrate` only after backup. Initialize before starting the service; startup never silently seeds or migrates data.

```bash
sudo nginx -t
sudo systemd-analyze verify /etc/systemd/system/cnc-ai.service
sudo systemctl daemon-reload
sudo systemctl enable --now nginx cnc-ai
sudo -u cncai /opt/conda/envs/smartfactoryllm/bin/python scripts/deployment/probe.py --manifest /etc/cnc-ai/deployment.json --env-file /etc/cnc-ai/app.env --wait-seconds 30
```

The probe tests all twelve instances and prints only service/model/revision results. Perform [capacity testing](CAPACITY_TESTING.md) and the disconnected cold start before acceptance. Use the factory browser URL, not an AI service URL. Browsers never receive model service keys.

### 13.8. Docker scope

`deployment/docker/compose.yml` runs **only the CPU application**, not twelve GPU services. It uses the host network and must sit behind the site's TLS proxy. Provision the runtime, environment and read-only configuration first. Build and transfer the image on a matching connected staging host; record the image digest, export with `docker save`, verify its checksum and import with `docker load`. Do not run a second application authority alongside systemd. Docker/OS qualification remains separate from the tested Python application.

### 13.9. Upgrade an existing factory installation


The exact baseline archive is `CNC_First_Industry_AI_Platform_v11.1.0_RCA.zip`, SHA256 `123b192ae7a105124efe3ffd7e28f3aa970f81a653ef3c18b4ca422c3d10d8ee`. Keep it unchanged with its v11.1 wheel/environment and a pre-upgrade consistent data/configuration backup. The release inventory records every baseline file. The separately retrieved plain-language manual and source inspection were used as references; no distinct earlier hardware recommendation file was found beyond the current supplied specification.

1. Stop/fence the application and recorder. Keep real writes disabled. Create and verify a backup using `scripts/deployment/backup.py` and retain the original release separately.
2. Extract v11.2 into a different directory. Create `smartfactoryllm_v112` with Python 3.12. Install its wheel/dependencies. Do not edit or overwrite the old environment.
3. Copy the runtime/configuration into an isolated upgrade test location. Point `CNC_DATA_DIR` there. Keep model/OPC UA credentials out of this test and use simulator mode.
4. Run `python -m cnc_ai db migrate`. Migrations 001–004 must have their original checksums. Migration 005 adds the persistent job table, indexes and model-call request ID; it does not reseed existing data. Verify users, conversations, approvals, documents, audit and RCA revisions.
5. Review the new `config/deployment.json`, preserve site policies and mappings, set the same model commits on both AI hosts, verify snapshots, and generate host-specific assets. Old `*_FALLBACK_URLS` remain a workstation/optional-specialist compatibility path; factory routing uses the manifest instead. Existing alternate Coder-Next configuration is not accepted under the default eight-GPU manifest.
6. Install the twelve independent services and test all role contracts. Run synthetic and physical-host acceptance separately. Only after the test migration succeeds should the stopped production runtime receive the same additive migration.
7. Start the sole application authority with the new environment and site configuration. Pending work interrupted by restart is explicitly failed/cancelled, never replayed. Operators can review retained records and explicitly resubmit/reassess.

Rollback uses the original v11.1 code/environment **and the pre-upgrade consistent backup**, restored to a new directory after fencing v11.2. Do not run older code against a newer database or delete migration rows. Keep post-upgrade evidence as a separate archive so rollback does not erase the history of work performed. Reconcile any real controller changes independently before commissioning the rollback authority.

### 13.10. Air-gapped preparation and transfer


Normal operation uses only local factory services and bundled browser assets. Public model downloads and dependency installation occur on connected staging, not the factory. Offline environment flags suppress common library downloads; enforce network egress policy and test actual behavior as well.

Prepare matching x86-64 Linux and Python 3.12 media. After qualifying the complete RTX serving installation, freeze it and create a transfer bundle outside both the source and weight trees:

```bash
conda activate smartfactorymodels
python -m pip list --format=freeze > /srv/staging/qualified-inference-lock.txt
conda activate smartfactoryllm
python scripts/prepare_airgap.py --output /srv/transfer --inference-lock /srv/staging/qualified-inference-lock.txt --model-root /srv/ai/models --copy-models
python scripts/verify_bundle.py /srv/transfer
```

Do not label an untested environment export as qualified. The helper creates an application wheelhouse, inference wheelhouse, source archive, checksums and optional copied snapshots. Optional historian/forecast/browser packages require their respective `--extra` selections; browser executables and OS libraries need separate staging. The core CPU profile uses in-process numerical analysis and does not require a public license service. Optional products may have different license obligations.

Prepare OS packages, an offline Python/Conda installer and its package cache, signed NVIDIA driver packages, the chosen GPU runtime, nginx/systemd dependencies, certificate chain, internal DNS/time configuration and a rollback copy of v11.1 plus its environment. Include signed container images and saved image digests only if using the app-only Docker alternative. Do not assume pip wheels contain OS drivers or that Linux and Windows wheels are interchangeable. Protect the transfer manifest and check every checksum at both ends.

On each inference host, copy complete models to local read-only storage, retain `.factory-downloads` metadata, verify all hashes and the pinned manifest, provision separate writable caches, and install its generated systemd/nginx files. On the CPU host, install the application from its wheelhouse using `--no-index`, initialize or migrate the database explicitly, and use the generated protected app environment. Provision secrets and certificates separately; do not embed them in the source ZIP.

Configure the firewall to permit browser-to-CPU HTTPS, CPU-to-inference TLS ports, approved management, and internal DNS/NTP only where needed. Inference nodes must not reach controller networks or public internet. Restrict the OPC UA path to the commissioned CPU service account and approved controller endpoints. Do not disable TLS validation.

Perform a cold reboot with external egress blocked. Capture firewall counters/packet records for attempted public destinations while starting services, signing in, ingesting an approved document, answering a cited question, producing a report and running an RCA. Verify all twelve model instances and the expected cache paths. A synthetic application egress test is included, but the actual factory/network/GPU cold start was not run here.

Keep the old code/environment, model revisions and a consistent pre-upgrade database/document/configuration backup for rollback. Follow `MIGRATION_V111_TO_V112.md`; do not automatically replay jobs or machine writes after recovery.

## 14. Operate, maintain and recover the service


Use a named administrator and preserve the release, runtime/configuration backup, dependency locks, model manifests and site evidence. Logs and backups contain sensitive operational records; restrict permissions and use encrypted independent backup storage with tested restoration.

### 14.1. Inference maintenance

Drain the node from the authenticated CPU API before stopping services. Sign in through a site-trusted browser or a session-aware HTTP client, obtain its CSRF token, and send `POST /api/inference/nodes/ai-a/drain` with `{"draining":true}` and `X-CSRF-Token`. This endpoint requires `settings.manage`; it is not an unauthenticated model-host command. Inspect `GET /api/status` until that node's in-flight counts reach zero. Drain state is process-local; keep the app running during node maintenance. After an app restart, drain again before continuing maintenance.

On the drained node:

```bash
sudo /opt/conda/envs/smartfactorymodels/bin/python scripts/deployment/manage.py stop --host ai-a --manifest /etc/cnc-ai/deployment.json
sudo /opt/conda/envs/smartfactorymodels/bin/python scripts/deployment/manage.py start --host ai-a --manifest /etc/cnc-ai/deployment.json
```

Use `ai-b` for B. To restart only the reranker, use `sudo systemctl restart cnc-model-ai-a-reranker`. Inspect its own journal. Restore the node through the same drain API with `{"draining":false}`. Recovery clears readiness and requires fresh identity/inference probes. Do not assume the remaining host will maintain the same latency while its peer is unavailable.

### 14.2. Application maintenance and backup

Tell users maintenance is starting and allow jobs to finish where possible. Stop the single app authority and telemetry recorder. Cancelled/interrupted jobs are not automatically replayed after restart. A snapshot of a running application folder is not a consistent multi-file backup.

```bash
sudo systemctl stop cnc-ai cnc-telemetry
sudo -u cncai /opt/conda/envs/smartfactoryllm/bin/python scripts/deployment/backup.py create --data /var/lib/cnc-ai --config /etc/cnc-ai --destination /srv/backup/cnc-2026-09-10
python scripts/deployment/backup.py verify --source /srv/backup/cnc-2026-09-10
```

The backup tool acquires the application/recorder authority locks, uses SQLite's backup interface for database files, copies document/source/configuration files, and verifies hashes. It refuses existing backup destinations. Give the backup account access only to a protected destination. If other site writers exist, stop/fence them too; a Python lock cannot fence another physical server or an unrelated external tool.

Restore only to a new empty location on a stopped, fenced target:

```bash
python scripts/deployment/backup.py restore --source /srv/backup/cnc-2026-09-10 --destination /srv/restore/cnc-2026-09-10
```

Review `data/` and `configuration/`, restore correct OS ownership, set the new environment paths, and keep writes disabled. Prove the old authority cannot operate, verify the audit chain/migrations, and reconcile controller state before enabling the recovered authority. Never start two authorities against shared SQLite, and never replay a proposal simply because a backup predates its result. Inference resilience is not automatic stateful application failover.

### 14.3. Capacity and retention

Back up both authoritative data and separately retained historical mappings. Suggested usable capacity begins at 12–24 TB, then calculate: retained full backups + retained daily changes + document/history growth + model rollback generations when stored there + at least 20% working headroom. For example, two 3 TB full backups plus thirty 100 GB daily change sets use 9 TB before headroom; a 25% reserve raises this to 11.25 TB. This is a sizing example, not measured factory growth. RAID 1 survives some drive failures; it does not protect against deletion, corruption, ransomware or a site loss.

### 14.4. Interpret model and job status

A reachable server is not necessarily a ready model. The router verifies the exact model and immutable revision, then checks the role-specific inference contract. Status distinguishes unchecked, ready, cooling down, draining and unavailable instances. A cooling-down instance is temporarily excluded after failure. A drained node accepts no new model requests. The displayed in-flight count is admitted model calls, not signed-in clients.

The browser polls recorded job state and displays a final answer only after its required output review. It does not display hidden model reasoning or partially reviewed tokens. Queue positions are estimates because fairness can move other users ahead. Queue-full errors request waiting or cancellation; failed or restarted jobs require explicit resubmission. Cancellation never reverses an already recorded business operation or stops a physical spindle.

### 14.5. Common problems

| Symptom | Action |
|---|---|
| Module not found | Activate the intended environment and install this package with pip. Run python -m cnc_ai from the project root; do not import a root-level db module. |
| PowerShell curl behaves unexpectedly | Use Invoke-RestMethod or curl.exe explicitly. |
| Model advertised but not ready | Run the per-instance contract probe and inspect the private service journal. Check model revision, chat template and key without sharing secrets. |
| Queue full | Let an existing job finish or cancel your queued job. Do not repeatedly resubmit. |
| One AI node lost | Healthy instances continue with lower capacity; expect longer waits. Follow the drain/recovery runbook. |
| Document evidence unavailable | Check permissions, approval, revision fingerprint and the reranker/embedding service status. Never weaken source authorization to restore a result. |
| Uncertain machine write | Keep the execution lock and reconcile with native controller evidence using the commissioning procedure before any retry. |
| Application server lost | Fence the old authority and restore a consistent backup. There is no automatic stateful failover. |


## 15. Validate capacity and understand limits


A client is an authenticated browser session performing work. Fifty accounts alone prove nothing about capacity. The repeatable harness creates isolated sample data and separate authenticated users, starts the real Flask/Waitress application, submits HTTP jobs, polls status and records outcomes. It never configures real OPC UA or executes a physical action.

### 15.1. Targets recorded before site acceptance

| Check | Initial target | Interpretation |
|---|---|---|
| Synthetic application status p95 | At most 2 seconds | Login/status/cancel remain responsive during slow jobs |
| Unexpected synthetic job error rate | At most 1% | Admission/context refusals must be separately counted |
| Routine real-model completed response p95 | At most 60 seconds | Proposed target for the agreed short/typical corpus |
| Long real-model job p95 | At most 300 seconds | Long lane, separate from routine requests |
| Real-model queue wait p95 | At most 30 seconds | Revisit worker/instance budgets using measurements |
| Safety and isolation | Zero unauthorized writes/data leakage | Never relax to improve throughput |

GPU targets are proposals, not achieved measurements. Define the factory's exact workload, acceptable wait, source quality and output quality before accepting the installation. If GPU 3 contention or generation quality fails, reduce scheduling pressure within the eight-GPU budget and remeasure; do not silently enable extra GPUs, quantization, truncation or skipped Guardian review.

### 15.2. Synthetic application test

Run on Linux with the installed test application package:

```bash
python scripts/evaluation/load_clients.py --mode synthetic --clients 5 10 25 50 --rounds 2 --duration 30 --deny-public-egress --output /tmp/synthetic-load.json
```

This runs bursts, sustained mixed workloads, conversation hotspots, serial long-input cases and a simulated AI A outage. The mixture includes chat/RAG, read-only SQL plans, Guardian input/output requests, embeddings, reranking, document ingestion, reports, RCA submission and status polling. The deterministic model transport intentionally cannot establish real language quality or GPU throughput. The egress hook records actual socket connects and rejects non-loopback destinations; no public connection should be attempted in this synthetic run. It is an application-level egress test, not proof of the factory firewall or a GPU host's offline cold start.

The harness records completed latency p50/p95/p99, queue wait, first reviewed final output, throughput, status latency, failures, role calls, instance distribution, peak process memory and degraded-node phases. The output also records revisions and cache conditions. Synthetic input token counts are approximations; true token lengths must be measured by the actual service tokenizer. A 32K input plus output/schema/evidence can exceed the configured 32K total limit; that case must explicitly fail with a context-budget error rather than truncate evidence. Long cases are submitted serially, not fifty at once.

### 15.3. Actual model contracts and load

With verified snapshots and the twelve services available, first run:

```bash
python scripts/deployment/probe.py --manifest /etc/cnc-ai/deployment.json --env-file /etc/cnc-ai/app.env --wait-seconds 30
```

The probe verifies immutable aliases and actual chat JSON, Guardian yes/no, vector dimensions and reranker scoring. Next use the same isolated load harness with **site credentials in the process environment**, a qualified manifest and `--mode models`. Do not use `--deny-public-egress` here, because it intentionally permits only loopback; use site firewall restrictions instead.

```bash
python scripts/evaluation/load_clients.py --mode models --manifest /etc/cnc-ai/deployment.json --clients 5 10 25 50 --rounds 3 --duration 900 --output /srv/acceptance/physical-model-load.json
```

Run this from the CPU evaluation environment. Keep production data/credentials for controllers out of that process. Actual models may produce different plans; investigate model-contract/quality failures instead of altering guards. Record source and dependency locks, driver/CUDA, firmware, all eight GPU serials/memory/power caps, hardware, cache state, request lengths, output lengths and exact duration. Save `nvidia-smi` metrics during the run. Evaluate approved factory questions/citations and Guardian false positives/negatives separately; synthetic fixture answers are not that evaluation.

Test loss of A, restoration, loss of B, restoration, and only the reranker stopping. Use the drain API for planned maintenance; an approved fault test can stop one host without a drain. Measure degraded latency and distribution. The unit fault tests cover routing logic but cannot prove physical-host resilience. Test all three GPU 3 services starting and serving simultaneously under long reviews and retrieval batches. Never reset GPU power limits as part of this test harness.

### 15.4. Remaining independent gates

- Matching-hardware clean offline installation and cold start with public egress denied at the host/network boundary.
- Windows/PowerShell execution on the supported workstation image.
- Nginx/systemd/Docker checks on the chosen factory OS and deployment method.
- Data mapping and multilingual retrieval/answer/diagnosis quality on the site's approved corpus.
- Human-approved controller commissioning, native safety enforcement, uncertain-write recovery and physical response verification.

Record each gate as PASS, FAIL, BLOCKED or NOT RUN with evidence. The release validation report lists which of these were actually executed here.

### 15.5. What this release does and does not prove

Read docs/VALIDATION.md and docs/v112/ for the measured software results. The source was compared with the exact v11.1.0 archive, its baseline tests were run, and defects were repaired between passes. The synthetic harness uses separate authenticated users, isolated sample records and synthetic model responses. It tests application behavior and bounded distribution, not model knowledge, GPU throughput or cutting safety. No physical CNC action was issued from this workspace. Real eight-GPU/fifty-client acceptance, Windows execution, site TLS/firewall rules, offline GPU cold starts, full runtime locking and machine commissioning remain on-site gates.

Keep the model set, corpus, reviewed precision, context limits and acceptance targets fixed during comparison. An approximately 32K input can exceed a 32K total model context once instructions, evidence and output tokens are counted. The application counts the full templated request and rejects over-budget requests; it does not silently remove evidence or skip review.

## 16. Plain-language glossary

| Term | Meaning in this installation |
|---|---|
| Server | A computer that runs shared services for other computers. This installation has two AI servers and one CPU application/data server. |
| Client | The user’s browser computer. It does not install this project or model weights. |
| Node | One participating server; AI A and AI B are separate inference nodes. |
| Rack, 2U and chassis/model number | A rack holds equipment. 2U describes a height of about 89 mm. The chassis is the enclosure and motherboard platform; SYS-212GB-FNR identifies a particular platform, not every installed component. |
| CPU | The general-purpose processor that runs application logic and coordinates work. |
| GPU and GPU memory | A graphics/AI processor and its own high-speed memory. Each specified card has 96 GB; separate cards do not automatically share one memory pool. |
| ECC RAM | Main system memory with error correction. It is separate from GPU memory and storage. |
| Boot SSD | A solid-state drive used to start the operating system. Boot describes its purpose, not its connection technology. |
| NVMe and drive form factor | NVMe is a storage interface/protocol over PCIe. Form factor is the physical size/connector, such as M.2, E1.S or U.2. A boot drive may also be NVMe. Bays must match the actual drive. |
| Mirroring / RAID 1 | Two drives hold the same data. Two 7.68 TB drives provide roughly 7.68 TB usable before overhead. Mirroring is not a backup. |
| Backup | A separate protected copy with a tested restore procedure and retained versions. |
| PSU and redundancy | A power supply unit converts electrical power for the server. Redundancy means the remaining qualified equipment can carry the required load after a failure; two PSUs alone do not prove this. |
| UPS and PDU | An uninterruptible power supply provides temporary power; a power distribution unit distributes it within the rack. Shared units can still be common failure points. |
| Fans and cooling | Components and airflow that remove heat. The complete server and room must handle the approved heat load. |
| PCIe | The internal connection used by GPUs, NICs and NVMe storage. Lane allocation and risers must be qualified. |
| NIC and Ethernet | A network interface card connects a server to the Ethernet network. Ordinary private 10 Gb Ethernet carries these service requests. |
| IP and port | An IP address identifies a network endpoint; a port distinguishes a service on that endpoint, such as conversation on 8001. |
| TLS | Encrypted, authenticated transport using certificates trusted by the site. Do not disable certificate validation. |
| API | A defined request/response interface between programs. The application API and model APIs are different trust boundaries. |
| Replica and load balancer | A replica serves the same model/revision on another instance. The request distributor acts as a bounded load balancer across healthy compatible instances. |
| BF16 | A 16-bit numerical format used for initial model weights/computation. A change of precision requires quality and compatibility tests. |
| Tokens and context | Tokens are pieces of text processed by a model. Context is the total allowed input and output budget, including instructions and retrieved evidence. |
| Cache | Stored work reused for speed, such as model key/value state. Cache memory can grow with context and concurrent requests. |
| Batching and concurrency | Batching combines model work for execution. Concurrency is the number of overlapping requests; fifty signed-in clients need not mean fifty simultaneous GPU generations. |
| Queue | A bounded list of admitted work waiting for a suitable worker. This application stores jobs persistently and schedules users fairly. |
| Failover | Using a healthy alternative after failure. Model-node recovery does not automatically recover or duplicate the stateful application server. |

### 16.1. Source and revision record

This manual edits the supplied Smart_CNC_Factory_v11.1.0_User_Manual_Plain_Language.docx. Chapters 1–11 retain its CNC, complete-machine assembly, evidence, planning, telemetry, engineering and RCA guidance, with revised queue/cancellation/recovery language. The deployment chapters are rebuilt against the v11.2 manifest and final scripts. The exact original source archive remains preserved separately and is identified by SHA-256 in docs/v112/baseline_inventory.json. Historical packaged documentation stays under docs/history/v111/. See docs/v112/DOCUMENTATION_AUDIT.md for file-by-file status. Hardware and runtime sources are linked in HARDWARE.md and MODEL_COMPATIBILITY.md. The separate earlier hardware recommendation was not found; the latest supplied implementation specification provides the new hardware target.

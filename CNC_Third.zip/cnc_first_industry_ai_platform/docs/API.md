# Local application API

The browser uses the same-origin JSON API below. It is an authenticated application boundary, not a public inference endpoint. Core inference ports 8001–8005 and optional specialist ports 8006–8007 are separate services. Do not expose the application or inference API directly to the internet.

Sign in with `POST /api/login` and a JSON object containing `username` and `password`. The response sets an HttpOnly session cookie and returns a CSRF token. Send that cookie on authenticated requests and the returned token as `X-CSRF-Token` on every mutation. `GET /api/session` refreshes the client's view of identity, permissions and the token. Login uses same-origin checks; site HTTPS deployments require the configured trusted proxy and secure cookies.

| Method and path | Purpose |
|---|---|
| GET `/api/health` | Unauthenticated application liveness/version only |
| GET `/api/status` | Database/RAG status, cached per-instance readiness (no blocking inference probe) and configured controller mode |
| POST `/api/models/verify` | Administrator-triggered real model request checks |
| GET `/api/conversations` | Current user's recent conversations |
| GET `/api/conversations/<key>` | Current user's messages and evidence |
| POST `/api/chat` | Strict `ChatRequest`: bounded planning, RAG/SQL evidence and answer, or a control proposal |
| POST `/api/speech/transcribe` | Optional multipart WAV transcription for operator review; no chat submission or control action |
| GET/POST `/api/documents` | List or ingest a multipart file with kind, sector and revision |
| DELETE `/api/documents/<key>` | Delete a source and its linked reports; prior answer evidence remains |
| POST `/api/documents/rebuild` | Rebuild document vectors for the current embedding fingerprint |
| GET/POST `/api/reports` | List reports or summarize a document |
| GET `/api/reports/<key>/evidence` | Source chunks cited by a report |
| DELETE `/api/reports/<key>` | Remove the summary while retaining the document |
| GET `/api/control/status` | Read current configured CNC-01 snapshot and telemetry health |
| POST `/api/control/preflight` | Evaluate a strict `ControlRequest` without issuing a write |
| GET/POST `/api/control/proposals` | List visible proposals or create a persistent proposal |
| POST `/api/control/proposals/<key>/decision` | Separate supervisor `Approval` decision |
| POST `/api/control/proposals/<key>/execute` | Requester confirmation and live deterministic recheck before a typed write |
| GET/POST `/api/sources` | List approved/visible sources or quarantine an uploaded SQLite file |
| GET `/api/schema?source=factory` | Approved query schema |
| GET `/api/sources/<key>/schema` | Administrative import-schema review |
| POST `/api/sources/<key>/approve` | Approve a reviewed table/column mapping |
| POST `/api/sources/create` | Create an analytical database from a validated definition |
| POST `/api/query` | Execute a strict `Query` inside `{query, source}` through read-only authorization |
| GET/POST `/api/sectors` | Read profiles or administer an analytical sector profile |
| GET/POST `/api/ui-text` | Read or administer translated fixed navigation labels |
| GET `/api/audit` | Authorized audit-event review |
| POST `/api/logout` | Invalidate the browser session |

Permissions are enforced by the web and service layers; possession of a CSRF token alone grants no role. Private conversation IDs, evidence IDs and proposal IDs are opaque references and never authorization credentials. Generated SQL cannot change users, approvals, policy or machine authority. Additional analytical sources cannot replace the CNC controller's authoritative data.

The execution request body is `{"confirmation":"EXECUTE APPROVED ACTION"}`. It contains no node ID, arbitrary OPC UA value or alternative machine action. Approved proposal fields are loaded from persistent state, checked against current identity/policy/context and consumed before network I/O.

Speech transcription requires `chat`, a current session and CSRF token, plus `CNC_SPEECH=true` and local model mode. Send multipart fields `file` and `language` (a supported UI language code). Only complete mono 16 kHz PCM 16-bit WAV, up to 30 seconds and 1 MiB, is accepted. The response is a JSON object matching `TranscriptionDraft.schema.json`; `review_required` is always true. Audio is sent to the configured local Whisper service and not stored. The endpoint never calls chat or machine-control services. Disabled or unavailable speech returns a readable 503. See OPTIONAL_SPECIALISTS.md for the explicit review-and-send UI.

JSON schema exports for Query, ControlRequest, Plan, Answer, Approval, Evidence, AuditEvent and ChatRequest are in `contracts/`; their authoritative Python definitions are `src/cnc_ai/contracts.py`. Pydantic rejects unknown fields and performs additional coherence checks beyond JSON Schema (for example, only a control plan may contain a control request). Never treat a model-constrained output as proof that the underlying request is permitted.

Failures return a readable `error` and a `request_id` for log correlation. Typical status codes are 400 for invalid requests, 401 for missing/expired sessions, 403 for denied permission/session verification, 409 for uncertain write outcomes, 503 for unavailable or invalid model responses and 500 for unexpected server failures. Raw backend tokens and exception bodies are not returned. `/api/health` success does not imply database, model or CNC readiness; use the authenticated status and explicit validation commands.

## Intelligence APIs

All app routes use existing session, current-role and CSRF protection.

| Route | Contract / behavior |
|---|---|
| GET /api/intelligence/status | Numerical transport and historian status |
| POST /api/timeseries/{kind} | AnalysisQuery; retained analysis and evidence |
| GET /api/analyses/{key} | Original analysis for authenticated owner |
| POST /api/knowledge/trace | ThreadQuery; source-bound relationships |
| POST /api/knowledge/rebuild | Administrative projection rebuild |
| POST /api/planning/schedule | ScheduleInput; deterministic allocation |
| POST /api/calculations/{kind} | cutting or oee typed inputs |
| POST /api/artifacts | CodeCandidate; static draft check |
| POST /api/artifacts/{key}/attest | Attestation; ordered human report/hash gate |
| GET /api/artifacts/{key}/export | Approved engineering ZIP, no program transfer |
| POST /api/documents/{key}/approve | Comment; distinct supervisor revision approval |
| POST /api/vision | Optional bounded multipart PNG/JPEG and question |
| GET /api/observability | audit.read; aggregate service/agent/audit metrics |

Separate port 8100: GET /health and Bearer-authenticated POST /v1/timeseries/{kind}. This accepts AnalysisInput, not SQL, file paths or OPC UA nodes. Kinds: anomaly, trend, change-point, forecast, health, tool-condition, quality-risk, rul. The app checks response input hash, machine and kind before persistence. Exported JSON schemas complement runtime coherence/permission checks; constrained output alone grants no authority.

## Root cause investigations

Version 11.1 adds `/api/rca/*` and a validated RCA mode to `/api/chat`. Session/CSRF, owner or reviewer access, data permission and document permission protect the full trace and export. See [RCA developer guide](rca/DEVELOPER_GUIDE.md) for endpoints and contracts.

## Persistent jobs in v11.2

In the factory profile, chat, ingestion, reports, rebuild and model verification return HTTP 202 with `{"job": {"id": "...", "state": "queued"}}`. Workstation callers can request the same contract with `Prefer: respond-async`; the bundled UI does so. `GET /api/jobs` lists the current account's recent jobs; `GET /api/jobs/<id>` returns its current authorized state and completed result; `POST /api/jobs/<id>/cancel` requires CSRF and records cooperative cancellation. Active requests may finish a bounded read before stopping. Completed results are withheld on cancellation or permission revocation. Restart fails unfinished jobs without replay. Explicit resubmission is required. The browser displays recorded state, then reviewed final output; it does not stream raw model tokens.

RCA start returns the investigation record while a linked job is queued in its dedicated lane. Saved cases retain their existing authorized case/reviewer access. A queued cancellation or expiry also terminates the case and records an event.

`POST /api/inference/nodes/<host>/drain` with `{"draining": true}` requires settings-management permission and CSRF. It changes routing admission in the active process, not the host's power/service state. In-flight inference finishes; persist maintenance by stopping the intended service through the runbook. Resume with false and re-probe. All mutation routes enforce an Origin check when supplied, as well as session/CSRF authorization.

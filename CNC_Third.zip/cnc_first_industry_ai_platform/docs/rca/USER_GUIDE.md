# CNC root cause investigation guide

Version 11.2.0 preserves the inspectable investigation workflow to the existing CNC Factory Assistant. Use it to compare recorded production, explain stops and scrap, investigate complete-machine assembly and acceptance, and examine work-order capacity risk. Each conclusion retains the records, calculations and checks that produced it. Operational changes continue through the existing, separately authorized factory workflows.

This guide supplements the v11.2 manual in `docs/USER_MANUAL.docx`. RCA reuses the five core models, database, RAG and deterministic control boundary. The factory has two four-GPU RTX inference servers and one CPU application server. RCA has two execution slots within the bounded application queue; fifty browser users do not mean fifty simultaneous investigations.

## Launch in a separate upgrade environment

First follow `docs/MIGRATION_V111_TO_V112.md` to preserve v11.1 and back up and migrate an isolated data copy. From this extracted project in Anaconda PowerShell Prompt:

```powershell
conda create -n smartfactoryllm_v112 python=3.12 pip
conda activate smartfactoryllm_v112
python -m pip install --upgrade-strategy only-if-needed -e '.[test,download]'
python -m pip check
python -m cnc_ai db migrate
python -m pytest
.\scripts\windows\start.ps1 -EnvironmentName smartfactoryllm_v112
```

Run `db migrate` only after pointing `.env` to the intended existing database copy. Migration 005 adds jobs and model request IDs; prior RCA tables and business records are retained. Existing launch scripts remain available. Linux uses `bash scripts/linux/start_app.sh`. For a new installation, use the eleven steps in README.md, including named accounts and `db init --sample` for a training database. Do not run the sample initializer against factory data.

The retained `pytz` dependency supplies factory timezone data. Keep existing model snapshots; configure the new factory replicas through `config/deployment.json` and follow the server guide. Installing the application does not download weights.

## Try the isolated training cases

Use a separate development runtime. Set these values in its `.env`, leaving real machine settings out of that runtime:

```dotenv
CNC_PROFILE=development
CNC_MODEL_MODE=demo
CNC_OPCUA_MODE=simulator
CNC_RCA_DEMO=true
```

With an administrator account already created, run:

```powershell
python -m cnc_ai rca demo --user admin
python -m cnc_ai serve
```

The demo command creates `rca-demo.db` beside the runtime database. It refuses to overwrite an existing file and does not insert demo history into operational tables. At sign-in, choose **Synthetic training cases** in the **RCA evidence** selector. The Investigations page also has an example button. Every training investigation carries a synthetic-data badge.

Ask: “Why did CNC-03 production decrease on 2026-09-08?” Use that explicit date when trying the fixed demo; “yesterday” follows the current factory calendar and will eventually refer to a different date. The fictional shift is 07:00–15:00 in America/Chicago. Expected findings are stored separately in `samples/rca/cases.json`; the agent reads history records, not the expected answers.

## Start a factory investigation

Select **Factory history** and ask a normal question containing the resource, manufactured machine or work-order identifier and a completed shift date. Examples include “Why did CNC-03 production decrease yesterday?”, “Why did scrap increase on CNC-07 on 2026-09-08?” and “Why is MX-500 assembly behind schedule on 2026-09-08?” No command prefix is required.

Open **Interpreted scope** before accepting a comparison. It shows the selected entity type, date, shift, timezone, comparison basis and UTC bounds. A resource is equipment doing production; a finished machine is the product being built. The same identifier in two categories requires clarification.

For production, “decreased” normally compares the preceding operating shift. “Below plan” uses recorded planned good output, and “last week” uses the corresponding prior-week shift. The executor checks part, operation, revision, mix, scheduled time and cycle-time normalization. Good and scrap must be separate final-operation quantities. A smaller raw count alone may not establish a decrease.

Idle duration is measured from recorded stop intervals. Acceptance uses recorded test measurements and limits. Assembly and due-date cases use recorded progress or planning capacity; they do not imply a historical production comparison. A prior-week comparison for those topics currently asks for a separately qualified mapping. A forecast of due-date risk is explicitly an estimate, not an observed late delivery or an APS simulation run.

When a date, shift or identifier is materially ambiguous, the investigation asks a focused question. If history is missing or its semantics are unqualified, it stops with that limitation. Current OPC UA readings are never substituted for yesterday’s records.

## Read the three levels of detail

**Summary** gives the main finding, completion status, investigation ID, revision, data cutoff and independent human-review state. A completed investigation can still have inconclusive causes. Completion means the bounded workflow finished; it does not mean every cause is known.

**Investigation** shows chronological checks recorded by the backend executor. Expand a check to see its purpose, tool, actual start and finish time, arguments, returned finding, evidence references and effect on the investigation. Planned means it has not started. Running means execution began. Completed means the executor returned a result. Failed, skipped and cancelled are distinct and never count as successful source checks. A running retry event means another bounded attempt is being made.

**Evidence** opens authorized source snapshots, document excerpts, provenance and content hashes. The display shows event and retrieval times, source revision and quality. A source that changed or became unavailable is flagged while the retained snapshot remains intact. A hash verifies that snapshot integrity; it does not prove that a source system recorded the truth.

Approved manuals supply background mechanisms. They cannot prove an incident happened. Source text is treated as data, even if it contains instructions asking the assistant to ignore policy. The interface presents concise decisions and executor records, not private model reasoning or system prompts.

## Interpret findings and the causal map

| Evidential state | Meaning |
|---|---|
| Hypothesis | A possible explanation awaiting the required checks. |
| Supported | A linked event sequence and mechanism support a contribution; required verification or criterion approval is incomplete. |
| Confirmed | The configured criterion has a current factory approval and its linked verification records pass. Training cases use an explicitly synthetic criterion. |
| Contradicted | Returned records directly contradict this explanation within the selected scope. |
| Inconclusive | Evidence is missing, poor quality, conflicting, or unable to establish causation. |

Each relationship in the map has a text label as well as line styling. Expand the relationship to inspect its mechanism, supporting records, contradictions and missing confirmation. On a narrow screen, scroll the diagram horizontally or read the full relationship descriptions beneath it.

Several causes may contribute to one problem. A coincident temperature rise is not proof of causation. Missing records do not refute a hypothesis. An immediate cooling fault can be confirmed while the reason for degradation remains unresolved; the agent does not infer maintenance negligence from a blocked filter.

Human review is separate. An authorized reviewer can record **Acknowledged** or **Needs more evidence** after the investigation stops. That action does not upgrade a hypothesis to Confirmed. No numerical probability or confidence percentage is manufactured.

## Inspect the production loss example

Open **Calculations and assumptions** in the CNC-03 training case. Both shifts have 480 scheduled minutes and a recorded standard cycle of 120 seconds. The comparison shift has 230 good pieces and 10 scrap; the investigated shift has 160 good and 20 scrap.

| Quantity | Backend result |
|---|---:|
| Good-output shortfall | 230 − 160 = 70 pieces |
| Two overlapping stop intervals | 90 + 75 − 45 = 120 minutes |
| Estimated downtime loss | 120 minutes ÷ 2 minutes per piece = 60 pieces |
| Additional scrap | 20 − 10 = 10 pieces |
| Scheduled capacity difference | 0 pieces |
| Unexplained residual | 70 − 60 − 10 = 0 pieces |

The 60 pieces are a constant-cycle counterfactual estimate, not observed recoverable production. The residual is shown, even when nonzero or negative. Overlapping reason codes are unioned before conversion. Loss attribution is withheld across incomparable part/operation/revision grains, multiple current grains or a plan-only baseline. The entire shortfall is not automatically assigned to the cooling event.

## Continue and revise an investigation

Follow-up questions in the same conversation can request evidence, remaining causes or required confirmation. “Compare this with last week” starts a new revision using that comparison. “Reassess using the new maintenance report” starts a revision; first ensure the report has been published through the approved history mapping or approved document workflow.

**Add source evidence** accepts a real record ID from the configured, authorized history source plus a reason. It does not accept an invented event or grant permission to another machine. A submitted snapshot becomes an input to a subsequent reassessment, and can include recorded verification after the investigated shift. A manual excerpt alone still cannot confirm the event. Adding a record leaves the old finding unchanged.

**Reassess** creates a new revision with a reason and fresh cutoff. The owner can revise the question, date and baseline. The original remains available under **Revision history**. Reviewers can add records and review notes; the owner starts a revision. Exports include the authorized evidence and technical record and remain sensitive factory files subject to the site’s retention rules.

Use **Cancel investigation** while checks are running. Cancellation takes effect at an execution checkpoint; a bounded in-flight read may finish first. Its unused result is not promoted into successful evidence. Saved investigations remain under **Investigations** after sign-out or restart.

## Understand an incomplete result

The defaults allow depth 3, 16 tool attempts, one retry per transient read, 90 seconds and two concurrent workers. The current workflow uses at most one bounded local planner request, even though the configurable model-call ceiling is two. Inference replica attempts and source reads have their own smaller timeouts. Depth includes the scope/comparison checks and deeper engineering background.

Incomplete results retain completed evidence and any established findings. Read the limitation rather than treating skipped or failed checks as negative evidence. A missing model may leave deterministic checks useful but the run marked incomplete. If the reported problem disappears after normalization, the status is **Problem not verified** and the workflow stops before inventing a cause.

The browser application admits a bounded queue and runs two investigations at a time. A queued cancellation terminates immediately; running work stops at a checkpoint. After a crash, fence the old authority and restart. Startup fails unfinished jobs and cancels active cases/steps while retaining snapshots. The standalone `python -m cnc_ai rca recover --user admin` command remains for expired legacy investigations. It does not automatically replay work or machine actions. Open the saved case and reassess to continue.

## Training case list

| Identifier | Question focus | Expected distinction |
|---|---|---|
| CNC-03 | Production decrease | Verified cooling contribution; reconciled 70-piece loss. |
| CNC-02 | Three-hour idle interval | Material shortage with issue/resume records. |
| CNC-07 | Scrap increase | Program revision and linked rollback/retest. |
| MX-500 | Complete-machine assembly delay | Purchased component blocks assembly; verification incomplete. |
| MX-700 | Acceptance failure | Out-of-limit measurement; calibration retest missing. |
| CNC-04 | Production decrease | Multiple supported contributors. |
| CNC-05 | Production decrease | Temperature correlation remains inconclusive. |
| CNC-06 | Production decrease | Conflicting cooling records prevent confirmation. |
| CNC-08 | Apparent production decrease | Cycle/mix normalization removes the apparent problem. |
| WO-300 | Due-date risk | Estimated capacity shortage; no live scheduling engine. |

## Configure and validate factory operation

Configure the IANA timezone, shifts, holidays and stable factory ID in `config/rca.json`. Set `CNC_RCA_HISTORY_PATH` to a qualified read-only historical export. Normal operation uses local application storage and the existing private inference endpoints. It adds no public API, runtime model download, CDN, cloud tracing or external authentication.

The built-in v11 database supplies real native rows, but does not establish all historical revision, shift and mix semantics needed for normalized RCA. It therefore reports those limits. ERPNext, a live MES, Siemens NX, Opcenter and Simio are not implemented live RCA connectors in this release. See `docs/rca/DEVELOPER_GUIDE.md` for the typed mapping and rule-approval process.

Run `python -m pytest` and `python scripts/rca/validate_browser.py` on a provisioned test workstation. The browser script uses a separate synthetic runtime. Actual-model and site tests are separate: `scripts/rca/validate_local_model.py` requires your configured private planner and qualified history. Software and synthetic tests do not establish factory diagnosis accuracy, live connector correctness or machine safety certification.

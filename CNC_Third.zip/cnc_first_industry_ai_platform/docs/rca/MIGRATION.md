# RCA migration in v11.2

Use the [v11.1 to v11.2 migration guide](../MIGRATION_V111_TO_V112.md). Retain the original archive, environment and consistent pre-upgrade backup. Migration 005 adds persistent jobs and model request IDs while preserving migrations 001–004 and existing RCA evidence.

The [original v11 to v11.1 RCA migration](../history/v111/rca/MIGRATION.md) is retained as historical guidance. It does not describe the current deployment layout. Never run an older application against an upgraded live database; rollback uses its pre-upgrade backup after fencing the current authority.

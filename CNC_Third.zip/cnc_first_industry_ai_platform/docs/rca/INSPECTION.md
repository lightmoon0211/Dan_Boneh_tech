# Actual v11 inspection and RCA change summary

Historical v11.0-to-v11.1 source inspection. It is retained as baseline evidence; v11.2 queue/distributor/deployment changes are in ../v112/SOURCE_AUDIT.md.

The integration started from the delivered `CNC_First_Industry_AI_Platform_v11.0.0.zip`, not an inferred project layout. Its SHA256 is `ce183ab5c5a523916cb62be12deb7c055c8649b704c36e90e89f8e19a68df6a0`. All 265 files in its content manifest were verified before editing. The original archive remains recoverable and the implementation used a separate working copy. `v11_baseline_inventory.json` records source hashes and the changed/added file inventory.

## Reused components

| Concern | Actual v11 implementation reused |
|---|---|
| Backend and imports | Installed `src/cnc_ai` Python package; Flask and Waitress. |
| Frontend | Local vanilla JavaScript/CSS, saved chat, language selector and configurable labels. |
| Persistence | SQLite database, checksummed migrations, append-only audit patterns and database backup. |
| Access | Local named users, current role permissions, sessions and same-origin CSRF middleware. |
| Model services | Existing local ModelRouter and planner alias of the code service. Model registry and GPU allocation preserved. |
| Retrieval | Approved document revision checks, stored excerpts and citation metadata. RCA uses bounded lexical retrieval for background. |
| Operational queries | QueryService with read-only SQLite connection, SQL validation and table/column allowlists. |
| Machine controls | Existing proposal, deterministic policy, supervisor approval, interlock checks and typed OPC UA adapters remain separate. |
| Numerical and planning features | Existing historian, signal processing, numerical APIs, digital thread and engineering artifact gates remain in place. |
| Launch and deployment | smartfactoryllm Windows scripts, Linux services, Docker and air-gap transfer tooling. |

## Added components

`src/cnc_ai/rca/` contains strict contracts, calendar/scope resolution, deterministic arithmetic, read-only history adapters, synthetic dataset creation, persistent bounded executor and CLI commands. `resources/migrations/004_rca.sql` adds eleven RCA tables. `config/rca.json` controls scope and budgets; `config/rca_rules.json` contains the reviewable mechanism/verification templates.

`web/rca.py` registers authenticated endpoints. `web/static/rca.js` and `rca.css` implement summaries, actual execution events, evidence inspection, causal relationships, independent reviews and revisions. Assistant routing and the existing page gain RCA entry points. New tests are under `tests/rca`; scripts and cases are under `scripts/rca` and `samples/rca`. The new release is 11.1.0.

## Findings and limits of the inspected source

The native business database contains production, downtime, maintenance, inventory, quality and other factory tables, but it does not fully qualify historical shift allocations, program revisions, final-count semantics or product mix. Its products table does not by itself distinguish complete CNC machines from manufactured parts. Native rows are retained as unqualified context; a canonical history mapping supplies validated comparison evidence. No current OPC UA value is used as historical substitute.

No live ERPNext, MES, Siemens NX, Opcenter or Simio interface was found in the inspected source. Existing PostgreSQL/ClickHouse/HTTP historian components are retained; they are not automatically claimed as a qualified RCA MES/ERP connector. New read-only mapping code is provided, but site ETL and live connector acceptance remain deployment work.

The initially available test interpreter lacked setuptools, defusedxml and Pillow. These were environment gaps: the v11 package already declared its application dependencies. After repairing the interpreter and installing actual v11, all 118 baseline tests passed. No baseline import defect required replacing the framework or root imports. RCA adds a direct pytz dependency for portable IANA timezone handling.

## Implementation sequence completed

Verified baseline and ran its tests; added contracts/storage/calendar; integrated a bounded executor and read-only evidence adapter; implemented calculated comparisons and reviewed causal criteria; integrated conversation and inspectable UI; added ten synthetic cases and security/workflow tests; ran source and browser checks; prepared migration, user/developer and offline validation instructions. The final validation record distinguishes implemented software from unexecuted live model/factory tests.

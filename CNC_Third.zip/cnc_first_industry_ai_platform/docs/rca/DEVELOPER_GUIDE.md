# RCA developer and connector guide

RCA is an application module with its own state and tool executor. It is not a prompt-only feature or a new GPU service. The implementation extends the actual Flask/Waitress v11 package, existing sessions/CSRF, SQLite authority, ModelRouter, RAG and safe query service. `INSPECTION.md` records the verified baseline and gaps. Source contracts and tests are authoritative when extending this release.

## Module boundaries

| Module | Responsibility |
|---|---|
| `cnc_ai.rca.contracts` | Strict scope/request/record/rule contracts; unknown fields and incoherent source payloads fail validation. |
| `cnc_ai.rca.scope` | Entity resolution, IANA timezone, shift/holiday calendar and explicit comparison semantics. |
| `cnc_ai.rca.history` | Typed read-only adapters, source identity, scope/cutoff validation, fixed parameterized queries. |
| `cnc_ai.rca.calculations` | Output and scrap comparisons, normalization, interval union, loss residual, progress and acceptance calculations. |
| `cnc_ai.rca.service` | Persistent bounded executor, state transitions, evidence, rule evaluation, cancellation, revisions and independent review. |
| `cnc_ai.rca.demo` | Explicit creation of separate fictional history. Expected test answers are not workflow inputs. |
| `cnc_ai.web.rca` | Existing authenticated web boundary for cases, events, snapshots and export. |
| `web/static/rca.js` | Polling cards, timeline, SVG relationships, evidence, reviews and saved cases. |

The control modules are not imported by RCA. It does not execute generated SQL or Python, edit NC artifacts, issue OPC UA writes or change schedules. Native history reads pass through the existing QueryService allowlists. The canonical adapter uses fixed SQL and a database-level read-only connection. Only the application's own investigation/audit store is writable.

## Execution and persistence

The workflow resolves scope, reads the smallest relevant families, verifies the problem, proposes a bounded set of hypotheses, checks their required sources, evaluates evidence, investigates the permitted deeper background, validates citations and reconciles arithmetic. Multiple rule findings and alternatives can coexist. A reported problem that disappears after normalization stops before causal attribution.

A check first receives a persisted `planned` event. The executor alone transitions it to `running`, then `completed`, `failed` or `cancelled`. A planned check can be skipped or cancelled without a start timestamp. Retries are actual running events with attempt numbers. Model selections never create completion events or retrieved records. The visible timeline and API event log come from the same persisted execution data.

`004_rca.sql` adds eleven tables to the existing SQLite authority. Cases retain owner, conversation, analytical source, stable application database UUID, factory ID, revision, parent, reason, scope and cutoff. Evidence, calculations, hypotheses, links, reviews, rule approvals and supplemental snapshots persist independently. Versions include application/workflow/tool/prompt version, model ID/revision when called, config/rule hashes and history identity/schema hash. Source snapshots retain hashes and original event/retrieval metadata.

One active application authority is retained, with two concurrent RCA workers by default. Web requests use the persistent bounded fair application queue with a dedicated two-worker RCA lane. Standalone synchronous/CLI use retains the bounded semaphore. Cancellation is cooperative: read timeouts, the SQLite progress callback and execution checkpoints bound the wait. Application startup automatically fails unfinished jobs and cancels linked active investigations/steps without replay. Standalone expired investigations can still use `rca recover`. Stop the old process before administrative recovery. Restarting does not replay operational actions.

Exports can contain sensitive factory evidence. Protect the runtime with site filesystem permissions, encrypted backups and retention procedures. This release does not implement an automatic deletion schedule, legal hold service or WORM storage. An authorized current user must still have case access to retrieve a retained snapshot; revocation blocks timeline/export as well as the answer. Snapshot hashes detect alteration, not falsified upstream data.

## Configuration and budgets

`config/rca.json` and packaged defaults are supplied together. An external configuration directory should receive a reviewed copy of the new RCA files. `CNC_FACTORY_TIMEZONE` overrides the timezone, `CNC_RCA_HISTORY_PATH` overrides the export path and `CNC_RCA_DEMO` controls explicit training access. Use an IANA name such as `Asia/Shanghai` or `America/Chicago`, not the AI server's local clock. Shift weekdays are Monday 0 through Sunday 6; crossing-midnight shifts are supported. Ambiguous or nonexistent DST boundary times request clarification. Each historical run covers one completed shift and one entity.

| Limit | Default | Enforcement |
|---|---:|---|
| Depth | 3 | Checks beyond the depth are skipped; unresolved work is visible. |
| Tool attempts | 16 | Includes scope/calculation/model checks and retry attempts. |
| Transient retries | 1 | Only timeout/locked/busy/interrupted read failures; no arbitrary tool replay. |
| Elapsed seconds | 90 | Monotonic deadline plus bounded in-flight operation handling. |
| Model calls | 2 ceiling | Current workflow makes at most one planner request. Zero disables it. |
| Model timeout | 12 seconds | Per replica bounded by remaining wall time divided across at most two factory replica attempts (legacy workstation maximum three). |
| Model output | 600 tokens | Strict, short hypothesis selection only. |
| Source rows | 200 per family/window | Exceeding the bound stops that read; truncated records do not silently feed calculations. |
| Query timeout | 3 seconds | Read-only SQLite timeout and progress handler. |
| Workers | 2 | Dedicated application queue lane; additional authorized submissions wait visibly. |

RCA's optional planner request sends the topic, bounded returned event codes and permitted hypothesis IDs. It never sends raw unrestricted fields or treats source text as policy. A strict HypothesisPlan response can reorder permitted checks; it cannot omit mandatory alternatives, authorize a new tool or supply findings. Invalid/truncated responses fail the step and deterministic checks can still return partial results. No new model selection or runtime download is introduced. RAG uses approved lexical document retrieval in this workflow so embedding/reranker latency cannot escape the RCA model budget; the existing main assistant's hybrid RAG remains unchanged.

## Qualify a read-only historical export

No live MES/ERP/NX/APS product connector is bundled as a working factory integration. The default native adapter reads existing v11 records but reports missing normalization semantics. For qualified investigations, a site integration process should publish a separate SQLite historical export using `samples/rca/history_schema.sql` and `docs/contracts/RCA_HistoryRecord.schema.json`.

The export is a **connector boundary**, not a replacement application authority. Populate it from approved historical records under a dedicated source account. Grant the application filesystem read access only. Set `CNC_RCA_HISTORY_PATH` to the export and keep `demo=false`. Never relabel the synthetic dataset as production. Publish validated exports atomically with a stable dataset ID, accurate revisions and a consistent cutoff. Concurrent upstream mutation is outside a multi-system snapshot guarantee: the case retains exact snapshots and flags later differences, but cannot manufacture consistency across source systems.

The three table names and column sets must match the supplied schema exactly. Metadata values are JSON literals: schema version `cnc-rca-history-1`, stable `dataset_id`, the configured `factory_id`, boolean `demo`, and `available_families`. Publish only actually connected families. Missing families yield explicit unavailable checks; an available but empty family yields no records, which is not proof of absence.

Use `resource`, `finished_machine` and `work_order` entity kinds. Keep serial/product and production-resource IDs distinct, even when labels look similar. Map all records for an incident to the investigation entity while preserving source IDs, linked work-order/component identifiers in the authorized detail and source revision. The current mechanism rules operate at entity/incident grain. Do not use their result as part-specific proof across mixed simultaneous operations without adding and testing a qualified operation-level rule/mapping.

Each record has source system/ID, entity/kind, family, event start/end, recorded-at time, revision, quality and a discriminated payload. Indexed timestamps must be canonical UTC `YYYY-MM-DDTHH:MM:SS[.ffffff]+00:00`, exactly matching the parsed snapshot. All timestamps require explicit offsets; end must not precede start and an observed record cannot be recorded before the event ends. The historical cutoff excludes records not yet recorded. Only good-quality records qualify causal evidence and arithmetic.

| Family | Payload and required semantics |
|---|---|
| production | Shift date/ID, part, operation, revision, mix, nonoverlapping allocated scheduled minutes, recorded standard cycle, exclusive final good/scrap and optional planned good. |
| downtime | Observation payload with incident/code and real start/end. Closed recorded intervals only. |
| machine_history, maintenance, materials, quality, engineering | Observation code, incident, related record ID, value/units and authorized detail. These are source facts, not prompt instructions. |
| assembly | Recorded planned/completed/remaining work minutes, available capacity before due date and timezone-aware due date. Covers finished-machine or work-order progress. |
| acceptance | Test ID, measured value, limits, units and pass/fail consistent with those limits. Site approval of the limits remains a separate requirement. |

The adapter opens `mode=ro`, sets `query_only`, disables extensions, installs a SELECT/column authorizer and bounds query time and rows. Identity, indexed fields and payload are revalidated before a returned record becomes evidence. No API accepts free SQL or a database filename from a model. The deployment administrator controls the configured path.

## Add another connector or manufacturing process

Implement an adapter exposing `assets()`, `read(family, ToolArguments) -> Batch`, `record(id, entity, kind, cutoff)` and `identity()`. Use server-side read-only credentials, reviewed fixed parameterized queries, explicit source/schema versions, bounded rows/timeouts and cancellation. Do not fall back to live telemetry for historical data. Return SourceUnavailable for disconnected capabilities, and preserve quality/lineage. Register the reviewed adapter in `adapter_for`; do not dynamically import a model-selected class or URL.

For direct PostgreSQL/ERP/MES use, add and test a dedicated read-only mapping; existing generic historian adapters alone do not qualify the semantics. Publish only needed fields and enforce source ACLs at least as strongly as existing case/data permissions. A source-specific ACL extension must be applied to start, every read, evidence additions, view and export. Add tests for SQL authorization, tenant/entity isolation, cancellation, timeouts, malformed payloads and identity changes.

The initial five rule templates cover cooling faults, material shortage, program revision, purchased-component assembly blockage and calibration/acceptance linkage. Mechanical/electrical assembly, controller configuration and other subassemblies can supply typed engineering/material/quality observations now; additional causal mechanisms require new reviewed codes, rules and labeled tests. The release does not claim universal fault coverage for every machine builder.

## Add and approve an engineering criterion

A rule in `rca_rules.json` has an ID, revision, hypothesis, source family, mechanism, cause/effect codes, verification codes, contradiction codes, cause level, recommended check and proposed action. The returned cause/effect must share a nonempty incident and have a valid time sequence. Verification codes must link to the effect record; the final verification must occur after the effect ends. Poor-quality data, missing links or contradictions prevent confirmation. A manual describing a mechanism remains background only.

Before enabling a criterion, factory engineering must approve its physical applicability, source mapping, linked verification procedure and failure cases. Ingest and approve the actual verification document using the existing document workflow. Then an authorized administrator can record the reviewed criterion:

```powershell
python -m cnc_ai rca approve-rule cooling_flow --user admin --document APPROVED_DOCUMENT_ID --expires '2027-03-01T00:00:00+00:00' --comment 'Engineering approved the mapped cooling verification procedure for this line.'
```

Replace the document ID and choose an expiry within one year of the actual approval date. Rule approval binds the current rule hash and approved document hash. Changing the rule, superseding the document, altering its content or letting approval expire prevents new Confirmed findings. Human review alone has no such causal authority. Existing past revisions retain what they found at their recorded cutoff; reassess after changed evidence or criteria.

There is no automatic rule execution of corrective actions. Recommendations must go through separate work-order, maintenance, engineering or CNC-control approval procedures. PLC/CNC safety mechanisms remain authoritative.

## HTTP and conversation interface

All routes use the existing same-origin session and CSRF boundary. POST requests require the current CSRF token using the existing client helper. Source contents and private prompts are not returned as execution reasoning. Field schemas are under `docs/contracts/RCA_*.schema.json`.

| Method and route | Behavior |
|---|---|
| GET `/api/rca/status` | Configured adapter capability, demo availability and budgets; does not claim a live connector is ready. |
| POST `/api/rca/investigations` | StartRequest; accepts question and optional typed scope; queues a bounded case. |
| GET `/api/rca/investigations` | Up to 100 authorized saved cases. |
| GET `/api/rca/investigations/{id}` | Scope, result, steps, events, evidence metadata, revisions and reviews. |
| GET `/api/rca/investigations/{id}/events` | Persisted executor events and current status. |
| POST `/api/rca/investigations/{id}/cancel` | Owner requests cooperative cancellation. |
| GET `/api/rca/investigations/{id}/evidence/{evidence_id}` | Authorized snapshot, provenance and current-source change flag. |
| POST `/api/rca/investigations/{id}/evidence` | Add an authorized actual source record ID and reason for reassessment. |
| POST `/api/rca/investigations/{id}/review` | Reviewer records a separate human disposition after completion. |
| POST `/api/rca/investigations/{id}/reassess` | Owner creates an immutable new revision with reason, optional question/scope. |
| GET `/api/rca/investigations/{id}/export` | Authorized full JSON export; audited download. |

The existing `/api/chat` also accepts `rca_source` (`factory` by default; `demo` only when explicitly enabled). Appropriate why-questions enter RCA automatically. Existing local plan routing can return a validated RCA scope. Follow-ups retrieve the saved result or start a revision. The UI polls only active visible cards once per second; no previous streaming system was replaced. User-facing RCA label overrides can be added under the existing `/api/ui-text` configuration, using `rca_*` keys. Key navigation labels have translations in the existing languages; detailed backend findings and source text currently remain English/source language.

## Test layers and offline acceptance

`tests/rca/` exercises the whole deterministic workflow with ten synthetic cases, actual SQLite reads, arithmetic, contracts, permissions, real backend events, cancellation barriers and failure injection. Planner tests are explicitly model test doubles. They do not establish real inference behavior or diagnosis accuracy. `scripts/rca/validate_browser.py` starts actual Waitress and Chromium against an isolated training runtime and compares visible checks with persisted events.

For a preprovisioned test environment:

```bash
python -m pytest
python scripts/validate_installation.py
python scripts/rca/validate_browser.py
python -m cnc_ai validate --offline
```

The last command validates the configured instance and must follow migration. Browser installation belongs on connected staging; offline tests need its executable and OS libraries already present. The application adds no external tracing or download dependency. RCA's deterministic offline test fails any model transport/network attempt. Service-level loopback tests exercise existing HTTP/OPC UA adapters without contacting factory equipment.

To validate actual local inference end to end after mapping site history, run a separately authorized read-only case:

```powershell
python scripts/rca/validate_local_model.py --user operator01 --question 'Why did CNC-03 production decrease on 2026-09-08?' --intent samples/rca/cnc03_intent.json --output runtime/rca-local-model-check.json
```

Replace the sample date/entity with an actual qualified site case and set `CNC_MODEL_MODE=local`. This command fails if a real planner check did not complete or the required evidence is unavailable. It does not automatically approve the causal criterion or establish accuracy. Report this run separately from mock tests, along with model revision, source identities, site labels and observed errors. Evaluate on factory-labeled cases before relying on RCA operationally.

For air-gap transfer, use the existing `scripts/prepare_airgap.py` on a matching staging host, verify its manifest, install from its wheelhouse and transfer the already accepted inference environment/model manifests separately. The source ZIP contains no weights or complete Python environment. Use the two-node RTX deployment in ../SERVER_INSTALLATION.md; RCA reuses those models and adds no GPU allocation. Keep credentials and production exports outside the source archive.

A complete synthetic result produced by the installed CLI is in `samples/rca/worked_investigation.json`. It contains actual executor events and snapshots for the training case, with no model call or operational action. The initial implementation expects one configured rule per hypothesis ID. Adding a new hypothesis category requires extending the strict enum and permitted selector, not only adding a JSON entry; include its read-only tool/causal tests.

# Server installation

These commands target the existing project at `/opt/cnc-ai`. Replace the example hostnames/IPs centrally in `config/deployment.json`, then regenerate assets. The default method is systemd plus nginx on vendor-qualified x86-64 Linux. AI A and AI B each have four 96 GB RTX PRO 6000 Blackwell Server Edition GPUs. The CPU application host and independent backup storage are separate. No Kubernetes, Redis or cluster scheduler is required.

## Connected preparation host

Use matching Linux, architecture and Python 3.12 for production dependency preparation. Windows development uses a separate application environment; users' browsers need no environment.

```bash
conda create -n smartfactoryllm python=3.12 pip
conda activate smartfactoryllm
python -m pip install -e '.[test,download]'
python -m pytest -q
python scripts/models/download_factory_models.py all --model-root /srv/ai/models --checksums
python scripts/models/download_factory_models.py all --model-root /srv/ai/models --verify --checksums
python scripts/deployment/configure.py --manifest config/deployment.json --bind-snapshots /srv/ai/models --qualified --output deployment/generated
```

Do not use partial file selections for factory core snapshots. The manifest includes reviewed upstream commit pins. Keep LICENSE/model-card files and all tokenizer, processor and shard files. Pinning or hashing is not proof of model quality. Existing local files can be reused through the resumable downloader at the selected paths; retain its completed manifests. An existing unmanifested snapshot is not silently trusted.

On a matching connected **GPU staging server**, install the candidate into a separate environment. This step is intentionally not called a qualified installation:

```bash
conda create -n smartfactorymodels python=3.12 pip
conda activate smartfactorymodels
python -m pip install -r requirements/rtx-blackwell-candidate.txt
python -m pip install packages/cnc_first_ai-11.2.0-py3-none-any.whl
python -m pip check
```

Install the wheel with its declared dependencies so package metadata remains consistent. Resolve those dependencies together with the serving engine on the target platform. Do not install the entire CPU lock over the GPU environment. A working `pip check`, `sm_120` BF16 kernel test, all five model contract probes and simultaneous GPU 3 operation are required before freezing the inference lock. Store the resolved CUDA/PyTorch/driver details, not merely the candidate requirements filename.

## AI server A

Install vendor-approved firmware, Linux, GPU driver and the validated serving environment from controlled media. System provisioning below runs as a site administrator. Weights must already have been copied to `/srv/ai/models` and verified. The chosen drive form factors and GPU power limits need vendor approval; these scripts do not change power caps.

```bash
conda create -n smartfactorymodels python=3.12 pip --offline
conda activate smartfactorymodels
python -m pip install --no-index --find-links /srv/transfer/inference-wheelhouse --find-links /srv/transfer/app-wheelhouse -r /srv/transfer/inference-lock.txt
python -m pip check
sudo useradd --system --home-dir /var/lib/cnc-models --create-home cncmodels
sudo install -d -o root -g cncmodels -m 0750 /etc/cnc-ai
sudo install -d -o cncmodels -g cncmodels -m 0750 /var/lib/cnc-models
sudo install -m 0644 config/deployment.json /etc/cnc-ai/deployment.json
sudo install -o root -g cncmodels -m 0640 deployment/generated/ai-a/models.env.example /etc/cnc-ai/models.env
sudo install -m 0644 deployment/generated/ai-a/cnc-model-*.service /etc/systemd/system/
sudo install -m 0644 deployment/generated/ai-a/nginx-models.conf /etc/nginx/conf.d/cnc-models.conf
```

Edit `/etc/cnc-ai/models.env` locally with five distinct strong API keys. The key for a role must match the CPU app and that role's replicas on AI B. Provision a site-trusted TLS certificate whose subject alternative names include `ai-a.factory.internal`, its private key, and the CA chain. The generated nginx path is `/etc/cnc-ai/tls/server.crt` and `server.key`. Protect the private key from other accounts. The model account requires read access to its model-only environment, manifest, configuration and weight tree, and write access only to its own cache. It must not have CPU application/OPC UA secrets.

```bash
sudo nginx -t
sudo systemd-analyze verify /etc/systemd/system/cnc-model-ai-a-*.service
sudo systemctl daemon-reload
sudo -u cncmodels /opt/conda/envs/smartfactorymodels/bin/python scripts/deployment/preflight.py --host ai-a --manifest /etc/cnc-ai/deployment.json --env-file /etc/cnc-ai/models.env --deep --check-ports-free --transfer /srv/transfer --output /var/lib/cnc-models/preflight.json
sudo systemctl enable nginx
sudo systemctl start nginx
sudo /opt/conda/envs/smartfactorymodels/bin/python scripts/deployment/manage.py start --host ai-a --manifest /etc/cnc-ai/deployment.json
sudo systemctl enable cnc-model-ai-a-conversation-1 cnc-model-ai-a-conversation-2 cnc-model-ai-a-code cnc-model-ai-a-safety cnc-model-ai-a-embedding cnc-model-ai-a-reranker
```

If only the model environment is installed on this host, run `manage.py` with its Python instead; the module uses the installed source wheel and standard library. Preflight is read-only and returns nonzero for missing gates. Do not turn a blocked preflight into a pass by ignoring its result. An individual unit's startup contract check can take up to ten minutes. Inspect `journalctl -u cnc-model-ai-a-safety` if it fails. No other model unit is automatically restarted because it fails.

## AI server B

Use the same manifest, complete model snapshots, serving lock and model keys on B. Install the **ai-b** generated files and a certificate for B's hostname. Repeat the account/directory steps above, then:

```bash
sudo install -m 0644 deployment/generated/ai-b/cnc-model-*.service /etc/systemd/system/
sudo install -m 0644 deployment/generated/ai-b/nginx-models.conf /etc/nginx/conf.d/cnc-models.conf
sudo nginx -t
sudo systemd-analyze verify /etc/systemd/system/cnc-model-ai-b-*.service
sudo systemctl daemon-reload
sudo -u cncmodels /opt/conda/envs/smartfactorymodels/bin/python scripts/deployment/preflight.py --host ai-b --manifest /etc/cnc-ai/deployment.json --env-file /etc/cnc-ai/models.env --deep --check-ports-free --transfer /srv/transfer --output /var/lib/cnc-models/preflight.json
sudo systemctl start nginx
sudo /opt/conda/envs/smartfactorymodels/bin/python scripts/deployment/manage.py start --host ai-b --manifest /etc/cnc-ai/deployment.json
sudo systemctl enable cnc-model-ai-b-conversation-1 cnc-model-ai-b-conversation-2 cnc-model-ai-b-code cnc-model-ai-b-safety cnc-model-ai-b-embedding cnc-model-ai-b-reranker
```

For normal operation each node keeps its own weight files; it does not mount them from its peer. Allow the CPU app IP to reach only the specified TLS model ports. Allow controlled management from the administration network. Deny public egress and all inference-to-controller traffic. The nginx IP allowlist complements, rather than replaces, the host/network firewall.

## CPU application and data server

Install the application wheelhouse offline and nginx. No GPU/CUDA is needed here. The default generated environment explicitly uses in-process numerical computation and the local SQLite historian for initial validation. Connect a larger approved historian separately if required; factory document approval restrictions remain active.

```bash
conda create -n smartfactoryllm python=3.12 pip --offline
conda activate smartfactoryllm
python -m pip install --no-index --find-links /srv/transfer/app-wheelhouse cnc-first-ai==11.2.0
sudo useradd --system --home-dir /var/lib/cnc-ai --create-home cncai
sudo install -d -o root -g cncai -m 0750 /etc/cnc-ai
sudo install -d -o cncai -g cncai -m 0700 /var/lib/cnc-ai
sudo install -m 0644 config/deployment.json /etc/cnc-ai/deployment.json
sudo install -o root -g cncai -m 0640 deployment/generated/app/app.env.example /etc/cnc-ai/app.env
sudo install -m 0644 deployment/generated/app/cnc-ai.service /etc/systemd/system/
sudo install -m 0644 deployment/generated/app/nginx-app.conf /etc/nginx/conf.d/cnc-ai.conf
```

An offline Conda command succeeds only when its interpreter packages were staged. An approved offline Python 3.12 installer plus a new `venv` is an alternative; update generated service interpreter paths consistently if using it. Populate the five service keys, CA certificate and the CPU server certificate/private key. Add real controller credentials only after separate commissioning. Never copy them to an inference host.

For **new training data only**:

```bash
sudo -u cncai env CNC_HOME=/opt/cnc-ai CNC_DATA_DIR=/var/lib/cnc-ai CNC_CONFIG_DIR=/opt/cnc-ai/config /opt/conda/envs/smartfactoryllm/bin/python -m cnc_ai db init --sample
sudo -u cncai env CNC_HOME=/opt/cnc-ai CNC_DATA_DIR=/var/lib/cnc-ai /opt/conda/envs/smartfactoryllm/bin/python -m cnc_ai user add admin --role admin
```

Create operator and supervisor accounts in the same way. For a new factory database omit `--sample`; for an existing one use `db migrate` only after backup. Initialize before starting the service; startup never silently seeds or migrates data.

```bash
sudo nginx -t
sudo systemd-analyze verify /etc/systemd/system/cnc-ai.service
sudo systemctl daemon-reload
sudo systemctl enable --now nginx cnc-ai
sudo -u cncai /opt/conda/envs/smartfactoryllm/bin/python scripts/deployment/probe.py --manifest /etc/cnc-ai/deployment.json --env-file /etc/cnc-ai/app.env --wait-seconds 30
```

The probe tests all twelve instances and prints only service/model/revision results. Perform [capacity testing](CAPACITY_TESTING.md) and the disconnected cold start before acceptance. Use the factory browser URL, not an AI service URL. Browsers never receive model service keys.

## Docker scope

`deployment/docker/compose.yml` runs **only the CPU application**, not twelve GPU services. It uses the host network and must sit behind the site's TLS proxy. Provision the runtime, environment and read-only configuration first. Build and transfer the image on a matching connected staging host; record the image digest, export with `docker save`, verify its checksum and import with `docker load`. Do not run a second application authority alongside systemd. Docker/OS qualification remains separate from the tested Python application.

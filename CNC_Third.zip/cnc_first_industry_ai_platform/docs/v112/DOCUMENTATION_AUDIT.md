# Documentation audit — v11.2.0

The exact source ZIP and original file hashes are recorded in baseline_inventory.json. The supplied plain-language Word manual and source inspection were located and used. A separate earlier hardware recommendation was not found; the latest supplied specification establishes the new target.

Current instructions describe two four-GPU RTX PRO 6000 Blackwell inference nodes, one CPU authority, independent backup, twelve instances and fifty browser clients. Historical material is explicitly archived or labeled. Existing CNC/component and complete-machine assembly/RCA explanations are retained. Model selection history is not a current compatibility certification.

The matrix inventories every documentation page, editable/rendered manual, configuration example, environment definition and script. Diagrams embedded in Markdown are covered by their containing file. Python help was actually executed where an argument parser exists; fixed database wrappers were inspected without running a data mutation. PowerShell/Conda, physical GPU, site systemd execution and Docker are NOT RUN/BLOCKED here. File hashes are in DOCUMENTATION_INVENTORY.json; these audit files do not hash themselves. Final archive hashes are authoritative after report generation.

Manual review repaired the RCA version/environment instructions, figure caption, and a shell command split across a PDF page. All final 51 main-manual and six RCA pages were inspected. See manual-qa.json. Static links, JSON/default parity, Python AST, JavaScript/Bash syntax and generated assets were checked; see static.json. Commands requiring site hardware/credentials are documented with their acceptance gates rather than labeled executed.

| File | Required change / disposition | Validation outcome / scope |
|---|---|---|
| `.dockerignore` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `.env.example` | Updated | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `.gitignore` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `README.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `START_HERE.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `config/application.json` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `config/deployment.json` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `config/engineering.json` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `config/models.coder-next.json` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `config/models.json` | Updated | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `config/opcua.json` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `config/policy.json` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `config/query_policy.json` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `config/qwen3_reranker.jinja` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `config/rag.json` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `config/rca.json` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `config/rca_rules.json` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `config/sectors.json` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `config/timeseries.json` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/docker/.dockerignore` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/docker/Dockerfile` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/docker/compose.yml` | Updated | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-a/cnc-model-ai-a-code.service` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-a/cnc-model-ai-a-conversation-1.service` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-a/cnc-model-ai-a-conversation-2.service` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-a/cnc-model-ai-a-embedding.service` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-a/cnc-model-ai-a-reranker.service` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-a/cnc-model-ai-a-safety.service` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-a/models.env.example` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-a/nginx-models.conf` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-b/cnc-model-ai-b-code.service` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-b/cnc-model-ai-b-conversation-1.service` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-b/cnc-model-ai-b-conversation-2.service` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-b/cnc-model-ai-b-embedding.service` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-b/cnc-model-ai-b-reranker.service` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-b/cnc-model-ai-b-safety.service` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-b/models.env.example` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/ai-b/nginx-models.conf` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/app/app.env.example` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/app/cnc-ai.service` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/app/nginx-app.conf` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/generated/generation.json` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/ha/README.md` | Updated | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/historian/clickhouse.sql` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/historian/postgresql.sql` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/nginx.conf` | Updated | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/observability/README.md` | Updated | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/systemd/cnc-ai.service` | Updated | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/systemd/cnc-models@.service` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/systemd/cnc-telemetry.service` | Updated | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/systemd/cnc-timeseries.service` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `deployment/systemd/specialists-override.example.conf` | Updated | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `docs/AIRGAP.md` | Preserved after review | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/AIR_GAP_DEPLOYMENT.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/API.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/ARCHITECTURE.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/BROWSER_QUICK_START.md` | New release artifact | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/CAPACITY_TESTING.md` | New release artifact | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/CHANGELOG.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/CNCBENCH.md` | Preserved after review | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/CONFIGURATION.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/CONTROL_COMMISSIONING.md` | Preserved after review | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/DATABASE.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/DATABASE_DESIGN.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/DEPLOYMENT.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/DOCUMENT_STYLE.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/FACTORY_PREPARATION.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/H200_DEPLOYMENT.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/HARDWARE.md` | New release artifact | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/IMPLEMENTATION_PLAN.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/MIGRATION.md` | Preserved after review | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/MIGRATION_V10_TO_V11.md` | Preserved after review | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/MIGRATION_V111_TO_V112.md` | New release artifact | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/MIGRATION_V9_TO_V10.md` | Preserved after review | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/MODELS.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/MODEL_COMPATIBILITY.md` | New release artifact | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/MODEL_SELECTION.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/OPC_UA_CONTROL.md` | Preserved after review | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/OPERATIONS.md` | New release artifact | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/OPTIONAL_SPECIALISTS.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/RAG_AND_PROVENANCE.md` | Preserved after review | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/REBUILD_REVIEW.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/RESEARCH_MODEL_ENVIRONMENTS.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/SAFETY_ARCHITECTURE.md` | Preserved after review | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/SERVER_INSTALLATION.md` | New release artifact | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/STATE_OF_THE_ART_2026.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/TIME_SERIES_INTELLIGENCE.md` | Preserved after review | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/TROUBLESHOOTING.md` | Preserved after review | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/USER_MANUAL.docx` | Updated | Rendered final manual; all pages visually inspected; docs/v112/manual-qa.json |
| `docs/USER_MANUAL.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/USER_MANUAL.pdf` | Updated | Rendered final manual; all pages visually inspected; docs/v112/manual-qa.json |
| `docs/VALIDATION.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/WINDOWS_DEVELOPMENT.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/history/README.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/AIRGAP.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/AIR_GAP_DEPLOYMENT.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/API.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/ARCHITECTURE.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/CHANGELOG.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/CNCBENCH.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/CONFIGURATION.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/CONTROL_COMMISSIONING.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/DATABASE.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/DATABASE_DESIGN.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/DEPLOYMENT.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/DOCUMENT_STYLE.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/FACTORY_PREPARATION.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/H200_DEPLOYMENT.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/IMPLEMENTATION_PLAN.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/MIGRATION.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/MIGRATION_V10_TO_V11.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/MIGRATION_V9_TO_V10.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/MODELS.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/MODEL_SELECTION.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/OPC_UA_CONTROL.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/OPTIONAL_SPECIALISTS.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/RAG_AND_PROVENANCE.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/README.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/REBUILD_REVIEW.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/RESEARCH_MODEL_ENVIRONMENTS.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/SAFETY_ARCHITECTURE.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/START_HERE.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/STATE_OF_THE_ART_2026.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/TIME_SERIES_INTELLIGENCE.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/TROUBLESHOOTING.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/USER_MANUAL.docx` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/USER_MANUAL.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/USER_MANUAL.pdf` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/VALIDATION.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/WINDOWS_DEVELOPMENT.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/rca/MIGRATION.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/rca/RCA_USER_GUIDE.docx` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/rca/RCA_USER_GUIDE.pdf` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/history/v111/rca/v11_baseline_validation.md` | Historical evidence retained; not current deployment instructions | Archived; no new execution claim |
| `docs/rca/DEVELOPER_GUIDE.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/rca/INSPECTION.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/rca/MIGRATION.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/rca/RCA_USER_GUIDE.docx` | Updated | Rendered final manual; all pages visually inspected; docs/v112/manual-qa.json |
| `docs/rca/RCA_USER_GUIDE.pdf` | Updated | Rendered final manual; all pages visually inspected; docs/v112/manual-qa.json |
| `docs/rca/USER_GUIDE.md` | Updated | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `docs/v112/SOURCE_AUDIT.md` | New release artifact | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `environments/smartfactoryllm.yml` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `environments/smartfactorymodels.yml` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `pyproject.toml` | Updated | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `requirements/app.txt` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `requirements/cpu.txt` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `requirements/download.txt` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `requirements/h200.txt` | Updated | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `requirements/rtx-blackwell-candidate.txt` | New release artifact | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `requirements/test.txt` | Preserved after review | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `requirements/validated-linux-py312.txt` | Updated | Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit |
| `run_windows.bat` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `samples/documents/spindle_change_sop.md` | Preserved after review | Current links, paths and release consistency reviewed; see validation report for execution scope |
| `scripts/database/import_v8.py` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/database/initialize.py` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/database/migrate.py` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/deployment/backup.py` | New release artifact | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/deployment/configure.py` | New release artifact | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/deployment/manage.py` | New release artifact | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/deployment/preflight.py` | New release artifact | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/deployment/probe.py` | New release artifact | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/deployment/validate_assets.py` | New release artifact | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/deployment/validate_migration.py` | New release artifact | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/deployment/validate_repository.py` | New release artifact | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/docs/audit_documentation.py` | New release artifact | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/docs/build_manual.py` | Updated | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/docs/build_rca_guide.py` | Updated | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/docs/export_reference.py` | Updated | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/evaluation/load_clients.py` | New release artifact | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/evaluation/run_cncbench.py` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/linux/start_app.sh` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/linux/start_models.sh` | Updated | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/linux/start_timeseries.sh` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/linux/validate.sh` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/models/download_factory_models.py` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/models/serve_models.py` | Updated | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/package_release.py` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/prepare_airgap.py` | Updated | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/rag/ingest.py` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/rca/validate_browser.py` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/rca/validate_local_model.py` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/rca/validate_migration.py` | Updated | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/timeseries/generate_telemetry.py` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/timeseries/run_service.py` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/validate_browser.py` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/validate_factory_readiness.py` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/validate_installation.py` | Updated | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/verify_bundle.py` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json; --help PASS |
| `scripts/windows/setup.ps1` | Updated | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/windows/start.ps1` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/windows/start_timeseries.ps1` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `scripts/windows/validate.ps1` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `setup_or_update_windows.bat` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `start_windows.bat` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |
| `validate_windows.bat` | Preserved after review | Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json |

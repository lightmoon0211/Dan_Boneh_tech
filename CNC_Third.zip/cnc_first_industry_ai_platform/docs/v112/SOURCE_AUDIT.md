# Source comparison and implementation decisions

The recovered original v11.1.0 archive hash is 123b192ae7a105124efe3ffd7e28f3aa970f81a653ef3c18b4ca422c3d10d8ee. The inventory contains every original file. The supplied plain-language Word/PDF manual and v11_1_0_source_inspection.txt were located and read. No separate earlier hardware-recommendation file was located; the current supplied specification defines the RTX target. The original ZIP was not overwritten.

| Verified baseline behavior | Actual source | v11.2 decision |
|---|---|---|
| Eight HTTP threads | src/cnc_ai/cli.py | Manifest-configured sixteen threads; slow chat/report/ingest/RCA work uses bounded persistent jobs. |
| Sixteen scheduled sequences per core service | config/models.json; scripts/models/serve_models.py | Four per instance, two admitted calls; twelve independent TP1 instances. |
| Two RCA workers, validator ceiling four | config/rca.json; src/cnc_ai/rca/service.py and validators | Preserve workflow budget; web submissions enter a dedicated two-worker lane. |
| Primary/fallback inference only | src/cnc_ai/models.py | Factory least-inflight distribution with round-robin ties, bounded attempts, readiness, cooldown and drain. Legacy workstation transport retained. |
| All overlapping GPUs rejected by host-group launcher | scripts/models/serve_models.py | Validated exact intentional sharing group on GPU 3; accidental overlap still rejected. Old host groups fail with migration guidance. |
| Non-streaming model calls | src/cnc_ai/models.py; web/static/app.js | Recorded job/status polling followed by reviewed final response; no unreviewed token stream. |
| One SQLite/controller authority | database and control modules | Retained, with local app/recorder locks and consistent stopped-authority backup. No NFS/SMB SQLite or claimed PostgreSQL application migration. |
| Existing five core models | config/models.json and alternate registry | Exact five IDs retained; alternate coder remains explicit workstation history. Optional SQLCoder/Whisper disabled. |

Read all original package/configuration/deployment/test files before changing the baseline. Current behavior is established by tests and source, external compatibility by primary publisher documentation, and target requirements by the latest supplied specification. A successful model advertisement is not functional readiness. GPU capacity is not inferred from CPU tests.

Notable repaired defects during passes: obsolete host-group test expectations; queued RCA jobs failing to terminate their cases on cancellation/expiry; planned steps left active after restart; model request correlation missing from audit metadata; incomplete prompt-budget checks; old deployment/manual paths; and the synthetic harness treating blocked SQL fixture responses as successful answers. The final reports distinguish these diagnostic runs from accepted results.


Final fault review repaired replica retries that could consume both attempts on one failed host. The retry now prefers a different host while retaining admission, timeout and attempt bounds. The new regression covers a healthy but busier peer. A queued-RCA test now holds its synchronization event until explicit cleanup rather than relying on a short wall-clock delay. No deterministic machine policy was weakened.

# Browser client quick start

Your computer needs a supported current browser, access to the internal factory network, a trusted site certificate and your own account. It does not need Python, Conda, CUDA, model files or a database installation.

1. Open the factory HTTPS address and sign in. Resolve a certificate warning with IT; do not disable certificate verification.
2. Check the operating mode. Training responses and synthetic records do not describe a real machine. Choose the response language and evidence database.
3. Ask a concrete question, such as “Compare CNC-03 production on the day shift on 8 September 2026 with its approved plan.” Distinguish a production resource from a finished machine being assembled.
4. A job can be queued or running. A queued job is waiting for bounded server capacity. A running job is executing recorded application steps; its progress is not hidden model reasoning. Read the final reviewed answer and open its citations.
5. Cancel an unwanted job. Cancellation takes effect at execution checkpoints; an in-flight operation may finish first. Completed records are retained. Use **My jobs → Refresh jobs** after reconnecting. Jobs and conversations belong to the authenticated account.
6. For RCA, inspect the problem comparison, evidence, calculations, hypotheses and recorded timeline. A review acknowledgement does not make an unproven cause confirmed. Reassessment creates a revision with a new cutoff.
7. A machine proposal is a separate request. Review policy results, obtain a different supervisor's required approval, and explicitly confirm execution as the requester. A setpoint readback does not prove the spindle's physical response.

If the queue is full, wait or cancel a pending job. Do not repeatedly submit the same machine request. If a server restarts, interrupted jobs fail with a recovery explanation and are not automatically replayed. If one AI server is unavailable, remaining capacity may be slower. The CPU application server remains a single point of service failure.

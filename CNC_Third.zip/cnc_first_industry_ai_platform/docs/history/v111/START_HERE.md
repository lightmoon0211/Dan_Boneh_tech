# Start here

This folder is the complete CNC Factory Assistant v11.1 project. The application works on a Windows CPU workstation in training mode. Real language models run in separate private inference services; weights stay on your external model drive. The factory target remains two Linux servers with eight H200 GPUs each.

| Your next task | Open this file |
|---|---|
| Upgrade v11 with RCA, preserving its data | docs/rca/MIGRATION.md |
| Investigate a factory problem and inspect the evidence | docs/rca/USER_GUIDE.md or docs/rca/RCA_USER_GUIDE.docx |
| Map factory history and approve causal verification rules | docs/rca/DEVELOPER_GUIDE.md |
| Review the actual inspected v11 baseline | docs/rca/INSPECTION.md |
| Install or recreate smartfactoryllm and run the demo | README.md — all eleven installation steps |
| Understand which of your 15 models were selected | docs/MODEL_SELECTION.md |
| Download/resume models, add SQL or speech, retain Coder-Next | docs/OPTIONAL_SPECIALISTS.md |
| Prepare the actual factory using your supplied guide | docs/FACTORY_PREPARATION.md and templates/ |
| Upgrade the old project without losing data | docs/MIGRATION_V10_TO_V11.md |
| Operate the assistant and approval workflow | docs/USER_MANUAL.docx or docs/USER_MANUAL.pdf |
| Place services on the H200 servers | docs/H200_DEPLOYMENT.md |
| Transfer to the disconnected factory | docs/AIR_GAP_DEPLOYMENT.md |
| Configure actual CNC access | docs/CONTROL_COMMISSIONING.md |
| See what was actually checked | docs/VALIDATION.md and docs/release_validation.json |

**Recommended first run:** create the environment, install the package, copy .env.example, set CNC_MODEL_MODE=demo, initialize the sample database and named accounts, then start the application. This lets operators learn citations, historical analysis, proposals and separate supervisor decisions without weights or a physical controller.

**Recommended model set:** five core models; add SQLCoder only when it improves your approved SQL results, and Whisper only if speech input helps. Do not install every candidate. A model name containing CNC, industrial or safety is not an equipment qualification.

**Three distinct kinds of proof:** software tests check implementation behavior; inference acceptance checks the actual model/runtime combination; factory commissioning checks real machine data, policies, people and PLC/CNC protections. A completed ZIP supplies the first kind of evidence and the procedures for the other two.

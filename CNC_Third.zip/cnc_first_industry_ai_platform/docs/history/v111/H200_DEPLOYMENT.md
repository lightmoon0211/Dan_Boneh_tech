# Two hosts, sixteen H200 GPUs

Each Linux host runs all five inference services, allowing either host to retain all roles after the other fails. GPU IDs are local to each host, never global indices 8–15. No cross-host tensor parallelism is required.

| Host-local GPUs | Role | Starting cap |
|---|---|---|
| 0 | Code/planner/control, TP1, :8002 | 32K context, memory fraction .85 |
| 2–3 | Conversation/report/vision, TP2, :8001 | 32K context, memory fraction .80 |
| 4 | Guardian :8003 | memory fraction .70 |
| 5 | Embedding :8004 | 8K context, memory fraction .60 |
| 6 | Reranker :8005 | 4K context, memory fraction .35 |
| 1 | Optional SQLCoder :8006 | 8K context, memory fraction .50, 8 sequences |
| 7 | Optional Whisper :8007 | 448 output context, memory fraction .20, 4 sequences |

Maximum sequences starts at 16 for core services. Optional specialists are disabled in the application by default. These are staging allocations, not measured throughput or H200 memory certifications. Tune context, batching, KV cache, concurrency and p50/p95 latency with representative workloads. A small workstation starts only fitting individual services or uses remote private endpoints/demo mode.

```bash
conda env create -f environments/smartfactorymodels.yml
conda activate smartfactorymodels
python -m pip install -r requirements/h200.txt
python scripts/models/serve_models.py server-a --dry-run
python scripts/models/serve_models.py server-a
```

Use server-b on the other host. Do not run both profiles on one host. models.json defines placements; per-service prefixes support GPU_IDS, TP, MAX_MODEL_LEN, GPU_MEMORY_UTILIZATION and MAX_NUM_SEQS overrides. Set Linux paths, private bind address and long distinct keys. Model children receive no CNC credentials; offline model resolution and usage-telemetry disabling are set by the launcher.

Primary/fallback URLs must advertise the same model revision/name and accept the same key. Example: CONVERSATION_BASE_URL=http://10.20.0.11:8001/v1 and CONVERSATION_FALLBACK_URLS=http://10.20.0.12:8001/v1. Reranker URLs omit /v1. A failed replica pauses for thirty seconds. Test host loss, cold starts, long contexts, Guardian score format, embeddings, reranking and structured schemas before freezing the inference environment.

Use local NVMe, adequate system RAM and at least 1 TB initial external model storage with upgrade/transfer room; measure actual snapshots. The coding model's sparse activation does not make its full weights equivalent to a small dense model. Numerical statistics run on CPU. GPU 7 is not required for application startup.

Browsers reach HTTPS ingress only. The application reaches private inference/historian and the reviewed OPC UA interface; models must have no CNC write route. The authority remains one active SQLite owner. Inference failover is implemented; stateful application HA requires tested site fencing/storage. See deployment/ha/README.md and AIR_GAP_DEPLOYMENT.md.

For the all-eight-GPU optional profile and Coder-Next alternative, see OPTIONAL_SPECIALISTS.md. vLLM memory fractions describe reservations, not measured weight sizes.

# Release validation · v11.0.0

Verified on 8 September 2026, Linux x86-64, Python 3.12.13. **118 tests passed against the installed application wheel from outside the repository.** The test suite, temporary CLI installation and browser workflow used fictional data, demo responses, mocked inference endpoints and loopback services. No physical factory equipment was contacted.

## Completed checks

| Check | Actual result |
|---|---|
| Installed package test suite | 118 passed, zero failures/errors. Covers database/migrations, authentication/CSRF, SQL authorization, evidence, RAG/revision review, model contracts/failover, deterministic control, approvals, expiry/revocation, concurrent execution, uncertain writes, numerical analysis, planning, artifacts and agent failure state. |
| Source and wheel consistency | All 74 packaged source/resource/UI assets match release source byte for byte. Imports resolve to the new environment's site-packages. Public schemas were exported from the installed classes and checked: 27 schemas. |
| Offline Python installation | Ran the actual transfer builder, verified all 60 staged files, created a clean environment and installed application/test/downloader dependencies using `uv pip install --no-index --no-cache --find-links`. All 56 installed packages passed the dependency check. Rebuilt and reinstalled the final wheel using only the staged wheelhouse; imports resolved to site-packages. |
| CLI lifecycle | Initialized 97 tables including FTS internals, 26 fictional machines, 100 work orders and 27,360 legacy readings. Created temporary named accounts; ingested and separately approved a SOP; ingested 30,240 canonical observations; ran the supplied anomaly query; rebuilt the digital thread; observed the simulator; backed up the database; verified integrity, foreign keys and audit. |
| v10 to v11 migration | Created a v10 database using its separately installed package, then initialized the copy with installed v11. All 26 machines, 100 work orders, 27,360 readings, one document and the audit chain remained. Existing Coder-Next configuration was retained and new optional features stayed disabled. All 13 control/migration source files remain byte-identical to v10. Earlier v9-to-v10 evidence is retained as historical evidence, not described as a new run. |
| Actual HTTP numerical service | An authenticated loopback HTTP request computed an analysis; the application retained matching input hashes and evidence. Missing/changed process context and failed agent steps were tested. |
| OPC UA protocol | An actual asyncua loopback server/client exercised typed reads, fresh timestamps, spindle-setpoint write and readback. Other tests cover malformed/stale samples, real-mode commissioning gates and uncertain delivery. |
| Browser workflow | Actual Waitress server and Chromium: sign-in, English language names, saved conversation, database evidence, seven checks, separate supervisor approval, requester execution, confirmed 7000 RPM setpoint, numerical anomaly charts, forecast interval and mobile navigation. No JavaScript page errors or horizontal overflow. The additional speech review-and-send UI used an explicitly mocked transcript; backend tests separately exercised actual loopback HTTP multipart transport and confirmed no chat/proposal/write occurs during transcription. |
| SQL examples | All five supplied queries passed the real authorization service, returning 26, 1, 23, 13 and 19 rows on the fresh sample. No generated DML execution is permitted, including for administrators. |
| CNCBench | Ran 11 SQL functional/adversarial cases, five lexical retrieval fixtures, synthetic anomaly screening and 280 forecast method/origin/signal comparisons. SQL pass fraction 1.0; synthetic anomaly F1 0.9870. These small fictional fixtures do not establish production accuracy. Neural runs are explicitly marked not run. |
| Downloader and launcher | Interruption/restart tests preserve partial files and pinned revisions; permanent errors and checksum corruption are rejected. Launcher tests check GPU arguments and removal of controller credentials from child environments. Seven-service core-plus-optional dry-run commands were generated using a separate model environment file. |
| Specialist and preparation contracts | SQL completion rejection, string-value binding, blocked credential columns, unchanged runtime query permissions, bounded WAV parsing, transcription authentication/CSRF, no automatic submission, disabled-service behavior, twelve evidence gates, expiry/hash/path tampering and GPU allocation conflicts passed. |
| Static checks | Python syntax/import lint, JavaScript syntax, Linux shell syntax, JSON/YAML/TOML parsing, packaged configuration parity, Markdown links and sample planning/analysis contracts passed. |
| Manual | All 24 Word/PDF pages reviewed. Native numbering, eleven setup steps, repeated table headers, code wrapping and current screenshots checked. |

Machine-readable evidence is in `release_validation.json` and `validation/`. UI screenshots are in `screenshots/`. The CPU application/test/download versions exercised are frozen in `requirements/validated-linux-py312.txt`. Do not apply that CPU constraint file to the GPU inference environment.

## Repeat application validation

From an extracted project in a clean Python 3.12 environment:

```bash
python -m pip install -c requirements/validated-linux-py312.txt '.[test,download]'
python -m pip check
python -m pytest
python scripts/validate_installation.py
```

The installation script uses its own temporary simulator database and accounts, forces demo mode and does not modify the configured factory database. It exercises the sample files delivered in this ZIP. Windows may need a separately resolved dependency lock if a Linux-pinned version lacks a matching wheel.

After initializing your intended instance:

```bash
python -m cnc_ai validate --offline
python -m cnc_ai audit-verify
python -m cnc_ai cncbench --output runtime/cncbench
```

The offline validation command does not probe model or controller endpoints. The default benchmark uses generated fictional data. See CNCBENCH.md for dataset splits, metrics, limitations and optional actual-model checks.

## Repeat browser validation

```bash
python -m pip install '.[browser]'
python -m playwright install chromium
python scripts/validate_browser.py
```

Provision browser OS libraries on staging. The script accepts `--browser-executable /path/to/chromium`, starts a temporary demo instance and writes screenshots. The build used an already provisioned Chromium executable. Offline browser checks require the matching browser binary and OS libraries; Python wheels alone do not supply them.

## Target-system acceptance still required

After starting the actual model services, use `CNC_MODEL_MODE=local` and run:

```bash
python -m cnc_ai validate --models
python -m cnc_ai cncbench --models --output runtime/cncbench-models
python -m cnc_ai validate --opcua
```

Model validation sends structured Answer/Plan requests, Guardian scoring, embeddings and reranker scoring. The control-shaped model output is only parsed during these tests; it is not submitted for execution. Actual machine proposals always follow the separate policy/approval workflow.

SQLCoder completion checks run only when the optional service is enabled. Speech readiness requires a real spoken WAV through the reviewed transcription UI; an advertised model ID is not a transcription-quality result. Compare the actual specialists on approved site cases before promotion.

The following were unavailable in the build environment and remain explicit site gates:

- Full model downloads and inference, including SQLCoder and Whisper; optional Chronos/vision models; H200 memory, driver/CUDA/vLLM compatibility, performance and both-host loss tests.
- Native Windows PowerShell/Conda and workstation GPU provisioning.
- Production systemd, nginx, Docker, TLS, account/device/file permissions and OS/network policies. Service examples now use separate application, model and numerical identities; validate these on the actual OS.
- External PostgreSQL/TimescaleDB, ClickHouse and historian gateway connections with the site's real schema, timestamps, retention and credentials.
- Physical CNC node mapping, certificates, tool/program/material/fixture qualifications, native safety enforcement and supervised failure testing in CONTROL_COMMISSIONING.md.
- Factory documents, languages and data volumes; retrieval quality, embedding/reranker relevance, process predictions and independently reviewed component remaining-life models.
- Complete air-gap transfer of OS, Python/Conda, GPU libraries, drivers, models and trusted configuration. Only the CPU Python bundle was installed offline here.

The project supports one active application/controller authority with inference replica failover. Automatic stateful authority failover, SSO, OCR and unrestricted external business SQL dialects are outside this release. These boundaries and the commissioning steps are part of the deployment manual.

# Upgrade v11 to v11.1 with RCA

Work in a new extracted directory. Keep the original v11 ZIP, configuration, environment export and a consistent runtime backup. Migration 004 adds RCA storage and permissions; migrations 001–003 and the deterministic control implementation remain unchanged. A database created or migrated by v11.1 must not be reopened for service by v11 without restoring the pre-upgrade copy.

## Back up before changing the installed package

Stop the old application, numerical writers and OPC UA monitor. Finish or reconcile pending controller commands under the existing procedure. Activate the existing smartfactoryllm environment in the **old project directory** and run:

```powershell
conda activate smartfactoryllm
conda env export -n smartfactoryllm --no-builds > smartfactoryllm-v11-backup.yml
python -m cnc_ai db backup 'F:/CNCBackups/factory-before-rca.db'
```

Use a new destination. Retain the entire stopped runtime directory as well: document files, artifact files, embeddings, configuration and supporting manifests belong with the database. Treat passwords, session records and audit evidence as sensitive. The SQLite backup command handles a consistent database snapshot; copying only a live `.db` file can miss WAL contents. Back up external history and reviewed site configuration separately.

## Validate a copy using the new package

Copy the backed-up runtime into an isolated evaluation directory. In the new project create a private `.env` from your existing values, preserving model paths and keys. Set `CNC_DATA_DIR` to the evaluation runtime and `CNC_CONFIG_DIR` to your reviewed configuration. Copy the new `rca.json` and `rca_rules.json` files into that configuration directory if it is external; review their values. Existing configuration files are not automatically overwritten.

```powershell
conda activate smartfactoryllm
python -m pip install --upgrade-strategy only-if-needed -e '.[test,download]'
python -m pip check
python -m cnc_ai db migrate
python -m cnc_ai validate --offline
python -m cnc_ai audit-verify
python -m pytest
```

This retains the environment name. To keep a separately runnable interpreter for rollback, clone first with `conda create -n smartfactoryllm_rca --clone smartfactoryllm` and install the new editable package only into that clone. Do not run the general first-install setup script against factory data; use the explicit migration command, without `--sample` or `db refresh-policy`.

The new direct dependency is `pytz>=2024,<2027`; no new neural model, inference endpoint, CUDA package or application framework is introduced. A frozen Linux CPU constraint set is provided after release validation. Build matching Windows wheels/constraints on Windows rather than applying Linux wheels there.

## Database changes and permissions

The additive migration creates eleven RCA tables: instance identity, investigations, steps, events, evidence, calculations, hypotheses, links, reviews, submissions and rule approvals. No production record is reseeded. The stable instance ID binds cases to this database and configured factory ID. Existing conversations, users, proposals, documents and audit chain remain intact.

The existing role initializer grants `rca.read` and `rca.run` to standard roles; operator/supervisor/admin also receive `rca.evidence.add`; supervisor/admin receive `rca.review`. Existing `data.read`, `chat` and document permissions still apply. Review these grants before cutover, including any custom role restrictions, because the v11 role-initialization pattern is retained. Exports, timeline and snapshots use the same ownership/reviewer checks as the case.

Configure and qualify a historical mapping before enabling factory RCA conclusions. Keep `CNC_RCA_DEMO=false` in factory deployments. Factory engineering must approve each causal verification rule against an approved document; the demo criterion has no factory authority.

## Cut over and roll back

After validating the copy and site mapping, stop all writers again, take a fresh backup and migrate the intended runtime with the reviewed package and configuration. Run a single active application authority, as in v11. Do not run two application versions against one runtime database.

For rollback, stop v11.1, archive its complete runtime and RCA exports, restore the pre-upgrade runtime/configuration backup, activate the retained v11 environment and reinstall the original v11 wheel if necessary. Start v11 only against that restored database. Do not delete migration rows or drop RCA tables in place. Post-cutover business changes need an explicit reconciliation plan before restoring an older backup.

The inspected recoverable baseline was `CNC_First_Industry_AI_Platform_v11.0.0.zip`, SHA256 `ce183ab5c5a523916cb62be12deb7c055c8649b704c36e90e89f8e19a68df6a0`. The delivered RCA ZIP is a separate project copy; it does not overwrite that archive.

# From the preparation guide to a working factory installation

This file applies your supplied **Smart CNC AI Agent — Preparation and Solutions Guide** to the delivered implementation. Its 20 topics are treated as commissioning work with owners and evidence, not as promises that an LLM can supply missing facts. The uploaded reference is not altered. Your site must replace fictional sample facts with verified machine and process records.

## Phase choice

Begin with observation and evidence-based recommendations. Keep real writes disabled while collecting reliable data and evaluating answers. Move to supervised control only after controls engineering, OT security, production and safety owners accept the site evidence. A passing software test does not promote the site or authorize an operation. The application’s internal simulator, OPC UA test endpoint and commissioned real endpoint are separate modes.

The guide's 90-day roadmap is a planning template: use the first 15 days for assets/ownership, the next 15 for data/time/identity, then database/history, approved knowledge and evaluation, read-only pilot, and finally reviewed recommendation workflows. Timing depends on local readiness; reaching day 90 is not authorization for autonomous machining.

## Traceability to all 20 guide topics

| Guide topic | Delivered support | Site work and evidence still required |
|---|---|---|
| 1. Asset inventory | CNC sample schema, machine catalog and deterministic machine profile | Walk the floor; identify OEM/controller/firmware/interfaces, limits and owners. Complete templates/asset_inventory.example.json. |
| 2. Use cases/KPIs | Cited queries, calculations, numerical analysis, scheduling and reports | Select 5–8 phase-one cases with measured baselines, owners and unacceptable outcomes. Complete the use-case register. |
| 3. Read-only connectivity | Real OPC UA adapter separated from simulator, telemetry recorder, historian clients | Configure vendor-specific nodes/certificates and permissions; test outages and reconnection. Plant-wide edge buffering/store-and-forward is not included. |
| 4. Tag dictionary | Typed control telemetry and numerical signal definitions with units/quality | Map raw tags to these contracts. Explicitly map RPM readback, commanded setpoint and override; never equate them. Complete the tag template. |
| 5. Time synchronization | UTC timestamps, freshness bounds, history windows and context checks | Operate internal NTP/PTP, measure drift and event/ingestion delay, verify controller timestamps against a trusted clock. |
| 6. Relational database | Deep CNC schema, foreign keys, migrations, controlled queries and backup tooling | Application authority is SQLite with one active owner; PostgreSQL/Timescale/ClickHouse are historian adapters. Core PostgreSQL replacement is an extension project, not implemented multi-active HA. Load/reconcile plant records and rehearse restore. |
| 7. Canonical IDs | Explicit machine/run/tool/program identifiers and digital-thread relationships | Cross-system ERP/MES/CMMS alias governance is site integration work. No general effective-dated alias service is implemented. Reject unknown/ambiguous IDs at the ingest boundary; do not fuzzy-join control context. |
| 8. Historical cleaning | Typed historical observations, quality labels, context matching and sample fixtures | Agree taxonomies and units, retain originals, map downtime reasons, quantify missing/duplicate records and reconcile KPIs against trusted reports. |
| 9. Approved RAG | Word/PDF/Excel/text extraction, chunk locations, hashes, revisions, approval, embedding/reranking | Supply current manuals/SOPs/material and tooling qualifications, machine applicability and controlled revisions. Scan-only files need external OCR; OCR is not included. Validate retrieval on plant-owned questions. |
| 10. OT cybersecurity | Separate OS service accounts, model-only environment, private endpoints, auth/CSRF and deployment examples | Zone/network allowlists, certificate lifecycle, patch/vulnerability review, offline supply-chain scanning and backup ownership are site responsibilities. |
| 11. Roles and permissions | Named accounts, four supplied roles, server-side permissions, separate approver/requester | Map real duties to permissions and review privileged access. Enterprise SSO/LDAP and every suggested plant role are not preconfigured. Never use an LLM-supplied identity. |
| 12. Deterministic commands | Ordered policy checks, approval, final confirmation, bounded OPC UA actions, uncertainty handling and audit | Qualify the actual CNC command contract and native interlocks. Example tool/process limits in the guide and seed are not commissioning values. |
| 13. End-to-end audit | Correlated workflow/model traces, query evidence, proposals, approvals, executions and chained audit | Export protected anchors/logs, set retention, control administrative access and rehearse incident reconstruction. Local hash chaining is not protection against an administrator replacing the whole database. |
| 14. Failure behavior | Bounded inference failover, explicit errors, lexical RAG degradation, fail-closed physical writes | Exercise plant network partitions, power loss, unknown write outcomes, stale/conflicting telemetry and restore/fencing. Never retry an uncertain physical write blindly. |
| 15. Equipment/semantic hierarchy | Factory/area/line/machine entities, sector profiles, extension boundaries | Map enterprise/site/work-center/work-unit naming to your systems; no ISA-95 compliance certification is claimed. |
| 16. Local AI and supply chain | Separate application/inference environments, resumable pinned downloads, external model paths and air-gap tooling | Freeze and verify the actual H200 GPU stack, model commits, license files, offline images/wheelhouses, endpoint health and workload limits. |
| 17. Evaluation | CPU software tests, simulator/wire checks, CNCBench and optional specialist tests | Build 100–300 plant-owned golden questions, source/SQL answers, safety negatives and noise-sensitive speech cases. No actual model benchmark ran in this build environment. |
| 18. Phased release | Clear simulator/real/model state labels, optional features default off, supervised action UI | Run a shadow pilot, gather operator feedback, review errors and own promotion/rollback decisions. A general feedback/ticket system is not bundled. |
| 19. Roadmap | README installation sequence and this preparation workflow | Assign owners, dates, dependencies, realistic acceptance thresholds and escalation paths; prioritize reliable read-only operation first. |
| 20. Go/no-go gates | Twelve-gate manifest and integrity/date checker | Supply reviewed evidence and have accountable owners assess its technical adequacy. The checker neither proves safety nor enables a controller. |

## Fill the site records

Copy templates/ into a site-controlled folder outside the checkout. Keep secrets out of these forms and out of Git. The JSON examples deliberately contain empty/unknown values. The same site's approved configurations, controller certificates, DB backups, corpus and model manifests must be restored as one coordinated release set.

The canonical numerical signals include rpm, vibration, bearing_temperature, spindle_load, spindle_current, feed_rate, cycle_time, power and quality_deviation. The control adapter has its own allowlisted fields such as setpoint and live interlocks. The guide's descriptive tag names must be mapped to these explicit fields; they are not an automatic rename or arbitrary write interface. Preserve raw units/quality/time upstream and mark uncertain conversions for review.

For tool/material/workpiece compatibility, a catalog entry alone is insufficient: verify the current loaded tool, material lot/workpiece, approved program and operation/process window. RAG can show qualification evidence; it cannot manufacture an authoritative qualification row or waive a missing controller signal.

## Run the twelve-gate record checker

```powershell
python scripts/validate_factory_readiness.py templates/site_readiness.example.json --output runtime/site-readiness.json
```

The untouched example returns exit code **2 / hold**. This is expected. For a site-owned copy, each gate needs an owner, a different reviewer, reviewed_at and expires_at timestamps with UTC offsets, and relative evidence file paths with SHA256 hashes. All files must stay within that manifest folder. Use `Get-FileHash -Algorithm SHA256` on Windows or `sha256sum` on Linux to fill the hashes. Do not copy the example into production and simply change statuses to passed.

Exit code 0 means only that all twelve records are marked passed, their dates are current and referenced bytes match the recorded hashes. The output deliberately says **evidence_complete**, not “factory safe”. The reviewer must judge whether the evidence actually demonstrates the requirement. Missing, altered, expired or future-dated evidence holds the record. This file is never read as a control approval and does not alter CNC_SITE_COMMISSIONED, CNC_REAL_WRITES_ENABLED, role permissions, policies or PLC state.

## Ready-to-review operator example

Question: “Is CNC-01 running, and may I request 7000 RPM?” First obtain fresh controller state, then run the read-only policy preflight. The report checks current tool rating, loaded material/workpiece/program qualification, machine/process limits and the signed-in operator. If supervisor approval is required, create a proposal only after an explicit action request, have a different supervisor review it, and let the requester confirm execution. The service rechecks authoritative facts and telemetry/interlocks before the typed write. A blocked or unknown answer is an actionable commissioning finding, never a prompt to bypass a check.

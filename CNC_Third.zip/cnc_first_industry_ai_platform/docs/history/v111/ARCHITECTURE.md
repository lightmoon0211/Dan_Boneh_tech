# Architecture · v11

The installable src/cnc_ai package separates web authentication, bounded model orchestration, evidence, numerical analysis and controller authority. Importing the package never loads model weights or opens the database. Use python -m cnc_ai after installing the package; no root-level db module or PYTHONPATH patch is needed.

```mermaid
flowchart TD
  U[Authenticated conversation] --> A[Bounded agent workflow]
  A --> R[Read-only RAG and SQL]
  A --> N[Numerical analysis and planning]
  A --> P[Structured control proposal]
  R --> E[Retained evidence]
  N --> E
  E --> O[Cited response and risk review]
  P --> D[Deterministic policy checks]
  D --> S[Separate supervisor review]
  S --> X[Requester confirmation and live recheck]
  X --> W[Allowlisted typed OPC UA write]
```

ModelRouter maps conversation/report/optional vision to 8001, code/planner/control to 8002, Guardian to 8003, embedding to 8004 and reranker to 8005. Report/planner/control are aliases, not extra weights. Primary/fallback URLs have matching model IDs/revisions/credentials and bounded retries with a thirty-second failed-replica pause. Model-call metadata records service, replica, duration and token counts; no raw secret-bearing prompt is logged there.

Two optional services are disabled by default. SQLCoder on 8006 receives only the question and approved analytical schema. Its raw completion becomes a single parsed SELECT with bound string values; the existing database authorizer still enforces tables, columns, functions and limits. When enabled, this replaces the planner's data-mode SQL draft before plan persistence. Malformed or rejected SQL stops the request. SQLCoder has no database connection or control adapter.

Whisper on 8007 receives bounded PCM WAV audio through the authenticated application. The response is a strict TranscriptionDraft containing text, duration, content hash, model and a mandatory review flag. It creates no conversation, proposal or execution. The operator edits the text, places it in the message composer and separately sends it through the normal workflow. Audio bytes are not persisted. The input hash and result status are audited.

The separate site-readiness checker verifies twelve evidence records, review expiry, contained file paths and hashes. Its evidence_complete result has no connection to controller write enablement. Factory engineering acceptance remains distinct from record validation. See FACTORY_PREPARATION.md and OPTIONAL_SPECIALISTS.md.

Agent states advance REQUEST → CLASSIFY → SAFETY_CHECK → PLAN → RETRIEVE_QUERY_ANALYZE → VERIFY → COMPOSE → FINAL_SAFETY_CHECK → RESPOND. Requests use one bounded plan, up to four approved SQL statements, and typed numerical/relationship/planning calls; no autonomous recursive tool loop exists. Strict schemas reject unknown fields. Failures and blocked responses persist their state.

Numerical service 8100 receives bounded event-time series and returns computed results, source/context/hash/model version and explicit uncertainty. It cannot create or execute control proposals. The application retains full input/result snapshots; only compact summaries enter LLM context. Development uses in-process statistics; factory uses a separate service identity plus read-only historian.

The authority database stays single-active local SQLite with ordered checksummed migrations, immutable evidence and chained audit events. Historian adapters support PostgreSQL/TimescaleDB, ClickHouse and a canonical HTTP gateway; those are not arbitrary generated-SQL dialects. The digital thread is a bounded relational edge projection, not a raw sensor archive or inference of causation.

CNC program drafts go through a separate artifact hash, static review and human simulation/collision/engineering/approval attestations. Export never sends a program to a controller. Numerical forecasts, RAG revisions and Guardian scores cannot change factory policy.

Preserved v9 functions include authentication/CSRF, conversations/languages, report management, sector/schema administration, document extraction, SQL engine authorizer, persistent control approval/unknown-write reconciliation, simulator and actual loopback OPC UA transport. See MIGRATION_V9_TO_V10.md and the original 134-file audit.

## RCA extension in 11.1

The dedicated `cnc_ai.rca` executor persists its own bounded workflow in the existing authority database. It uses a read-only canonical history adapter or explicit native context limitations, deterministic calculations and factory-approved causal criteria. A local planner may select permitted checks; only the executor supplies completion events and only returned records supply evidence. RAG mechanisms remain background. RCA imports no controller adapter and cannot run generated code, DML, schedule updates or OPC UA writes. The existing action flow remains separate. See `rca/DEVELOPER_GUIDE.md` for the API, version/retention and connector contracts.

# Deployment and operations

## Supported topology

Both eight-H200 hosts run the same five inference services as replicas. One active application owns SQLite, documents and controller authority. Factory numerical computation runs separately on port 8100 with a read-only historian. See H200_DEPLOYMENT.md and deployment/ha/README.md.

Only the application service can reach the reviewed OPC UA endpoint. Inference services do not receive OPC UA credentials and should have no route to controller write interfaces. Restrict ports 8001–8005 (8006–8007 only when optional specialists are enabled) on both hosts and numerical port 8100 to the application host. Restrict port 5000 to the local reverse proxy. DNS/NTP can be supplied by the factory's internal infrastructure.

## Files and permissions

Extract code to `/opt/cnc-ai`; store models at `/srv/ai/models`; create a dedicated `cncai` OS account and local runtime directory. Edit paths to suit site conventions. Keep `.env` and certificates readable only by the service account and authorized administrators. Configuration is reviewed code-adjacent input; only the runtime directory needs application write access.

```bash
sudo install -d -o cncai -g cncai -m 700 /opt/cnc-ai/runtime
sudo chown cncai:cncai /opt/cnc-ai/.env
sudo chmod 600 /opt/cnc-ai/.env
```

Prepare the account and Conda environments using the site's normal OS provisioning. Do not blindly apply recursive ownership changes to existing factory data. On Linux replace every `F:/...` model path in `.env`, and set `MODEL_ROOT=/srv/ai/models`. Restart services after configuration changes.

## systemd

The supplied unit files are examples with `/opt/conda/envs/...` interpreter paths. Resolve the actual environment path with `conda run -n smartfactoryllm python -c 'import sys; print(sys.executable)'` and update the units before installation. Models use `smartfactorymodels`. Create separate `cncmodels` and `cncts` OS accounts. Give them read access to code, numerical configuration and the relevant external models, without access to the application's `.env`, runtime database or controller credentials. The model unit reads only `/etc/cnc-ai/models.env` through `--env-file`. Include MODEL_ROOT, individual model paths, the private bind address, service keys and any GPU overrides there. The numerical unit uses a separate CNC_HOME so it never opens the application `.env`.

Create `/etc/cnc-ai` with traversal permissions for these service accounts. Protect models.env as owner cncmodels, mode 600; protect timeseries.env as owner cncts, mode 600. Put CNC_PROFILE=factory and CNC_TIMESERIES_API_KEY in timeseries.env, with any optional Chronos/component-model paths. Use the same numerical API key in the application configuration. Numerical computation receives bounded input from the application and requires no historian or controller credentials. systemd StateDirectory creates separate writable caches/log directories under /var/lib for both services. Use the site's GPU device groups for cncmodels.

```bash
sudo cp deployment/systemd/cnc-ai.service /etc/systemd/system/
sudo cp deployment/systemd/cnc-models@.service /etc/systemd/system/
sudo cp deployment/systemd/cnc-telemetry.service /etc/systemd/system/
sudo cp deployment/systemd/cnc-timeseries.service /etc/systemd/system/
sudo systemctl daemon-reload
```

On A, after initialization and configuration:

```bash
sudo systemctl enable --now cnc-models@server-a.service
sudo systemctl enable --now cnc-timeseries.service
sudo systemctl enable --now cnc-ai.service
```

On B:

```bash
sudo systemctl enable --now cnc-models@server-b.service
```

Start the optional read-only telemetry recorder on the authoritative application host after validating the adapter:

```bash
sudo systemctl enable --now cnc-telemetry.service
journalctl -u cnc-ai.service -n 100 --no-pager
journalctl -u cnc-models@server-a.service -n 100 --no-pager
```

Model child logs are under `/var/lib/cnc-models/logs` with systemd, or `runtime/model_logs` for the default interactive launcher. Configure log rotation and monitor free disk. The service launcher stops its sibling children if one fails; systemd restarts that host profile. This supervises startup; ModelRouter separately supports bounded replica failover. For maintenance stop the profile explicitly.

## HTTPS browser access

Install `deployment/nginx.conf` into the site's nginx HTTP configuration, set the actual hostname and certificate/key paths and test it using `nginx -t`. Waitress stays at `127.0.0.1:5000`. Set:

```dotenv
CNC_COOKIE_SECURE=true
CNC_TRUST_PROXY=true
CNC_HOST=127.0.0.1
```

The proxy replaces forwarded headers. `CNC_TRUST_PROXY=true` trusts exactly one proxy hop, so direct untrusted access to Waitress must be blocked. It allows correct HTTPS origin checks and secure cookies. Use the site's trusted CA; do not disable browser certificate validation. Local workstation HTTP uses both flags false.

## Docker option

The Linux-only Compose example uses host networking so local and private model/controller endpoints resolve as configured. It runs the application as UID/GID 10001 with a read-only container filesystem and writable runtime mount. The image includes historian client dependencies for the factory profile. Model serving remains a separate host environment. Review the environment and mount paths first.

```bash
docker compose -f deployment/docker/compose.yml build
mkdir -p runtime
sudo chown 10001:10001 runtime
docker compose -f deployment/docker/compose.yml run --rm app python -m cnc_ai db init --sample
docker compose -f deployment/docker/compose.yml run --rm app python -m cnc_ai user add factory_admin --role admin
docker compose -f deployment/docker/compose.yml up -d
```

For real OPC UA, add read-only mounts for the site's client key/certificates and configure the container-visible paths. Do not mount the Docker socket. This image requires build-time dependency access; build on staging and use image save/load for air-gapped use. The example is not a Windows Docker Desktop networking profile. Keep the host HTTPS proxy and loopback application bind.

## Backups and restore

`python -m cnc_ai db backup /srv/backups/cnc-YYYYMMDD.db` uses SQLite's online backup API and refuses to overwrite an existing backup. Back up runtime documents, imported source databases, configuration, model manifests and audit-chain checkpoints as well. Stop ingestion/report activity when taking a coordinated filesystem/database backup so references align. Encrypt/protect backups using the site's standard tooling.

For a consistent whole-runtime backup, stop the application and telemetry services, take the database backup, copy the documents/sources/configuration, then restart. Do not copy a live SQLite main file without its WAL. During restore keep the application stopped, restore a consistent set, run `db migrate`, `validate --offline` and `audit-verify`, and reconcile actual controller state before accepting control actions. Never use a rollback to replay a delivered proposal.

The SHA256 audit chain and append-only triggers detect ordinary tampering but do not defeat an administrator who rewrites an entire database and its anchors. Export the chain head to a separately protected log/archive as part of operations. Retention and immutable external anchoring are site responsibilities.

## Capacity and maintenance

The telemetry recorder defaults to one observation every five seconds. Set a site retention/archival policy based on actual row growth; no background deletion of evidence/audit/control records is performed. SQLite is not a high-rate multi-server historian. Use curated analytical replicas for bulk history, and never share the live file over SMB/NFS.

RAG ingestion is synchronous with bounded document size. Schedule large ingestion and report jobs outside peak interactive periods. Benchmark semantic retrieval on the actual corpus before expanding it substantially. Back up before upgrades, apply migrations through the CLI, refresh a reviewed SQL allowlist with `db refresh-policy`, and restart the service. Applied migration files must not be edited.

## RCA release archive

The 11.1 source archive adds RCA without model weights or production runtime data. After reviewing your source tree for private content, reproduce it with `python scripts/package_release.py --output /path/outside/project/CNC_First_Industry_AI_Platform_v11.1.0_RCA.zip`. Verify an extracted copy using `python scripts/verify_bundle.py .`. This source ZIP does not include OS packages or dependency/model weights; prepare those using the matching-platform air-gap procedure. For v11 data use `rca/MIGRATION.md`, never reseed an existing factory runtime.

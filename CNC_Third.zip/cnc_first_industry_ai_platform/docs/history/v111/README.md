# CNC Factory Assistant · v11.1.0

A local CNC conversational platform with cited RAG/database evidence, numerical machine intelligence, deterministic planning and a supervised OPC UA control boundary. The complete v10 repository was verified and inspected before this rebuild. CNC remains the deepest domain; approved analytical schemas and sector profiles support extension.

**Start in simulator mode.** Set `CNC_MODEL_MODE=demo` in `.env` for CPU development: the UI, database, lexical RAG, statistics and simulator run without model weights. The ZIP has no default passwords, site secrets or weights. Actual H200 inference and physical CNC control have separate staging/commissioning checks.

| Port | Roles | Model / implementation |
|---|---|---|
| 8001 | conversation, report; optional vision | Qwen/Qwen3.8-27B |
| 8002 | code, planner, control proposals | Qwen/Qwen3-Coder-30B-A3B-Instruct |
| 8003 | secondary language-risk judge | ibm-granite/granite-guardian-4.1-8b |
| 8004 | embedding | Qwen/Qwen3-Embedding-4B |
| 8005 | reranking | Qwen/Qwen3-Reranker-0.6B |
| 8006 | optional SQL specialist | defog/llama-3-sqlcoder-8b |
| 8007 | optional speech transcription | openai/whisper-large-v3-turbo |
| 8100 | numerical analysis | Statistical engine; optional local Chronos-2 |

Report/planner/control reuse services. The LLM proposes; deterministic policies and authenticated approval determine eligibility. Only a typed adapter can write, after live context/limits/interlocks are rechecked. Granite Guardian cannot grant CNC permission.

Included: saved conversational UI with consistent language names; complete CNC sample schema; hybrid approved-revision RAG; strict read-only SQL; provenance; digital thread; historian adapters; signal processing and eight numerical analysis APIs; planning/cutting calculations; NC engineering artifact gates; audit and agent state; resumable downloads; Windows/Linux/H200/air-gap tooling; tests and a formatted manual.

**New in v11:** reviewed model selection, a smaller default coder with the previous coder profile retained, optional SQLCoder and reviewed Whisper transcription, and site-readiness evidence checks. Start with [START_HERE.md](START_HERE.md), then [model decisions](docs/MODEL_SELECTION.md) and [your preparation guide applied](docs/FACTORY_PREPARATION.md). See [v10 migration](docs/MIGRATION_V10_TO_V11.md) before reusing an existing runtime.

## Root cause investigations in v11.1

RCA extends the actual v11 application with a bounded, read-only workflow, visible executor timeline, causal evidence map, authorized snapshots, deterministic loss calculations and saved revisions. It distinguishes CNC production resources from finished machines being assembled. The original model configuration and control boundary remain in place; no new model is required.

Read [the RCA user guide](docs/rca/USER_GUIDE.md), [upgrade and rollback steps](docs/rca/MIGRATION.md), [connector and rule documentation](docs/rca/DEVELOPER_GUIDE.md), and [the actual v11 inspection](docs/rca/INSPECTION.md). The formatted RCA guide supplements the unchanged v11 base manual. [Validation](docs/VALIDATION.md) separates software tests from site acceptance.

For an existing v11 runtime, back up first, install this package in `smartfactoryllm`, then run `python -m cnc_ai db migrate`. Do not reseed an existing factory database. For training, set `CNC_MODEL_MODE=demo`, `CNC_PROFILE=development`, `CNC_OPCUA_MODE=simulator` and `CNC_RCA_DEMO=true`, then run:

```powershell
python -m cnc_ai rca demo --user admin
python -m cnc_ai serve
```

Select **Synthetic training cases** under **RCA evidence**, then ask “Why did CNC-03 production decrease on 2026-09-08?” The example reconciles 70 fewer good pieces into an estimated 60-piece downtime loss and 10 additional scrap. Real factory RCA requires a qualified historical mapping; no live MES/ERP/NX/APS connector is implied.

## Eleven installation steps

Run commands from the extracted project directory. Quote paths containing spaces. Use Python 3.12 for the supplied environment definitions; Python 3.11–3.13 is supported by the application package.

### 1. Create or recreate `smartfactoryllm`

For a new installation, in Anaconda PowerShell Prompt:

```powershell
conda env create -f environments/smartfactoryllm.yml
conda activate smartfactoryllm
python -m pip install -e '.[test,download]'
Copy-Item .env.example .env
```

For an existing old environment, first export it and create a clean replacement while retaining the old one:

```powershell
conda env export -n smartfactoryllm --no-builds > smartfactoryllm-old.yml
conda list -n smartfactoryllm --explicit > smartfactoryllm-old-explicit.txt
conda create -n smartfactoryllm_v11 python=3.12 pip -y
conda activate smartfactoryllm_v11
python -m pip install -e '.[test,download]'
python -m pytest
```

After backing up the old project's data and validating the replacement, recreate the requested environment name:

```powershell
conda deactivate
conda env remove -n smartfactoryllm
conda create -n smartfactoryllm --clone smartfactoryllm_v11 -y
conda activate smartfactoryllm
python -m pip check
```

The removal command deletes only that Conda environment. Do not run it before exporting and validating the replacement. Reinstall the editable package if you move the extracted project. [MIGRATION.md](docs/MIGRATION.md) covers old databases and documents. Existing compatible environments can use `scripts/windows/setup.ps1`; it does not delete environments or overwrite an existing database.

Without Conda, `python -m venv .venv` followed by environment activation and the same pip command works. GPU libraries belong in the separate `smartfactorymodels` Linux environment.

### 2. Download or resume the factory models

Keep model storage outside the project, for example `F:/AI/models/`. In the application environment:

```powershell
python scripts/models/download_factory_models.py all --model-root 'F:/AI/models' --workers 2 --checksums
```

The four core role ports remain stable; v11 selects a different default coder and retains the reranker. The all command downloads five core snapshots. Statistical numerical analysis needs no weights. Chronos-2 is a separate optional download.

Download one model:

```powershell
python scripts/models/download_factory_models.py code --model-root 'F:/AI/models' --workers 1 --checksums
```

After Ctrl+C, reboot or lost internet, run the **same command** again. Partial files, Hugging Face metadata and the pinned commit are retained. Each operation retries 20 times by default; `--retries 0` retries indefinitely. Permanent authorization/not-found/disk errors stop with a clear message. Keep the model root's `.factory-downloads` manifests and each model's `.cache/huggingface` metadata.

```powershell
python scripts/models/download_factory_models.py all --model-root 'F:/AI/models' --verify --checksums
```

Verification is offline. SHA256 verification requires a download completed with `--checksums`; otherwise repeat the download command with that option first. Linux uses paths such as `/srv/ai/models`; WSL uses `/mnt/f/AI/models`.

### 3. Point to existing local models

Edit `.env`; no application source changes are required:

```dotenv
MODEL_ROOT=F:/AI/models
CONVERSATION_MODEL_PATH=${MODEL_ROOT}/Qwen3.8-27B
CODE_MODEL_PATH=${MODEL_ROOT}/Qwen3-Coder-30B-A3B-Instruct
SAFETY_MODEL_PATH=${MODEL_ROOT}/granite-guardian-4.1-8b
EMBEDDING_MODEL_PATH=${MODEL_ROOT}/Qwen3-Embedding-4B
RERANKER_MODEL_PATH=${MODEL_ROOT}/Qwen3-Reranker-0.6B
```

Each path must be a complete Hugging Face Transformers snapshot containing its configuration, tokenizer and weight shards. An existing Hub cache can use its concrete `snapshots/<commit>` directory. GGUF files are not interchangeable with the included vLLM serving path. Set `EMBEDDING_MODEL_REVISION` to the exact snapshot commit and rebuild embeddings whenever it changes. Existing local models without downloader manifests may be served, but cannot pass manifest verification until acquired/registered through a verified download root.

### 4. Start the inference and numerical services

Use Linux on the H200 servers, or WSL2 for suitable workstation hardware. A smaller Windows PC can run the UI, database, RAG lexical search and simulator in `CNC_MODEL_MODE=demo`, or point to the factory servers. It is not expected to load all original models locally.

On **each Linux inference host**, with the project installed at `/opt/cnc-ai`:

```bash
conda env create -f environments/smartfactorymodels.yml
conda activate smartfactorymodels
python -m pip install -r requirements/h200.txt
```

The H200 requirements specify a staging candidate, not a hardware certification. Run the model tests on the actual GPUs, then freeze the entire working environment before transfer.

Edit `.env` on each host to use Linux model paths. Set `MODEL_SERVER_BIND` to its private inference-interface address and set distinct long API keys for services hosted there. On server A:

```bash
python scripts/models/serve_models.py server-a --dry-run
python scripts/models/serve_models.py server-a
```

On server B:

```bash
python scripts/models/serve_models.py server-b --dry-run
python scripts/models/serve_models.py server-b
```

Each host runs the same five services as replicas: code on host-local GPU 0 (TP1), conversation on 2–3 (TP2), safety on 4, embedding on 5 and reranker on 6. Optional SQLCoder uses GPU 1 and Whisper uses GPU 7. The core allocation uses twelve GPUs across both hosts, or sixteen with both specialists. Run server-a on A and server-b on B; never both host targets on one host. These are staging allocations, not measured throughput guarantees. See H200_DEPLOYMENT.md for capacity and failover tests.

On the application host, configure the corresponding URLs and the same keys, for example:

```dotenv
CONVERSATION_BASE_URL=http://10.20.0.11:8001/v1
CODE_BASE_URL=http://10.20.0.12:8002/v1
SAFETY_BASE_URL=http://10.20.0.11:8003/v1
EMBEDDING_BASE_URL=http://10.20.0.11:8004/v1
RERANKER_BASE_URL=http://10.20.0.11:8005
CONVERSATION_FALLBACK_URLS=http://10.20.0.12:8001/v1
CODE_FALLBACK_URLS=http://10.20.0.11:8002/v1
SAFETY_FALLBACK_URLS=http://10.20.0.12:8003/v1
EMBEDDING_FALLBACK_URLS=http://10.20.0.12:8004/v1
RERANKER_FALLBACK_URLS=http://10.20.0.12:8005
CNC_MODEL_MODE=local
```

These addresses are examples; substitute your private addresses. Restrict inference ports to the application host. Use site TLS termination for inference if traffic crosses a shared network. `/v1/models` means reachable and advertised; **Verify model inference** performs actual test requests.

Development runs statistical analysis inside the app. For the factory, set CNC_PROFILE=factory, configure the historian reader and numerical service key, then start:

```bash
python -m cnc_ai timeseries serve --host 127.0.0.1 --port 8100
```

Set a random CNC_TIMESERIES_API_KEY of at least 24 characters for both clients and service. The factory profile selects PostgreSQL historian, HTTP numerical transport and approved-only documents. Install the historian extra and set CNC_HISTORIAN_DSN, or explicitly select a reviewed alternative backend. The numerical service needs no controller credentials. See TIME_SERIES_INTELLIGENCE.md.

### 5. Initialize the CNC database and accounts

```powershell
python -m cnc_ai db init --sample
python -m cnc_ai user add factory_admin --role admin --display-name 'Factory administrator'
python -m cnc_ai user add operator01 --role operator --display-name 'Operator 01'
python -m cnc_ai user add supervisor01 --role supervisor --display-name 'Shift supervisor'
```

Passwords are securely prompted twice, with a 12-character minimum. No default login credentials are shipped. Administrator privileges do not grant machine control or supervisor approval. Use separate named accounts. `db init` without `--sample` creates the complete empty business schema for a new factory database; it still includes simulator state for training. Initialization preserves existing data and applies checksummed migrations.

### 6. Ingest RAG documents

```powershell
python -m cnc_ai ingest samples/documents/spindle_change_sop.md --user factory_admin --kind sop --revision training-v10
python -m cnc_ai ingest samples/documents/tool_material_specifications.csv --user factory_admin --kind tool --revision training-v10
python -m cnc_ai ingest samples/documents/shift_report.txt --user factory_admin --kind report
python -m cnc_ai rebuild-embeddings --user factory_admin
```

A different supervisor approves the reviewed revision using Approve revision in Documents & reports. An uploader cannot approve their own source. Factory retrieval uses the current approved revision; a new approval supersedes the old revision in the same sector/category/filename family. Keep filenames stable within a revision family. Development can retrieve a draft when no approved revision exists, with its status recorded. Approval is not inferred from document text.

Load the numerical sample and digital thread:

```powershell
python -m cnc_ai timeseries ingest samples/telemetry/cnc_telemetry.csv --user factory_admin
python -m cnc_ai knowledge rebuild --user factory_admin
```

Or sign in as an administrator/supervisor and use **Documents & reports**. Categories include manuals, SOPs, maintenance, machine/tool/material specifications and production reports. Scanned PDFs need offline OCR; legacy `.doc` needs local conversion to `.docx`. Excel formulas are read from saved cached results. Sample documents are fictional training material, not OEM-approved machining parameters.

### 7. Run the OPC UA simulator

The default `CNC_OPCUA_MODE=simulator` uses a persistent internal simulator and needs no other process. For a real OPC UA protocol test without machinery, start this in a second terminal:

```powershell
conda activate smartfactoryllm
python -m cnc_ai opcua-simulator --port 4840
```

Then set `CNC_OPCUA_MODE=opcua_test` and `OPCUA_ENDPOINT=opc.tcp://127.0.0.1:4840` in `.env`, restart the application and run `python -m cnc_ai validate --opcua`. Test mode is restricted to loopback.

Sign in as `operator01`, prepare CNC-01 at 7000 RPM and run the policy checks. Create the proposal. A separate signed-in `supervisor01` reviews and approves it. The requester returns and types `EXECUTE APPROVED ACTION`. Successful setpoint readback is not proof that measured spindle speed changed.

### 8. Configure a real CNC OPC UA endpoint

Follow [CONTROL_COMMISSIONING.md](docs/CONTROL_COMMISSIONING.md). A controls engineer must replace the training recipes/limits and sample node mapping; prove native controller enforcement; configure the actual machine state semantics; and test timestamp quality, interlocks and authenticated write access.

Configure an OPC UA client certificate/private key, pinned server certificate and restricted controller service account in `.env`. The real adapter uses `Basic256Sha256` with `SignAndEncrypt`. It exposes only allowlisted typed spindle setpoint and feed-hold actions. Real mode requires `real_mapping_reviewed=true` and `controller_enforces_limits=true` in `config/opcua.json`. Keep `CNC_REAL_WRITES_ENABLED=false` while testing reads. Enable real writes and `CNC_SITE_COMMISSIONED=true` only after the documented site acceptance. Demo model mode cannot be combined with a real controller.

### 9. Start the application

```powershell
conda activate smartfactoryllm
python -m cnc_ai serve
```

Open `http://127.0.0.1:5000`. Windows wrappers are `scripts/windows/start.ps1` and `start_windows.bat`. Linux uses `bash scripts/linux/start_app.sh`. The server is Waitress; there are no fragile root-level `db` imports.

For factory users, keep Waitress on loopback behind the provided HTTPS nginx configuration and set `CNC_COOKIE_SECURE=true`, `CNC_TRUST_PROXY=true`. Only the trusted proxy may access Waitress. [DEPLOYMENT.md](docs/DEPLOYMENT.md) includes systemd, Docker, firewall and backup instructions.

### 10. Validate the complete installation

```powershell
python -m pip check
python -m pytest
python -m cnc_ai validate --offline
python -m cnc_ai validate --models --opcua
python -m cnc_ai audit-verify
python -m cnc_ai cncbench --output runtime/cncbench
python -m cnc_ai timeseries analyze anomaly samples/telemetry/anomaly_query.json --user operator01 --output runtime/anomaly.json
Invoke-RestMethod -Uri 'http://127.0.0.1:5000/api/health'
```

You can also run `python scripts/validate_installation.py` to exercise a fresh temporary simulator instance, including database setup, document approval, telemetry ingestion and numerical analysis, without modifying your configured factory database. Use the network checks after starting the relevant services. `--offline` validates the database and package without probing network endpoints. Do not combine it with network flags. In PowerShell, use `Invoke-RestMethod`; if you specifically need native curl, call `curl.exe`, not its ambiguous alias. Optional browser testing: `python scripts/validate_browser.py` after installing the browser test dependencies described in [VALIDATION.md](docs/VALIDATION.md).

### 11. Transfer to the air-gapped H200 servers

On a connected **Linux staging host matching the factory OS, CPU architecture and Python version**, install and validate the H200 environment. Freeze it:

```bash
conda activate smartfactorymodels
python -m pip freeze > /srv/transfer/inference-lock.txt
conda activate smartfactoryllm
python scripts/prepare_airgap.py --output /srv/transfer/cnc-wheels --inference-lock /srv/transfer/inference-lock.txt --extra historian
python scripts/verify_bundle.py /srv/transfer/cnc-wheels
```

Transfer this project ZIP, the wheel bundle, complete model directories and manifests, an offline Python/Conda environment or installer/package cache, compatible NVIDIA drivers, required OS libraries, site certificates and approved configuration. Windows wheels do not satisfy Linux installation. See [AIR_GAP_DEPLOYMENT.md](docs/AIR_GAP_DEPLOYMENT.md) for exact offline installation, checksum checks, Docker image transfer, commissioning and rollback commands. Model weights are deliberately absent from this ZIP.

## Project guide

| Folder | Purpose |
|---|---|
| src/cnc_ai | Installed Python package, typed services, web UI and resources |
| config | Reviewed model, safety, engineering, RAG and numerical configuration |
| scripts | Download, serving, database, ingestion, validation and offline packaging |
| samples | Fictional CNC documents, telemetry, planning and sector schemas |
| deployment | Linux services, Docker/nginx, historians, HA and observability |
| tests | Deterministic, security, HTTP and loopback OPC UA tests |
| docs | Detailed manual, architecture, deployment and actual validation results |
| packages | Application wheel; prepare dependency wheels for the target OS separately |

Start with [USER_MANUAL.pdf](docs/USER_MANUAL.pdf), [editable manual](docs/USER_MANUAL.docx), [Windows guide](docs/WINDOWS_DEVELOPMENT.md), [H200 guide](docs/H200_DEPLOYMENT.md), [air-gap guide](docs/AIR_GAP_DEPLOYMENT.md), [migration](docs/MIGRATION_V9_TO_V10.md), [numerical intelligence](docs/TIME_SERIES_INTELLIGENCE.md) and [validation](docs/VALIDATION.md).

One active application authority is supported. Inference failover is implemented; stateful authority HA requires site fencing/storage. This is not a safety PLC or a certified CNC safety function. Synthetic accuracy is not factory accuracy.

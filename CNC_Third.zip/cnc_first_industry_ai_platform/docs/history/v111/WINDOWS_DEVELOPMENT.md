# Windows and the old smartfactoryllm environment

Use Anaconda PowerShell Prompt from the extracted project directory. CPU development needs no Torch/CUDA weights. Python 3.12 runs the UI, database, lexical RAG, numerical statistics and simulators.

```powershell
conda env create -f environments/smartfactoryllm.yml
conda activate smartfactoryllm
python -m pip install -e '.[test,download]'
Copy-Item .env.example .env
```

For an old environment, export it before replacing anything. The setup script's -Recreate option uses a separate smartfactoryllm_v11 environment and retains the old one:

```powershell
conda env export -n smartfactoryllm --no-builds > smartfactoryllm-old.yml
conda list -n smartfactoryllm --explicit > smartfactoryllm-old-explicit.txt
powershell -ExecutionPolicy Bypass -File scripts/windows/setup.ps1 -Recreate
conda activate smartfactoryllm_v11
python -m pip check
python -m pytest
```

README step 1 explains deliberate cloning back to the original name after validation. Do not blindly copy a Conda directory across machines/operating systems. Recreate from a tested lock/wheelhouse or use a validated same-platform environment package.

Set CNC_PROFILE=development, CNC_MODEL_MODE=demo and CNC_OPCUA_MODE=simulator in .env. Initialize named accounts, documents and telemetry as in README. Run python -m cnc_ai serve. PowerShell scripts accept -EnvironmentName smartfactoryllm_v11; .bat wrappers default to smartfactoryllm.

Use Invoke-RestMethod -Uri 'http://127.0.0.1:5000/api/health', or explicitly curl.exe, to avoid the PowerShell curl alias. Quote paths with spaces. F:/AI/models is Windows; WSL uses /mnt/f/AI/models. vLLM serving belongs in Linux/WSL2. Use private model URLs to reach actual inference services from a smaller workstation. Native PowerShell execution remains a target-machine validation gate.

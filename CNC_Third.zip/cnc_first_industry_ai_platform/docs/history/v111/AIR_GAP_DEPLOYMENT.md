# Air-gap transfer and execution

Prepare on a connected Linux staging host matching factory OS, architecture and Python 3.12. Windows wheels are not Linux wheels. First validate exact model commits and the complete H200 driver/CUDA/Torch/vLLM environment, then freeze it.

```bash
conda activate smartfactorymodels
python -m pip freeze > /srv/transfer/inference-lock.txt
conda activate smartfactoryllm
python scripts/prepare_airgap.py --output /srv/transfer/cnc-bundle --inference-lock /srv/transfer/inference-lock.txt --model-root /srv/ai/models --extra historian
python scripts/verify_bundle.py /srv/transfer/cnc-bundle
```

The helper builds an application wheelhouse, exports source/frontend/configuration, optionally downloads the validated inference lock and copies model manifests/references. Models remain external unless --copy-models is explicitly given. Output must be outside both source and model trees. It excludes runtime data, secrets, private keys, caches and weights from the source archive. Download all required model snapshots with --checksums, preserve metadata, and run offline verification. Do not prune tokenizer/config/shard files to save space without testing the exact snapshot.

Transfer the project ZIP, matching wheelhouses, verified model directories/manifests, approved offline Python/Conda installer or packaged environment, NVIDIA drivers, OS libraries, site configuration and certificates through the factory's controlled media process. The project ZIP itself contains no weights. Provision credentials separately. The factory profile requires `--extra historian` above. Add `--extra forecast` for Chronos or `--extra browser` for browser validation; extras may be repeated. Browser executables and their OS libraries must also be staged separately.

On the offline host:

```bash
python -m venv /opt/cnc-env
/opt/cnc-env/bin/python -m pip install --no-index --find-links /srv/transfer/cnc-bundle/app-wheelhouse 'cnc-first-ai[historian,test,download]'
/opt/cnc-env/bin/python -m pip check
python scripts/verify_bundle.py /srv/transfer/cnc-bundle
```

Create the separate inference environment using the approved offline Python installer:

```bash
python -m venv /opt/cnc-model-env
/opt/cnc-model-env/bin/python -m pip install --no-index --find-links /srv/transfer/cnc-bundle/inference-wheelhouse -r /srv/transfer/cnc-bundle/inference-lock.txt
/opt/cnc-model-env/bin/python -m pip check
```

Extract source to /opt/cnc-ai for reviewed configuration, scripts, tests and docs. Set CNC_HOME=/opt/cnc-ai and runtime/model paths. These venv paths differ from the sample Conda service paths; edit ExecStart in each systemd unit to match the installed interpreter. If using containers, build/test on staging, `docker save -o /srv/transfer/cnc-ai-image.tar cnc-first-ai:11.0.0`, verify its checksum and `docker load -i /srv/transfer/cnc-ai-image.tar` offline. The supplied Dockerfile is not an offline package downloader.

Initialize or migrate a consistent database copy, create named users, ingest and approve documents, configure the historian and numerical key, start services and run validation. HF_HUB_OFFLINE/TRANSFORMERS_OFFLINE prevent runtime Hub retrieval. Remove internet routes from inference hosts; test offline startup with no DNS dependency outside the factory.

Run wire simulator tests, actual model verification, CNCBench --models, numerical historian queries, audit verification and both host-failure scenarios. Record exact hashes/versions, observed latency and operator acceptance. Keep real writes disabled until commissioning.

For rollback stop the single active authority and recorder, preserve a complete consistent runtime/config backup, restore the prior release and reconcile physical CNC state. Never replay a delivered proposal from a restored backup. Automatic stateful authority failover is not supplied; use site fencing/storage and the HA procedure.

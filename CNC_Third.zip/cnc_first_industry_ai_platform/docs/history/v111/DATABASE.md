# CNC database catalog

Generated from the initialized v11.1 sample database. All business records are fictional training data. Live controller policy remains in reviewed site configuration.

## Domain coverage

The full business seed covers factories, lines, machines, tools, customers, materials, BOMs, orders, operations, production, downtime, maintenance, quality, stock, sensors and OEE. Platform tables cover authenticated users/roles, approvals, control proposals/executions, documents/vectors, reports and chained audit. Version 11.1 adds bounded RCA investigations, execution events, evidence snapshots, causal links and independent reviews. Version 10 adds canonical historian observations, numerical analyses, digital-thread relations, approved program qualifications, controlled document revisions, agent traces and engineering artifact attestations.

The seed contains 108 tables including FTS internals, 26 machines, 100 work orders and 27,360 legacy sensor readings. The separate canonical telemetry CSV contains 30,240 observations; import it using the manual. Tables that record runtime activity start empty.

Application storage uses SQLite with foreign keys and WAL. The positive SQL allowlist excludes authorization, session, audit and control-authority tables. External PostgreSQL/ClickHouse historian adapters use fixed parameterized queries; they do not change the generated SQL dialect or turn SQLite into a multi-active database. See DATABASE_DESIGN.md for extension boundaries.

## Tables and columns

| Table | Seed rows | Columns |
|---|---:|---|
| agent_plans | 0 | id TEXT PK; conversation_id TEXT; actor TEXT; plan_json TEXT; created_at TEXT |
| agent_runs | 0 | id TEXT PK; conversation_id TEXT; actor TEXT; started_at TEXT; finished_at TEXT; status TEXT; request_sha256 TEXT |
| agent_steps | 0 | id INTEGER PK; run_id TEXT; state TEXT; at TEXT; detail_json TEXT |
| agv_tasks | 40 | task_id INTEGER PK; agv_id INTEGER; task_type TEXT; source_location TEXT; destination_location TEXT; requested_at TEXT; started_at TEXT; completed_at TEXT; status TEXT |
| agvs | 4 | agv_id INTEGER PK; agv_code TEXT; model TEXT; status TEXT; battery_pct REAL; pos_x REAL; pos_y REAL |
| analysis_records | 0 | id TEXT PK; actor TEXT; kind TEXT; machine_id TEXT; created_at TEXT; input_sha256 TEXT; request_json TEXT; result_json TEXT |
| answer_citations | 0 | message_id TEXT PK; evidence_id TEXT PK |
| app_settings | 0 | key TEXT PK; value TEXT |
| approvals | 0 | id INTEGER PK; proposal_id TEXT; actor TEXT; decision TEXT; comment TEXT; at TEXT |
| areas | 7 | area_id INTEGER PK; factory_id INTEGER; factory_code TEXT; area_name TEXT; area_type TEXT |
| artifact_attestations | 0 | id INTEGER PK; artifact_id TEXT; gate TEXT; actor TEXT; at TEXT; result TEXT; report_sha256 TEXT; comment TEXT |
| audit_events | 0 | id INTEGER PK; at TEXT; actor TEXT; event TEXT; payload TEXT; previous_hash TEXT; hash TEXT |
| bom_items | 33 | bom_item_id INTEGER PK; product_id INTEGER; material_id INTEGER; quantity_per REAL; scrap_factor REAL |
| chat_messages | 0 | id TEXT PK; conversation_id TEXT; role TEXT; content TEXT; response_json TEXT; created_at TEXT |
| chunk_embeddings | 0 | chunk_id TEXT PK; model_fingerprint TEXT; dimensions INTEGER; vector_json TEXT |
| cnc_program_deployments | 40 | id INTEGER PK; program_id INTEGER; machine_id INTEGER; deployed_at TEXT; status TEXT |
| cnc_programs | 36 | program_id INTEGER PK; program_code TEXT; product_id INTEGER; operation_seq INTEGER; revision TEXT; controller_family TEXT; file_name TEXT; approved_at TEXT |
| code_artifacts | 0 | id TEXT PK; sha256 TEXT; owner TEXT; created_at TEXT; machine TEXT; program_text TEXT; review_json TEXT; state TEXT |
| component_history | 7 | id INTEGER PK; machine_id INTEGER; component TEXT; event_type TEXT; event_time TEXT; operating_hours REAL; detail TEXT; source TEXT |
| control_executions | 0 | id TEXT PK; proposal_id TEXT; actor TEXT; mode TEXT; started_at TEXT; finished_at TEXT; status TEXT; requested_value REAL; confirmed_value REAL; detail TEXT; checks_json TEXT |
| control_proposals | 0 | id TEXT PK; machine TEXT; requester TEXT; request_json TEXT; policy_hash TEXT; binding_json TEXT; created_at TEXT; expires_at REAL; status TEXT; checks_json TEXT |
| controller_snapshots | 0 | id INTEGER PK; machine TEXT; mode TEXT; captured_at TEXT; healthy INTEGER; detail TEXT; samples_json TEXT |
| conversations | 0 | id TEXT PK; owner TEXT; title TEXT; source TEXT; created_at TEXT |
| customers | 4 | customer_id INTEGER PK; customer_code TEXT; customer_name TEXT; industry TEXT; country TEXT |
| cutting_tools | 107 | tool_id INTEGER PK; tool_code TEXT; tool_type_id INTEGER; manufacturer TEXT; diameter_mm REAL; max_life_minutes REAL; used_life_minutes REAL; status TEXT; location TEXT |
| data_sources | 1 | id TEXT PK; name TEXT; filename TEXT; sector TEXT; policy_json TEXT; approved INTEGER |
| document_chunks | 0 | id TEXT PK; document_id TEXT; ordinal INTEGER; locator TEXT; content TEXT; sha256 TEXT |
| document_fts | 0 | content ; chunk_id  |
| document_fts_config | 1 | k  PK; v  |
| document_fts_content | 0 | id INTEGER PK; c0 ; c1  |
| document_fts_data | 2 | id INTEGER PK; block BLOB |
| document_fts_docsize | 0 | id INTEGER PK; sz BLOB |
| document_fts_idx | 0 | segid  PK; term  PK; pgno  |
| document_revisions | 0 | document_id TEXT PK; family TEXT; state TEXT; reviewer TEXT; reviewed_at TEXT; review_comment TEXT |
| documents | 0 | id TEXT PK; filename TEXT; sha256 TEXT; revision TEXT; kind TEXT; sector TEXT; stored_name TEXT; created_by TEXT; created_at TEXT |
| downtime_events | 240 | downtime_id INTEGER PK; machine_id INTEGER; run_id INTEGER; reason_code TEXT; start_time TEXT; end_time TEXT; description TEXT |
| downtime_reasons | 10 | reason_code TEXT PK; category TEXT; description TEXT; is_planned INTEGER |
| employees | 13 | employee_id INTEGER PK; employee_code TEXT; full_name TEXT; department TEXT; role TEXT; skill_level TEXT |
| energy_readings | 1368 | energy_reading_id INTEGER PK; machine_id INTEGER; recorded_at TEXT; power_kw REAL; cumulative_kwh REAL |
| evidence_records | 0 | id TEXT PK; conversation_id TEXT; kind TEXT; title TEXT; locator TEXT; captured_at TEXT; sha256 TEXT; content TEXT; metadata_json TEXT |
| factories | 1 | factory_id INTEGER PK; factory_code TEXT; factory_name TEXT; city TEXT; state TEXT; country TEXT |
| historian_observations | 0 | id INTEGER PK; machine_id TEXT; signal TEXT; event_time TEXT; ingestion_time TEXT; value REAL; unit TEXT; quality TEXT; source TEXT; sampling_hz REAL; tool_id TEXT; program_id TEXT; material_lot TEXT; run_id TEXT; sequence TEXT |
| inspection_characteristics | 10 | characteristic_id INTEGER PK; product_id INTEGER; code TEXT; name TEXT; nominal REAL; lower_spec REAL; upper_spec REAL; unit TEXT; critical INTEGER |
| inventory_lots | 12 | lot_id INTEGER PK; warehouse_id INTEGER; material_id INTEGER; lot_no TEXT; on_hand_qty REAL; reserved_qty REAL; bin_location TEXT; received_date TEXT |
| inventory_transactions | 12 | txn_id INTEGER PK; warehouse_id INTEGER; material_id INTEGER; lot_id INTEGER; txn_time TEXT; txn_type TEXT; quantity REAL; reference_type TEXT; reference_id INTEGER |
| lines | 7 | line_id INTEGER PK; area_id INTEGER; line_code TEXT; line_name TEXT; target_oee REAL |
| login_attempts | 0 | identity TEXT PK; failures INTEGER; blocked_until REAL |
| machine_alarms | 100 | alarm_id INTEGER PK; machine_id INTEGER; alarm_code TEXT; alarm_time TEXT; cleared_time TEXT; severity TEXT; description TEXT |
| machine_sensors | 95 | machine_sensor_id INTEGER PK; machine_id INTEGER; sensor_type_id INTEGER; sensor_tag TEXT |
| machine_state_history | 1 | id INTEGER PK; machine_id INTEGER; state TEXT; source_time TEXT; received_at TEXT; quality TEXT; source_sequence TEXT |
| machine_types | 16 | machine_type_id INTEGER PK; type_code TEXT; type_name TEXT; category TEXT |
| machine_write_locks | 0 | machine TEXT PK; execution_id TEXT |
| machines | 26 | machine_id INTEGER PK; line_id INTEGER; machine_type_id INTEGER; machine_code TEXT; machine_name TEXT; manufacturer TEXT; model TEXT; controller TEXT; max_rpm INTEGER; rated_power_kw REAL; status TEXT; criticality TEXT; pos_x REAL; pos_y REAL |
| maintenance_plans | 19 | plan_id INTEGER PK; machine_id INTEGER; plan_name TEXT; maintenance_type TEXT; interval_days INTEGER; next_due_at TEXT |
| maintenance_work_orders | 40 | maintenance_wo_id INTEGER PK; maintenance_no TEXT; machine_id INTEGER; plan_id INTEGER; maintenance_type TEXT; priority TEXT; opened_at TEXT; completed_at TEXT; technician_id INTEGER; issue TEXT; root_cause TEXT; action_taken TEXT; parts_cost REAL; labor_hours REAL; status TEXT |
| material_lots | 7 | lot_id TEXT PK; material_id INTEGER; supplier_lot TEXT; received_at TEXT; certificate_sha256 TEXT; disposition TEXT |
| materials | 13 | material_id INTEGER PK; material_code TEXT; material_name TEXT; material_type TEXT; specification TEXT; unit TEXT; standard_cost REAL |
| model_calls | 0 | id INTEGER PK; at TEXT; role TEXT; service TEXT; replica TEXT; model TEXT; revision TEXT; elapsed_ms REAL; status TEXT; input_tokens INTEGER; output_tokens INTEGER |
| ncrs | 20 | ncr_id INTEGER PK; ncr_no TEXT; work_order_id INTEGER; machine_id INTEGER; opened_at TEXT; defect_type TEXT; description TEXT; quantity_affected INTEGER; disposition TEXT; status TEXT |
| nonconformances | 0 | id TEXT PK; inspection_id INTEGER; run_id INTEGER; category TEXT; description TEXT; disposition TEXT; created_at TEXT |
| oee_snapshots | 171 | oee_id INTEGER PK; machine_id INTEGER; snapshot_date TEXT; shift_id INTEGER; availability REAL; performance REAL; quality REAL; oee REAL; downtime_minutes REAL; total_count INTEGER; good_count INTEGER |
| permissions | 17 | name TEXT PK |
| production_runs | 159 | run_id INTEGER PK; wo_operation_id INTEGER; machine_id INTEGER; operator_id INTEGER; shift_id INTEGER; run_start TEXT; run_end TEXT; good_qty INTEGER; scrap_qty INTEGER; rework_qty INTEGER; avg_cycle_seconds REAL; energy_kwh REAL |
| production_schedule | 30 | schedule_id INTEGER PK; schedule_date TEXT; line_id INTEGER; work_order_id INTEGER; sequence_no INTEGER; scheduled_start TEXT; scheduled_end TEXT |
| production_thread | 7 | run_id INTEGER PK; sales_order_id INTEGER; program_id INTEGER; tool_id INTEGER; lot_id TEXT; recorded_at TEXT; source TEXT |
| products | 8 | product_id INTEGER PK; product_code TEXT; product_name TEXT; product_family TEXT; customer_id INTEGER; revision TEXT; standard_cost REAL; target_scrap_rate REAL |
| program_qualifications | 7 | program_id INTEGER PK; name TEXT; revision TEXT; sha256 TEXT; postprocessor TEXT; approval_state TEXT; envelope_json TEXT |
| purchase_order_items | 30 | po_item_id INTEGER PK; po_id INTEGER; material_id INTEGER; ordered_qty REAL; received_qty REAL; unit_price REAL |
| purchase_orders | 20 | po_id INTEGER PK; po_no TEXT; supplier_id INTEGER; order_date TEXT; expected_date TEXT; received_date TEXT; status TEXT |
| quality_inspections | 155 | inspection_id INTEGER PK; wo_operation_id INTEGER; characteristic_id INTEGER; inspected_at TEXT; inspector_id INTEGER; sample_size INTEGER; measured_value REAL; defects_found INTEGER; result TEXT |
| rca_calculations | 0 | id TEXT PK; investigation_id TEXT; payload_json TEXT |
| rca_events | 0 | sequence INTEGER PK; investigation_id TEXT; step_id TEXT; at TEXT; status TEXT; payload_json TEXT |
| rca_evidence | 0 | id TEXT PK; investigation_id TEXT; step_id TEXT; kind TEXT; title TEXT; source_system TEXT; record_id TEXT; event_time TEXT; retrieved_at TEXT; revision TEXT; quality TEXT; sha256 TEXT; snapshot_json TEXT; locator_json TEXT |
| rca_hypotheses | 0 | id TEXT PK; investigation_id TEXT; payload_json TEXT |
| rca_instance | 1 | id INTEGER PK; database_id TEXT |
| rca_investigations | 0 | id TEXT PK; case_id TEXT; revision INTEGER; parent_id TEXT; reason TEXT; owner TEXT; conversation_id TEXT; source TEXT; factory_id TEXT; database_id TEXT; evidence_source TEXT; question TEXT; language TEXT; status TEXT; created_at TEXT; updated_at TEXT; cutoff TEXT; cancel_requested INTEGER; scope_json TEXT; versions_json TEXT; result_json TEXT |
| rca_links | 0 | id TEXT PK; investigation_id TEXT; payload_json TEXT |
| rca_reviews | 0 | id TEXT PK; investigation_id TEXT; actor TEXT; at TEXT; status TEXT; comment TEXT |
| rca_rule_approvals | 0 | id TEXT PK; rule_id TEXT; rule_hash TEXT; actor TEXT; at TEXT; expires_at TEXT; document_id TEXT; document_hash TEXT; comment TEXT |
| rca_steps | 0 | id TEXT PK; investigation_id TEXT; ordinal INTEGER; title TEXT; purpose TEXT; tool TEXT; arguments_json TEXT; status TEXT; started_at TEXT; finished_at TEXT; result_json TEXT |
| rca_submissions | 0 | id TEXT PK; investigation_id TEXT; actor TEXT; at TEXT; reason TEXT; snapshot_json TEXT; sha256 TEXT |
| reports | 0 | id TEXT PK; document_id TEXT; report_date TEXT; language TEXT; summary TEXT; analysis_json TEXT; status TEXT; updated_at TEXT |
| role_permissions | 41 | role TEXT PK; permission TEXT PK |
| roles | 4 | name TEXT PK |
| routing_operations | 34 | routing_op_id INTEGER PK; product_id INTEGER; operation_seq INTEGER; operation_name TEXT; machine_type_id INTEGER; setup_minutes REAL; cycle_seconds REAL; inspection_required INTEGER |
| sales_order_items | 30 | id INTEGER PK; sales_order_id INTEGER; product_id INTEGER; ordered_qty INTEGER; unit_price REAL |
| sales_orders | 20 | sales_order_id INTEGER PK; sales_order_no TEXT; customer_id INTEGER; order_date TEXT; promised_date TEXT; status TEXT |
| schema_migrations | 4 | version TEXT PK; sha256 TEXT; applied_at TEXT |
| sector_profiles | 8 | id TEXT PK; profile_json TEXT |
| semantic_relations | 0 | id INTEGER PK; subject_type TEXT; subject_key TEXT; predicate TEXT; object_type TEXT; object_key TEXT; source_table TEXT; source_key TEXT; recorded_at TEXT |
| sensor_readings | 27360 | reading_id INTEGER PK; machine_sensor_id INTEGER; recorded_at TEXT; value REAL |
| sensor_types | 5 | sensor_type_id INTEGER PK; sensor_code TEXT; sensor_name TEXT; unit TEXT; warning_high REAL; alarm_high REAL |
| sessions | 0 | token_hash TEXT PK; username TEXT; csrf TEXT; expires REAL |
| shifts | 3 | shift_id INTEGER PK; shift_code TEXT; shift_name TEXT; start_time TEXT; end_time TEXT |
| simulator_state | 1 | machine TEXT PK; values_json TEXT |
| supplier_materials | 9 | id INTEGER PK; supplier_id INTEGER; material_id INTEGER; unit_price REAL; min_order_qty REAL |
| suppliers | 5 | supplier_id INTEGER PK; supplier_code TEXT; supplier_name TEXT; country TEXT; lead_time_days INTEGER; quality_rating REAL; on_time_rating REAL |
| tool_assignments | 80 | id INTEGER PK; machine_id INTEGER; tool_id INTEGER; pocket_no INTEGER; installed_at TEXT |
| tool_limits | 1 | tool_id INTEGER PK; max_rpm REAL; holder_max_rpm REAL; policy_revision TEXT |
| tool_material_compatibility | 1 | tool_id INTEGER PK; material_id INTEGER PK; min_rpm REAL; max_rpm REAL; approved_by TEXT; revision TEXT |
| tool_types | 5 | tool_type_id INTEGER PK; tool_code TEXT; tool_name TEXT; category TEXT |
| tool_usage | 300 | usage_id INTEGER PK; tool_id INTEGER; run_id INTEGER; minutes_used REAL; parts_processed INTEGER; wear_pct REAL; event_time TEXT |
| user_roles | 0 | username TEXT PK; role TEXT PK |
| users | 0 | username TEXT PK; display_name TEXT; password_hash TEXT; enabled INTEGER; created_at TEXT |
| v_daily_oee (view) | 57 | machine_code TEXT; snapshot_date TEXT; availability ; performance ; quality ; oee  |
| v_inventory_available (view) | 13 | material_code TEXT; material_name TEXT; on_hand_qty ; reserved_qty ; available_qty  |
| v_machine_downtime (view) | 26 | machine_code TEXT; downtime_minutes ; unplanned_downtime_minutes ; downtime_events  |
| v_work_order_performance (view) | 100 | work_order_no TEXT; product_code TEXT; product_name TEXT; planned_qty INTEGER; status TEXT; planned_end TEXT; actual_end TEXT; total_good_qty ; total_scrap_qty ; total_rework_qty  |
| warehouses | 2 | warehouse_id INTEGER PK; factory_id INTEGER; warehouse_code TEXT; warehouse_name TEXT |
| work_order_operations | 410 | wo_operation_id INTEGER PK; work_order_id INTEGER; routing_op_id INTEGER; machine_id INTEGER; planned_start TEXT; planned_end TEXT; actual_start TEXT; actual_end TEXT; status TEXT; planned_qty INTEGER; good_qty INTEGER; scrap_qty INTEGER; rework_qty INTEGER; actual_cycle_seconds REAL |
| work_orders | 100 | work_order_id INTEGER PK; work_order_no TEXT; product_id INTEGER; planned_qty INTEGER; priority INTEGER; planned_start TEXT; planned_end TEXT; actual_start TEXT; actual_end TEXT; status TEXT |
| workpieces | 1 | workpiece_code TEXT PK; material_id INTEGER; work_order_id INTEGER; fixture_code TEXT; recipe_revision TEXT |

## Query examples

All supplied questions were executed through QueryService with a viewer account and bound parameters. Sample work-order planning spans August–September 2026.

| Example | Returned rows |
|---|---:|
| Machine inventory | 26 |
| Approved tool assembly records | 1 |
| Work-order final output | 23 |
| Available material stock | 13 |
| Daily machine OEE | 19 |

## Extension rules

Add ordered migration files under src/cnc_ai/resources/migrations; never edit an applied checksum. Review both external configuration and packaged defaults when extending the query allowlist. Preserve authorization, provenance and control-lifecycle contracts. Other sectors can use separately approved analytical schemas. A new controller action requires a strict contract, deterministic policy, typed adapter and tests. Generated SQL remains read-only for every role.

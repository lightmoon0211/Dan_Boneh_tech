# Model serving and hardware

## Chosen roles

The default core set uses Qwen3.8, Qwen3-Coder-30B-A3B-Instruct, Granite Guardian, Qwen embeddings and reranking. Report shares conversation; planning and control proposals share coding. SQLCoder and Whisper are optional integrated services. MODEL_SELECTION.md records the decision for all 15 candidates, including deferred and unverified entries. OPTIONAL_SPECIALISTS.md explains their deployment and the preserved Coder-Next profile.

The conversation card describes a 27B model with controllable thinking; this implementation disables thinking and retained thinking for predictable structured answers. Text RAG is default; the optional bounded image evidence feature reuses its vision capability. [Qwen3.8 model card](https://huggingface.co/Qwen/Qwen3.8-27B).

The default coding model has 30.5B total and 3.3B active parameters. All weights still need storage; the included TP1/32K profile is a conservative starting allocation for H200 staging. No generated NC/robot program is certified or executed. [Qwen3-Coder-30B-A3B-Instruct model card](https://huggingface.co/Qwen/Qwen3-Coder-30B-A3B-Instruct).

Embedding requests use an instruction for queries and 1024-dimensional vectors with validated lengths, indices and finite values. The embedding service runs vLLM's pooling runner, not a chat endpoint. [Embedding model card](https://huggingface.co/Qwen/Qwen3-Embedding-4B), [vLLM pooling documentation](https://docs.vllm.ai/en/stable/models/pooling_models/).

Guardian 4.1 receives a final user judge-instruction block containing criteria and a scoring schema. The parser accepts only a well-formed yes/no score after optional thinking tags. Here **yes means the configured risk criterion matched** and blocks the draft. This differs from old Guardian 3.3 examples using `guardian_config`; those are not used. Documents may be supplied through the 4.1 chat template's document context. [Guardian 4.1 model card](https://huggingface.co/ibm-granite/granite-guardian-4.1-8b).

## Inference environment

`requirements/h200.txt` pins vLLM 0.28.0 as the staging candidate and requires Transformers 5.8 or later. This avoids treating the coding model's older minimum vLLM version as sufficient for every newer model. The official Qwen3.8 recipe calls out the newer processor dependency. The full CUDA/PyTorch/vLLM combination must be validated on the actual H200 servers, then frozen and transferred as a tested environment. [Qwen3.8 serving recipe](https://recipes.vllm.ai/Qwen/Qwen3.8-27B), [vLLM releases](https://pypi.org/project/vllm/).

The core schema-constrained chat calls use `response_format` with a JSON schema. Validate that your chosen inference build accepts the exact schema contracts with the installation smoke test and factory acceptance prompts. A server merely advertising a model is not sufficient. [vLLM structured outputs](https://docs.vllm.ai/en/stable/features/structured_outputs/).

The launcher sets offline model resolution, disables usage telemetry, assigns host-local CUDA devices, captures each service's logs and reads API keys through the environment. API keys do not appear in the launch command. [vLLM environment configuration](https://docs.vllm.ai/en/stable/configuration/env_vars/).

## Sizing guidance

These are planning estimates; no GPU memory or throughput benchmark was performed in the build environment.

- Windows development: 4 or more CPU cores, 16 GB RAM minimum, 32 GB preferred; several GB free for application dependencies and training data. Use demo mode or remote private inference endpoints. No CUDA dependency is installed into the CPU application environment.
- H200 servers: the initial profile assumes 8 H200s per host with a compatible NVIDIA driver and Linux x86-64. Reserve RAM and local NVMe for model loading and caches. A practical starting allocation is at least 256 GB system RAM per model host, with more for concurrent replicas and staging.
- Original BF16 weights require roughly two bytes per parameter, before tokenizer, buffers, KV caches, activations and runtime overhead. The default 30.5B coding model implies roughly 61 GB of raw parameter storage; the alternate 80B Coder-Next profile is substantially larger. Actual snapshots and memory footprints must be measured.
- Reserve at least 1 TB external model storage for the core snapshots, download metadata, an upgrade generation and transfer room; plan additional disk for factory documents, telemetry and backups. Keep weights on local fast storage rather than relying on an untested shared filesystem.
- Start with the conservative context limits in the table. Measure p50/p95 response latency, queue depth, token rates, GPU utilization and peak memory under simultaneous conversation, safety, embedding and report workloads before enabling the two optional specialists.

The launcher supports five physical services on both hosts; ModelRouter provides bounded primary/fallback routing. Tensor parallelism stays within each host. GPU indices are host-local. See H200_DEPLOYMENT.md.

## Existing models and updates

Local paths may differ from canonical directory names through each `*_MODEL_PATH` environment variable. Keep `--served-model-name` equal to the model registry ID so routing and health checks agree. No download or serving code silently substitutes another model if a repository is unavailable.

A downloader root records commit pins before large files start. To test a new model revision, use a separate root and an explicit `--revision` for that one service. Complete checksum verification, stage inference, change the local path, set the embedding revision if applicable, rebuild vectors, and run acceptance tests before promotion. Preserve the previous root for rollback.

The app's `EMBEDDING_MODEL_REVISION` must match the deployed snapshot commit on the application host. It is not inferred from a remote server's filesystem. Leaving `site-default` is acceptable for a training smoke test only; commission an exact commit for persistent factory indexing.

## Acceptance prompts

Use trusted expected answers and source documents for at least these cases: machine inventory; historical versus current CNC state; exact tool-rating evidence; mixed Chinese/English manual lookup; parameterized work-order query; an invented table; an injected SQL second statement; a request to bypass an interlock; a missing material; a 7000-RPM proposal; refusal at an excessive step; report citations; and unverified NC-code drafts. Record outcomes with model commits, runtime lock, policy revision and corpus hashes.

Qwen reranking uses the pooling /score endpoint with an explicit query/document prompt and classification overrides; see config/qwen3_reranker.jinja. Numerical service 8100 is separate from chat inference. STATE_OF_THE_ART_2026.md explains optional Chronos-2 and research candidates.

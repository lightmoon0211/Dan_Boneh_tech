# Version 11.1.0

Adds a dedicated read-only RCA executor, strict source contracts, factory-local calendar, baseline normalization, interval union and loss reconciliation; persistent evidence, causal criteria, independent reviews and immutable reassessment; chat routing and inspectable timeline/map; ten isolated synthetic cases, tests and deployment documentation. Reuses v11 framework, model services, environment and control architecture. Additive migration 004 and direct pytz dependency. See rca/INSPECTION.md and VALIDATION.md.

# Version 11.0.0

- Reviewed all 15 model candidates with primary-source links and clear selected/deferred decisions.
- Default coder is Qwen3-Coder-30B-A3B-Instruct; Coder-Next is preserved as an explicit profile.
- Optional SQLCoder completion adapter preserves query authorization/evidence.
- Optional Whisper WAV transcription requires review before Send; no implicit machine actions.
- Added twelve-gate site-evidence checker and traceability to all 20 preparation-guide topics.
- Updated model downloads, serving, H200 placement, manuals and migration instructions.

# v10.0.0

Retains the v9 CNC platform and adds numerical telemetry intelligence, read-only historians, digital thread, approved-revision RAG, local reranking, explicit agent state, optional vision, deterministic planning/cutting/OEE, machine/program-bound control, NC artifact review/export gates, replica failover, CNCBench, synthetic telemetry and updated Windows/H200/air-gap operations. Includes source tests, a rebuilt manual and a clean installable wheel. No model weights or site credentials are included.

# Model and architecture decisions · 8 September 2026

These are evidence-informed deployment choices, not measured claims that one model is universally best for CNC. The v11 review selects Qwen3-Coder-30B-A3B-Instruct for the default coding service and preserves Coder-Next as an explicit alternative. MODEL_SELECTION.md records all fifteen candidate decisions and the optional SQLCoder and Whisper integrations. The delivered tests establish implementation behavior; CNC knowledge quality, safety-judge recall, multilingual retrieval and H200 throughput must be measured with the site's corpus and accepted prompts.

| Role | Selection and rationale |
|---|---|
| Conversation/report | Qwen/Qwen3.8-27B; one shared local service, optional bounded image evidence |
| Code/planner/control proposals | Qwen/Qwen3-Coder-30B-A3B-Instruct; strict structured outputs, no direct execution |
| Embedding | Qwen/Qwen3-Embedding-4B; instruction-form query embeddings, fixed fingerprint/dimensions |
| Secondary policy judge | Granite Guardian 4.1 8B; input/output risk checks, no CNC authority |
| Reranking | Qwen3-Reranker-0.6B; small separate relevance stage after hybrid candidate retrieval |
| Numerical intelligence | Auditable statistical methods by default; optional local Chronos-2 adapter |

The selected model interfaces are grounded in their official cards: [Qwen3.8](https://huggingface.co/Qwen/Qwen3.8-27B), [Qwen3 Coder 30B](https://huggingface.co/Qwen/Qwen3-Coder-30B-A3B-Instruct), [embedding](https://huggingface.co/Qwen/Qwen3-Embedding-4B), [Guardian 4.1](https://huggingface.co/ibm-granite/granite-guardian-4.1-8b) and [reranker](https://huggingface.co/Qwen/Qwen3-Reranker-0.6B). Repository/license/runtime revisions must be pinned during staging. None is a safety-rated CNC controller.

Chronos-2 provides a practical optional local probabilistic forecasting interface; the implemented adapter loads an external snapshot without downloads and compares the same rolling horizons as statistical baselines. It is not a pretrained CNC RUL model. See [official repository](https://github.com/amazon-science/chronos-forecasting), [model card](https://huggingface.co/amazon/chronos-2) and [paper](https://arxiv.org/abs/2510.15821).

TimesFM 2.5 and Moirai 2 are explicit research download candidates. Their prediction interfaces are not silently treated as interchangeable with Chronos. TimesFM 3, announced on 31 August 2026, is excluded from factory defaults because its current model card specifies a non-commercial license. This is why merely choosing the newest model is inappropriate for a commercial factory. See [TimesFM 2.5](https://huggingface.co/google/timesfm-2.5-200m-pytorch), [TimesFM 3](https://huggingface.co/google/timesfm-3.0-pytorch), [Google announcement](https://research.google/blog/timesfm-3-a-zero-shot-foundation-model-for-multivariate-forecasting/) and [Moirai 2](https://huggingface.co/Salesforce/moirai-2.0-R-small).

PatchTST and TimesNet are useful domain-training candidates, not validated drop-in factory fault predictors. Site-specific tool wear, quality and RUL require representative labels, operating-regime coverage and component-group holdouts. The delivered portable regression is an explicit starting interface; it does not handle censoring as a full survival model. [PatchTST](https://arxiv.org/abs/2211.14730), [TimesNet](https://arxiv.org/abs/2210.02186).

A typed digital thread is selected over automatic LLM-generated causal graphs: business foreign keys already provide reliable entity relationships, while temporal correlation is not a root cause. Graph-assisted retrieval can help cross-document questions, but all evidence must retain source lineage. [GraphRAG research](https://arxiv.org/abs/2404.16130).

The architecture uses short, persisted agent workflows with deterministic authorization and explicit approvals. Agent benchmarks motivate evaluating tool selection, environment behavior and prompt injection separately from answer fluency; they do not certify this factory implementation. [AgentDojo](https://arxiv.org/abs/2406.13352), [tau2-bench](https://arxiv.org/abs/2506.07982).

OT segmentation, least privilege, monitored remote access and native safety mechanisms inform deployment boundaries. This repository does not claim standards certification. Follow the site's assessed controls using [NIST SP 800-82 Rev.3](https://csrc.nist.gov/pubs/sp/800/82/r3/final) and the [OPC UA security model](https://reference.opcfoundation.org/specs/OPC-10000-2/4).

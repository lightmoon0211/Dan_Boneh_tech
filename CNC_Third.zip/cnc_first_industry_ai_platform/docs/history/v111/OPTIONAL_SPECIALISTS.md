# SQL and speech: optional local specialists

The default installation needs neither specialist. Core coding already produces structured SQL plans; the application remains usable with typed messages. Keep both disabled until site evaluation shows a benefit.

## Download and resume

Run from the project root in smartfactoryllm on a connected preparation machine. Use the same command after Ctrl+C, reboot or lost internet; completed and partial files and commit pins remain on the external drive.

```powershell
python scripts/models/download_factory_models.py all --model-root F:/AI/models --checksums
python scripts/models/download_factory_models.py sqlcoder --model-root F:/AI/models --checksums
python scripts/models/download_factory_models.py speech --model-root F:/AI/models --checksums
```

To acquire the five core models plus both integrated specialists in one run:

```powershell
python scripts/models/download_factory_models.py all --with-optional sqlcoder --with-optional speech --model-root F:/AI/models --checksums
```

`all` alone downloads five core services, not all 15 proposed candidates. Optional numerical-model downloads from v10 remain individually available. The speech download selects safetensors/config/tokenizer files and omits duplicate legacy weight formats. Preserve the resulting download manifests and license files. Network authorization/gated-repository errors stop with a message; the script does not bypass them. Verify offline by repeating the selected command with `--verify --checksums`.

## Start local services

Use Linux/WSL2 and the separate smartfactorymodels environment with requirements/h200.txt, including vLLM's audio dependencies. Model paths stay outside this checkout. On each H200 host, core code uses GPU 0, optional SQLCoder GPU 1, conversation GPUs 2–3, Guardian 4, embedding 5, reranker 6, optional Whisper 7.

```bash
python scripts/models/serve_models.py server-a --with-optional sqlcoder --with-optional speech --env-file /etc/cnc-ai/models.env --dry-run
python scripts/models/serve_models.py server-a --with-optional sqlcoder --with-optional speech --env-file /etc/cnc-ai/models.env
```

Use server-b on the other physical host. For individual terminals use targets `sqlcoder` and `speech`. Do not run a host group and one of its child services twice. The launcher checks GPU overlap inside each launch group; it cannot coordinate separately started OS processes. Keep all groups under one reviewed service manager. For systemd, use the supplied specialist override example. A smaller Windows workstation runs the CPU application or connects to these private inference endpoints; no claim is made that all BF16 models fit a workstation GPU.

Add model-only paths, bind address and distinct API keys to the inference host's models.env. Set application options/URLs/keys in the application .env:

```dotenv
CNC_SQL_SPECIALIST=true
CNC_SPEECH=true
SQLCODER_BASE_URL=http://10.20.0.11:8006/v1
SQLCODER_API_KEY=replace-with-site-secret
SPEECH_BASE_URL=http://10.20.0.11:8007/v1
SPEECH_API_KEY=replace-with-different-site-secret
```

Optional `SQLCODER_FALLBACK_URLS` and `SPEECH_FALLBACK_URLS` select same-model replicas on host B. The keys for a given primary/replica pair must match. Allowlist these addresses on the private inference network. Do not grant inference hosts a controller write route or CNC credentials.

## SQL behavior

When enabled, a data-mode plan delegates one query for the current question to SQLCoder. The planner's preliminary SQL is replaced with this specialist draft before the plan is recorded. SQLCoder uses `/v1/completions` with a Llama 3 completion prompt, not the generic Plan JSON chat contract. The current application database dialect remains **SQLite**, even when an external PostgreSQL historian is configured. Large schemas stop at a bounded prompt budget; use a smaller approved view or the core coder.

The application checks one SELECT, rejects incomplete/multiple/writing statements and unresolved parameters, binds generated string literals, and runs the existing SQLite authorizer with table/column/function allowlists, read-only credentials, time and row limits. Query results retain SQL, bound parameters, capture time and evidence hash. Every attempted execution is audited. There is no fallback that silently executes a rejected SQL draft through a different path. Numeric expressions and limits remain syntax; no user input is concatenated into an executed SQL string outside the validated AST.

A model card's SQL benchmark does not validate the factory's schema or dialect. Turn the specialist off if its approved result accuracy or latency is worse than core coding.

## Speech behavior

In Chat, open **Dictate from a recording**. Upload mono 16 kHz PCM 16-bit WAV, at most 30 seconds / 1 MiB. Choose the correct conversation language. The application validates format, duration, truncation and very quiet input before forwarding the recording to the private transcription endpoint. Blank/malformed responses stop. It retains an audio hash and transcript hash in audit, not the audio file. The inference server's own logging/retention must be configured separately.

Review and edit the returned text, especially CNC-01, tool numbers, decimal separators and RPM. Click **Put reviewed text in message**, then **Send**. Existing message drafts are not overwritten. A transcript alone creates no conversation, SQL query, proposal or control execution. The normal session permissions, Guardian review and deterministic machine workflow apply after Send. Browser microphone recording and arbitrary MP3/video uploads are not implemented; the bounded WAV input is deliberate.

The health card distinguishes disabled, model advertised and successful inference. Model verification checks SQL completion shape without executing it. Speech readiness requires a representative spoken WAV; a `/models` response or a silent audio fixture is not a transcription accuracy test. vLLM supports the local transcription API and needs audio dependencies; turbo is not selected for translation. [vLLM speech API documentation](https://docs.vllm.ai/en/latest/serving/openai_compatible_server/#transcriptions-api).

## Restore the previous larger coder

To keep existing Coder-Next weights, set both the registry and the model path consistently on application and inference hosts:

```dotenv
CNC_MODEL_CONFIG=config/models.coder-next.json
CODE_MODEL_PATH=F:/AI/models/Qwen3-Coder-Next
```

On Linux use `/srv/ai/models/Qwen3-Coder-Next`. The alternate profile uses GPUs 0–1 for code. Optional SQLCoder and speech then both default to GPU 7 as alternatives; the combined launch refuses this overlap. Choose one, or make a reviewed custom allocation. Existing Coder-Next downloads are never deleted; the downloader uses a separate state file when the `code` role changes repositories. To obtain this model explicitly, download `code-next`, or `code` with `--config config/models.coder-next.json`. An existing model path is sufficient when files already exist.

# Release validation for version 11.1.0

Validated on 9 September 2026 on Linux x86-64 with Python 3.12.14. The **final installed application wheel passed 159 tests, with zero failures, errors or skips**, from outside the source checkout. This includes the 118 existing v11 tests and 41 RCA tests. Fictional records, test doubles and local loopback services were used; no physical factory equipment was contacted.

## Executed checks

| Check | Actual result |
|---|---|
| Recoverable baseline | Verified all 265 content-manifest files from the actual v11 ZIP. Ran its 118 tests before changes. |
| Final wheel tests | 159 passed in 77.42 seconds in a fresh, offline-installed environment. Imports resolved to site-packages outside the repository. Full JUnit/log files are in `rca/final_junit.xml` and `rca/final_pytest.log`. |
| RCA workflow | Ten cases cover equipment fault, material shortage, program revision, complete-machine assembly, acceptance, multiple causes, correlation, contradictory/missing evidence, normalized comparison and due-date capacity risk. Tests inspect scope, source records, calculations, hypotheses, actual event transitions, revision history and authority boundaries. |
| Loss arithmetic | Overlapping 90- and 75-minute stops merge to 120 minutes. The 70-piece shortfall reconciles as 60 estimated downtime pieces plus 10 additional scrap with zero residual. Other cases with incomplete/incomparable evidence withhold confirmation or attribution. |
| Access and resilience | Current permissions/ownership protect saved results, timeline, evidence and export. Tested CSRF, record scope/cutoff mismatches, invalid extra fields, prompt injection as data, source change flags, demo isolation, cancellation, query failures, time budgets, retries, recovery and retained calculations. |
| Model boundary | Bounded local planner transport exercised using explicit test doubles. Invalid or unpermitted selections cannot attest tool success, create evidence, remove required alternatives or authorize operational writes. A separate actual-model validation script is provided. |
| v11 migration | A separately installed original v11 wheel created a synthetic database with two named accounts, one document/revision and one pending control proposal. Migration 004 retained byte-equivalent contents of eight checked business/authority/evidence tables, all original migration rows and the valid audit chain. No RCA case was seeded. |
| Existing CLI lifecycle | Actual installed-package script initialized sample data/accounts, ingested and approved a document, exercised existing numerical/history/simulator workflows, backed up and verified integrity/audit. The RCA CLI also created separate demo history, ran the example, exported evidence and passed offline validation. |
| Browser regression | Real Waitress and Chromium exercised the existing sign-in, conversation, citations, proposal/approval/execution simulator flow, numerical charts, speech review fixture and mobile UI with no page errors. |
| RCA browser | Real chat routing, summary, calculations, visible checks matching persisted events, inspectable SVG relationships, source snapshot, follow-up context, saved cases, independent review, new revision and mobile-width checks passed. The in-flight cancellation state is exercised with actual executor barriers in backend tests. |
| Offline application installation | Ran the transfer builder on connected staging, then installed application/test/downloader dependencies in a new environment using only local wheels and `--no-index`. All 56 packages passed dependency checks. All 60 staged transfer files verified after refreshing the final application wheel. GPU/OS/browser provisioning remains separate. |
| Wheel/source parity | All 89 packaged Python/resource/UI assets exactly match the final source; current wheel SHA256 is in `rca/wheel_validation.json`. No stale v11 wheel remains in the new project's packages folder. |
| Static checks | Python parsing and focused import/undefined-name lint, JavaScript and Bash syntax, JSON/YAML/TOML parsing, configured/package-default parity, Markdown targets and regenerated public schemas passed. |
| Documentation | The new six-page RCA Word guide and matching PDF were rendered and every page visually reviewed. The existing 24-page v11 base manual is retained unchanged and explicitly supplemented. |

The original model registry, control modules, applied migrations 001–003 and Windows/Linux startup scripts remain byte-identical to the inspected baseline. The new application adds a direct `pytz` dependency and eleven RCA tables. All five core local model roles and optional specialists retain their v11 configuration.

## Unexecuted target checks

Actual local neural RCA inference was **not run** because the configured weights/services were not available in this execution environment. Model-selection test doubles are not evidence of real inference accuracy. H200 throughput, multi-host deployment/failover, Windows/PowerShell runtime execution, Docker deployment, live MES/ERP/NX/APS mapping, physical CNC operation and factory-labeled diagnosis accuracy were also **not run**. Their reasons are missing target hardware, operating systems, source mappings or commissioned equipment. They are not counted as passed or as pytest skips.

The new canonical SQLite history adapter is implemented and tested on synthetic historical exports. A site-qualified live exporter/connector is still required. The default native v11 adapter explicitly reports insufficient historical normalization semantics. Training criteria cannot approve a factory diagnosis. Site engineering must qualify each causal rule, data mapping and verification procedure before production use.

## Repeat the checks

In the extracted project with the intended smartfactoryllm environment:

```powershell
python -m pip install -c requirements/validated-linux-py312.txt '.[test,download]'
python -m pip check
python -m pytest
python scripts/validate_installation.py
python scripts/rca/validate_browser.py
```

The constraint file records this Linux CPU run. Prepare matching Windows dependency wheels/constraints on a Windows staging machine. Browser validation requires an already provisioned Chromium and Playwright package; use `--browser-executable` if needed. Do not attempt a browser download inside the disconnected factory.

After migrating your intended runtime, run `python -m cnc_ai validate --offline` and `python -m cnc_ai audit-verify`. To repeat migration verification against the actual old package, supply the wheel extracted from the retained original ZIP:

```powershell
python scripts/rca/validate_migration.py --baseline-wheel 'F:/CNCBackups/cnc_first_ai-11.0.0-py3-none-any.whl'
```

For actual-model RCA, configure local inference and qualified historical data, then use `scripts/rca/validate_local_model.py`. See `rca/DEVELOPER_GUIDE.md` for its arguments and acceptance limits. Software checks do not establish production diagnosis accuracy or replace commissioning.

Current machine-readable evidence is indexed by `release_validation.json` and stored under `rca/`. Files under `validation/` and the explicitly named v11 baseline records document earlier releases; they must not be described as newly rerun v11.1 results unless listed above. The earlier 158-test source run preceded the additional retained-recovery test; the final wheel run contains all 159 tests.

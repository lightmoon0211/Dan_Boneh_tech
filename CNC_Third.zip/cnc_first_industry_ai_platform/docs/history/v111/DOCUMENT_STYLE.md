# Manual source and layout

`USER_MANUAL.md` is the editable content source. `USER_MANUAL.docx` and the matching PDF are release exports. The supplied Word document uses native heading numbering and a clickable chapter list. The PDF is the fixed-layout reference.

To regenerate Word after editing Markdown, install the application dependencies and run:

```bash
python scripts/docs/build_manual.py
```

Open the resulting Word document in Word or LibreOffice, update fields, and export PDF. Review every page after changes. The v11 release was rendered with LibreOffice and all 24 pages were visually checked. Fonts installed on another workstation can change pagination; the included PDF retains the reviewed result.

The layout follows a compact reference guide: US Letter; 1-inch margins; Calibri 11-point body text with 1.25 line spacing and 6-point paragraph spacing. Heading levels use 16/13/12-point blue text, native multilevel numbering, and keep-with-next. Named editorial overrides are a 32-point navy cover title, a 15-point subtitle, 9-point DejaVu Sans Mono code, and 10-point table text. Tables use a fixed 9360-twip grid, repeated header rows and unsplit rows. The builder asserts matching grid/cell widths. Commands remain executable single lines in the Markdown source even when they wrap visually in Word/PDF.

## RCA supplement

`rca/USER_GUIDE.md` is the source for `rca/RCA_USER_GUIDE.docx` and its matching PDF. Run `python scripts/docs/build_rca_guide.py` to regenerate the Word file, then render and review every page before release. The six-page 11.1 supplement uses black headings, editable tables, Letter pages, readable body text and a separate final deployment section. The original 24-page v11 base manual is retained unchanged; use the supplement for RCA-specific behavior and migration.

# CNC Factory Assistant

User and deployment manual · Version 11.0.0

For CNC operators, supervisors, factory administrators and controls engineers. The source Markdown, formatted Word manual and PDF describe the same release. Exact engineering configuration and acceptance records remain site controlled.

## 1. Purpose and working model

This platform combines factory conversation, code drafting, cited database analysis, document retrieval, source-linked reports and supervised machine proposals. It runs through local inference endpoints and can be deployed without external internet. CNC is the deepest built-in domain; separate analytics schemas and sector profiles support other manufacturing processes.

The assistant helps people interpret evidence and prepare work. A machine action is always a structured proposal, followed by deterministic checks and an authenticated review. No model can write arbitrary OPC UA values, run generated programs, or grant a user permission.

### 1.1. Local services and shared roles

| Service | Model | Roles | Port |
|---|---|---|---:|
| Conversation | Qwen/Qwen3.8-27B | Conversation and reports | 8001 |
| Code | Qwen/Qwen3-Coder-30B-A3B-Instruct | Code, planning and control proposals | 8002 |
| Risk judge | ibm-granite/granite-guardian-4.1-8b | Secondary input/output policy assessment | 8003 |
| Embeddings | Qwen/Qwen3-Embedding-4B | Semantic retrieval | 8004 |
| Reranker | Qwen/Qwen3-Reranker-0.6B | Relevance scoring | 8005 |
| Optional SQL | defog/llama-3-sqlcoder-8b | Guarded SQL drafts | 8006 |
| Optional speech | openai/whisper-large-v3-turbo | Reviewed transcription | 8007 |
| Numerical service | Statistical engine; optional Chronos-2 | Signal analysis and forecasting | 8100 |

Granite Guardian does not establish tool ratings or machine permission. Reviewed policy files, current controller context, authenticated roles, recorded supervisor approval and the native CNC/PLC determine whether an action may occur. MODEL_SELECTION.md explains the review of all 15 suggested candidates. Five services are core; SQLCoder and Whisper are optional and disabled by default. Coder-Next remains available through the alternate registry. See OPTIONAL_SPECIALISTS.md for exact commands.

### 1.2. Modes you will see

| Label | What it actually means |
|---|---|
| Training mode | Sample responses; no language model or Guardian evaluation. |
| Local inference | Configured private model endpoints; inspect each service. |
| Internal simulator | Software state in the app database; no external controller. |
| Local OPC UA test server | Loopback OPC UA training server; no physical CNC. |
| Real controller | Commissioned authenticated/encrypted endpoint; writes require all gates. |
| Reachable/model advertised | Model-list response advertises the model; generation is not yet verified. |
| Last successful inference | Most recent successful inference in this app process; not a readiness guarantee. |

The application does not label a listening TCP port as a loaded, ready model. If inference is unavailable, it reports the affected service. Embedding failure may leave lexical document retrieval usable; a safety service failure stops local-model orchestration.

### 1.3. Roles and responsibility

| Role | Main permitted work |
|---|---|
| Viewer | Conversations, approved read-only data, documents and machine observations |
| Operator | Viewer functions plus preparing and executing their own eligible machine proposals |
| Supervisor | Operator functions plus separate approval/rejection, document ingestion and report management |
| Administrator | Data/schema/sector and interface management, documents/reports and audit review; no inherited machine control/approval |

Use named accounts and a separate supervisor. The account display name is for readability; privileges are derived from server-side roles. Passwords are not displayed or stored in plaintext. The browser session expires after eight hours. Disabling an account or resetting its password invalidates its sessions.

## 2. Installation and deployment


Run commands from the extracted project directory. Quote paths containing spaces. Use Python 3.12 for the supplied environment definitions; Python 3.11–3.13 is supported by the application package.

### 2.1. Create or recreate `smartfactoryllm`

For a new installation, in Anaconda PowerShell Prompt:

```powershell
conda env create -f environments/smartfactoryllm.yml
conda activate smartfactoryllm
python -m pip install -e '.[test,download]'
Copy-Item .env.example .env
```

For an existing old environment, first export it and create a clean replacement while retaining the old one:

```powershell
conda env export -n smartfactoryllm --no-builds > smartfactoryllm-old.yml
conda list -n smartfactoryllm --explicit > smartfactoryllm-old-explicit.txt
conda create -n smartfactoryllm_v11 python=3.12 pip -y
conda activate smartfactoryllm_v11
python -m pip install -e '.[test,download]'
python -m pytest
```

After backing up the old project's data and validating the replacement, recreate the requested environment name:

```powershell
conda deactivate
conda env remove -n smartfactoryllm
conda create -n smartfactoryllm --clone smartfactoryllm_v11 -y
conda activate smartfactoryllm
python -m pip check
```

The removal command deletes only that Conda environment. Do not run it before exporting and validating the replacement. Reinstall the editable package if you move the extracted project. [MIGRATION.md](MIGRATION.md) covers old databases and documents. Existing compatible environments can use `scripts/windows/setup.ps1`; it does not delete environments or overwrite an existing database.

Without Conda, `python -m venv .venv` followed by environment activation and the same pip command works. GPU libraries belong in the separate `smartfactorymodels` Linux environment.

### 2.2. Download or resume the factory models

Keep model storage outside the project, for example `F:/AI/models/`. In the application environment:

```powershell
python scripts/models/download_factory_models.py all --model-root 'F:/AI/models' --workers 2 --checksums
```

The four core role ports remain stable; v11 selects a different default coder and retains the reranker. The all command downloads five core snapshots. Statistical numerical analysis needs no weights. Chronos-2 is a separate optional download.

Download one model:

```powershell
python scripts/models/download_factory_models.py code --model-root 'F:/AI/models' --workers 1 --checksums
```

After Ctrl+C, reboot or lost internet, run the **same command** again. Partial files, Hugging Face metadata and the pinned commit are retained. Each operation retries 20 times by default; `--retries 0` retries indefinitely. Permanent authorization/not-found/disk errors stop with a clear message. Keep the model root's `.factory-downloads` manifests and each model's `.cache/huggingface` metadata.

```powershell
python scripts/models/download_factory_models.py all --model-root 'F:/AI/models' --verify --checksums
```

Verification is offline. SHA256 verification requires a download completed with `--checksums`; otherwise repeat the download command with that option first. Linux uses paths such as `/srv/ai/models`; WSL uses `/mnt/f/AI/models`.

### 2.3. Point to existing local models

Edit `.env`; no application source changes are required:

```dotenv
MODEL_ROOT=F:/AI/models
CONVERSATION_MODEL_PATH=${MODEL_ROOT}/Qwen3.8-27B
CODE_MODEL_PATH=${MODEL_ROOT}/Qwen3-Coder-30B-A3B-Instruct
SAFETY_MODEL_PATH=${MODEL_ROOT}/granite-guardian-4.1-8b
EMBEDDING_MODEL_PATH=${MODEL_ROOT}/Qwen3-Embedding-4B
RERANKER_MODEL_PATH=${MODEL_ROOT}/Qwen3-Reranker-0.6B
```

Each path must be a complete Hugging Face Transformers snapshot containing its configuration, tokenizer and weight shards. An existing Hub cache can use its concrete `snapshots/<commit>` directory. GGUF files are not interchangeable with the included vLLM serving path. Set `EMBEDDING_MODEL_REVISION` to the exact snapshot commit and rebuild embeddings whenever it changes. Existing local models without downloader manifests may be served, but cannot pass manifest verification until acquired/registered through a verified download root.

### 2.4. Start the inference and numerical services

Use Linux on the H200 servers, or WSL2 for suitable workstation hardware. A smaller Windows PC can run the UI, database, RAG lexical search and simulator in `CNC_MODEL_MODE=demo`, or point to the factory servers. It is not expected to load all original models locally.

On **each Linux inference host**, with the project installed at `/opt/cnc-ai`:

```bash
conda env create -f environments/smartfactorymodels.yml
conda activate smartfactorymodels
python -m pip install -r requirements/h200.txt
```

The H200 requirements specify a staging candidate, not a hardware certification. Run the model tests on the actual GPUs, then freeze the entire working environment before transfer.

Edit `.env` on each host to use Linux model paths. Set `MODEL_SERVER_BIND` to its private inference-interface address and set distinct long API keys for services hosted there. On server A:

```bash
python scripts/models/serve_models.py server-a --dry-run
python scripts/models/serve_models.py server-a
```

On server B:

```bash
python scripts/models/serve_models.py server-b --dry-run
python scripts/models/serve_models.py server-b
```

Each host runs the same five core services as replicas: code on host-local GPU 0 (TP1), conversation on 2–3 (TP2), safety on 4, embedding on 5 and reranker on 6. Optional SQLCoder uses GPU 1 and Whisper uses GPU 7. The core allocation uses twelve GPUs across two hosts; enabling both specialists uses all sixteen. Run server-a on A and server-b on B; never both host targets on one host. These are staging allocations, not measured throughput guarantees. See H200_DEPLOYMENT.md for capacity and failover tests.

On the application host, configure the corresponding URLs and the same keys, for example:

```dotenv
CONVERSATION_BASE_URL=http://10.20.0.11:8001/v1
CODE_BASE_URL=http://10.20.0.12:8002/v1
SAFETY_BASE_URL=http://10.20.0.11:8003/v1
EMBEDDING_BASE_URL=http://10.20.0.11:8004/v1
RERANKER_BASE_URL=http://10.20.0.11:8005
CONVERSATION_FALLBACK_URLS=http://10.20.0.12:8001/v1
CODE_FALLBACK_URLS=http://10.20.0.11:8002/v1
SAFETY_FALLBACK_URLS=http://10.20.0.12:8003/v1
EMBEDDING_FALLBACK_URLS=http://10.20.0.12:8004/v1
RERANKER_FALLBACK_URLS=http://10.20.0.12:8005
CNC_MODEL_MODE=local
```

These addresses are examples; substitute your private addresses. Restrict inference ports to the application host. Use site TLS termination for inference if traffic crosses a shared network. `/v1/models` means reachable and advertised; **Verify model inference** performs actual test requests.

Development runs statistical analysis inside the app. For the factory, set CNC_PROFILE=factory, configure the historian reader and numerical service key, then start:

```bash
python -m cnc_ai timeseries serve --host 127.0.0.1 --port 8100
```

Set a random CNC_TIMESERIES_API_KEY of at least 24 characters for both clients and service. The factory profile selects PostgreSQL historian, HTTP numerical transport and approved-only documents. Install the historian extra and set CNC_HISTORIAN_DSN, or explicitly select a reviewed alternative backend. The numerical service needs no controller credentials. See TIME_SERIES_INTELLIGENCE.md.

### 2.5. Initialize the CNC database and accounts

```powershell
python -m cnc_ai db init --sample
python -m cnc_ai user add factory_admin --role admin --display-name 'Factory administrator'
python -m cnc_ai user add operator01 --role operator --display-name 'Operator 01'
python -m cnc_ai user add supervisor01 --role supervisor --display-name 'Shift supervisor'
```

Passwords are securely prompted twice, with a 12-character minimum. No default login credentials are shipped. Administrator privileges do not grant machine control or supervisor approval. Use separate named accounts. `db init` without `--sample` creates the complete empty business schema for a new factory database; it still includes simulator state for training. Initialization preserves existing data and applies checksummed migrations.

### 2.6. Ingest RAG documents

```powershell
python -m cnc_ai ingest samples/documents/spindle_change_sop.md --user factory_admin --kind sop --revision training-v10
python -m cnc_ai ingest samples/documents/tool_material_specifications.csv --user factory_admin --kind tool --revision training-v10
python -m cnc_ai ingest samples/documents/shift_report.txt --user factory_admin --kind report
python -m cnc_ai rebuild-embeddings --user factory_admin
```

A different supervisor approves the reviewed revision using Approve revision in Documents & reports. An uploader cannot approve their own source. Factory retrieval uses the current approved revision; a new approval supersedes the old revision in the same sector/category/filename family. Keep filenames stable within a revision family. Development can retrieve a draft when no approved revision exists, with its status recorded. Approval is not inferred from document text.

Load the numerical sample and digital thread:

```powershell
python -m cnc_ai timeseries ingest samples/telemetry/cnc_telemetry.csv --user factory_admin
python -m cnc_ai knowledge rebuild --user factory_admin
```

Or sign in as an administrator/supervisor and use **Documents & reports**. Categories include manuals, SOPs, maintenance, machine/tool/material specifications and production reports. Scanned PDFs need offline OCR; legacy `.doc` needs local conversion to `.docx`. Excel formulas are read from saved cached results. Sample documents are fictional training material, not OEM-approved machining parameters.

### 2.7. Run the OPC UA simulator

The default `CNC_OPCUA_MODE=simulator` uses a persistent internal simulator and needs no other process. For a real OPC UA protocol test without machinery, start this in a second terminal:

```powershell
conda activate smartfactoryllm
python -m cnc_ai opcua-simulator --port 4840
```

Then set `CNC_OPCUA_MODE=opcua_test` and `OPCUA_ENDPOINT=opc.tcp://127.0.0.1:4840` in `.env`, restart the application and run `python -m cnc_ai validate --opcua`. Test mode is restricted to loopback.

Sign in as `operator01`, prepare CNC-01 at 7000 RPM and run the policy checks. Create the proposal. A separate signed-in `supervisor01` reviews and approves it. The requester returns and types `EXECUTE APPROVED ACTION`. Successful setpoint readback is not proof that measured spindle speed changed.

### 2.8. Configure a real CNC OPC UA endpoint

Follow [CONTROL_COMMISSIONING.md](CONTROL_COMMISSIONING.md). A controls engineer must replace the training recipes/limits and sample node mapping; prove native controller enforcement; configure the actual machine state semantics; and test timestamp quality, interlocks and authenticated write access.

Configure an OPC UA client certificate/private key, pinned server certificate and restricted controller service account in `.env`. The real adapter uses `Basic256Sha256` with `SignAndEncrypt`. It exposes only allowlisted typed spindle setpoint and feed-hold actions. Real mode requires `real_mapping_reviewed=true` and `controller_enforces_limits=true` in `config/opcua.json`. Keep `CNC_REAL_WRITES_ENABLED=false` while testing reads. Enable real writes and `CNC_SITE_COMMISSIONED=true` only after the documented site acceptance. Demo model mode cannot be combined with a real controller.

### 2.9. Start the application

```powershell
conda activate smartfactoryllm
python -m cnc_ai serve
```

Open `http://127.0.0.1:5000`. Windows wrappers are `scripts/windows/start.ps1` and `start_windows.bat`. Linux uses `bash scripts/linux/start_app.sh`. The server is Waitress; there are no fragile root-level `db` imports.

For factory users, keep Waitress on loopback behind the provided HTTPS nginx configuration and set `CNC_COOKIE_SECURE=true`, `CNC_TRUST_PROXY=true`. Only the trusted proxy may access Waitress. [DEPLOYMENT.md](DEPLOYMENT.md) includes systemd, Docker, firewall and backup instructions.

### 2.10. Validate the complete installation

```powershell
python -m pip check
python -m pytest
python -m cnc_ai validate --offline
python -m cnc_ai validate --models --opcua
python -m cnc_ai audit-verify
python -m cnc_ai cncbench --output runtime/cncbench
python -m cnc_ai timeseries analyze anomaly samples/telemetry/anomaly_query.json --user operator01 --output runtime/anomaly.json
Invoke-RestMethod -Uri 'http://127.0.0.1:5000/api/health'
```

Use the network checks after starting the relevant services. `--offline` validates the database and package without probing network endpoints. Do not combine it with network flags. In PowerShell, use `Invoke-RestMethod`; if you specifically need native curl, call `curl.exe`, not its ambiguous alias. Optional browser testing: `python scripts/validate_browser.py` after installing the browser test dependencies described in [VALIDATION.md](VALIDATION.md).

### 2.11. Transfer to the air-gapped H200 servers

On a connected **Linux staging host matching the factory OS, CPU architecture and Python version**, install and validate the H200 environment. Freeze it:

```bash
conda activate smartfactorymodels
python -m pip freeze > /srv/transfer/inference-lock.txt
conda activate smartfactoryllm
python scripts/prepare_airgap.py --output /srv/transfer/cnc-wheels --inference-lock /srv/transfer/inference-lock.txt --extra historian
python scripts/verify_bundle.py /srv/transfer/cnc-wheels
```

Transfer this project ZIP, the wheel bundle, complete model directories and manifests, an offline Python/Conda environment or installer/package cache, compatible NVIDIA drivers, required OS libraries, site certificates and approved configuration. Windows wheels do not satisfy Linux installation. See [AIR_GAP_DEPLOYMENT.md](AIR_GAP_DEPLOYMENT.md) for exact offline installation, checksum checks, Docker image transfer, commissioning and rollback commands. Model weights are deliberately absent from this ZIP.

## 3. Everyday use

### 3.1. Sign in and orient yourself

Open the application at the configured address. A local workstation uses http://127.0.0.1:5000; factory users use the site's trusted HTTPS hostname. Sign in with your named account. Check the mode label before interpreting any machine status. Choose a language and response detail level. Language names use English consistently: English, French, German, Chinese (Simplified), Chinese (Traditional), Japanese and Korean.

The language selector controls the assistant's response language and the available translated navigation labels. Administrative help and technical configuration fields remain English. Administrators can customize the fixed navigation labels for the selected language in System & settings. These text customizations do not change policy checks.

Use New conversation when changing the evidence database or topic. The browser shows recent conversations belonging to your account only. Changing an analytical source starts a new conversation so context cannot silently mix databases. Enter sends a question; Shift+Enter inserts a line; IME composition does not submit prematurely. Copy response copies the rendered answer text.

![Conversation workspace](screenshots/conversation_desktop.png)

The desktop workspace keeps evidence, conversation history and the active mode visible.

### 3.2. Ask questions with usable scope

A helpful factory question identifies the machine/work order, timeframe, units and the decision needed. For example: “For work orders planned between 2026-09-01 and 2026-09-07, show incomplete quantities and their evidence.” The fictional sample database spans late August and September 2026; asking about today's date in a later deployment may correctly return no matching records.

Other useful requests include “Explain spindle-bearing failure symptoms using the maintenance manual,” “Compare available AISI-4140 stock with planned requirements,” and “Draft a Python function to summarize an exported tool-life CSV.” A general engineering explanation is different from a claim about your actual machine or stock. Inspect evidence before acting on a specific factory claim.

“Is CNC-01 running now?” can use the bounded live-status plan. Its evidence records source times, signal quality and the active simulator/real adapter. Historical production/status fields must not be described as current controller state. A timestamped observation is already historical once captured; use Refresh machine when a fresh observation is needed.

If the assistant asks for a tool, material or timeframe, supply that missing fact rather than asking it to guess. The model does not inspect hidden controller details that are absent from the approved mapping.

### 3.3. Read citations and database results

Open each source card under the answer. A document card shows its filename, revision, location, capture time, excerpt and hash. A database card shows the executed row snapshot and a separate query/parameter view. A truncated result explicitly means the configured row limit was reached; request a narrower timeframe or an aggregate count rather than interpreting the visible rows as the entire factory.

The citation snapshot is retained with the answer. Later changes to the source document or database do not silently change what the earlier answer cited. A citation demonstrates the source used, but the interpretation can still be mistaken. Verify derived conclusions, units and production assumptions when the result matters.

### 3.4. Documents and report summaries

Open Documents & reports. Administrators and supervisors can upload one supported file at a time, choose its category and sector, and record a revision. Ingestion extracts text and attempts embeddings. If the embedding endpoint is unavailable, the file remains searchable through BM25 and the interface says to rebuild vectors later.

PDFs retain page locations; DOCX retains paragraph/table locations; XLSX/XLS retains sheet and row; CSV retains row; text/Markdown retains line ranges. Upload readable text PDFs, not encrypted files. OCR scanned pages locally before ingestion. Save/recalculate Excel workbooks before uploading so formula results are cached; macros and embedded code are not executed. Large files must be split: the limit is 50 MiB per document, 2 million extracted characters and 100,000 spreadsheet rows.

Identical content in the same category/sector is deduplicated by hash. A changed revision should contain the actual revised source; relabeling identical bytes does not create a second duplicate. A separate supervisor promotes a reviewed revision. Current approved sources are preferred; superseded sources are excluded. Factory profile also excludes drafts. Revision state, file hash and extraction location accompany evidence. Text in documents never becomes a machine policy automatically.

Use Summarize as report to produce a source-linked report. The report service reuses conversation inference and summarizes source batches with citations; the displayed result may contain several sections for a long report. Show cited excerpts exposes the actual supporting chunks. Delete summary before deleting its source document. Deleting a document removes it from future retrieval while preserving prior answer evidence snapshots.

### 3.5. Code drafts and planning

The code model can draft SQL, Python, NC/G-code and other manufacturing software. The app can execute a validated read-only SQL query for evidence; it does not execute arbitrary generated Python, shell, NC or robot programs. Treat generated machining code as unverified engineering work. Check the controller dialect, coordinate systems, tool offsets, units, spindle/feed conventions, stock/fixture geometry and the site's normal simulation/dry-run approval before any independent use.

Production planning answers are analytical proposals, not automatic MES schedules. They should cite capacity, downtime, work-order and material evidence and explain assumptions. The release does not include a mathematically certified scheduling optimizer or autonomous shop-floor dispatch.

### 3.6. Stop waiting and recover a response

Stop waiting cancels the browser's wait. The server may still finish the bounded request and save the response. Refresh recent conversations or reopen the conversation to retrieve it. Stopping a chat wait does not execute or cancel a machine proposal, and it is not a CNC stop function.

### 3.7. Optional SQL and speech specialists

Administrators may enable SQLCoder at port 8006 after comparing it with the core coder on approved plant queries. Data-mode questions then use its single SQL draft, followed by exactly the same read-only validation, bound values, allowlists, row/time caps and evidence logging. An incomplete or disallowed query stops. This changes the draft generator, not database permission.

For Whisper, open **Dictate from a recording** in Chat. Select mono 16 kHz PCM 16-bit WAV, up to 30 seconds and 1 MiB. Review the transcript and correct machine IDs, tool numbers, units and values. Choose **Put reviewed text in message**, then press **Send**. No chat or machine proposal is created by transcription alone. Existing message drafts are not overwritten. Speech is not operator authentication.

Use OPTIONAL_SPECIALISTS.md for downloads, private endpoint settings, startup and Coder-Next rollback. Without these services, type the question and use core coding as before.

## 4. The supervised spindle-change workflow

### 4.1. Prepare and evaluate

In Machine control, refresh CNC-01 and inspect its adapter mode, actual RPM, setpoint, tool and material. Select Set spindle speed, enter the requested RPM and a meaningful reason. Run policy checks before creating the proposal.

| Stage | Evaluation |
|---:|---|
| 1 | Machine running in an appropriate configured state |
| 2 | Observed selected tool has an approved assembly RPM rating |
| 3 | Tool, material and workpiece match the approved recipe |
| 4 | Requested RPM and step are within machine and process limits |
| 5 | Authenticated operator has permission |
| 6 | Required separate supervisor approval is identified or recorded |
| 7 | All required telemetry/interlocks have healthy types, quality and timestamps |
| 8 | Only then does requester-confirmed execution reach the typed adapter |

A blocked stage explains why the request stopped; later stages are marked skipped. An approval-required stage means the request needs a recorded review. It does not mean the action may write yet. The default training request from 6000 to 7000 RPM passes only with T07, AISI-4140, WP-4140-01 and the configured healthy simulated context. These are fictional training parameters.

### 4.2. Supervisor decision

Creating a proposal saves its requester, requested action, policy version/hash, observed binding and expiry. Sign in with a different supervisor account to review it. The supervisor records an approval or rejection with a comment. Self-approval is rejected even if a person has supervisor capabilities. Approval alone does not contact the setpoint write node.

The proposal's five-minute lifetime includes the time spent waiting for review. If it expires, prepare a new proposal from current conditions. A policy, machine identity, active CNC program, tool, material, workpiece or state change invalidates the old context. The observed program must have a reviewed qualification matching the tool and process recipe. Program identity is read from the controller, never trusted from chat.

### 4.3. Requester execution

The original requester returns to Machine control and chooses Confirm execution. Type EXECUTE APPROVED ACTION exactly. All live checks and both accounts' current permissions are rechecked. The request is consumed before network I/O, so repeated clicks cannot replay it. The adapter accepts only the allowlisted typed value for that proposal.

On success, the interface says the setpoint readback was confirmed. Check measured actual spindle behavior separately through the controller and the site's normal operating procedures. The simulator intentionally leaves actual RPM distinct from accepted setpoint.

### 4.4. Blocked and uncertain outcomes

Rejected, expired, blocked, confirmed and unknown states are different. A rejected/expired proposal cannot execute. Confirmed means setpoint readback matched. Unknown or unfinished executing means the command may have arrived but could not be conclusively confirmed. Further writes to that machine are blocked, including after restart.

Do not retry an unknown operation. A controls engineer must inspect the physical controller and use the local reconciliation command with a meaningful note. Reconciliation cannot overlap an active write and does not replay it. A new action needs a new proposal. The full procedure and native-controller acceptance requirements are in CONTROL_COMMISSIONING.md.

Feed hold is a fixed supervised Boolean command. It is not an emergency-stop path and does not replace the machine's native safety mechanisms.

## 5. Factory data and extensibility

### 5.1. The CNC database

A fresh sample installation contains 26 fictional machines, 100 work orders and 27,360 historical sensor readings, plus the full linked business domain. Ingesting the synthetic CSV adds 30,240 canonical historian observations, separate from the original sensor_readings table. The six added CNC machines match the new program/tool/lot/run examples. Tables cover factories/lines, machines, states, products/BOMs, routings/operations, production runs, tools/ratings/compatibility, materials/workpieces, downtime, maintenance, quality, inventory, procurement, alarms, users/permissions, proposals/approvals/executions, documents/vectors, evidence, reports and audit events. DATABASE.md contains the generated table/column catalog and seed counts.

The authoritative application database is runtime/factory.db. Creating an empty business schema uses db init without --sample. Sample data and policies are clearly fictional. Old CNC business records can be copied and migrated with the provided legacy importer; old editable operator labels do not become authenticated identities.

### 5.2. Read-only SQL controls

Generated SQL requires data.read permission and is read-only for every role. The whole statement is parsed; second statements, DML, DDL, pragmas, attachment and recursive queries are rejected. Approved tables, columns and functions are checked again by the database engine. User-supplied values should be named parameters. The default output cap is 100 rows and the configured execution time is 5 seconds.

Changing the selected analytical database cannot grant access to control state or credentials. Administrators change business configuration through typed administration services or reviewed offline migrations, not generated DML. A failed SQL validation returns an understandable error and an audit record; the app does not silently run only the first fragment of a dangerous query.

### 5.3. Import an additional database

An administrator can upload a SQLite database in Factory data. It is quarantined until the schema allowlist is explicitly approved. Remove sensitive tables/columns from the displayed JSON before approval. Pending imports remain available for review after refreshing the page. Only approved analytical sources appear in the conversation selector.

Importing does not replace the CNC controller's authority. The source name is a readable label; the underlying technical reference stays internal. Generated business SQL uses SQLite. SQL Server/PostgreSQL business queries require a reviewed analytical export or an additional dialect-specific connector. Numerical historian access has separate PostgreSQL/TimescaleDB, ClickHouse and HTTP read-only adapters; that does not create a general generated-SQL connector.

### 5.4. Add a sector

Use System & settings to add a domain profile, then select it when importing documents or an analytical schema. The supplied robot-cell and process-batch JSON examples show tables, typed columns, primary keys and foreign keys. Create a sector database in Factory data and review its allowlist before use.

Sector extensions add analysis, not new machine-write powers. New controller actions need a typed contract, approved adapter mapping, deterministic policies and tests. Preserve the shared evidence, identity, audit and approval interfaces when extending the CNC domain.

### 5.5. Build a schema from clear row meanings

Define what one row means before adding columns: one machine, one work order, one routing operation, one production run or one timestamped sensor observation. Keep these grains separate. A machine has a stable primary key and a unique readable machine code; operations/runs refer to it through foreign keys. Record units in names such as cycle_seconds and diameter_mm. Separate tool catalog ratings, installed-tool assignments and live controller observations.

Store source and received timestamps, value quality and source sequence for telemetry. Never treat a new receive time as proof of a fresh measurement. Use normalized operational tables, curated analytical views and immutable event/evidence snapshots for their respective purposes. Summing output across all routing steps can count the same part repeatedly; the supplied final-operation view avoids that error. DATABASE_DESIGN.md gives detailed key, relationship, indexing, history, maintenance and quality design guidance.

### 5.6. Understand planning numbers

All numbers in these examples are fictional teaching inputs.

| Decision | Calculation and meaning |
|---|---|
| Shift capacity | 420 available minutes minus 30 setup leaves 390. At 2 minutes per part, ideal capacity is 195 parts before other losses. |
| Delivery risk | 60 remaining parts need 120 minutes at 2 minutes each. Add 30 setup and 20 buffer: 170 minutes. With 150 minutes available, the shortfall is 20 minutes. |
| Material shortage | 120 kg on hand minus 30 reserved gives 90 available. Forty parts at 2.5 kg each need 100 kg: a 10 kg shortage before scrap allowance. |
| Quality sample | Five rejects among 200 inspected observations is 2.5%. This is not automatically the rate for every produced part. |
| OEE | Availability 0.90 times performance 0.80 times quality 0.99 gives 0.7128, or 71.28%. Use consistent site definitions and time windows. |
| Bottleneck | Serial stages taking 2, 3 and 1 minute per part have ideal rates of 30, 20 and 60 parts/hour. The 3-minute stage limits balanced flow to 20/hour. |

Ask the assistant to state the timeframe, units, assumptions and source rows. Compare work-order risk, material reservations, open maintenance, downtime categories and inspected quality separately before combining them into a proposed shift plan. Do not double-count overlapping downtime minutes or mix sample defects with total production. The assistant suggests options; it does not automatically dispatch or resequence machines.

### 5.7. Follow the digital thread

Recorded relationships connect customer and sales order to work order, operation, production run, CNC program, tool, material lot, inspection, alarm and maintenance. Rebuild the projection after business imports. Ask “Trace the digital-thread relationships for Production_Run 1001,” or use the relationship form in Telemetry & health. Results are bounded to three hops and two hundred edges, with explicit truncation and source table/key citations.

An association is not a validated cause. A maintenance record attached to a machine does not prove it explains every alarm. Raw high-frequency samples remain in the historian; the graph stores selected relationships. Captured answer evidence remains immutable after projection rebuilds.

## 6. Numerical machine intelligence

### 6.1. Select a historical window

Open Telemetry & health after ingesting the sample CSV. Select CNC-02, signals bearing_temperature and vibration, reference start 2026-09-01 08:00 UTC, analysis start 11:00 and end 14:00 UTC. Choose Anomaly detection. The end is exclusive. These are historical fictional measurements, not the current controller state.

Numerical methods compute the result and keep its input hash, source timestamps, algorithm version and context. Tool, program, lot and run changes within the window cause rejection; reference tool/program/material context must match. Recorded tool usage, maintenance age and alarm counts are joined as of the window end when available in the local database. Missing history remains unknown. The numerical process has no OPC UA write capability.

### 6.2. Understand eight analysis choices

| Choice | Output | Interpretation |
|---|---|---|
| Anomaly | Robust reference deviations; joint signal screen | Departure from baseline, not failure probability |
| Trend | Slope/minute, fit strength, significance caveat | Fitted direction; autocorrelation affects significance |
| Change point | Candidate mean-shift times | Transition screen, not a unique physical fault |
| Forecast | Future values, horizon and uncertainty interval | Extrapolation; coverage requires validation |
| Health | Reference/alarm screening index | Inspection priority, not calibrated health probability |
| Tool condition | Tool-context screening; optional trained model | Not proven wear or chatter without validation |
| Quality risk | Process screening; optional trained model | Not an actual rejected-part count |
| Remaining useful life | Approved component-specific estimate | Unavailable until suitable labeled data/model exist |

A baseline median of 2.0 mm/s and robust scale of 0.1 gives z = 6 for a 2.6 mm/s sample. That is six reference scales away, not a 60% failure chance. A 0.10 °C/minute fitted trend is about 6 °C/hour. Cutting load, coolant, program and sensor mounting may explain a change; inspect them before calling it a bearing fault.

### 6.3. Forecasts and waveforms

Thirty future samples at one sample/minute means thirty minutes. The default selects naive, drift, seasonal or Holt forecasts by earlier rolling-origin error. The chart separates measurements from predictions and shows a widening interval. The nominal 90% historical-residual band does not guarantee 90% future coverage. Recheck after tool/program/load changes.

Chronos-2 is optional. Download the local snapshot explicitly, install the forecast extra on staging, set CHRONOS_MODEL_PATH and CHRONOS_MODEL_REVISION, then request method chronos2. No runtime download is attempted. TimesFM 2.5 and Moirai 2 are research candidates with separate evaluation work; they are not active interchangeable adapters. TimesFM 3 is excluded from factory defaults because its current model card specifies a non-commercial license.

A one-minute vibration indicator cannot reveal a 240 Hz tone. FFT, power spectral density, band energy, RMS, kurtosis and crest factor require a waveform with matching declared sampling rate and regular timestamps. The fixture is one second at 4096 Hz with a 240 Hz tone. Use reviewed bands and machine-specific baselines; generic peaks do not establish a validated fault.

### 6.4. Component training and evidence

RUL starts as unavailable. Train a component artifact from labeled features with independent unit groups held out, inspect MAE/RMSE and operating scope, then register its approved hash, family, component and programs. Inference rejects mismatched context, missing features and out-of-range inputs. The simple portable ridge regression does not implement censored survival analysis. TIME_SERIES_INTELLIGENCE.md contains the exact training and configuration format.

Observations, anomalies, correlations, hypotheses and validated causes are different claims. The assistant receives compact computed summaries and cites their retained analyses. A validated cause requires separately reviewed engineering evidence. Bad quality, unknown units, irregular cadence and truncated historian results produce readable errors.

CNCBench reports retrieval Recall/MRR/nDCG, SQL validation, anomaly precision/recall/F1/AUROC/false-alarm rate, forecast MAE/RMSE/MASE and horizon errors. Default results use fictional data. --models runs real conversation, planner, Guardian, embeddings and reranking; --neural-forecast adds Chronos comparisons. Small curated scores are smoke metrics, not factory accuracy. See CNCBENCH.md.

## 7. Planning, physics and engineering artifacts

### 7.1. Deterministic planning

Supply explicit jobs, durations, precedence, due times, machines, shared labor/tools/fixtures, maintenance windows, inventory and power limits. The bounded scheduler uses an earliest-due-date greedy allocation and reports infeasible work, lateness, capacity and energy estimates. It is a transparent baseline, not a proof of optimality. The sample is samples/planning/next_shift.json.

The assistant can select this typed tool when inputs are complete; missing inputs require clarification. The session-protected planning API is another entry point. The result is an analytical proposal. There is no automatic MES dispatch or machine resequencing.

### 7.2. Cutting calculations

The typed service computes surface speed, feed and torque and checks configured limits. A 10 mm cutter at 7000 RPM has surface speed pi × 10 × 7000 / 1000 = 219.9 m/min. Four teeth at 0.03 mm/tooth gives 840 mm/min. At 5 kW, torque is approximately 9550 × 5 / 7000 = 6.82 N·m.

These fictional inputs do not approve a cut. Holder ratings, geometry, engagement, rigidity, material condition, coolant and fixture clearance still need review. The calculation records inputs/assumptions as evidence and cannot change the spindle-control policy.

### 7.3. NC artifact review and optional images

The artifact API stores a candidate and content hash. Its static checker accepts a restricted G21/G90/G0/G1 dialect with reviewed speed/feed/tool/envelope constraints; macros and unsupported commands are blocked. Static coordinate checking is not a collision simulation.

Separate simulation, collision-review, engineering-review and final-approval attestations must pass in order. Each references the same candidate hash and external report hash. The uploader cannot attest their own candidate; the final approver differs from the engineering reviewer. Approved export creates an engineering bundle only, with no CNC upload or execution endpoint. Use qualified external CAM/simulation tools with actual fixture/tool models for those reports.

Optional PNG/JPEG evidence uses the conversation service's vision capability and is disabled by default. Image dimensions are bounded; both original-file and analyzed-thumbnail hashes are recorded. It is not calibrated measurement and cannot approve tolerances or machine actions. Scanned-document OCR remains separate offline preparation.

## 8. Administration and maintenance

### 8.1. Model and retrieval health

System & settings shows each physical service, its model, mapped roles and endpoint state. Administrators can verify actual inference. A model mismatch means a reachable server advertises a different ID; align the server's served model name with config/models.json. An unavailable model should not be fixed by changing its display label alone.

The document status shows total documents/chunks and vectors for the current embedding fingerprint. A collection with missing vectors can still use lexical search. After the exact embedding model revision or dimension changes, update configuration and rebuild vectors; stale vectors are ignored. The baseline semantic retriever scans its local vectors, so measure real-corpus latency before large expansion.

### 8.2. Accounts and audit

Create/reset/disable accounts through the local administration CLI. This is an OS-trusted path; users cannot call it from a chat prompt. Avoid shared supervisor accounts. The web UI checks current permissions on every request; the control service rechecks requester and approver before execution.

Administrators can inspect recent audit events and verify the hash chain with audit-verify. Keep an externally protected copy of the chain head for stronger tamper evidence. Database administrators who control all storage are outside the protection of the local hash chain alone. Do not delete audit/control records as an ad hoc troubleshooting step.

### 8.3. Backups, migrations and service restart

Use the online backup CLI for the database and coordinate document/source backups during a maintenance window. A whole-runtime backup is easiest with application and telemetry recording stopped. Preserve model manifests and reviewed configuration with every release; keep secrets in the site's separate protected process.

Migrations are ordered and checksummed. Apply new migration files through db migrate and do not rewrite an already applied SQL file. On a configuration update restart the application. An outstanding control proposal with a different policy hash becomes ineligible. Read DEPLOYMENT.md and AIRGAP.md for consistent restore, service units and offline rollback.

### 8.4. Telemetry recording

The optional monitor command records timestamped observations without issuing control writes. The default interval is five seconds; choose the site's interval and retention policy deliberately. Historical observations show what was read then. They must not be reused as fresh preflight telemetry.

```bash
python -m cnc_ai monitor --interval 5 --count 10
```

Omit --count for continuous recording. The Linux telemetry service restarts after read failures. It does not insert fabricated healthy values during an outage. Monitor disk capacity and archive history through a reviewed maintenance process.

### 8.5. Apply the factory preparation guide

FACTORY_PREPARATION.md maps all 20 topics in your supplied guide to implemented functions and site responsibilities. Copy the JSON templates outside the checkout and assign owners, evidence and reviewers. The twelve-gate checker validates record completeness, current review dates and referenced file hashes:

```powershell
python scripts/validate_factory_readiness.py templates/site_readiness.example.json
```

The unfilled template returns hold (exit 2). A completed record reports evidence_complete; this is not a safety certification or control approval. The checker never enables real writes. Use site controls-engineering review to qualify actual tags, tool/process limits, time synchronization, native interlocks and the final OPC UA command contract. Start with read-only use cases and plant-owned acceptance questions.

## 9. Availability and service operations

Both H200 hosts serve the same five inference roles. Configure primary/fallback URLs with matching model IDs, revisions and credentials. A failed replica pauses for thirty seconds. The UI distinguishes model advertisement from last successful inference. Model retry does not repeat controller writes.

The application database/controller authority has one active owner. Automatic authority failover needs site-tested fencing, ownership and consistent storage. Do not use live SQLite over NFS/SMB or activate two writers. Stop the authority/recorder, back up consistently, restore on standby, verify audit/migrations and reconcile physical controller state before accepting new proposals.

Use a separate numerical OS account without controller secrets, private inference/historian networking, HTTPS browser ingress, read-only model storage and protected external audit anchors. The authenticated observability API reports aggregate model/agent counts without raw prompts. Deployment examples include systemd, nginx, Docker, historian schema, failover procedures and alert guidance.

## 10. Troubleshooting

| Symptom | Action |
|---|---|
| No module named cnc_ai or db | Activate the intended environment and install the package from the project root. Use python -m cnc_ai. Do not restore old root-level imports. |
| Old smartfactoryllm has dependency conflicts | Export/backup it, create smartfactoryllm_v11 and validate before recreating the original name. |
| PowerShell curl behaves strangely | Use Invoke-RestMethod or explicitly curl.exe. |
| Local model service unavailable | Check server log, Linux path, host-local GPU IDs, API key and private base URL; verify inference separately. |
| Model advertised but generation fails | Confirm the runtime supports the exact model and JSON schema API; inspect truncated or invalid output and context size. |
| Download stops | Keep caches/manifests, check disk/access/network, then rerun the same command. Use one worker on unstable links. |
| Model verification says checksum unavailable | Complete a download with --checksums before asking for deep verification. |
| No readable PDF text | OCR the scanned PDF offline or provide a text PDF; decrypt protected files locally first. |
| Missing Excel values | Recalculate and save the workbook so cached formula results exist. |
| No relevant document evidence | Confirm category/sector/source and document revision; inspect extracted text and embedding status; narrow the query. |
| SQL query blocked | Inspect approved schema, parameters, one-statement syntax, functions, row/time constraints and column aliases. |
| Proposal cannot execute | Inspect expiry, separate supervisor approval, current permissions, policy hash, context binding and live telemetry. |
| Unknown controller write | Stop retrying and arrange engineering inspection/reconciliation. |
| HTTPS login/session failure | Check secure cookies, trusted hostname, proxy headers, CNC_TRUST_PROXY and browser time/certificate trust. |
| Changed .env appears ignored | Existing process environment variables take precedence; restart with the intended environment and configuration home. |

API errors include a request reference so administrators can correlate application logs. Do not share full credential-bearing environment files while troubleshooting. Model IDs appear in system status for diagnostics; normal conversation and approval cards use readable source/action labels.

## 11. Validation and release boundaries

Tests cover database/RAG/SQL authorization, accounts, approvals, policy and concurrency failures, uncertain writes, numerical tools, specialist contracts and loopback OPC UA. Browser checks exercise Waitress and the transcript review UI with fixtures. VALIDATION.md records the actual runs and their scope.

Actual model weights, H200 inference, native Windows, production Docker/systemd and physical CNC commissioning were not exercised here. Complete the documented checks on your equipment. Simulation does not establish real-machine safety or cutting compatibility.

The application has one active SQLite/control authority and inference replica failover. Automatic stateful authority failover, SSO, OCR, generic external business SQL dialects, arbitrary robot motion and million-document performance guarantees remain outside this release.

Keep the ZIP, environment lock, model commits, policy/node-map revision, corpus hashes and site acceptance evidence together. Native CNC/PLC protections and approved factory procedures remain authoritative.

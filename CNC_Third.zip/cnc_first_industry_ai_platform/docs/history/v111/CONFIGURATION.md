# Configuration reference

`Settings.load()` reads `.env` from `--home`, `CNC_HOME` or the working directory, in that order. Existing process environment variables take precedence over `.env`. Relative data/configuration paths resolve from that home directory. Each requested JSON file falls back to its packaged default only when the site file is absent. Importing the package does not initialize storage or load a model.

| Setting | Meaning and default |
|---|---|
| CNC_HOME | Project/configuration home; working directory if omitted |
| CNC_DATA_DIR | Local runtime directory; `./runtime` |
| CNC_CONFIG_DIR | Reviewed site JSON directory; `./config` |
| CNC_HOST / CNC_PORT | Waitress address; `127.0.0.1` / `5000` |
| CNC_MODEL_MODE | `local` for real private inference; `demo` for deterministic training replies |
| CNC_OPCUA_MODE | `simulator`, `opcua_test` (loopback only), or `real` |
| CNC_REAL_WRITES_ENABLED | Default false; real adapter write gate |
| CNC_SITE_COMMISSIONED | Default false; explicit site acceptance flag |
| CNC_COOKIE_SECURE | False for loopback HTTP; true for production HTTPS |
| CNC_TRUST_PROXY | False by default; trust one reviewed proxy only when true |
| MODEL_ROOT | External model root; example `F:/AI/models` |
| CONVERSATION_MODEL_PATH / CODE_MODEL_PATH | Local Transformers snapshot directories for serving |
| SAFETY_MODEL_PATH / EMBEDDING_MODEL_PATH | Local Guardian/embedding snapshot directories |
| CONVERSATION_BASE_URL / CODE_BASE_URL | OpenAI-compatible base URLs ending in `/v1` |
| SAFETY_BASE_URL / EMBEDDING_BASE_URL | Private judge/embedding base URLs |
| CONVERSATION_API_KEY / CODE_API_KEY / SAFETY_API_KEY / EMBEDDING_API_KEY | Matching service credentials; required by launcher for LAN binds |
| EMBEDDING_MODEL_REVISION | Exact deployed commit for persistent vector compatibility |
| MODEL_API_TIMEOUT | Generation HTTP timeout in seconds; 120 |
| MODEL_SERVER_BIND | Interface for vLLM; `127.0.0.1` by default |
| MODEL_LOG_DIR | Optional model log directory; otherwise `runtime/model_logs` |
| HF_HUB_DOWNLOAD_TIMEOUT / HF_HUB_ETAG_TIMEOUT | Downloader timeout settings; 120 / 30 seconds |
| HF_HUB_DISABLE_XET | Defaults to 1 for the restart-friendly HTTP download path |
| HF_TOKEN | Optional download credential; keep out of Git and shared logs |
| OPCUA_ENDPOINT | Actual `opc.tcp://...` endpoint; training default uses loopback port 4840 |
| OPCUA_USERNAME / OPCUA_PASSWORD | Restricted native controller service account |
| OPCUA_CERTIFICATE / OPCUA_PRIVATE_KEY / OPCUA_SERVER_CERTIFICATE | Client cert, private key and pinned server cert paths outside the repository |

`models.json` defines physical model IDs, role aliases, ports, environment-key names, host-local GPU IDs, tensor parallel degree, context caps and embedding dimensions. `policy.json` defines commissioned action limits, approval requirement, proposal expiry, telemetry age/span and readback tolerance. `opcua.json` maps reviewed node aliases and explicit native-enforcement gates.

`query_policy.json` contains table-to-column lists, maximum rows and timeout for the fixed factory analytical source. After reviewing a change, run `python -m cnc_ai db refresh-policy`. The query engine caps configuration at its implemented row/time boundaries; generated DML is always denied. Imported sources have separate approved policies stored in the database.

`sectors.json` supplies initial domain profiles. The database stores custom profiles after initialization. Use the UI to update existing sector guidance. Changing a sector does not change the fixed CNC controller authority.

Do not copy Windows model paths into a Linux serving `.env`. A model URL is the client-to-server address; a model path belongs to the inference server's filesystem. These are different fields. `--dry-run` prints the model paths and serving arguments without loading weights. Never put a secret in a URL query string.

## Numerical, historian and retrieval configuration

CNC_PROFILE=development uses in-process statistics, SQLite history, optional draft retrieval and no reranking/vision by default. CNC_PROFILE=factory uses HTTP numerical transport, PostgreSQL history, approved-only sources and reranking. This does not commission real writes.

| Setting | Purpose |
|---|---|
| CNC_TIMESERIES_TRANSPORT | inprocess/http |
| CNC_TIMESERIES_URL, CNC_TIMESERIES_API_KEY | Private :8100 URL and secret at least 24 characters |
| CNC_HISTORIAN_BACKEND, CNC_HISTORIAN_DSN | sqlite, postgresql/timescaledb, clickhouse or http; PostgreSQL reader DSN |
| CNC_CLICKHOUSE_HOST, CNC_CLICKHOUSE_PORT, CNC_CLICKHOUSE_USER, CNC_CLICKHOUSE_PASSWORD | TLS reader settings |
| CNC_HISTORIAN_URL, CNC_HISTORIAN_API_KEY | Private canonical HTTP historian |
| CNC_RERANKING, CNC_REQUIRE_RERANKING | Enable reranking / require it on outage |
| RERANKER_MODEL_PATH, RERANKER_BASE_URL, RERANKER_API_KEY | External snapshot, root URL :8005 without /v1, credential |
| CNC_REQUIRE_APPROVED_DOCUMENTS | Current controlled sources only |
| CNC_VISION | Explicit opt-in image evidence |
| CHRONOS_MODEL_PATH, CHRONOS_MODEL_REVISION, CHRONOS_DEVICE | Local forecast snapshot, commit, cpu or cuda |
| CNC_COMPONENT_MODEL_ROOT | Reviewed local regression artifacts |
| *_FALLBACK_URLS | Matching model replica URLs |
| *_GPU_IDS/TP/MAX_MODEL_LEN/GPU_MEMORY_UTILIZATION/MAX_NUM_SEQS | Per-service host overrides |

The wildcard above is a service prefix, for example CONVERSATION_FALLBACK_URLS and CONVERSATION_GPU_IDS. application.json declares profile overrides; rag.json bounds retrieval; timeseries.json sets quality/forecast/threshold rules; engineering.json defines static NC and cutting envelopes. Restart after reviewed configuration changes. The model launcher accepts --env-file for a model-only configuration; production systemd accounts use separate files as described in DEPLOYMENT.md.

## v11 model choices and optional services

CNC_MODEL_CONFIG selects an explicit registry JSON, relative to the project home or absolute. Default is config/models.json; config/models.coder-next.json retains the previous larger coder. Set the matching CODE_MODEL_PATH and the same registry on application and inference hosts. Missing explicit files are errors. Core ports 8001–8004 remain unchanged; reranker remains 8005.

CNC_SQL_SPECIALIST and CNC_SPEECH default false. Their private endpoints are SQLCODER_BASE_URL at 8006/v1 and SPEECH_BASE_URL at 8007/v1, with separate API_KEY, MODEL_PATH and optional FALLBACK_URLS variables. Serving/download details are in OPTIONAL_SPECIALISTS.md. Existing application.json files get false defaults for these new switches. An enabled specialist requires its role/specification in the model registry. These settings never change operator permissions or OPC UA policy.

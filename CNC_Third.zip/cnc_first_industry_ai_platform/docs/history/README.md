# Historical material

This directory preserves earlier releases and test evidence. It is not the current deployment guide and does not establish RTX or fifty-client qualification. Use ../../README.md and ../SERVER_INSTALLATION.md for v11.2.

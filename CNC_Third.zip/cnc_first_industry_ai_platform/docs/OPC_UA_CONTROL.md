# OPC UA spindle control

Use CNC_OPCUA_MODE=simulator for persistent internal training state. For protocol testing run python -m cnc_ai opcua-simulator --port 4840, set CNC_OPCUA_MODE=opcua_test and OPCUA_ENDPOINT=opc.tcp://127.0.0.1:4840, then validate --opcua. Test mode is loopback-only.

The training request is CNC-01, T07, AISI-4140, WP-4140-01 and O1001, from 6000 to 7000 RPM. These are fictional commissioned-example values, not OEM machining instructions. A proposal, separate supervisor review and requester confirmation are all required. Setpoint readback does not prove measured spindle speed changed.

Real OPC UA is a separate adapter with Basic256Sha256/SignAndEncrypt, a client certificate/key, pinned server certificate and restricted service identity. Map reviewed aliases in config/opcua.json, including machine identity, active program, state, tool, material, workpiece, timestamps/interlocks and allowlisted typed outputs. Preserve native controller enforcement. Keep CNC_REAL_WRITES_ENABLED=false until read and commissioning tests pass; real mode cannot use demo inference.

Follow CONTROL_COMMISSIONING.md for exact native-enforcement flags, site acceptance, unknown-write reconciliation and rollback. Neither arbitrary node IDs nor arbitrary programs are accepted from the model. Feed hold is a supervised fixed Boolean action, not an emergency stop.

# Research environments kept outside the factory application

Current v11.2 deployment is defined by [MODEL_COMPATIBILITY.md](MODEL_COMPATIBILITY.md) and [SERVER_INSTALLATION.md](SERVER_INSTALLATION.md). The research below records earlier selection decisions, not a hardware benchmark. Optional services require a separately qualified allocation within the existing eight-GPU budget; they are not enabled in the default twelve-instance layout. Any older accelerator placement below is historical.

The optional research candidates are not downloaded by `all`, imported by cnc_ai, installed into smartfactoryllm or given controller credentials. Their upstream instructions are a starting point, not a tested factory deployment. Review and pin source, dependencies, weights, licenses and submodules on an internet-connected staging host; transfer verified artifacts only after the lab test passes.

## GigaBrain and robots

[The supplied GigaBrain repository](https://github.com/open-gigaai/giga-brain-0) describes an embodied stack with robot-specific inference clients. Its AgileX and Maker H01 workflows require matching observations/actions, normalization statistics and additional pretrained assets. An arbitrary CNC OPC UA node map cannot replace an embodiment. The H01 client documents a dry-run mode; hardware command publishing is a separate action that this project does not integrate.

If your robotics team evaluates it, allocate a separate Linux research host/OS account and virtual environment. On connected staging, clone the supplied repository outside this project, inspect and choose an immutable commit, and check out that commit before following its requirements files. Save `git rev-parse HEAD`, the full environment freeze, model manifests and the selected embodiment configuration. Install its custom dependencies only into that research environment. Read its README's matching robot and model version sections; do not combine examples for different releases. Acquire all referenced secondary assets before disconnecting the network.

First run offline dataset/simulator inference without ROS publishers or a route to production robot/CNC networks. Validate units, axes, observation order, action dimensions, control cadence, joint/Cartesian bounds and emergency-stop integration with the robot integrator. A project-side chat integration and robot execution adapter are not supplied or claimed tested. The factory assistant can still explain robot manuals through RAG without running a VLA model.

## IndustrialCoder

[Industrial-Coder source](https://github.com/CSJianYang/Industrial-Coder) provides industrial engineering examples and training tooling. The model card identifies custom architecture code; a simple replacement of CODE_MODEL_PATH is insufficient assurance. Review the pinned code and its dependencies before enabling any custom-code loader in a separate environment. This project's launcher does not enable `trust_remote_code` automatically. Test CAD/RTL/embedded/compiler workloads using their appropriate tools and engineering checks. Do not use publisher leaderboard claims as evidence of controller-specific NC safety.

## Policy and reasoning challengers

[Granite Guardian's source](https://github.com/ibm-granite/granite-guardian) is the reference for the integrated custom-criteria judge. The existing application prompt/parsing contract is explicit in src/cnc_ai/models.py. [Qwen3's repository](https://github.com/QwenLM/Qwen3) is a family reference; use the exact selected model card and frozen runtime for serving.

GPT-OSS and safeguard candidates require Harmony-aware serving; Shieldstral uses a different binary scoring protocol. None is a drop-in replacement for Guardian's score-tag parser. If comparison is warranted, create an isolated evaluation adapter, retain the same plant policies and test labels, and measure failures and false positives before promoting it. Raw model reasoning is not a UI feature. Do not start multiple judges merely because GPUs are available.

## Small GGUF code models

Brey's and joehiggi's supplied models can be considered in a separate llama.cpp/Ollama lab after provenance/license review. Choose one reviewed quantization and pin the runtime. Their model-specific prompt templates and output shapes must be evaluated. The factory application's NC artifact review/export workflow still applies to any imported draft; passing a syntax subset check does not validate tool paths, collisions or a machine's dialect.

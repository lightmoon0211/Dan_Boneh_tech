# Numerical CNC intelligence

Development uses in-process NumPy/SciPy computation and SQLite observations. Ingest the fictional dataset, then run a retained analysis:

```powershell
python -m cnc_ai timeseries ingest samples/telemetry/cnc_telemetry.csv --user factory_admin
python -m cnc_ai timeseries analyze anomaly samples/telemetry/anomaly_query.json --user operator01 --output runtime/anomaly.json
```

Factory deployment uses CNC_PROFILE=factory, a reviewed historian reader and HTTP numerical process:

```bash
python -m cnc_ai timeseries serve --host 127.0.0.1 --port 8100
```

Set CNC_TIMESERIES_API_KEY to a separately generated secret of at least 24 characters for application and service; CNC_TIMESERIES_URL defaults to loopback 8100. Use TLS if crossing hosts. The service has no controller adapter or write route. GET /health reports process availability, while authenticated POST /v1/timeseries/{kind} accepts AnalysisInput. The session-protected app route /api/timeseries/{kind} accepts AnalysisQuery and retrieves the bounded data first.

## Contract and preparation

Each observation carries machine/signal, UTC event and ingestion timestamps, finite value, engineering unit, quality, source, sampling rate, tool, program, lot, run and sequence. Event time measures freshness; late ingestion does not create a new measurement. Queries are start-inclusive/end-exclusive, capped at 20,000 observations; combined analysis/reference input is capped at 40,000 points. One authoritative unit/source per signal is required. Mixed tool/program/lot/run windows are rejected. Reference tool/program/material context must match.

Bad/uncertain samples are excluded only above the configured good-quality fraction; there is no implicit interpolation. Forecasting requires regular all-good cadence. A waveform must declare sample_kind=waveform and matching sampling rate. Do not run spectral diagnosis on minute-average vibration indicators. The supplied waveform is sampled at 4096 Hz and contains a 240 Hz tone.

## Methods

| API kind | Implemented computation |
|---|---|
| anomaly | Median/MAD robust z-score against a separate normal reference; regularized Mahalanobis screen for aligned signals |
| trend | OLS slope/minute, R-squared and significance caveat |
| change-point | Bounded windowed mean-shift candidates |
| forecast | Rolling-origin naive/drift/seasonal/Holt selection; optional local Chronos-2 |
| health/tool-condition/quality-risk | Reference/alarm screening index, plus optional approved scoped regression |
| rul | Approved component artifact only; unavailable by default |

Rolling mean/std, EWMA, standard/robust z-score, RMS, kurtosis, crest factor, rate, FFT, PSD and configured band energy are computed. The output identifies observation/anomaly/correlation/hypothesis, method version, input/config hash, units, window, assumptions and recommended review. No calibrated failure probability is fabricated. OLS residual independence and approximate Mahalanobis thresholds are explicit limitations. The statistical forecast's nominal 90% historical-residual band is not guaranteed future coverage.

## Optional neural forecast and component models

```powershell
python scripts/models/download_factory_models.py chronos --model-root 'F:/AI/models' --checksums
python -m pip install '.[forecast]'
```

Stage the forecast extra in a separate numerical environment with a compatible approved Torch build. Set CHRONOS_MODEL_PATH, CHRONOS_MODEL_REVISION and CHRONOS_DEVICE=cpu or cuda. Use method=chronos2 in the query. Snapshot resolution is offline; no application startup download occurs. TimesFM/Moirai targets are research downloads, not implemented alternate backends.

```bash
python -m cnc_ai train-component labeled_runs.json --features vibration_rms spindle_current_mean --target remaining_hours --component spindle --machine-family site_spindle_A --output /srv/ai/component-models/spindle-rul.json
```

Rows require numerical feature/target columns and independent unit_id groups; at least 60 rows and six groups are required. Whole units are held out. Review MAE/RMSE, feature bounds, target meaning, operating scope, interventions and censored examples. This ridge-regression interface is not a complete survival-model pipeline.

Set CNC_COMPONENT_MODEL_ROOT. In timeseries.json register trained_models.rul with file, sha256, approved=true, compatible programs and output unit. The artifact itself carries machine family/component/feature normalization and held-out metrics. Inference checks scope, hash and feature envelope; analogous registrations support health, tool-condition and quality-risk. Never infer RUL from an unvalidated generic forecast.

## Historians

CNC_HISTORIAN_BACKEND selects sqlite, postgresql/timescaledb, clickhouse or http. Install the historian extra for the external SQL readers. Use CNC_HISTORIAN_DSN or CNC_CLICKHOUSE_HOST/PORT/USER/PASSWORD with SELECT-only credentials and reviewed TLS. HTTP uses CNC_HISTORIAN_URL/API_KEY and canonical /v1/observations/query; arbitrary prompt URLs are forbidden and truncated responses rejected. The adapter does not turn external databases into unrestricted generated-SQL sources.

The MTConnect parser accepts bounded Streams XML with a reviewed dataItem-to-machine/signal/unit mapping and forbids XML entities. The site collector handles transport, sequence gaps and persistence. High-rate retention/downsampling belongs in the production historian; SQLite is a development archive. Full bounded analysis inputs/results remain in analysis_records; compact cited summaries enter the LLM.

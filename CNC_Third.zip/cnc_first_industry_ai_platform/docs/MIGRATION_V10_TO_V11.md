# Upgrade v10 to v11 without losing existing data

This release changes model selection and adds optional SQL/speech integration and site-readiness records. It does not change the CNC authority schema or replace your runtime database. The previous numerical intelligence, RAG, planning, artifact review, accounts and deterministic controller checks remain.

1. Stop the old application and take a coordinated backup of runtime, documents, approved policy/configuration, model manifests and environment exports. Retain the old release ZIP and external model folders.
2. Extract v11 into a separate folder. Create smartfactoryllm_v11 using README step 1; install the package before running scripts. Do not overwrite the old environment in place.
3. Compare configuration files manually. Preserve site credentials/certificates, custom allowlists, document policies and real endpoint settings; do not replace them with fictional examples. Point CNC_DATA_DIR to a restored copy for testing, not the active production directory.
4. Select the code profile. Default v11 uses Qwen3-Coder-30B-A3B-Instruct; existing Coder-Next users can set CNC_MODEL_CONFIG=config/models.coder-next.json and CODE_MODEL_PATH to their existing snapshot. Set the same registry/model name on both application and inference hosts. New optional settings CNC_SQL_SPECIALIST and CNC_SPEECH default false.
5. Existing custom application.json files may lack v11 optional keys; the loader supplies false defaults. Existing custom model registries can keep the old seven core roles; optional services are absent until merged deliberately. Do not enable a specialist without adding its matching role/specification.
6. Run `python -m cnc_ai db migrate` against the restored runtime, then `python -m cnc_ai validate --offline`, the tests and scripts/validate_installation.py. v11 introduces no additional schema migration; already-migrated v10 data remains intact.
7. Stage model inference, RAG citations, known SQL answers, recorder/historian links and simulator control. Test optional SQL/voice only if enabled. Repeat site acceptance for any changed model/policy/runtime.
8. Stop the staging application, perform the site-controlled cutover to one active authority and retain rollback backups. Never run v10 and v11 control services against the same controller/runtime concurrently. Complete fencing/restore work before calling this application highly available.

If rollback is necessary, stop v11 and restore the coordinated pre-upgrade set with the prior package/model profile. Do not discard v11 audit evidence; export/retain it as part of the incident record. Your separate model files are not altered by the application upgrade.

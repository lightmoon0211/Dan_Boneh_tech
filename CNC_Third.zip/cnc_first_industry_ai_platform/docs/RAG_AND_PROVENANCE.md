# RAG and retained evidence

Ingestion supports text PDF, DOCX paragraphs/tables, XLSX/XLS cached cell results, CSV, TXT and Markdown. Scans need offline OCR; legacy DOC needs conversion. Macros/code are not executed. File size, extracted characters and spreadsheet rows are bounded. Exact page/paragraph/sheet/row/line locations and hashes are kept.

Retrieval filters sector and revision eligibility before BM25/dense retrieval, fuses ranks with RRF, optionally applies Qwen reranking and returns a bounded final set. Reranker uses vLLM /score, not a chat or embedding endpoint. Development may retrieve drafts where no approved source exists. Factory requires approved current revisions. A different supervisor approves; approval atomically supersedes the prior member of the same sector/category/filename family. Never change a filename accidentally during a controlled revision. Eligibility is rechecked before evidence persistence.

Embedding fingerprint includes exact model revision and dimensions; stale vectors are ignored. Rebuild after changing either. Lexical retrieval remains available during embedding outage. Optional reranking can degrade explicitly unless CNC_REQUIRE_RERANKING makes failure blocking. Defaults bound eligible chunks to 50,000 and candidate/final counts; measure actual-corpus latency before expansion.

Evidence snapshots retain source bytes/text hash, extraction location, revision/state, ingestion metadata and retrieval method. SQL evidence includes executed query, bound parameters, approved source and result rows/time. Numerical evidence includes method/config/input hashes, window, units, context and analysis record. Answers may cite only returned sources; required operational answers cannot omit citations. A citation proves what was consulted, not that an LLM interpretation is infallible.

Documents and database text are untrusted evidence, never executable instructions. They cannot grant permissions, promote documents, change CNC policies or bypass approval. Reports reuse conversation inference with source citations; a draft summary is not a controlled SOP approval.

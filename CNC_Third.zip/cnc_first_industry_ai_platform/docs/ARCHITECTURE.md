# Architecture for v11.2

The original installable `src/cnc_ai` Flask/Waitress application remains the single stateful authority. It owns local SQLite, documents, conversations, approvals, audit history and the deterministic controller adapter. A file lock prevents two supported CLI server processes from owning the same runtime. Live SQLite is never placed on NFS or SMB. An external historian is a separately configured read-only integration, not a completed PostgreSQL migration of the application database.

```mermaid
flowchart TD
 B["50 authenticated browsers"] --> T["CPU server HTTPS and sessions"]
 T --> Q["Persistent bounded jobs"]
 Q --> R["Active local model router"]
 R --> A["AI A six instances four GPUs"]
 R --> C["AI B six instances four GPUs"]
 Q --> E["Authorized evidence and tools"]
 E --> D["Local database and documents"]
 E --> P["Deterministic proposal approval and rechecks"]
 P --> O["Reviewed OPC UA adapter"]
 D --> K["Independent protected backup"]
```

The default manifest has six routine workers, one long-job worker and two RCA workers, at most 100 pending/running jobs, at most three per user and one executing per user. Dispatch cycles through eligible owners; each owner's oldest eligible job goes first. Admission is transactional. A long question goes to the long lane; reports and ingestion always use that lane. Engine token counting rejects context overflow without silently removing evidence. Fifty browser sessions do not imply fifty executing RCA investigations or fifty simultaneous 32K contexts.

The browser receives queued/running/final status and can cancel. Final chat/report output appears after the existing risk review; no hidden reasoning or provisional model tokens are streamed. Queues store protected request/result records in the authoritative local database, not logs. Worker checkpoints verify current account permissions and cancellation. Timeouts are cooperative; bounded network/parser operations may finish before cancellation. Cancellation does not undo already completed records. On process restart, unfinished jobs are marked failed and active RCA cases cancelled with recovery evidence. Nothing automatically replays a tool sequence.

The distributor uses least occupied compatible instances with round-robin tie breaking, per-instance in-flight limits, five-second admission, a sixty-second overall inference deadline, at most two attempts and a thirty-second failed-instance cooldown. All five roles are actively distributed. Readiness requires both the exact model and immutable revision alias plus a real role-specific inference check; `/v1/models` alone is insufficient. Readiness is cached for sixty seconds and invalidated by failures and node recovery. A drain prevents new assignments while bounded in-flight calls finish. Inference retries operate on an immutable inference request only, never on SQL/tool/controller execution.

Twelve independently supervised vLLM instances listen on loopback backend ports. Each inference node's nginx presents the specified TLS service ports and permits only the CPU server IP. Reranking retains `/score` at the service root; the other services use `/v1`. GPU 3 starts Guardian, then embeddings, then reranking after actual startup probes. One service's restart does not restart its neighbors. GPU memory sharing is explicitly declared and budget checked, but remains a physical qualification gate.

The supported single-authority server starts sixteen bounded HTTP threads; slow jobs run elsewhere. Essential status does not synchronously probe every inference endpoint. The UI distinguishes unchecked, inference-ready, cooldown, unavailable and draining states. Model-call records contain request IDs, role, instance, revision, latency and token counts, without raw prompts. Existing detailed factory evidence retains its authorization boundary.

Inference identities receive only their own service key and a minimal process environment. They have no controller credentials. Site firewalls must deny their access to controller networks and public internet. All browser assets are local. Model storage is read-only to serving accounts; each instance has a writable private cache. Ordinary private Ethernet is sufficient; no cross-host model shard or NVLink fabric is used.

# v11.2 validation and acceptance

The project was upgraded from the exact preserved v11.1.0 RCA archive. All local execution used isolated fictional data, model test doubles, loopback OPC UA or temporary deployment fixtures. No physical factory machine was contacted. **Real eight-GPU/fifty-client acceptance was not performed.**

## Three validation passes

| Pass | Result and evidence |
|---|---|
| Baseline | PASS: original v11.1 wheel ran all 159 baseline tests before changes. SHA-256 and all 337 original file hashes are in v112/baseline_inventory.json. |
| 1: implementation/regressions | PASS: 184 tests; v112/pass1-junit.xml. Preserved control, SQL, authorization, RCA and evidence tests; added routing, manifests and jobs. |
| 2: deployment/isolation/failures | PASS: 187 tests; v112/pass2-junit.xml. Added queued RCA cancellation/expiry propagation. Migration, browser, proxy/systemd syntax and backup tests have separate reports. |
| 3: final release reproduction | See v112/RELEASE_REPORT.json for actual final installed-wheel test counts, static checks, fresh extraction/installation and final hashes. No pending hardware gate is counted as a software pass. |

The final installed-wheel suite passed 190 tests in 75.26 seconds. It additionally checks full-context rejection, unmanifested backup-content rejection, and retrying the other node when one node has failed. Existing migrations 001–004 are unchanged. Migration 005 is additive. The actual original v11.1 wheel created the synthetic upgrade database; migration preserved the checked users, document/revision, pending proposal, conversation tables, RCA case/evidence and audit history. See v112/migration.json.

Nginx 1.30.4 `-t` validated all three generated proxy configurations using temporary test certificates and an unprivileged substitute for the app's 443 listener. `systemd-analyze verify` validated thirteen units with available interpreter paths substituted in temporary copies. These checks do not start the actual factory services or validate site certificates. Docker is unavailable here: container execution/build is BLOCKED, not passed. See v112/deployment-syntax.json for exact scope.

Both Chromium/Waitress browser scripts passed on desktop/mobile layouts: sign-in, conversations, source cards, approvals/requester execution in the simulator, numerical charts, RCA summary/events/evidence/revisions, and no JavaScript errors. The backend suite tests current-role revocation, ownership, CSRF, origin checks, fair admission, cancelled jobs and restart reconciliation.

## Synthetic capacity evidence

Use the final report v112/load-accepted.json. It records separate authenticated 5/10/25/50-client phases, bursts, mixed RAG/SQL/report/ingestion/RCA work, conversation hotspots, long inputs, node loss, role calls, instance distribution, queue wait, p50/p95/p99, first final reviewed output, throughput, RSS and actual socket egress observations. All GPU measurements remain NOT RUN. Approximate input token lengths use a synthetic counter; the actual model service tokenizer is authoritative onsite.

Earlier load-synthetic.json and load-final.json are explicitly superseded: the first harness counted a completed blocked answer as a completed response. Review exposed a missing required query label in the synthetic SQL fixture. The fixture and semantic outcome checks were corrected and the full workload repeated. load-context-final.json records that diagnostic failure; it is not final acceptance. A 32K over-budget input is an expected safe refusal, separately reported, not an answered request. No evidence was silently truncated. A subsequent fault run exposed two retries reaching different replicas on one failed host; the distributor now prefers the other host after a failure. load-node-retry-diagnostic.json preserves that failure. The regression test and full repeated load run passed.

Measured final synthetic run: 506 completed requests in 325.12 seconds, zero unexpected job failures, one expected context refusal, status p95 0.1701 seconds, completed-response p95 51.2871 seconds, and queue-wait p95 46.624 seconds. The 50-client node-loss phase completed all 50 requests with p95 58.8232 seconds. All twelve replicas handled calls during the run. The egress hook observed 52,169 loopback connections and no non-loopback attempts. These CPU/test-double timings do not satisfy or fail the separate real-GPU latency targets.

## Repeat software checks

```powershell
python -m pip install -c requirements/validated-linux-py312.txt '.[test,download]'
python -m pip check
python -m pytest -q
python scripts/validate_installation.py
python scripts/deployment/configure.py
python scripts/deployment/validate_migration.py --baseline-wheel 'F:/CNCBackups/cnc_first_ai-11.1.0-py3-none-any.whl'
```

The CPU constraints record Linux/Python 3.12. Prepare a separate Windows wheelhouse. Browser checks require provisioned Playwright/Chromium; use --browser-executable with scripts/validate_browser.py and scripts/rca/validate_browser.py. Never download a browser during disconnected operation.

## Remaining independent gates

| Gate | Status and reason | Site action |
|---|---|---|
| All five physical model snapshots | BLOCKED here: weights absent | Download/resume, verify complete manifests/licenses and bind pins. |
| Exact driver/CUDA/Torch/vLLM kernels | BLOCKED here: no RTX GPUs | Qualify sm_120, BF16, hybrid attention, MoE and pooling; freeze the successful complete environment. |
| Shared GPU 3 startup/operation | NOT RUN | Test simultaneous Guardian/embedding/reranker load; measure actual memory, contention and approved power. |
| Real eight-GPU/50-client workload | NOT RUN | Follow CAPACITY_TESTING.md with recorded hardware and unchanged acceptance targets. |
| Both-host physical failure and recovery | NOT RUN | Synthetic routing tests pass; repeat real node/service loss and degraded-capacity measurement onsite. |
| Offline GPU cold start and site network | NOT RUN | Disable public egress, boot from transferred assets, inspect real network traffic and test TLS/DNS/time/firewalls. |
| Native Windows/PowerShell and Docker | NOT RUN/BLOCKED | Execute target-system scripts and the app-only container workflow on provisioned hosts. |
| Chassis whole-system qualification | BLOCKED pending vendor/site | Verify E1.S/M.2 details, risers, CPU/RAM, cooling, PSU surviving-load capacity and support; no automatic 600 W caps. |
| Factory data/rules and real CNC | NOT RUN | Qualify mappings, evidence, approvals, native interlocks and uncertain-write reconciliation through site commissioning. |

These are acceptance gates, not hidden TODO implementations. Software tests do not certify causal correctness, machine safety or a vendor integration. The CPU authority remains a single point of failure with manual fenced restoration; no automatic stateful failover is claimed.

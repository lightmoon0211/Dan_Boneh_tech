# Capacity testing and acceptance gates

A client is an authenticated browser session performing work. Fifty accounts alone prove nothing about capacity. The repeatable harness creates isolated sample data and separate authenticated users, starts the real Flask/Waitress application, submits HTTP jobs, polls status and records outcomes. It never configures real OPC UA or executes a physical action.

## Targets recorded before site acceptance

| Check | Initial target | Interpretation |
|---|---|---|
| Synthetic application status p95 | At most 2 seconds | Login/status/cancel remain responsive during slow jobs |
| Unexpected synthetic job error rate | At most 1% | Admission/context refusals must be separately counted |
| Routine real-model completed response p95 | At most 60 seconds | Proposed target for the agreed short/typical corpus |
| Long real-model job p95 | At most 300 seconds | Long lane, separate from routine requests |
| Real-model queue wait p95 | At most 30 seconds | Revisit worker/instance budgets using measurements |
| Safety and isolation | Zero unauthorized writes/data leakage | Never relax to improve throughput |

GPU targets are proposals, not achieved measurements. Define the factory's exact workload, acceptable wait, source quality and output quality before accepting the installation. If GPU 3 contention or generation quality fails, reduce scheduling pressure within the eight-GPU budget and remeasure; do not silently enable extra GPUs, quantization, truncation or skipped Guardian review.

## Synthetic application test

Run on Linux with the installed test application package:

```bash
python scripts/evaluation/load_clients.py --mode synthetic --clients 5 10 25 50 --rounds 2 --duration 30 --deny-public-egress --output /tmp/synthetic-load.json
```

This runs bursts, sustained mixed workloads, conversation hotspots, serial long-input cases and a simulated AI A outage. The mixture includes chat/RAG, read-only SQL plans, Guardian input/output requests, embeddings, reranking, document ingestion, reports, RCA submission and status polling. The deterministic model transport intentionally cannot establish real language quality or GPU throughput. The egress hook records actual socket connects and rejects non-loopback destinations; no public connection should be attempted in this synthetic run. It is an application-level egress test, not proof of the factory firewall or a GPU host's offline cold start.

The harness records completed latency p50/p95/p99, queue wait, first reviewed final output, throughput, status latency, failures, role calls, instance distribution, peak process memory and degraded-node phases. The output also records revisions and cache conditions. Synthetic input token counts are approximations; true token lengths must be measured by the actual service tokenizer. A 32K input plus output/schema/evidence can exceed the configured 32K total limit; that case must explicitly fail with a context-budget error rather than truncate evidence. Long cases are submitted serially, not fifty at once.

## Actual model contracts and load

With verified snapshots and the twelve services available, first run:

```bash
python scripts/deployment/probe.py --manifest /etc/cnc-ai/deployment.json --env-file /etc/cnc-ai/app.env --wait-seconds 30
```

The probe verifies immutable aliases and actual chat JSON, Guardian yes/no, vector dimensions and reranker scoring. Next use the same isolated load harness with **site credentials in the process environment**, a qualified manifest and `--mode models`. Do not use `--deny-public-egress` here, because it intentionally permits only loopback; use site firewall restrictions instead.

```bash
python scripts/evaluation/load_clients.py --mode models --manifest /etc/cnc-ai/deployment.json --clients 5 10 25 50 --rounds 3 --duration 900 --output /srv/acceptance/physical-model-load.json
```

Run this from the CPU evaluation environment. Keep production data/credentials for controllers out of that process. Actual models may produce different plans; investigate model-contract/quality failures instead of altering guards. Record source and dependency locks, driver/CUDA, firmware, all eight GPU serials/memory/power caps, hardware, cache state, request lengths, output lengths and exact duration. Save `nvidia-smi` metrics during the run. Evaluate approved factory questions/citations and Guardian false positives/negatives separately; synthetic fixture answers are not that evaluation.

Test loss of A, restoration, loss of B, restoration, and only the reranker stopping. Use the drain API for planned maintenance; an approved fault test can stop one host without a drain. Measure degraded latency and distribution. The unit fault tests cover routing logic but cannot prove physical-host resilience. Test all three GPU 3 services starting and serving simultaneously under long reviews and retrieval batches. Never reset GPU power limits as part of this test harness.

## Remaining independent gates

- Matching-hardware clean offline installation and cold start with public egress denied at the host/network boundary.
- Windows/PowerShell execution on the supported workstation image.
- Nginx/systemd/Docker checks on the chosen factory OS and deployment method.
- Data mapping and multilingual retrieval/answer/diagnosis quality on the site's approved corpus.
- Human-approved controller commissioning, native safety enforcement, uncertain-write recovery and physical response verification.

Record each gate as PASS, FAIL, BLOCKED or NOT RUN with evidence. The release validation report lists which of these were actually executed here.

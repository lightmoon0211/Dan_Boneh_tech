# Migration from the earlier project

## Preserve the old installation first

Stop the old application and export the old `smartfactoryllm` environment. Copy its databases, documents/reports, custom schemas, UI label customizations and non-secret model settings to a dated backup outside the new project. If the old database is live, use SQLite's backup API or stop the process before copying it. Model files should stay in their existing external directory.

Use the README's `smartfactoryllm_v11` replacement environment workflow. Do not try to fix the old environment by successively installing conflicting Torch, vLLM and UI packages into it. The new application imports the installed `cnc_ai` package; no root-level `db` module or `PYTHONPATH` workaround is required.

## Import a legacy CNC database

Set `CNC_DATA_DIR` to a new, unused runtime directory in `.env`, then run:

```powershell
python scripts/database/import_v8.py 'D:/old-project/data/manufacturing.db'
python -m cnc_ai validate --offline
```

Substitute the actual old database path. The import script checks for the legacy CNC tables, copies the database through SQLite's backup API and applies the new migrations. It refuses to overwrite an existing target or import an already migrated platform database. Existing CNC business records are preserved; the 20th training machine is not injected into an imported factory database. The training simulator remains separate and clearly labeled.

For a v9 backup, restore the complete coordinated runtime set with the application stopped and use `python -m cnc_ai db migrate`. Do not pass a v9 database to the legacy importer. For an unrelated sector schema, use **Factory data → Import an analytics database** and explicitly review the allowlist instead of making it the CNC authority.

## Accounts, documents and customizations

The old project used editable operator labels rather than authenticated human identities. Those strings are not imported as privileged accounts. Create new named users and role assignments. Re-ingest the original documents to generate reliable page/row citations, hashes and current embedding fingerprints. Legacy summaries remain in a copied database if present; the new report panel creates source-linked summaries from re-ingested files rather than treating old generated prose as approved evidence.

Copy custom sector definitions deliberately into the new JSON schema format or use the administration UI. SQL allowlists are now explicit table/column policies; credentials, employees' personal data and control authority tables are not exposed by default. UI language names are English-only labels; navigation labels and answer language remain configurable.

The new factory control configuration must be commissioned from the actual controller and approved process data. Do not carry over a generic OPC UA write function or automatically mark a previous simulated endpoint as commissioned.

## Retained capabilities

CNC analytics and production questions, factory-domain conversation, code drafts, report ingestion/summaries, document retrieval, database import/schema inspection, custom sector schemas, language selection, custom navigation labels and simulator spindle/feed-hold proposals remain available. They now share coherent package configuration and authenticated service boundaries. Response-style selection replaces unclear generated-mode labels. Structured plans are internal; normal users see actions, evidence and proposal status.

The archived repository inventory in `previous_repository_inventory.json` records the source/configuration files reviewed before the rebuild. `REBUILD_REVIEW.md` explains deliberate behavior changes and remaining extension points.

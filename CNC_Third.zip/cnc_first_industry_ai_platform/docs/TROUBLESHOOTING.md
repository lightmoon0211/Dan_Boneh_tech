# Troubleshooting

Start with the manual's troubleshooting table and python -m cnc_ai validate --offline. Use the intended Conda interpreter and install the package from the root. No module named db means an obsolete root-level script is being used; use python -m cnc_ai and python -m pytest.

PowerShell: Invoke-RestMethod or curl.exe; avoid curl aliases. Existing environment variables override .env; restart after changes. A Windows model path does not work on Linux. Reachable/model advertised means a listing answered; last successful inference is a separate real request result.

Missing numerical data: check explicit UTC interval, exclusive end, signal names, quality, units, historian backend and ingestion. Mixed tool/program/lot/run windows must be split. Forecasts require regular all-good samples. RUL unavailable is expected until a reviewed component artifact exists. Check the numerical service key if HTTP transport returns unauthorized.

Missing RAG results: inspect extraction, sector, approved revision and embedding fingerprint. A draft may be excluded in factory mode. Reranker failure is distinct from missing embeddings. Do not relabel a model or promote a source just to make a status green.

A blocked proposal needs its actual failing stage resolved. Unknown controller outcome requires physical inspection and reconciliation, not a retry. Check active program, permissions, expiry, policy hash, interlock quality and source timestamp freshness. Use request references to correlate errors without sharing secret-bearing environment files.

## RCA investigations

An RCA migration error means the configured database has not received migration 004: back up and run `python -m cnc_ai db migrate`. A missing `cnc_ai` import means the active smartfactoryllm interpreter needs this project installed; run `python -m pip install -e .` from its root and `python -c "import cnc_ai; print(cnc_ai.__file__)"`.

“Comparison mapping incomplete” is a capability limit, not an inference connection failure. Native v11 history lacks qualified shift/revision/mix semantics; configure the read-only export described in `rca/DEVELOPER_GUIDE.md`. A missing family is an unavailable source, not negative evidence. Wrong timezone or an incomplete shift needs corrected scope. An unavailable planner leaves its check failed; verify the existing code service without downloading another model.

A training selector is disabled unless RCA demo, development profile and demo model mode are all enabled. Do not relabel demo files as factory history. After a crash stop the old worker, run `python -m cnc_ai rca recover --user admin`, inspect the saved case and start a revision. Repeated permission errors should be resolved by an authorized administrator, not by changing case ownership in SQL.

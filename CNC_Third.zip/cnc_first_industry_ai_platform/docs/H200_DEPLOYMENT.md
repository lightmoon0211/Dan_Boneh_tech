# Legacy accelerator deployment

This filename is retained for old bookmarks. It does not describe the v11.2 default. Historical instructions are [archived here](history/v111/H200_DEPLOYMENT.md). Use [Server installation](SERVER_INSTALLATION.md) and [Hardware](HARDWARE.md) for the two four-GPU RTX nodes plus CPU application server.

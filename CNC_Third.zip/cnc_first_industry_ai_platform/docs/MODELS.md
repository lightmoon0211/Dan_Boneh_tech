# Local model services

[Model compatibility](MODEL_COMPATIBILITY.md) records the five preserved models, immutable revisions, licenses, BF16 sizing, runtime candidate and unresolved hardware gates. [Server installation](SERVER_INSTALLATION.md) gives download, verification and per-instance serving commands. Twelve instances reuse five physical model snapshots on two hosts. Weights stay outside Git.

`download_factory_models.py all` downloads the five core snapshots, including reranker. Individual targets are conversation, code, safety, embedding and reranker. Downloads resume and retry; existing directories must pass snapshot verification before factory serving. Optional SQLCoder/Whisper remain disabled. `models.coder-next.json` is a retained alternative workstation registry; it is incompatible with the default factory manifest and must not silently replace the coder.

Factory distribution uses the manifest rather than old fallback URL lists. GPU indices are local to each host. Advertised models, functional readiness, draining and cooldown are different statuses. Only a successful contract probe for the pinned model/revision admits a replica. A failed inference is bounded and cannot replay business or machine writes.

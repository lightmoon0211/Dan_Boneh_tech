# Air-gapped deployment

Normal operation uses only local factory services and bundled browser assets. Public model downloads and dependency installation occur on connected staging, not the factory. Offline environment flags suppress common library downloads; enforce network egress policy and test actual behavior as well.

Prepare matching x86-64 Linux and Python 3.12 media. After qualifying the complete RTX serving installation, freeze it and create a transfer bundle outside both the source and weight trees:

```bash
conda activate smartfactorymodels
python -m pip list --format=freeze > /srv/staging/qualified-inference-lock.txt
conda activate smartfactoryllm
python scripts/prepare_airgap.py --output /srv/transfer --inference-lock /srv/staging/qualified-inference-lock.txt --model-root /srv/ai/models --copy-models
python scripts/verify_bundle.py /srv/transfer
```

Do not label an untested environment export as qualified. The helper creates an application wheelhouse, inference wheelhouse, source archive, checksums and optional copied snapshots. Optional historian/forecast/browser packages require their respective `--extra` selections; browser executables and OS libraries need separate staging. The core CPU profile uses in-process numerical analysis and does not require a public license service. Optional products may have different license obligations.

Prepare OS packages, an offline Python/Conda installer and its package cache, signed NVIDIA driver packages, the chosen GPU runtime, nginx/systemd dependencies, certificate chain, internal DNS/time configuration and a rollback copy of v11.1 plus its environment. Include signed container images and saved image digests only if using the app-only Docker alternative. Do not assume pip wheels contain OS drivers or that Linux and Windows wheels are interchangeable. Protect the transfer manifest and check every checksum at both ends.

On each inference host, copy complete models to local read-only storage, retain `.factory-downloads` metadata, verify all hashes and the pinned manifest, provision separate writable caches, and install its generated systemd/nginx files. On the CPU host, install the application from its wheelhouse using `--no-index`, initialize or migrate the database explicitly, and use the generated protected app environment. Provision secrets and certificates separately; do not embed them in the source ZIP.

Configure the firewall to permit browser-to-CPU HTTPS, CPU-to-inference TLS ports, approved management, and internal DNS/NTP only where needed. Inference nodes must not reach controller networks or public internet. Restrict the OPC UA path to the commissioned CPU service account and approved controller endpoints. Do not disable TLS validation.

Perform a cold reboot with external egress blocked. Capture firewall counters/packet records for attempted public destinations while starting services, signing in, ingesting an approved document, answering a cited question, producing a report and running an RCA. Verify all twelve model instances and the expected cache paths. A synthetic application egress test is included, but the actual factory/network/GPU cold start was not run here.

Keep the old code/environment, model revisions and a consistent pre-upgrade database/document/configuration backup for rollback. Follow `MIGRATION_V111_TO_V112.md`; do not automatically replay jobs or machine writes after recovery.


The version export uses `pip list --format=freeze` so the application wheel does not become an absolute staging-only file URL in the offline lock. Retain original custom CUDA/serving wheels alongside their provenance and checksums. If a qualified package is not available on the configured index, set `PIP_FIND_LINKS` to that reviewed local wheel cache before running prepare_airgap.py; do not silently substitute another build. The transfer helper must finish successfully and verify every file. On each inference host, create the matching offline interpreter and install with:

```bash
conda create -n smartfactorymodels python=3.12 pip --offline
conda activate smartfactorymodels
python -m pip install --no-index --find-links /srv/transfer/inference-wheelhouse --find-links /srv/transfer/app-wheelhouse -r /srv/transfer/inference-lock.txt
python -m pip check
```

An offline Conda creation also requires its separately staged interpreter/package cache. Keep those OS/interpreter assets outside the source ZIP. Never install a CPU environment's constraint file over the qualified GPU serving environment.

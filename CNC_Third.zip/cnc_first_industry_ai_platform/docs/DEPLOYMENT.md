# Factory deployment

The v11.2 default uses two four-GPU RTX PRO 6000 Blackwell Server Edition inference nodes and one CPU application/data server. Use [Server installation](SERVER_INSTALLATION.md), [Hardware](HARDWARE.md), [Air gap transfer](AIR_GAP_DEPLOYMENT.md) and [Operations](OPERATIONS.md). `config/deployment.json` is authoritative. Generated per-host systemd and TLS proxy files are under `deployment/generated/`. Docker supports the CPU application only.

Older accelerator instructions are retained under `history/v111/`; they are not this release's default or qualification evidence.

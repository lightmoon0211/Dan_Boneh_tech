# v11 repository review

Historical earlier-rebuild review retained for traceability. For current v11.2 implementation and tested deployment use [SOURCE_AUDIT.md](v112/SOURCE_AUDIT.md), [VALIDATION.md](VALIDATION.md) and [SERVER_INSTALLATION.md](SERVER_INSTALLATION.md). Older limits/placements below are not current defaults.

The complete 241-file v10 deployment archive was verified against its SHA-256 manifest and inspected before this rebuild. `v10_repository_inventory.json` retains the file hashes. The earlier 134-member v9 audit remains in `v9_repository_audit.json` for history.

The review covered the package, resources and migrations; model routing and serving; download resume/verification; configuration and Windows/Linux startup; database/RAG/evidence; typed controller authority and approvals; numerical and planning services; authentication and UI; tests; deployment and manuals. Existing useful functions were preserved. The v10 control implementation and applied SQL migrations remain byte-identical; this release adds specialist draft generation and evidence-record validation without expanding machine-write authority.

All fifteen newly proposed model candidates have an explicit decision in MODEL_SELECTION.md. SQLCoder and Whisper are optional, use independent local services and cannot grant database or controller permissions. The default coder uses the requested Qwen3-Coder-30B-A3B-Instruct; the old Coder-Next profile and existing downloads remain available. Factory-preparation templates cover all twenty topics in the supplied guide.

The final pass corrected old Windows environment names and centralized numerical-service, benchmark and evidence software-version metadata on the package version. Historical seed-source labels remain unchanged so migration remains idempotent. The source package and final installed wheel were checked against each other. VALIDATION.md separates software, mock/loopback and physical-site acceptance. MIGRATION_V10_TO_V11.md explains configuration and runtime reuse.

# Operations and recovery

Use a named administrator and preserve the release, runtime/configuration backup, dependency locks, model manifests and site evidence. Logs and backups contain sensitive operational records; restrict permissions and use encrypted independent backup storage with tested restoration.

## Inference maintenance

Drain the node from the authenticated CPU API before stopping services. Sign in through a site-trusted browser or a session-aware HTTP client, obtain its CSRF token, and send `POST /api/inference/nodes/ai-a/drain` with `{"draining":true}` and `X-CSRF-Token`. This endpoint requires `settings.manage`; it is not an unauthenticated model-host command. Inspect `GET /api/status` until that node's in-flight counts reach zero. Drain state is process-local; keep the app running during node maintenance. After an app restart, drain again before continuing maintenance.

On the drained node:

```bash
sudo /opt/conda/envs/smartfactorymodels/bin/python scripts/deployment/manage.py stop --host ai-a --manifest /etc/cnc-ai/deployment.json
sudo /opt/conda/envs/smartfactorymodels/bin/python scripts/deployment/manage.py start --host ai-a --manifest /etc/cnc-ai/deployment.json
```

Use `ai-b` for B. To restart only the reranker, use `sudo systemctl restart cnc-model-ai-a-reranker`. Inspect its own journal. Restore the node through the same drain API with `{"draining":false}`. Recovery clears readiness and requires fresh identity/inference probes. Do not assume the remaining host will maintain the same latency while its peer is unavailable.

## Application maintenance and backup

Tell users maintenance is starting and allow jobs to finish where possible. Stop the single app authority and telemetry recorder. Cancelled/interrupted jobs are not automatically replayed after restart. A snapshot of a running application folder is not a consistent multi-file backup.

```bash
sudo systemctl stop cnc-ai cnc-telemetry
sudo -u cncai /opt/conda/envs/smartfactoryllm/bin/python scripts/deployment/backup.py create --data /var/lib/cnc-ai --config /etc/cnc-ai --destination /srv/backup/cnc-2026-09-10
python scripts/deployment/backup.py verify --source /srv/backup/cnc-2026-09-10
```

The backup tool acquires the application/recorder authority locks, uses SQLite's backup interface for database files, copies document/source/configuration files, and verifies hashes. It refuses existing backup destinations. Give the backup account access only to a protected destination. If other site writers exist, stop/fence them too; a Python lock cannot fence another physical server or an unrelated external tool.

Restore only to a new empty location on a stopped, fenced target:

```bash
python scripts/deployment/backup.py restore --source /srv/backup/cnc-2026-09-10 --destination /srv/restore/cnc-2026-09-10
```

Review `data/` and `configuration/`, restore correct OS ownership, set the new environment paths, and keep writes disabled. Prove the old authority cannot operate, verify the audit chain/migrations, and reconcile controller state before enabling the recovered authority. Never start two authorities against shared SQLite, and never replay a proposal simply because a backup predates its result. Inference resilience is not automatic stateful application failover.

## Capacity and retention

Back up both authoritative data and separately retained historical mappings. Suggested usable capacity begins at 12–24 TB, then calculate: retained full backups + retained daily changes + document/history growth + model rollback generations when stored there + at least 20% working headroom. For example, two 3 TB full backups plus thirty 100 GB daily change sets use 9 TB before headroom; a 25% reserve raises this to 11.25 TB. This is a sizing example, not measured factory growth. RAID 1 survives some drive failures; it does not protect against deletion, corruption, ransomware or a site loss.

# CNC authority and safety boundaries

Granite Guardian is a secondary risk/policy judge. It is not a CNC authority or safety PLC. An LLM can generate only a strict ControlRequest; it cannot supply arbitrary OPC UA nodes, operator identities, policy changes or write code.

The deterministic order is: running/appropriate state and machine identity; selected tool assembly rating; tool/material/workpiece compatibility; machine/process/program envelope and step limits; authenticated operator permission; separate supervisor approval requirement; healthy interlocks and fresh typed telemetry; only then the typed write. Later checks are visibly skipped after a failure. The active program qualification and observed context are bound to the proposal.

A separate supervisor reviews a persistent proposal. The requester then confirms execution. All policy/context/identity/permission/approval checks run again immediately before the adapter. A consumed proposal cannot replay. A changed program/tool/recipe or expired/changed policy blocks execution. Unknown write/readback outcomes lock further writes, including after restart, until authorized physical reconciliation.

Native CNC/PLC enforcement must handle the real-time gap between read and write. Application checks cannot replace interlocks or guarantee atomic physical state. Real mappings, signed/encrypted OPC UA identity, pinned server certificate, commissioned policy and explicit site/write flags are required. See CONTROL_COMMISSIONING.md.

Generated SQL is read-only for every role and validated twice: AST rules plus database authorizer. Generated NC/Python/robot text is never executed. Numerical forecasts, image analysis, RAG evidence and learned scores cannot authorize machinery. Inference replica retry never retries a controller write. Protect one active authority with site fencing and external audit anchors.

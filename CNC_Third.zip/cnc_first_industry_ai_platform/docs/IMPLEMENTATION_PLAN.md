# v11 implementation decisions

Historical earlier-rebuild review retained for traceability. For current v11.2 implementation and tested deployment use [SOURCE_AUDIT.md](v112/SOURCE_AUDIT.md), [VALIDATION.md](VALIDATION.md) and [SERVER_INSTALLATION.md](SERVER_INSTALLATION.md). Older limits/placements below are not current defaults.

The v11 release preserves the numerical, historian, control and RAG features below. It reviews all fifteen requested models, changes the default coder, adds optional SQLCoder and reviewed Whisper drafts, and maps the supplied preparation guide to twelve evidence gates. See MODEL_SELECTION.md, FACTORY_PREPARATION.md and MIGRATION_V10_TO_V11.md. Final verification is recorded in VALIDATION.md.

## Preserved v10 rebuild decisions

The complete 134-member v9 archive was read, hashed against its release manifest and inspected before this working copy was changed. See `v9_repository_audit.json`. The package, transactional control authority, role checks, SQL engine authorization, local UI and offline tools remain the base.

1. Add an independent Pydantic/Flask numerical service on 8100. Development can run the same engine in-process. Add explicit reference windows, timestamp/quality/unit checks, statistical and spectral preprocessing, pluggable forecasters and trained-component model contracts.
2. Add a normalized historian interface with SQLite, PostgreSQL/TimescaleDB, ClickHouse and read-only HTTP historian/MTConnect inputs. Keep the transactional controller authority separate from high-frequency history.
3. Extend the CNC digital thread and expose bounded, cited semantic relationships. Add numerical planning and physics checks, with explicit unimplemented collision-simulation gates for generated code.
4. Add approved document revisions, configurable fusion/reranking, Qwen3-Reranker-0.6B, bounded multimodal evidence and stateful agent traces. Keep retrieved text out of policy and control tool definitions.
5. Add replica routing and safe degradation; use reviewed active/passive authority with external fencing rather than copying a live SQLite database across active servers. Provide target-specific deployment gates.
6. Build reproducible CNCBench datasets, rolling-origin forecasting evaluation, detection/retrieval metrics and adversarial end-to-end tests. Distinguish measured statistical baselines from neural models requiring local weights and hardware.
7. Update and render the manual, verify source/wheel/offline workflows and package a clean v10 release.

Research choices and evidence are recorded in `STATE_OF_THE_ART_2026.md`. A published benchmark result is not a CNC-site acceptance result. Optional services must never prevent simulator development startup.

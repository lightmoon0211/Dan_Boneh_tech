# Hardware and purchasing checklist

The target has three server computers: two inference nodes, one CPU application/data server, and independent backup infrastructure. Fifty browser computers are clients. Existing qualified servers/storage may supply the CPU and backup roles. A single working computer with four GPUs would not provide the requested node resilience.

## Inference servers

The preferred reference is **two Supermicro SYS-212GB-FNR** systems, each vendor-configured for four **NVIDIA RTX PRO 6000 Blackwell Server Edition 96 GB** cards. The manufacturer's page lists four double-width GPUs, PCIe 5.0 x16 CPU links, four rear E1.S bays, two M.2 slots, five heavy-duty fans, two 2700 W supplies, and 900 mm chassis depth. RHEL 10.0 appears in its OS list. Obtain written qualification of the exact ordered configuration. [Supermicro system specification](https://www.supermicro.com/en/products/system/gpu/2u/sys-212gb-fnr).

| Item per inference node | Requested starting configuration | Vendor confirmation required |
|---|---|---|
| GPU | Four Server Edition cards, 96 GB each | Exact board SKU, risers, cables, firmware, power cap and thermal qualification |
| CPU | About 32 physical cores | Supported socket/SKU, lanes and cooling within chassis limits |
| System RAM | 512 GB ECC | Qualified modules, channel population and speed |
| Boot storage | Two approximately 1 TB enterprise SSDs, mirrored | Supported M.2 form factor and mirror implementation |
| Model/data storage | Two approximately 7.68 TB enterprise NVMe drives, mirrored | **E1.S** drive/backplane compatibility; no assumed U.2 interchangeability |
| Network | Dual-port 10 Gb Ethernet plus management | NIC/riser compatibility, optics/DAC or copper, switch support |
| Power | Redundant supplies at approved site voltage | Surviving capacity covers the whole configured server |
| Support | Three years for the complete system | Response time, on-site parts, GPU coverage and installation scope |

Each node has 384 GB of aggregate GPU memory, but four separate 96 GB memory spaces. Across both nodes the aggregate is 768 GB; a model cannot treat it as a single automatic pool. The Server Edition specification provides configurable power up to 600 W and ECC GDDR7; this software does not set a power limit. [NVIDIA product specification](https://www.nvidia.com/en-us/data-center/rtx-pro-6000-blackwell-server-edition/).

A mirror of two 7.68 TB drives provides approximately 7.68 TB usable before formatting and reserve space. Two 1 TB boot drives similarly provide roughly 1 TB. “Boot” describes what the drive does; NVMe describes how a drive communicates. M.2, E1.S and U.2 describe different physical arrangements. They are not interchangeable without a qualified backplane/cabling design.

Four GPUs at 600 W would consume 2400 W before the CPU, memory, drives, NIC and fans. Thus one 2700 W supply cannot be assumed to cover that entire configuration with adequate margin. The vendor must calculate the surviving supply capacity and derating at the proposed GPU caps, operating temperature and input voltage. Do not apply 600 W automatically or infer full redundancy simply from two PSUs.

This design uses independent TP1 replicas over ordinary Ethernet. It does not require an NVLink bridge, NVSwitch, InfiniBand or RDMA. The chassis's optional bridge statement is not RTX PRO GPU qualification. GPU-specific NVLink capability was not established by the reviewed sources; require vendor confirmation in the final bill of materials. This deployment does not use a bridge. No tested software path here depends on GPU peer links.

## CPU host, backup and site equipment

Start the CPU authority at approximately 16–24 physical cores, 128 GB ECC RAM and 4 TB usable mirrored enterprise storage, with 10 Gb Ethernet. These are sizing recommendations, not measured requirements. It runs the web application, bounded jobs, SQLite, documents and numerical computation; no AI GPU is required. Measure ingestion CPU use, concurrent query latency and historian growth before final purchase.

Independent backup starts at an estimated 12–24 TB usable. Use the retention formula and worked example in `OPERATIONS.md`. Include at least one recovery copy outside the production failure domain. Mirroring is not a backup.

Provide a rack with enough usable depth for a 900 mm chassis plus rails/cables, verified floor/rack loading, appropriate branch circuits, protected A/B power feeds where required, sized UPS runtime, compatible PDUs, qualified airflow and room cooling. Include NICs, transceivers/DACs, patch cables, switches, management access, internal DNS, NTP, certificates and secure media transfer. A common switch, UPS or room can still be a shared failure point. Measure total input watts and cooling at the actual approved configuration.

## Budget worksheet dated 10 September 2026

The figures below are **planning allowances in USD, not sourced vendor quotations**. Obtain an itemized regional quote, taxes, lead times, installation and whole-system support. These allowances avoid presenting a bare chassis price as a complete server price.

| Item | Quantity | Allowance per item | Extended allowance |
|---|---:|---:|---:|
| Server Edition 96 GB GPUs | 8 | $12,000–$18,000 | $96,000–$144,000 |
| Qualified GPU host platform excluding GPUs, including CPU/RAM/drives/NIC | 2 | $18,000–$30,000 | $36,000–$60,000 |
| CPU application/data server | 1 | $8,000–$15,000 | $8,000–$15,000 |
| Independent backup equipment/storage | 1 | $5,000–$12,000 | $5,000–$12,000 |
| Network/rack/power/cooling allowance | 1 | $10,000–$25,000 | $10,000–$25,000 |
| Installation and three-year whole-system support allowance | 1 | $10,000–$25,000 | $10,000–$25,000 |
| Total planning range | | | **$165,000–$281,000** |

The two populated GPU servers alone account for $132,000–$204,000 of this worksheet before the separately listed support/site work. Do not add a quoted fully populated server price to these GPU component allowances; that would double-count GPUs. Existing site facilities may reduce incremental cost. Currency, taxes and country-specific availability are not established by this worksheet.

# Air-gap deployment

Use the current [AIR_GAP_DEPLOYMENT.md](AIR_GAP_DEPLOYMENT.md) procedure.

# Designing a CNC factory database

## Start with the meaning of a row

A schema works when each row has one clear meaning. One machine row identifies one physical machine. One work-order row identifies one requested product quantity. One operation row identifies one scheduled routing step on a machine. One production run row records one execution interval for that operation. One sensor-reading row records one sensor at one timestamp. Combining these meanings into one wide spreadsheet causes duplicated quantities and misleading totals.

Separate identity, configuration and observations. Machine master data changes slowly; machine-state history changes every observation. A tool's catalog rating is different from the tool currently installed in a machine and different again from a timestamped wear reading. A retrieved document is evidence; the commissioned policy is a reviewed control decision. The assistant should not infer these distinctions from vague column names.

## Keys and relationships

| Design choice | CNC example | Reason |
|---|---|---|
| Stable primary key | `machine_id` identifies the machine row | Relationships remain valid if a display name changes. |
| Unique business key | `machine_code = CNC-01` | Operators recognize the physical asset; duplicates are rejected. |
| Foreign key | `production_runs.machine_id → machines.machine_id` | A run cannot refer to a nonexistent machine. |
| Association table | tool/material compatibility | Many tools can cut many materials under different approved recipes. |
| Composite uniqueness | sensor + source time/sequence | Distinguishes separate observations and supports deduplication. |
| Unit-bearing column | `cycle_seconds`, `diameter_mm`, `maximum_rpm` | Prevents seconds/minutes or speed/override confusion. |
| Revision and provenance | policy revision, file hash, source location | Allows reconstruction of what was approved or consulted. |

Use foreign keys for relationships rather than repeating machine names. Keep codes and names separate. Avoid putting comma-separated tool lists or entire production schedules in a normal relational column. JSON is appropriate for a versioned event/proposal snapshot or raw typed telemetry envelope; it is less useful as the sole representation of core work-order relationships.

```mermaid
erDiagram
    MACHINES ||--o{ WORK_ORDER_OPERATIONS : assigned_to
    WORK_ORDERS ||--o{ WORK_ORDER_OPERATIONS : contains
    ROUTING_OPERATIONS ||--o{ WORK_ORDER_OPERATIONS : defines
    WORK_ORDER_OPERATIONS ||--o{ PRODUCTION_RUNS : executed_as
    MACHINES ||--o{ MACHINE_SENSORS : has
    MACHINE_SENSORS ||--o{ SENSOR_READINGS : observes
    CUTTING_TOOLS ||--o{ TOOL_ASSIGNMENTS : installed_as
    MACHINES ||--o{ TOOL_ASSIGNMENTS : receives
```

The diagram shows row relationships, not a command sequence. A work order may contain many operations; each operation may have multiple runs. Summing the output of every routing stage can count the same physical part several times. The provided work-order output view therefore uses the final routing operation.

## Three useful schema styles

Use normalized relational tables for operational records with keys, constraints and transactions. This is the default CNC implementation. Use an analytical star schema or curated views when business users need stable measures such as good quantity, downtime minutes and OEE by machine/day/shift. Define the measure's grain before joining facts. Use immutable event/snapshot records for audit, controller observations and evidence; include source and receive times so late arrivals can be understood.

These styles can coexist. Do not replace the normalized factory authority with an unreviewed uploaded analytics database. The application can query an approved read-only export without allowing it to alter control permissions or recipes.

## Telemetry and machine-state history

Record asset identity, sensor identity, unit, source timestamp, receive timestamp, status quality, value and source sequence where available. Store UTC or an unambiguous timezone-aware representation. Retain the difference between the time the controller measured a value and the time the application received it. A newly received packet can still contain an old measurement.

Model state transitions separately from high-frequency sensor samples. Include interval boundaries for downtime; decide how open intervals and overlapping events affect reports. Do not count the same minute twice when calculating downtime. Distinguish planned stops from unplanned downtime using the site's KPI definition.

The supplied monitor records full typed controller snapshots and, when a machine code is registered, machine-state history. It never supplies old historian rows to the write preflight. Control snapshots are read afresh through the adapter. A `GOOD` status describes the source quality at observation time, not an evergreen machine-ready flag.

Index common filters such as sensor/time, machine/time, work-order status/planned end and pending proposal/expiry. Measure actual query plans and row growth. Keep the authoritative SQLite files on one local host. A high-rate historian with many writers requires a separately designed storage/ingestion system; GPU capacity does not solve write contention.

## Tools, materials and workpieces

A tool catalog row identifies the tool. A tool-limit row records rated spindle/holder limits with an approval revision. Compatibility links the tool and material to a process range. A workpiece links material, work order, fixture and recipe revision. Tool assignment identifies the installed tool/pocket at a time; historical assignments should not be confused with currently observed controller context.

Commissioned spindle policy must represent the weakest applicable assembly/recipe limit, including holder and fixture restrictions. A tool catalog's maximum RPM alone does not prove that a workpiece can be cut at that speed. The deployed policy uses observed tool/material/workpiece binding and reviewed recipes; external documents or model-generated SQL never edit it automatically.

## Maintenance and quality

Keep maintenance plans separate from maintenance work orders and completed actions. A plan has recurrence/due information; a work order records an actual issue, technician, dates, root cause and action. Join downtime through machine and time deliberately rather than assuming every stop is maintenance.

A quality characteristic defines nominal and specification limits in a stated unit. An inspection records a particular measured value/sample and result. A nonconformance records affected quantity, defect, disposition and closure state. Distinguish inspected sample size from total production quantity when reporting defect rates. Preserve corrected measurements and audit their correction rather than silently erasing evidence.

## Evidence, approvals and audit

Documents have content hashes and revisions; chunks have exact source locators. Answers cite immutable snapshots of retrieved chunks or actual database query results. A database citation includes parameters and capture time, so an answer can be reviewed after underlying records change.

Control proposals contain requested action, requester, policy hash, bound machine context and expiry. Approvals identify a separate authenticated reviewer. Executions record write intent, attempt mode, result/readback and uncertainty. These records must remain separate from a free-text chat transcript; they represent different authority and retention needs.

Audit events are appended transactionally alongside mutations and chained by SHA256. Protect an external chain head or archive to strengthen tamper evidence. User passwords/session tokens must never be exposed to generated analytical SQL. The delivered query allowlist excludes those tables.

## Numeric examples for planning and management

All figures below are fictional teaching examples, not predictions for a real CNC operation.

| Question | Explicit calculation | Interpretation |
|---|---|---|
| How many parts fit in this shift? | 420 available minutes − 30 setup = 390 production minutes. At 2 minutes/part, 390 ÷ 2 = 195 parts. | This assumes no other downtime, scrap, labor or material constraint. Add those before promising output. |
| Is the order at risk? | 60 remaining parts × 2 minutes = 120; plus 30 setup and 20 buffer = 170 minutes. Only 150 minutes remain, a 20-minute shortage. | Flag a risk and compare feasible alternatives; do not automatically reschedule the floor. |
| Is material sufficient? | 120 kg on hand − 30 kg reserved = 90 kg available. 40 parts × 2.5 kg = 100 kg required; shortage = 10 kg. | This simplified estimate excludes scrap allowance and purchasing lead time. |
| What is the inspection defect rate? | 5 rejected observations ÷ 200 inspected observations = 2.5%. | It is an inspection-sample result, not necessarily the defect rate for all production. |
| What is OEE? | Availability 0.90 × performance 0.80 × quality 0.99 = 0.7128, or 71.28%. | Use the site's definitions, ideal cycle and comparable time window. Do not average unrelated percentages blindly. |
| Which serial process is the bottleneck? | At 2, 3 and 1 minute/part, three stages have ideal rates of 30, 20 and 60 parts/hour. | The 3-minute stage limits a balanced serial flow to 20/hour before other constraints. |

A production-risk answer should identify the time window, source rows, remaining quantity, setup/cycle assumptions, available minutes, material/tool constraints and suggested options. A downtime answer should identify category, duration and overlap handling. A shift summary should separate measured production/quality/material facts, reported maintenance issues and proposed next actions.

Example questions to practice:

- “For CNC machines in the sample week, list planned work-order end dates and final good quantities.”
- “Which material codes have the lowest available stock after reservations? Show source rows.”
- “Compare unplanned downtime by machine for one stated shift, without counting overlapping minutes twice.”
- “Which maintenance work orders remain open and which machines do they affect?”
- “Show tool usage and rated limits separately; do not infer current installed tooling from old assignments.”
- “Summarize this shift report into completed work, risks, evidence gaps and next actions.”

## Replacing or extending the domain

First write the new domain's row meanings, stable keys, units and relationships. Create a separate reviewed schema using the supplied examples, load realistic sample rows and approve a narrow analytical allowlist. Add a domain profile and sector-tagged documents. Test questions and expected cited answers with known data.

Changing schema names alone does not create a railway, food or robot-control safety system. New sectors need their own domain semantics, applicable procedures and typed control policy if control is added. Keep identity, evidence, approval and audit services shared while replacing the domain tables and adapters deliberately.

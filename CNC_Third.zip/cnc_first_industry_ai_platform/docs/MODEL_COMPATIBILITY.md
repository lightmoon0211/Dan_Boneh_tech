# Model and Blackwell compatibility review

Review date: 10 September 2026. Public model identities and available metadata were checked against publisher repositories. No full weight snapshot or physical RTX server was available in this execution environment. The packaged manifest therefore keeps `snapshot_verified=false`; serving is blocked until the local complete-snapshot verification succeeds. Public availability, dependency metadata and software tests are not model/GPU qualification.

| Role | Preserved model | Reviewed immutable revision |
|---|---|---|
| Conversation/report | Qwen/Qwen3.8-27B | 1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0 |
| Code/planner/proposals | Qwen/Qwen3-Coder-30B-A3B-Instruct | b2cff646eb4bb1d68355c01b18ae02e7cf42d120 |
| Secondary risk judge | ibm-granite/granite-guardian-4.1-8b | ab01ccca5dcfb80246369a086a4a87a29198f5af |
| Embedding | Qwen/Qwen3-Embedding-4B | 5cf2132abc99cad020ac570b19d031efec650f2b |
| Reranking | Qwen/Qwen3-Reranker-0.6B | e61197ed45024b0ed8a2d74b80b4d909f1255473 |

The publisher repositories label the five core models Apache 2.0. Retain the actual license/model card at the selected commit in the staged snapshots and have the site review use/distribution terms. The optional SQLCoder model has separate upstream licensing obligations and is disabled; Whisper is also optional. The original fifteen-candidate review remains in `MODEL_SELECTION.md` and is historical selection evidence, not a benchmark of newly enabled models.

The conversation model is a dense vision-language model using a Qwen3.5-family hybrid architecture. Its documented recipe requires Transformers at least 5.8.0. The application disables thinking/history thinking and defaults vision off; its startup disables image/video prompts unless a separately qualified vision setting is enabled. About 54 GB is a raw 27-billion-parameter BF16 estimate; the reviewed repository lists about 55.6 GB of artifacts. This does not include request caches or runtime memory. [Publisher model card](https://huggingface.co/Qwen/Qwen3.8-27B), [vLLM recipe](https://recipes.vllm.ai/Qwen/Qwen3.8-27B).

The coder has 30.5 billion total parameters and about 3.3 billion active parameters. BF16 parameter storage is approximately 61 GB using total parameters, before caches/buffers; do not size it as a 3.3B dense model. The application requests strict structured outputs and never executes generated NC/Python/robot programs. [Qwen coder model card](https://huggingface.co/Qwen/Qwen3-Coder-30B-A3B-Instruct).

Guardian is used only in its documented yes/no scoring format with custom factory risk criteria. It is not a generic conversation model and cannot authorize machine writes. The parser requires a valid score and fails closed on malformed output. Its roughly 16.8 GB repository still needs runtime/KV headroom. [IBM model card and scoring instructions](https://huggingface.co/ibm-granite/granite-guardian-4.1-8b).

Embeddings retain 1024 output dimensions and a fingerprint containing model/revision/dimensions. A revision change requires rebuilding vectors; incompatible vectors are not mixed. Reranking uses the Qwen sequence-classification override and supplied template at the root `/score` endpoint, with validated indices/scores. Approximate raw BF16 parameter sizes are 8 GB and 1.2 GB respectively. [Embedding publisher](https://huggingface.co/Qwen/Qwen3-Embedding-4B), [reranker publisher](https://huggingface.co/Qwen/Qwen3-Reranker-0.6B).

## Candidate runtime and unresolved gates

The candidate is x86-64 RHEL 10.0, Python 3.12, a vendor-approved R595-or-newer NVIDIA driver, PyTorch 2.13.0 with CUDA 13.0, Transformers at least 5.8 and vLLM 0.28.0. PyTorch publishes a CUDA 13.0 build for 2.13.0. The vLLM package metadata selects Torch 2.13.0; its exact wheel/kernel/CUDA combination still needs a matching-GPU installation. Install compatible builds together, run `pip check`, record the resolved libraries, and reject a CPU-only Torch build. Do not blindly replace the CUDA libraries supplied by the chosen serving build. [PyTorch installation versions](https://pytorch.org/get-started/previous-versions/), [vLLM 0.28.0 release](https://pypi.org/project/vllm/0.28.0/), [NVIDIA runtime/driver notes](https://docs.nvidia.com/cuda/cuda-toolkit-release-notes/index.html).

NVIDIA lists this Server Edition as compute capability 12.0 (`sm_120`). That differs from data-center accelerator compute capabilities. The preflight performs a BF16 device kernel check on all four GPUs; model probes must additionally exercise dense hybrid attention, MoE, Guardian scoring and pooling/reranking kernels. No claim that a different Blackwell platform's benchmark qualifies these cards is made. [NVIDIA compute capability table](https://developer.nvidia.com/cuda/gpus).

`requirements/rtx-blackwell-candidate.txt` is explicitly a candidate, not a qualified lock. Do not rename a previous accelerator requirements file as evidence. No full GPU dependency lock is fabricated. After successful physical tests, freeze the complete working environment, archive resolved package metadata and hardware/driver/power records, and repeat installation offline. The vLLM audio extra is not part of the core installation; optional Whisper requires separate dependency/runtime testing.

All factory instances initially use BF16 and TP1, a 32K total context limit for generation/Guardian, 8K for embeddings and 4K for reranking. Output tokens consume the same context budget. GPU 3 fractions 0.45/0.20/0.10 are per-process planning limits, not hard hardware partitions or a memory safety proof. Profile simultaneous startup, large batches, long review inputs and competing requests. Maintain headroom for weights, KV/recurrent caches, workspaces, CUDA graphs and image processing if later enabled. Do not reduce precision or bypass review to meet a latency target without a separately measured quality baseline.

# Migration from v9 to v10

The complete 134-file v9 ZIP was read and hashed before edits; docs/v9_repository_audit.json records that review. Useful package, UI, authentication, RAG, SQL, reports, complete business seed, sector administration and control workflows are preserved. No root-level db import is restored.

New migration 003 adds canonical historian observations, analysis records, controlled document revisions, program qualifications, material lots, production thread, nonconformances/components, semantic relations, agent runs/steps/model-call metrics and NC artifact attestations. The original 001/002 migrations remain byte-identical. Old document revisions require review; old pending/approved proposals are blocked because the new program/machine binding must be established.

Back up database/runtime/configuration consistently before upgrading. Keep the old environment while validating smartfactoryllm_v10. Extract beside the old project, point CNC_DATA_DIR to a working backup copy and run:

```bash
python -m cnc_ai db migrate
python -m cnc_ai db refresh-policy
python -m cnc_ai validate --offline
python -m cnc_ai audit-verify
```

Copy reviewed secret values into the new .env layout; do not overwrite site settings blindly. Review new application/timeseries/engineering/rag configuration and both-host model profiles. Set exact embedding revisions and rebuild vectors when changed. Approve controlled sources separately. Existing business data is not reseeded; a new --sample installation adds six telemetry-example CNC machines to the original twenty.

The original four models/ports are unchanged; all now adds the reranker. Statistical numerical analysis requires no extra weights. Optional Chronos/TimesFM/Moirai downloads are explicit. Reconcile current machine/program context and repeat commissioning before enabling real writes. Inference failover does not make SQLite multi-active. Preserve the prior release, model snapshots and tested rollback backup.

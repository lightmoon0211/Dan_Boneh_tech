#!/usr/bin/env python3
"""Validate the twelve preparation-guide site gates without changing the factory."""

import argparse
import json
from pathlib import Path
from cnc_ai.readiness import SiteReadiness, evaluate_readiness


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        manifest = SiteReadiness.model_validate_json(
            args.manifest.read_text(encoding="utf-8")
        )
        result = evaluate_readiness(manifest, args.manifest.parent)
        text = json.dumps(result, indent=2)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(text + "\n", encoding="utf-8")
        print(text)
        return 0 if result["status"] == "evidence_complete" else 2
    except (OSError, ValueError) as exc:
        parser.exit(2, "Readiness review failed: " + str(exc) + "\n")


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Build an offline transfer bundle on a matching connected staging host."""

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(*args):
    print("Running: " + " ".join(map(str, args)), flush=True)
    subprocess.run(list(map(str, args)), check=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument(
        "--inference-lock",
        type=Path,
        help="Freeze from the qualified RTX PRO 6000 Blackwell environment",
    )
    p.add_argument(
        "--model-root", type=Path, help="External model manifests/reference directory"
    )
    p.add_argument(
        "--copy-models",
        action="store_true",
        help="Explicitly copy large model directories",
    )
    p.add_argument(
        "--extra",
        action="append",
        choices=["historian", "forecast", "browser"],
        default=[],
        help="Include optional matching-platform dependency wheels",
    )
    args = p.parse_args()
    output = args.output.resolve()
    if output.is_relative_to(ROOT):
        p.error("Use a transfer directory outside the project.")
    if args.copy_models and not args.model_root:
        p.error("--copy-models requires --model-root")
    if args.model_root and (
        output.is_relative_to(args.model_root.resolve())
        or args.model_root.resolve().is_relative_to(output)
    ):
        p.error("Transfer output and model root must be separate trees.")
    output.mkdir(parents=True, exist_ok=True)
    wheels = output / "app-wheelhouse"
    wheels.mkdir(exist_ok=True)
    package = str(ROOT) + ("[" + ",".join(args.extra) + "]" if args.extra else "")
    run(sys.executable, "-m", "pip", "wheel", "--wheel-dir", wheels, package)
    run(
        sys.executable,
        "-m",
        "pip",
        "download",
        "--only-binary=:all:",
        "--dest",
        wheels,
        "setuptools>=77",
        "wheel",
        "pytest>=8,<10",
        "pytest-cov>=6,<8",
        "huggingface-hub>=1,<2",
    )
    if args.inference_lock:
        inference = output / "inference-wheelhouse"
        inference.mkdir(exist_ok=True)
        shutil.copy2(args.inference_lock, output / "inference-lock.txt")
        run(
            sys.executable,
            "-m",
            "pip",
            "download",
            "--only-binary=:all:",
            "--dest",
            inference,
            "-r",
            args.inference_lock,
        )
    with zipfile.ZipFile(output / "cnc-ai-source.zip", "w", zipfile.ZIP_DEFLATED) as z:
        source_manifest = {"project_version": "11.2.0", "files": {}}
        for f in sorted(ROOT.rglob("*")):
            rel = f.relative_to(ROOT)
            if (
                f.is_file()
                and not any(
                    x
                    in {
                        "runtime",
                        "__pycache__",
                        ".git",
                        ".pytest_cache",
                        ".ruff_cache",
                        "build",
                        "dist",
                        "packages",
                        "model_logs",
                    }
                    or x.endswith(".egg-info")
                    or x.startswith((".venv", ".tox"))
                    for x in rel.parts
                )
                and rel.parts[0] != "models"
                and not (ROOT / rel.parts[0] / "pyvenv.cfg").is_file()
                and rel.as_posix() != "SHA256SUMS.json"
                and not f.name.startswith(".coverage")
                and not f.name.endswith(("-wal", "-shm"))
                and (not f.name.startswith(".env") or f.name == ".env.example")
                and f.suffix
                not in {
                    ".pyc",
                    ".key",
                    ".pem",
                    ".bin",
                    ".safetensors",
                    ".gguf",
                    ".pt",
                    ".pth",
                    ".onnx",
                    ".ckpt",
                    ".crt",
                    ".der",
                }
            ):
                z.write(f, Path("cnc_first_industry_ai_platform") / rel)
                with f.open("rb") as stream:
                    sha = hashlib.file_digest(stream, "sha256").hexdigest()
                source_manifest["files"][rel.as_posix()] = {
                    "size": f.stat().st_size,
                    "sha256": sha,
                }
        z.writestr(
            "cnc_first_industry_ai_platform/SHA256SUMS.json",
            json.dumps(source_manifest, indent=2) + "\n",
        )
    if args.model_root:
        model_root = args.model_root.resolve()
        manifests = model_root / ".factory-downloads"
        if not manifests.is_dir():
            raise ValueError("Model root has no download manifests.")
        shutil.copytree(manifests, output / "model-manifests", dirs_exist_ok=True)
        (output / "model-reference.json").write_text(
            json.dumps(
                {
                    "original_model_root": str(model_root),
                    "mode": "copied" if args.copy_models else "external-reference",
                    "action": "Transfer verified model snapshots, metadata and manifests; preserve commit/hash identity.",
                },
                indent=2,
            )
        )
        if args.copy_models:
            shutil.copytree(
                model_root,
                output / "models",
                dirs_exist_ok=True,
                ignore=shutil.ignore_patterns(".factory-download.lock"),
            )
    (output / "INSTALL_OFFLINE.md").write_text("""# CNC v11 offline transfer

1. Verify SHA256SUMS.json using scripts/verify_bundle.py.
2. Extract cnc-ai-source.zip.
3. Create a clean Python 3.12 environment with an approved offline installer.
4. Install: python -m pip install --no-index --find-links app-wheelhouse cnc-first-ai
5. Follow docs/AIR_GAP_DEPLOYMENT.md for models, configuration, database and commissioning.
6. Provision site credentials and certificates separately. Optional browser binaries and OS/CUDA/driver packages are not pip wheels.
""")
    metadata = {
        "project_version": "11.2.0",
        "python": sys.version,
        "platform": sys.platform,
        "optional_extras": args.extra,
        "files": {},
    }
    for f in sorted(output.rglob("*")):
        if f.is_file() and f.name != "SHA256SUMS.json":
            with f.open("rb") as stream:
                checksum = hashlib.file_digest(stream, "sha256").hexdigest()
            metadata["files"][f.relative_to(output).as_posix()] = {
                "size": f.stat().st_size,
                "sha256": checksum,
            }
    (output / "SHA256SUMS.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(
        "Transfer bundle complete. Models remain external unless explicitly copied. Validate on matching factory hardware."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

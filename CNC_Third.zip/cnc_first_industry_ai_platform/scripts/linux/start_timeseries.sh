#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.."
exec python -m cnc_ai timeseries serve --host 127.0.0.1 --port 8100

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/../.."
exec python scripts/deployment/manage.py start --host "${1:?Usage: start_models.sh ai-a or ai-b}" --manifest "${CNC_DEPLOYMENT_MANIFEST:-config/deployment.json}"

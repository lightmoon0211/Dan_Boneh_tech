#!/usr/bin/env python3
"""Isolated authenticated HTTP workload. Synthetic measures app behavior, never GPU performance."""

import argparse, copy, http.cookiejar, json, os, platform, resource, secrets, shutil, tempfile, threading, time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib import request, error
from waitress import create_server
from cnc_ai.auth import Auth
from cnc_ai.config import Settings, RESOURCE_DIR
from cnc_ai.database import Database
from cnc_ai.distributor import Distributor
from cnc_ai.models import ModelRouter
from cnc_ai.web.app import create_app

ROOT = Path(__file__).resolve().parents[2]


class SyntheticTransport:
    def __init__(self, m, delay=0.005):
        self.manifest = m
        self.delay = delay
        self.disabled_host = None
        self.counts = Counter()
        self.lock = threading.Lock()

    def __call__(self, url, path, body, headers, timeout):
        i = next(
            i
            for i in self.manifest["instances"]
            if ":" + str(i["port"]) in url
            and self.manifest["hosts"][i["host"]]["hostname"] in url
        )
        if i["host"] == self.disabled_host:
            raise OSError("Synthetic node loss")
        model = self.manifest["models"][i["role"]]
        if path.endswith("models"):
            return {
                "data": [
                    {"id": model["id"]},
                    {"id": model["id"] + "@" + model["revision"]},
                ]
            }
        time.sleep(self.delay)
        with self.lock:
            self.counts[i["id"]] += 1
        if path == "embeddings":
            return {
                "data": [
                    {"index": idx, "embedding": [1.0] + [0.0] * 1023}
                    for idx, _ in enumerate(body["input"])
                ]
            }
        if path == "score":
            return {
                "data": [
                    {"index": idx, "score": 0.8}
                    for idx, _ in enumerate(body["documents"])
                ]
            }
        if path == "tokenize":
            return {"count": len(json.dumps(body)) // 4}
        schema = body.get("response_format", {}).get("json_schema", {}).get("name")
        prompts = json.dumps(body.get("messages", []))
        if i["role"] == "safety":
            content = "<score>no</score>"
        elif schema == "Readiness":
            content = '{"ready":true}'
        elif schema == "Plan":
            content = (
                json.dumps(
                    {
                        "mode": "data",
                        "queries": [
                            {
                                "label": "Machine count",
                                "sql": "SELECT COUNT(*) AS machine_count FROM machines",
                                "parameters": {},
                            }
                        ],
                    }
                )
                if "Count the machines" in prompts
                else json.dumps({"mode": "conversation"})
            )
        elif schema == "Answer":
            content = json.dumps(
                {
                    "answer": "Synthetic reviewed fixture answer: consult the recorded spindle procedure. This is evaluation data.",
                    "citations": ["source_1"] if "source_1" in prompts else [],
                    "suggestions": [],
                }
            )
            if "Summarize production" in prompts:
                data = json.loads(body["messages"][-1]["content"])
                content = json.dumps(
                    {
                        "answer": "Synthetic report summary for evaluation.",
                        "citations": [x["id"] for x in data],
                        "suggestions": [],
                    }
                )
        else:
            content = '{"selected":[]}'
        return {
            "choices": [{"finish_reason": "stop", "message": {"content": content}}],
            "usage": {
                "prompt_tokens": len(prompts) // 4,
                "completion_tokens": len(content) // 4,
            },
        }


class Client:
    def __init__(self, base):
        self.base = base
        self.csrf = ""
        self.opener = request.build_opener(
            request.ProxyHandler({}),
            request.HTTPCookieProcessor(http.cookiejar.CookieJar()),
        )

    def call(self, path, body=None):
        req = request.Request(
            self.base + path,
            data=json.dumps(body).encode() if body is not None else None,
            headers={
                "Content-Type": "application/json",
                "X-CSRF-Token": self.csrf,
                "Prefer": "respond-async",
            },
        )
        with self.opener.open(req, timeout=15) as r:
            return json.load(r)

    def upload(self, name, text):
        boundary = "cnc-evaluation-" + secrets.token_hex(8)
        body = (
            f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{name}"\r\nContent-Type: text/plain\r\n\r\n{text}\r\n--{boundary}--\r\n'
        ).encode()
        req = request.Request(
            self.base + "/api/documents",
            data=body,
            headers={
                "Content-Type": "multipart/form-data; boundary=" + boundary,
                "X-CSRF-Token": self.csrf,
                "Prefer": "respond-async",
            },
        )
        with self.opener.open(req, timeout=15) as r:
            return json.load(r)


def quantiles(xs):
    xs = sorted(xs)
    return {
        k: round(xs[min(len(xs) - 1, int((len(xs) - 1) * q))], 4) if xs else None
        for k, q in [("p50", 0.5), ("p95", 0.95), ("p99", 0.99)]
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--deny-public-egress", action="store_true")
    p.add_argument("--mode", choices=["synthetic", "models"], default="synthetic")
    p.add_argument("--clients", type=int, nargs="+", default=[5, 10, 25, 50])
    p.add_argument("--rounds", type=int, default=2)
    p.add_argument(
        "--duration",
        type=int,
        default=0,
        help="Minimum sustained seconds per phase; site recommendation 900.",
    )
    p.add_argument("--manifest", type=Path, default=ROOT / "config/deployment.json")
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--synthetic-delay-ms", type=float, default=5)
    a = p.parse_args()
    if any(n < 1 or n > 50 for n in a.clients):
        p.error("Use 1 to 50 clients.")
    egress = {"connections": 0, "blocked": []}
    if a.deny_public_egress:
        import sys, ipaddress

        def audit(event, args):
            if event == "socket.connect":
                address = args[1]
                if isinstance(address, tuple):
                    try:
                        allowed = ipaddress.ip_address(address[0]).is_loopback
                    except ValueError:
                        allowed = False
                    if not allowed:
                        egress["blocked"].append(str(address[0]))
                        raise PermissionError(
                            "Public egress blocked by evaluation hook."
                        )
                    egress["connections"] += 1

        sys.addaudithook(audit)
    start = time.time()
    records = []
    status_times = []
    errors = []
    with tempfile.TemporaryDirectory(prefix="cnc-load-") as tmp:
        root = Path(tmp)
        cfg = root / "config"
        shutil.copytree(ROOT / "config", cfg)
        settings = Settings(root, root / "runtime", cfg, model_mode="local")
        appconf = json.loads((cfg / "application.json").read_text())
        appconf["profiles"]["development"]["reranking"] = True
        (cfg / "application.json").write_text(json.dumps(appconf))
        m = json.loads(a.manifest.read_text())
        registry = settings.read("models.json")
        if a.mode == "synthetic":
            for role, model in m["models"].items():
                model.update(snapshot_verified=True)
                os.environ[registry["services"][role]["key_env"]] = (
                    "evaluation-synthetic-secret-not-for-production"
                )
        router = ModelRouter(settings)
        transport = (
            SyntheticTransport(m, a.synthetic_delay_ms / 1000)
            if a.mode == "synthetic"
            else None
        )
        router.distributor = (
            Distributor(m, registry, transport)
            if transport
            else Distributor(m, registry)
        )
        db = Database(settings)
        db.initialize(sample=True)
        auth = Auth(db)
        password = secrets.token_urlsafe(24)
        for n in range(max(a.clients)):
            auth.create_user(f"load{n:03}", password, "supervisor")
        app = create_app(settings, router=router)
        services = app.extensions["cnc"]
        jobs = services["jobs"]
        jobs.start()
        document = root / "spindle.txt"
        document.write_text(
            "Synthetic evaluation SOP: inspect spindle lubrication and use approved tool limits. No physical machine operation is permitted."
        )
        doc = services["rag"].ingest(document, auth.user("load000"))
        server = create_server(
            app, host="127.0.0.1", port=0, threads=16, connection_limit=128
        )
        thread = threading.Thread(target=server.run, daemon=True)
        thread.start()
        base = "http://127.0.0.1:" + str(server.effective_port)
        clients = []
        for n in range(max(a.clients)):
            client = Client(base)
            client.csrf = client.call(
                "/api/login", {"username": f"load{n:03}", "password": password}
            )["csrf"]
            clients.append(client)

        def request_work(n, phase, iteration, barrier):
            client = clients[n]
            barrier.wait()
            t = time.monotonic()
            kind = "chat"
            row = None
            question = ""
            try:
                st = time.monotonic()
                client.call("/api/status")
                status_times.append(time.monotonic() - st)
                if phase == "mixed" and n % 10 == 1:
                    kind = "ingest"
                    response = client.upload(
                        f"fixture-{n}-{iteration}.txt",
                        f"Synthetic spindle fixture {n} {iteration}. Inspect maintenance records; no control action.",
                    )
                elif phase == "mixed" and n % 10 == 2:
                    kind = "report"
                    response = client.call("/api/reports", {"document_id": doc["id"]})
                elif phase == "mixed" and n % 10 == 3:
                    kind = "rca"
                    response = client.call(
                        "/api/rca/investigations",
                        {
                            "question": "Why was CNC-03 production low on 2026-09-08?",
                            "intent": {
                                "entity_kind": "resource",
                                "entity": "CNC-03",
                                "topic": "production",
                                "date": "2026-09-08",
                                "shift": "day",
                                "baseline": "plan",
                            },
                        },
                    )
                    with db.connect() as c:
                        key = c.execute(
                            "SELECT id FROM application_jobs WHERE resource_id=?",
                            (response["id"],),
                        ).fetchone()[0]
                    response = {"job": {"id": key}}
                else:
                    question = (
                        "Count the machines in the factory."
                        if phase == "mixed" and n % 3 == 0
                        else "Explain the documented spindle maintenance procedure."
                    )
                    if phase == "long-8k":
                        question += " cnc" * (8192 - 32)
                    if phase == "long-32k":
                        question += " cnc" * (32768 - 32)
                    response = client.call("/api/chat", {"question": question})
                key = response["job"]["id"]
                deadline = time.monotonic() + 900
                while time.monotonic() < deadline:
                    row = client.call("/api/jobs/" + key)
                    if row["state"] not in ["queued", "running"]:
                        break
                    # Poll essential status while slow requests run.
                    st = time.monotonic()
                    client.call("/api/health")
                    status_times.append(time.monotonic() - st)
                    time.sleep(0.05)
                if not row or row["state"] != "completed":
                    raise RuntimeError(row["error"] if row else "deadline")
                result_mode = (
                    (row.get("result") or {}).get("mode", "completed")
                    if isinstance(row.get("result"), dict)
                    else "completed"
                )
                if result_mode == "blocked":
                    detail = row["result"].get("answer", "")
                    expected = (
                        phase == "long-32k"
                        and "context" in detail.lower()
                        and "truncat" in detail.lower()
                    )
                    errors.append(
                        {
                            "clients": count,
                            "phase": phase,
                            "kind": kind,
                            "error_type": "ReviewedRefusal",
                            "detail": "Context budget refusal"
                            if expected
                            else detail[:250]
                            if transport
                            else "Unexpected blocked answer; inspect isolated evaluation result",
                            "expected_context_boundary": expected,
                        }
                    )
                    return
                records.append(
                    {
                        "input_characters": len(question),
                        "output_characters": len(
                            json.dumps(row.get("result"), ensure_ascii=False)
                        ),
                        "request_id": key,
                        "clients": count,
                        "phase": phase,
                        "kind": kind,
                        "seconds": time.monotonic() - t,
                        "queue_wait": row["started_at"] - row["created_at"],
                        "first_reviewed_output_seconds": time.monotonic() - t,
                        "state": row["state"],
                    }
                )
            except Exception as exc:
                errors.append(
                    {
                        "clients": count,
                        "phase": phase,
                        "kind": kind,
                        "error_type": type(exc).__name__,
                        "detail": str(exc)[:160],
                        "expected_context_boundary": phase == "long-32k"
                        and "InputBudgetError" in str(exc),
                    }
                )

        try:
            for count in a.clients:
                for phase in ["burst", "mixed", "hotspot"]:
                    phase_start = time.monotonic()
                    iteration = 0
                    while (
                        iteration < a.rounds
                        or time.monotonic() - phase_start < a.duration
                    ):
                        barrier = threading.Barrier(count)
                        with ThreadPoolExecutor(max_workers=count) as executor:
                            list(
                                executor.map(
                                    lambda n: request_work(
                                        n, phase, iteration, barrier
                                    ),
                                    range(count),
                                )
                            )
                        iteration += 1
            # Long contexts are serialized; these are character fixtures, actual tokens measured at the serving gateway.
            count = 1
            for phase in ["long-8k", "long-32k"]:
                request_work(0, phase, 0, threading.Barrier(1))
            if transport:
                transport.disabled_host = "ai-a"
                count = max(a.clients)
                barrier = threading.Barrier(count)
                with ThreadPoolExecutor(max_workers=count) as executor:
                    list(
                        executor.map(
                            lambda n: request_work(n, "node-loss", 0, barrier),
                            range(count),
                        )
                    )
                transport.disabled_host = None
                router.distributor.drain("ai-a", False)
            with db.connect() as c:
                controller_writes = c.execute(
                    "SELECT count(*) FROM control_executions"
                ).fetchone()[0]
                role_calls = {
                    r[0]: r[1]
                    for r in c.execute(
                        "SELECT role,count(*) FROM model_calls GROUP BY role"
                    )
                }
            result = {
                "egress": egress,
                "egress_enforced": a.deny_public_egress,
                "mode": a.mode,
                "status": "PASS"
                if not [e for e in errors if not e.get("expected_context_boundary")]
                and controller_writes == 0
                else "FAIL",
                "hardware": platform.platform(),
                "python": platform.python_version(),
                "elapsed_seconds": time.time() - start,
                "clients": a.clients,
                "rounds": a.rounds,
                "minimum_sustained_seconds": a.duration,
                "completed": len(records),
                "errors": errors,
                "controller_writes": controller_writes,
                "latency_seconds": quantiles([r["seconds"] for r in records]),
                "queue_wait_seconds": quantiles([r["queue_wait"] for r in records]),
                "first_reviewed_output_seconds": quantiles(
                    [r["first_reviewed_output_seconds"] for r in records]
                ),
                "status_seconds": quantiles(status_times),
                "throughput_jobs_per_second": len(records) / (time.time() - start),
                "process_max_rss_kib": resource.getrusage(
                    resource.RUSAGE_SELF
                ).ru_maxrss,
                "role_calls": role_calls,
                "distribution": router.distributor.status(),
                "phase_results": {
                    phase: {
                        "count": len([r for r in records if r["phase"] == phase]),
                        "latency": quantiles(
                            [r["seconds"] for r in records if r["phase"] == phase]
                        ),
                    }
                    for phase in {r["phase"] for r in records}
                },
                "records": records,
                "models": {
                    role: dict(model, snapshot_verified=False) if transport else model
                    for role, model in m["models"].items()
                },
                "model_verification_scope": "Synthetic identity fixture; no physical snapshot verified"
                if transport
                else "Bound manifest; independently retain snapshot checksums",
                "precision": "synthetic" if transport else "bfloat16",
                "cache": "new isolated DB; reused role readiness cache; no application prompt cache",
                "gpu_power_caps": "NOT MEASURED"
                if transport
                else "Record nvidia-smi output separately",
                "limitations": "Synthetic transport does not measure model quality or GPU performance. Real mode still uses an isolated sample DB and cannot commission machinery.",
            }
            unexpected = [e for e in errors if not e.get("expected_context_boundary")]
            result["acceptance"] = {
                "targets": m["acceptance"],
                "unexpected_error_rate": len(unexpected)
                / max(1, len(records) + len(errors)),
                "status_p95_within_target": result["status_seconds"]["p95"]
                <= m["acceptance"]["synthetic_status_p95_seconds"],
                "GPU_latency_acceptance": "NOT RUN"
                if transport
                else "Assess phase latency and queue results against site targets",
            }
            if (
                not result["acceptance"]["status_p95_within_target"]
                or result["acceptance"]["unexpected_error_rate"]
                > m["acceptance"]["synthetic_error_rate_max"]
            ):
                result["status"] = "FAIL"
            a.output.parent.mkdir(parents=True, exist_ok=True)
            a.output.write_text(json.dumps(result, indent=2) + "\n")
            print(
                json.dumps(
                    {
                        k: result[k]
                        for k in [
                            "mode",
                            "status",
                            "completed",
                            "latency_seconds",
                            "status_seconds",
                            "errors",
                        ]
                    },
                    indent=2,
                )
            )
            return 0 if result["status"] == "PASS" else 1
        finally:
            server.close()
            jobs.close()
            services["rca"].close()


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Create a source deployment ZIP with a SHA256 manifest; weights/runtime stay outside."""

import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIRECTORIES = {
    "config",
    "deployment",
    "docs",
    "environments",
    "packages",
    "requirements",
    "samples",
    "scripts",
    "src",
    "templates",
    "tests",
}
TOP_FILES = {
    ".env.example",
    ".gitignore",
    ".dockerignore",
    "README.md",
    "START_HERE.md",
    "VERSION",
    "pyproject.toml",
    "run_windows.bat",
    "setup_or_update_windows.bat",
    "start_windows.bat",
    "validate_windows.bat",
}
EXCLUDED = {
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    "runtime",
    "build",
    "dist",
    ".git",
    "model_logs",
    "htmlcov",
}
BLOCKED = {
    ".pyc",
    ".pyo",
    ".key",
    ".pem",
    ".crt",
    ".der",
    ".safetensors",
    ".gguf",
    ".bin",
    ".pt",
    ".pth",
    ".onnx",
    ".ckpt",
}


def included(path):
    rel = path.relative_to(ROOT)
    if not path.is_file() or path.is_symlink():
        return False
    if len(rel.parts) == 1:
        return rel.name in TOP_FILES
    if rel.parts[0] not in DIRECTORIES:
        return False
    if any(
        p in EXCLUDED or p.endswith(".egg-info") or p.startswith((".venv", ".tox"))
        for p in rel.parts
    ):
        return False
    if path.suffix in BLOCKED or path.name.endswith(("-wal", "-shm")):
        return False
    if path.name.startswith((".env", ".coverage")):
        return False
    if (
        path.suffix == ".db"
        and rel.as_posix() != "src/cnc_ai/resources/cnc_sample_base.db"
    ):
        return False
    if path.suffix == ".whl" and (
        rel.parts[0] != "packages"
        or path.name
        != f"cnc_first_ai-{(ROOT / 'VERSION').read_text().strip()}-py3-none-any.whl"
    ):
        return False
    return True


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    output = args.output.resolve()
    if output.is_relative_to(ROOT) or output.exists():
        p.error("Choose a new ZIP path outside the project.")
    files = sorted(f for f in ROOT.rglob("*") if included(f))
    manifest = {"project_version": (ROOT / "VERSION").read_text().strip(), "files": {}}
    for f in files:
        manifest["files"][f.relative_to(ROOT).as_posix()] = {
            "size": f.stat().st_size,
            "sha256": hashlib.sha256(f.read_bytes()).hexdigest(),
        }
    (ROOT / "SHA256SUMS.json").write_text(json.dumps(manifest, indent=2) + "\n")
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for f in [*files, ROOT / "SHA256SUMS.json"]:
            z.write(f, ROOT.name + "/" + f.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None
        for name, entry in manifest["files"].items():
            assert (
                hashlib.sha256(z.read(ROOT.name + "/" + name)).hexdigest()
                == entry["sha256"]
            )
    print(
        json.dumps(
            {
                "file": str(output),
                "files": len(files) + 1,
                "size": output.stat().st_size,
                "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
                "manifest_verified": True,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()

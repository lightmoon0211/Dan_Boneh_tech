#!/usr/bin/env python3
"""Run the real Waitress RCA UI against isolated, explicitly synthetic history."""

import argparse
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
from urllib.request import build_opener, ProxyHandler
from cnc_ai.auth import Auth
from cnc_ai.config import Settings
from cnc_ai.database import Database
from cnc_ai.rca.demo import create_demo

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser-executable")
    parser.add_argument(
        "--screenshot-dir", type=Path, default=ROOT / "docs/rca/screenshots"
    )
    args = parser.parse_args()
    args.screenshot_dir.mkdir(parents=True, exist_ok=True)
    from playwright.sync_api import sync_playwright, expect

    with tempfile.TemporaryDirectory(prefix="cnc-rca-browser-") as temporary:
        home = Path(temporary)
        settings = Settings(home, home / "runtime", ROOT / "config", model_mode="demo")
        db = Database(settings)
        db.initialize(sample=True)
        Auth(db).create_user(
            "admin", "Browser-test-only-123", "admin", "RCA browser tester"
        )
        create_demo(settings.data / "rca-demo.db")
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        env = dict(
            os.environ,
            CNC_DATA_DIR=str(settings.data),
            CNC_CONFIG_DIR=str(settings.config),
            CNC_MODEL_MODE="demo",
            CNC_PROFILE="development",
            CNC_RCA_DEMO="true",
            CNC_OPCUA_MODE="simulator",
            CNC_COOKIE_SECURE="false",
            CNC_TRUST_PROXY="false",
            CNC_HOST="127.0.0.1",
        )
        with (home / "server.log").open("w") as log:
            server = subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "cnc_ai",
                    "--home",
                    str(home),
                    "serve",
                    "--port",
                    str(port),
                ],
                env=env,
                stdout=log,
                stderr=log,
            )
            try:
                base = f"http://127.0.0.1:{port}"
                opener = build_opener(ProxyHandler({}))
                for _ in range(100):
                    try:
                        with opener.open(base + "/api/health", timeout=1) as response:
                            assert response.status == 200
                        break
                    except OSError:
                        time.sleep(0.1)
                else:
                    raise RuntimeError((home / "server.log").read_text())
                with sync_playwright() as playwright:
                    launch = {"headless": True}
                    if args.browser_executable:
                        launch.update(
                            executable_path=args.browser_executable,
                            args=[
                                "--no-sandbox",
                                "--disable-dev-shm-usage",
                                "--no-zygote",
                                "--use-angle=swiftshader",
                            ],
                        )
                    browser = playwright.chromium.launch(**launch)
                    context = browser.new_context(
                        viewport={"width": 1440, "height": 1100}
                    )
                    page = context.new_page()
                    errors = []
                    page.on("pageerror", lambda error: errors.append(str(error)))
                    page.goto(base)
                    page.locator("#loginUser").fill("admin")
                    page.locator("#loginPassword").fill("Browser-test-only-123")
                    page.locator("#loginForm button[type=submit]").click()
                    expect(page.locator("#workspace")).to_be_visible()
                    page.wait_for_function(
                        "() => !document.getElementById('rcaDemoOption').disabled"
                    )
                    page.locator("#rcaSource").select_option("demo")
                    page.locator("#question").fill(
                        "Why did CNC-03 production decrease on 2026-09-08?"
                    )
                    page.locator("#sendMessage").click()
                    card = page.locator(".rca-card").last
                    expect(card.locator(".rca-heading")).to_contain_text(
                        "Completed", timeout=20000
                    )
                    expect(card).to_contain_text("Synthetic training data")
                    key = card.get_attribute("data-run")
                    run = context.request.get(
                        base + "/api/rca/investigations/" + key
                    ).json()
                    assert (
                        run["result"]["problem_verified"]
                        and run["status"] == "completed"
                    )
                    card.locator("[data-open=scope]>summary").click()
                    card.locator("[data-open=calculations]>summary").click()
                    card.locator(
                        "[data-open=calculation-production_loss]>summary"
                    ).click()
                    expect(card).to_contain_text("60 pieces")
                    expect(card).to_contain_text("Unexplained residual: 0")
                    page.screenshot(path=str(args.screenshot_dir / "rca_summary.png"))
                    card.locator("[data-open=calculations]>summary").click()
                    card.locator("[data-open=scope]>summary").click()
                    card.locator("[data-open=timeline]>summary").click()
                    expect(card.locator(".rca-step")).to_have_count(len(run["steps"]))
                    for step in run["steps"]:
                        visible = card.locator(".rca-step").filter(
                            has=page.get_by_text(step["title"], exact=True)
                        )
                        expect(visible.locator(".rca-state")).to_have_text(
                            step["status"].capitalize()
                        )
                        last = [e for e in run["events"] if e["step_id"] == step["id"]][
                            -1
                        ]
                        assert last["status"] == step["status"]
                    page.screenshot(path=str(args.screenshot_dir / "rca_timeline.png"))
                    card.locator("[data-open=timeline]>summary").click()
                    card.locator("[data-open=map]>summary").click()
                    expect(card.locator(".rca-map")).to_be_visible()
                    card.locator(".rca-link-detail").first.locator("summary").click()
                    page.screenshot(
                        path=str(args.screenshot_dir / "rca_causal_map.png")
                    )
                    card.locator(".rca-link-detail").first.locator(
                        "[data-evidence]"
                    ).first.click()
                    expect(card.locator(".rca-evidence-detail")).to_contain_text(
                        "hash verified"
                    )
                    expect(card.locator(".rca-evidence-detail")).to_contain_text(
                        "CNC-03"
                    )
                    page.locator("#question").fill("Show the evidence.")
                    page.locator("#sendMessage").click()
                    expect(page.locator(".rca-card")).to_have_count(2)
                    expect(page.locator(".rca-card").last).to_have_attribute(
                        "data-run", key
                    )
                    page.evaluate("panel('rcaPanel')")
                    expect(page.locator("#rcaSavedList button")).to_have_count(1)
                    page.locator("#rcaSavedList button").click()
                    saved = page.locator("#rcaSavedView")
                    expect(saved.locator(".rca-heading")).to_contain_text("Completed")
                    saved.locator("[data-rca-action=review]").click()
                    saved.locator("[name=reason]").fill(
                        "Reviewed linked records; deeper cause still unresolved."
                    )
                    saved.locator(".rca-action-form button.primary").click()
                    expect(saved).to_contain_text("review: acknowledged")
                    saved.locator("[data-rca-action=reassess]").click()
                    saved.locator("[name=reason]").fill(
                        "Repeat after source verification and preserve the original."
                    )
                    saved.locator(".rca-action-form button.primary").click()
                    expect(saved).to_contain_text("revision 2", timeout=20000)
                    expect(saved.locator(".rca-heading")).to_contain_text(
                        "Completed", timeout=20000
                    )
                    assert saved.get_attribute("data-run") != key
                    page.set_viewport_size({"width": 390, "height": 844})
                    saved.locator("[data-open=map]>summary").click()
                    page.screenshot(
                        path=str(args.screenshot_dir / "rca_mobile.png"), full_page=True
                    )
                    assert page.evaluate(
                        "document.documentElement.scrollWidth <= window.innerWidth + 1"
                    )
                    assert not errors, errors
                    browser.close()
                result = {
                    "status": "passed",
                    "live_models": "not_run",
                    "live_factory_connectors": "not_run",
                    "checks": [
                        "real chat routing",
                        "actual timeline vs persisted events",
                        "60+10=70 loss display",
                        "causal relationships",
                        "authorized source snapshot",
                        "context follow-up",
                        "saved cases",
                        "separate review",
                        "immutable revision",
                        "mobile width",
                        "no browser errors",
                    ],
                }
                (args.screenshot_dir / "browser_validation.json").write_text(
                    json.dumps(result, indent=2) + "\n"
                )
                print(json.dumps(result))
            finally:
                server.terminate()
                server.wait(timeout=15)


if __name__ == "__main__":
    main()

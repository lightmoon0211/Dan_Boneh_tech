#!/usr/bin/env python3
"""Test actual v11 wheel -> current migration using disposable synthetic records only."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from cnc_ai import __version__
from cnc_ai.config import Settings
from cnc_ai.database import Database

ROOT = Path(__file__).resolve().parents[2]


def fingerprints(db):
    result = {}
    with db.connect() as c:
        for table in [
            "machines",
            "work_orders",
            "production_runs",
            "users",
            "documents",
            "document_revisions",
            "control_proposals",
            "audit_events",
        ]:
            rows = [
                dict(r) for r in c.execute("SELECT * FROM " + table + " ORDER BY rowid")
            ]
            result[table] = {
                "rows": len(rows),
                "sha256": hashlib.sha256(
                    json.dumps(rows, sort_keys=True).encode()
                ).hexdigest(),
            }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-wheel", type=Path, required=True)
    parser.add_argument(
        "--output", type=Path, default=ROOT / "docs/rca/migration_validation.json"
    )
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="cnc-rca-migration-") as temporary:
        root = Path(temporary)
        target = root / "baseline-package"
        home = root / "instance"
        subprocess.run(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                "--no-index",
                "--no-deps",
                "--target",
                str(target),
                str(args.baseline_wheel.resolve()),
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        script = r"""
import json,sys
from pathlib import Path
from cnc_ai import __version__
from cnc_ai.config import Settings
from cnc_ai.database import Database
from cnc_ai.auth import Auth
from cnc_ai.models import ModelRouter
from cnc_ai.rag import RAG
from cnc_ai.control.adapters import SimulatorAdapter
from cnc_ai.control.service import ControlService
from cnc_ai.contracts import ControlRequest
assert __version__=='11.0.0', __version__
home=Path(sys.argv[1]);settings=Settings(home,home/'runtime',home/'config',model_mode='demo')
db=Database(settings);db.initialize(sample=True);auth=Auth(db)
for user,role in [('operator','operator'),('admin','admin')]:auth.create_user(user,'Migration-fixture-only-123',role,user)
report=home/'verification.md';report.write_text('Synthetic maintenance verification procedure. Confirm cooling restoration with independent source records.')
RAG(db,ModelRouter(settings)).ingest(report,auth.user('admin'),revision='migration-fixture')
ControlService(settings,db,auth,SimulatorAdapter(db)).create(ControlRequest(machine='CNC-01',action='set_spindle_rpm',rpm=7000.,reason='Synthetic migration test; proposal only'),auth.user('operator'))
print(json.dumps({'version':__version__,'stats':db.stats(),'audit':db.verify_audit()}))
"""
        env = {
            k: v for k, v in os.environ.items() if not k.startswith(("CNC_", "OPCUA_"))
        }
        env["PYTHONPATH"] = str(target)
        result = subprocess.run(
            [sys.executable, "-c", script, str(home)],
            env=env,
            cwd=root,
            check=True,
            capture_output=True,
            text=True,
        )
        baseline = json.loads(result.stdout)
        settings = Settings(home, home / "runtime", home / "config", model_mode="demo")
        db = Database(settings)
        before = fingerprints(db)
        with db.connect() as c:
            old_migrations = [
                dict(r)
                for r in c.execute("SELECT * FROM schema_migrations ORDER BY version")
            ]
        db.initialize()  # intentionally no sample=True
        after = fingerprints(db)
        assert before == after, (
            "Migration modified retained baseline business/evidence/authority rows."
        )
        with db.connect() as c:
            migrations = [
                dict(r)
                for r in c.execute("SELECT * FROM schema_migrations ORDER BY version")
            ]
            assert migrations[:3] == old_migrations and len(migrations) == 5
            assert c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
            assert not c.execute("PRAGMA foreign_key_check").fetchall()
            assert (
                c.execute("SELECT count(*) FROM rca_investigations").fetchone()[0] == 0
            )
        assert db.verify_audit()["valid"]
        record = {
            "status": "passed",
            "from": baseline,
            "to": __version__,
            "retained_tables": after,
            "original_migrations_unchanged": True,
            "new_migrations": ["004_rca.sql", "005_jobs.sql"],
            "new_rca_cases": 0,
            "audit_valid": True,
            "synthetic_only": True,
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(record, indent=2) + "\n")
        print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()

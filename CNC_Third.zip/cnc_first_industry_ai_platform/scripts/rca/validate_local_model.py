#!/usr/bin/env python3
"""Opt-in RCA end-to-end check with the actual configured local planner and factory history.

No downloads; requires an already qualified, read-only historical mapping.
A model-service connection failure is a failed/unexecuted integration check, not a pass.
"""

import argparse
import json
from pathlib import Path
from cnc_ai.auth import Auth
from cnc_ai.config import Settings
from cnc_ai.database import Database
from cnc_ai.models import ModelRouter
from cnc_ai.rca.service import RCAService


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--home", type=Path, default=Path.cwd())
    p.add_argument("--user", required=True)
    p.add_argument("--question", required=True)
    p.add_argument("--intent", type=Path)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    if args.output.exists():
        p.error("Choose a new output path to preserve earlier evidence.")
    settings = Settings.load(args.home)
    if settings.model_mode != "local":
        p.error("Set CNC_MODEL_MODE=local; this check must use real inference.")
    db = Database(settings)
    svc = RCAService(db, ModelRouter(settings))
    try:
        principal = Auth(db).user(args.user)
        request = {"question": args.question, "evidence_source": "factory"}
        if args.intent:
            request["intent"] = json.loads(args.intent.read_text(encoding="utf-8"))
        inv = svc.start(request, principal, background=False)
        svc.execute(inv["id"])
        result = svc.export(inv["id"], principal)
        steps = [s for s in result["steps"] if s["tool"] == "model.planner"]
        passed = (
            result["status"] == "completed"
            and len(steps) == 1
            and steps[0]["status"] == "completed"
            and bool(result["evidence"])
        )
        result["integration_validation"] = {
            "status": "passed" if passed else "failed_or_not_executed",
            "actual_configured_model": True,
            "diagnosis_accuracy_established": False,
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(
            json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )
        print(json.dumps(result["integration_validation"]))
        return 0 if passed else 2
    finally:
        svc.close()


if __name__ == "__main__":
    raise SystemExit(main())

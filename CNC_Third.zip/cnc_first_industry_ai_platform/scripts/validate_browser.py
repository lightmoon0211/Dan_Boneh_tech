#!/usr/bin/env python3
"""Exercise the actual local UI with temporary demo data; never connects to machinery."""

import argparse
import csv
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
from urllib.request import build_opener, ProxyHandler
from cnc_ai.config import Settings
from cnc_ai.database import Database
from cnc_ai.auth import Auth
from cnc_ai.timeseries.contracts import Observation
from cnc_ai.timeseries.historian import SQLiteHistorian

ROOT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--browser-executable")
    p.add_argument("--screenshot-dir", type=Path, default=ROOT / "docs/screenshots")
    args = p.parse_args()
    args.screenshot_dir.mkdir(parents=True, exist_ok=True)
    from playwright.sync_api import sync_playwright, expect

    with tempfile.TemporaryDirectory(prefix="cnc-browser-") as temporary:
        home = Path(temporary)
        settings = Settings(home, home / "runtime", ROOT / "config", model_mode="demo")
        db = Database(settings)
        db.initialize(sample=True)
        with (ROOT / "samples/telemetry/cnc_telemetry.csv").open(newline="") as f:
            fields = set(Observation.model_fields)
            rows = []
            for row in csv.DictReader(f):
                data = {k: v for k, v in row.items() if k in fields}
                data["value"] = float(data["value"])
                data["sampling_hz"] = (
                    float(data["sampling_hz"]) if data.get("sampling_hz") else None
                )
                rows.append(Observation.model_validate(data))
            SQLiteHistorian(db).append(rows)
        auth = Auth(db)
        for user, role in [
            ("operator", "operator"),
            ("supervisor", "supervisor"),
            ("admin", "admin"),
        ]:
            auth.create_user(user, "Browser-test-only-123", role, user.title())
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        env = dict(
            os.environ,
            CNC_DATA_DIR=str(settings.data),
            CNC_CONFIG_DIR=str(settings.config),
            CNC_MODEL_MODE="demo",
            CNC_OPCUA_MODE="simulator",
            CNC_COOKIE_SECURE="false",
            CNC_TRUST_PROXY="false",
            CNC_HOST="127.0.0.1",
        )
        with (home / "server.log").open("w") as log:
            server = subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "cnc_ai",
                    "--home",
                    str(home),
                    "serve",
                    "--port",
                    str(port),
                ],
                env=env,
                stdout=log,
                stderr=log,
            )
            try:
                base = f"http://127.0.0.1:{port}"
                opener = build_opener(ProxyHandler({}))
                for _ in range(100):
                    try:
                        with opener.open(base + "/api/health", timeout=1) as response:
                            assert response.status == 200
                        break
                    except OSError:
                        time.sleep(0.1)
                else:
                    raise RuntimeError(
                        "Waitress did not become healthy: "
                        + (home / "server.log").read_text()
                    )
                with sync_playwright() as playwright:
                    launch = {"headless": True}
                    if args.browser_executable:
                        launch.update(
                            executable_path=args.browser_executable,
                            args=[
                                "--no-sandbox",
                                "--disable-dev-shm-usage",
                                "--no-zygote",
                                "--use-angle=swiftshader",
                            ],
                        )
                    browser = playwright.chromium.launch(**launch)
                    context = browser.new_context(
                        viewport={"width": 1440, "height": 980}
                    )
                    page = context.new_page()
                    errors = []
                    page.on("pageerror", lambda error: errors.append(str(error)))

                    def login(username):
                        page.goto(base)
                        page.locator("#loginUser").fill(username)
                        page.locator("#loginPassword").fill("Browser-test-only-123")
                        page.locator("#loginForm button[type=submit]").click()
                        expect(page.locator("#workspace")).to_be_visible()
                        expect(page.locator("#modeBadge")).to_contain_text(
                            "Training mode"
                        )

                    login("operator")
                    page.screenshot(
                        path=str(args.screenshot_dir / "conversation_desktop.png")
                    )
                    names = page.locator("#language option").all_text_contents()
                    assert names == [
                        "English",
                        "French",
                        "German",
                        "Chinese (Simplified)",
                        "Chinese (Traditional)",
                        "Japanese",
                        "Korean",
                    ]
                    # UI-only speech fixture: the backend/HTTP adapter is tested separately.
                    expect(page.locator("#speechPanel")).to_be_hidden()

                    def speech_status(route):
                        response = route.fetch()
                        payload = response.json()
                        payload["models"]["services"]["speech"]["state"] = "reachable"
                        route.fulfill(response=response, json=payload)

                    page.route("**/api/status", speech_status)
                    page.route(
                        "**/api/speech/transcribe",
                        lambda route: route.fulfill(
                            json={
                                "text": "Set CNC-01 to seven thousand RPM.",
                                "review_required": True,
                            }
                        ),
                    )
                    page.evaluate("loadStatus()")
                    page.locator("#speechPanel summary").click()
                    page.locator("#speechFile").set_input_files(
                        {
                            "name": "fixture.wav",
                            "mimeType": "audio/wav",
                            "buffer": b"UI fixture; backend WAV validation has separate tests",
                        }
                    )
                    page.locator("#speechForm button").click()
                    expect(page.locator("#speechReview")).to_be_visible()
                    expect(page.locator("#question")).to_have_value("")
                    expect(page.locator(".message.user")).to_have_count(0)
                    page.locator("#speechText").fill(
                        "Show recorded information for CNC-01."
                    )
                    page.locator("#useTranscript").click()
                    expect(page.locator("#question")).to_have_value(
                        "Show recorded information for CNC-01."
                    )
                    expect(page.locator(".message.user")).to_have_count(0)
                    page.screenshot(
                        path=str(args.screenshot_dir / "speech_review_desktop.png")
                    )
                    page.locator("#question").fill("")
                    page.unroute("**/api/status", speech_status)
                    page.unroute("**/api/speech/transcribe")
                    page.evaluate("loadStatus()")
                    page.locator("#question").fill("Show the CNC machine inventory.")
                    page.locator("#sendMessage").click()
                    expect(page.locator(".message.assistant")).to_contain_text(
                        "26 machines"
                    )
                    expect(page.locator(".message.assistant .evidence")).to_have_count(
                        2
                    )
                    page.locator(".evidence>summary").first.click()
                    expect(page.locator(".evidence table")).to_be_visible()
                    page.screenshot(
                        path=str(args.screenshot_dir / "evidence_desktop.png")
                    )
                    page.locator("[data-panel=intelligencePanel]").click()
                    page.locator("#runAnalysis").click()
                    expect(
                        page.locator("#analysisResults .telemetry-chart")
                    ).to_have_count(2)
                    page.screenshot(
                        path=str(args.screenshot_dir / "telemetry_desktop.png")
                    )
                    page.locator("#analysisResults").screenshot(
                        path=str(args.screenshot_dir / "anomaly_chart.png")
                    )
                    page.locator("#analysisKind").select_option("forecast")
                    page.locator("#analysisSignals").fill("bearing_temperature")
                    page.locator("#runAnalysis").click()
                    expect(
                        page.locator("#analysisResults .telemetry-chart")
                    ).to_have_count(1)
                    expect(page.locator("#analysisResults")).to_contain_text(
                        "historical-residual"
                    )
                    page.locator("#analysisResults").screenshot(
                        path=str(args.screenshot_dir / "forecast_chart.png")
                    )
                    page.locator("[data-panel=controlPanel]").click()
                    page.locator("#preflight").click()
                    expect(page.locator("#policyChecks .check")).to_have_count(7)
                    page.locator("#controlForm button[type=submit]").click()
                    expect(page.locator("#proposalList")).to_contain_text("pending")
                    page.screenshot(
                        path=str(args.screenshot_dir / "control_desktop.png")
                    )
                    page.locator("#logout").click()
                    login("supervisor")
                    page.locator("[data-panel=controlPanel]").click()
                    page.get_by_role(
                        "button", name="Approve proposal", exact=True
                    ).click()
                    page.locator("#dialogInput").fill(
                        "Checked the training tool, material and limits."
                    )
                    page.locator("#dialogConfirm").click()
                    expect(page.locator("#proposalList")).to_contain_text("approved")
                    page.locator("#logout").click()
                    login("operator")
                    page.locator("[data-panel=controlPanel]").click()
                    page.get_by_role(
                        "button", name="Confirm execution", exact=True
                    ).click()
                    page.locator("#dialogInput").fill("EXECUTE APPROVED ACTION")
                    page.locator("#dialogConfirm").click()
                    expect(page.locator("#proposalList")).to_contain_text("confirmed")
                    expect(page.locator("#machineStatus")).to_contain_text(
                        "Setpoint 7000"
                    )
                    page.set_viewport_size({"width": 390, "height": 844})
                    page.locator("[data-panel=chatPanel]").click()
                    expect(page.locator("#logout")).to_be_visible()
                    expect(page.locator("#newChat")).to_be_visible()
                    page.locator("#newChat").click()
                    page.screenshot(
                        path=str(args.screenshot_dir / "conversation_mobile.png")
                    )
                    page.locator("[data-panel=intelligencePanel]").click()
                    page.locator("#analysisKind").select_option("forecast")
                    page.locator("#analysisSignals").fill("bearing_temperature")
                    page.locator("#runAnalysis").click()
                    expect(
                        page.locator("#analysisResults .telemetry-chart")
                    ).to_have_count(1)
                    page.locator("#analysisResults").screenshot(
                        path=str(args.screenshot_dir / "telemetry_mobile.png")
                    )
                    assert page.evaluate(
                        "document.documentElement.scrollWidth <= window.innerWidth"
                    ), "Mobile horizontal overflow"
                    assert not errors, errors
                    browser.close()
                print(
                    json.dumps(
                        {
                            "browser": "passed",
                            "checks": [
                                "sign-in",
                                "language labels",
                                "speech review without submission (UI fixture)",
                                "demo conversation",
                                "database citations",
                                "ordered checks",
                                "supervisor approval",
                                "requester execution",
                                "readback",
                                "mobile navigation",
                                "numerical anomaly charts",
                                "forecast interval",
                                "mobile telemetry",
                                "no JavaScript errors",
                            ],
                        },
                        indent=2,
                    )
                )
            finally:
                server.terminate()
                try:
                    server.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    server.kill()
                    server.wait()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

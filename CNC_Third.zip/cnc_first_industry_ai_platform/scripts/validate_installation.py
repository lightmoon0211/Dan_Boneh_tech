#!/usr/bin/env python3
"""Exercise an installed package in an isolated temporary simulator instance."""

import argparse
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    env = {
        k: v
        for k, v in os.environ.items()
        if not k.startswith(("CNC_", "OPCUA_")) and k != "PYTHONPATH"
    }
    env.update(
        CNC_MODEL_MODE="demo",
        CNC_OPCUA_MODE="simulator",
        CNC_PROFILE="development",
        CNC_VALIDATION_PASSWORD=secrets.token_urlsafe(28),
    )
    record = {
        "release": "11.2.0",
        "mode": "isolated simulator; no inference or real CNC",
        "commands": [],
    }
    with tempfile.TemporaryDirectory(prefix="cnc-installation-") as tmp:
        home = Path(tmp)

        def run(*parts):
            result = subprocess.run(
                [sys.executable, "-m", "cnc_ai", "--home", str(home), *map(str, parts)],
                env=env,
                cwd=home,
                text=True,
                capture_output=True,
            )
            if result.returncode:
                raise RuntimeError(f"Command {parts[0]} failed: {result.stderr}")
            text = result.stdout
            offset = min([i for c in "[{" if (i := text.find(c)) >= 0], default=-1)
            payload = json.loads(text[offset:]) if offset >= 0 else text
            record["commands"].append({"command": str(parts[0]), "status": "passed"})
            return payload

        record["database"] = run("db", "init", "--sample")
        for name, role in [
            ("factory_admin", "admin"),
            ("operator01", "operator"),
            ("supervisor01", "supervisor"),
        ]:
            run(
                "user",
                "add",
                name,
                "--role",
                role,
                "--password-env",
                "CNC_VALIDATION_PASSWORD",
            )
        document = run(
            "ingest",
            ROOT / "samples/documents/spindle_change_sop.md",
            "--user",
            "factory_admin",
            "--kind",
            "sop",
            "--revision",
            "training-v10",
        )
        run(
            "approve-document",
            document[0]["id"],
            "--user",
            "supervisor01",
            "--comment",
            "Reviewed fictional installation fixture",
        )
        record["telemetry_import"] = run(
            "timeseries",
            "ingest",
            ROOT / "samples/telemetry/cnc_telemetry.csv",
            "--user",
            "factory_admin",
        )
        analysis_file = home / "analysis.json"
        run(
            "timeseries",
            "analyze",
            "anomaly",
            ROOT / "samples/telemetry/anomaly_query.json",
            "--user",
            "operator01",
            "--output",
            analysis_file,
        )
        analysis = json.loads(analysis_file.read_text())["analysis"]
        assert analysis["status"] == "ok"
        record["analysis"] = {
            "status": analysis["status"],
            "signals": len(analysis["signals"]),
            "model_version": analysis["model_version"],
        }
        record["knowledge"] = run("knowledge", "rebuild", "--user", "factory_admin")
        record["observation"] = run("monitor", "--count", "1")
        record["validation"] = run("validate", "--offline")
        record["opcua"] = run("validate", "--opcua")["opcua"]
        run("db", "backup", home / "backup.db")
        record["audit"] = run("audit-verify")
    record["status"] = "passed"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()

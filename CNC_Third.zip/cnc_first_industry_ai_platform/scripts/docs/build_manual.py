#!/usr/bin/env python3
"""Build the Word manual from docs/USER_MANUAL.md; render PDF with Word or LibreOffice.

Run from any directory after installing the application dependencies.
"""

from pathlib import Path
import json, re
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "docs/USER_MANUAL.md"
doc = Document()
section = doc.sections[0]
section.page_width = Inches(8.5)
section.page_height = Inches(11)
for side in ["top_margin", "bottom_margin", "left_margin", "right_margin"]:
    setattr(section, side, Inches(1))
section.header_distance = Inches(0.492)
section.footer_distance = Inches(0.492)


def style(
    name,
    size=11,
    color="000000",
    before=0,
    after=6,
    line=1.25,
    font="Calibri",
    bold=False,
):
    st = (
        doc.styles[name]
        if name in doc.styles
        else doc.styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
    )
    st.font.name = font
    st.font.size = Pt(size)
    st.font.color.rgb = RGBColor.from_string(color)
    st.font.bold = bold
    f = st.paragraph_format
    f.space_before = Pt(before)
    f.space_after = Pt(after)
    f.line_spacing = line
    st.element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), font)
    return st


style("Normal")
for n, size, before, after, color in [
    (1, 16, 18, 10, "000000"),
    (2, 13, 14, 7, "000000"),
    (3, 12, 10, 5, "000000"),
]:
    st = style("Heading " + str(n), size, color, before, after, bold=True)
    st.paragraph_format.keep_with_next = True
style("Title", 32, "000000", 0, 12, 1.1, bold=True)
style("Manual Subtitle", 15, "000000", 0, 12, 1.25)
style("Manual Kicker", 10, "000000", 0, 18, 1.25, bold=True)
style("Manual Code", 9, "000000", 3, 5, 1.1, "DejaVu Sans Mono")
style("Manual Table", 10, "000000", 0, 4, 1.1)
style("Manual Caption", 9, "667676", 4, 4, 1.1)
style("Manual TOC", 11, "000000", 0, 10, 1.25)
style("Manual Header", 8, "667676", 0, 0, 1)
for name in ["List Bullet", "List Number"]:
    st = style(name, 11, "000000", 0, 4, 1.25)
    st.paragraph_format.left_indent = Inches(0.375)
    st.paragraph_format.first_line_indent = Inches(-0.188)

# Native heading hierarchy and list numbering; no typed bullet/number markers.
numroot = doc.part.numbering_part.element


def addnum(abstract_id, num_id, levels):
    abstract = OxmlElement("w:abstractNum")
    abstract.set(qn("w:abstractNumId"), str(abstract_id))
    multi = OxmlElement("w:multiLevelType")
    multi.set(qn("w:val"), "multilevel" if len(levels) > 1 else "singleLevel")
    abstract.append(multi)
    for level, fmt, text, left, hanging, stylename in levels:
        el = OxmlElement("w:lvl")
        el.set(qn("w:ilvl"), str(level))
        for tag, attr, value in [
            ("start", "val", "1"),
            ("numFmt", "val", fmt),
            ("lvlText", "val", text),
            ("lvlJc", "val", "left"),
        ]:
            child = OxmlElement("w:" + tag)
            child.set(qn("w:" + attr), value)
            el.append(child)
        if stylename:
            ps = OxmlElement("w:pStyle")
            ps.set(qn("w:val"), stylename)
            el.append(ps)
        pp = OxmlElement("w:pPr")
        ind = OxmlElement("w:ind")
        ind.set(qn("w:left"), str(left))
        ind.set(qn("w:hanging"), str(hanging))
        pp.append(ind)
        tabs = OxmlElement("w:tabs")
        tab = OxmlElement("w:tab")
        tab.set(qn("w:val"), "num")
        tab.set(qn("w:pos"), str(left))
        tabs.append(tab)
        pp.append(tabs)
        spacing = OxmlElement("w:spacing")
        spacing.set(qn("w:before"), "0")
        spacing.set(qn("w:after"), "80")
        spacing.set(qn("w:line"), "300")
        spacing.set(qn("w:lineRule"), "auto")
        pp.append(spacing)
        el.append(pp)
        if fmt == "bullet":
            rp = OxmlElement("w:rPr")
            fonts = OxmlElement("w:rFonts")
            fonts.set(qn("w:ascii"), "Calibri")
            fonts.set(qn("w:hAnsi"), "Calibri")
            rp.append(fonts)
            el.append(rp)
        abstract.append(el)
    numroot.append(abstract)
    number = OxmlElement("w:num")
    number.set(qn("w:numId"), str(num_id))
    aid = OxmlElement("w:abstractNumId")
    aid.set(qn("w:val"), str(abstract_id))
    number.append(aid)
    numroot.append(number)


addnum(
    100,
    100,
    [
        (0, "decimal", "%1.", 576, 576, "Heading1"),
        (1, "decimal", "%1.%2.", 792, 792, "Heading2"),
        (2, "decimal", "%1.%2.%3.", 1008, 1008, "Heading3"),
    ],
)
addnum(101, 101, [(0, "bullet", "•", 540, 270, "ListBullet")])
addnum(102, 102, [(0, "decimal", "%1.", 540, 270, "ListNumber")])
# Heading token spacing lives in heading styles, not list-level overrides.
for lvl in numroot.xpath('./w:abstractNum[@w:abstractNumId="100"]/w:lvl'):
    for sp in lvl.findall("./" + qn("w:pPr") + "/" + qn("w:spacing")):
        sp.getparent().remove(sp)


def numbered(p, numid, level=0):
    pp = p._p.get_or_add_pPr()
    np = OxmlElement("w:numPr")
    il = OxmlElement("w:ilvl")
    il.set(qn("w:val"), str(level))
    ni = OxmlElement("w:numId")
    ni.set(qn("w:val"), str(numid))
    np.extend([il, ni])
    pp.append(np)


def field(p, instr):
    r = OxmlElement("w:r")
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    r.append(begin)
    p._p.append(r)
    r = OxmlElement("w:r")
    t = OxmlElement("w:instrText")
    t.set(qn("xml:space"), "preserve")
    t.text = " " + instr + " "
    r.append(t)
    p._p.append(r)
    r = OxmlElement("w:r")
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    r.append(end)
    p._p.append(r)


header = section.header.paragraphs[0]
header.style = "Manual Header"
header.text = "CNC FACTORY ASSISTANT  /  USER & DEPLOYMENT MANUAL"
footer = section.footer.paragraphs[0]
footer.style = "Manual Header"
footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
footer.add_run("Version 11.2.0  ·  Page ")
field(footer, "PAGE")

# Editorial cover, with named cover typography overrides.
p = doc.add_paragraph(style="Manual Kicker")
p.paragraph_format.space_before = Pt(105)
p.alignment = 1
p.add_run("CNC SMART FACTORY  /  LOCAL AI")
p = doc.add_paragraph("CNC Factory\nAssistant", style="Title")
p.alignment = 1
p = doc.add_paragraph("User & deployment manual", style="Manual Subtitle")
p.alignment = 1
p = doc.add_paragraph("Version 11.2.0  ·  September 2026", style="Manual Kicker")
p.alignment = 1
p.paragraph_format.space_after = Pt(60)
p = doc.add_paragraph(
    "From factory questions to cited evidence\nand supervised machine proposals.",
    style="Manual Subtitle",
)
p.alignment = 1
p = doc.add_paragraph(
    "Windows development · Two RTX inference nodes + CPU server · Air-gapped operation",
    style="Manual Caption",
)
p.alignment = 1
p = doc.add_paragraph(
    "Includes environment migration, model serving and numerical intelligence,\ndatabase/RAG setup, simulator training and real CNC commissioning.",
    style="Manual Caption",
)
p.alignment = 1


def bookmark(p, name, index):
    a = OxmlElement("w:bookmarkStart")
    a.set(qn("w:id"), str(index))
    a.set(qn("w:name"), name)
    b = OxmlElement("w:bookmarkEnd")
    b.set(qn("w:id"), str(index))
    p._p.insert(0, a)
    p._p.append(b)


def link(p, title, target, internal=False):
    hl = OxmlElement("w:hyperlink")
    if internal:
        hl.set(qn("w:anchor"), target)
    else:
        rid = p.part.relate_to(
            target,
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
            is_external=True,
        )
        hl.set(qn("r:id"), rid)
    run = OxmlElement("w:r")
    rp = OxmlElement("w:rPr")
    color = OxmlElement("w:color")
    color.set(qn("w:val"), "000000")
    rp.append(color)
    run.append(rp)
    text = OxmlElement("w:t")
    text.text = title
    run.append(text)
    hl.append(run)
    p._p.append(hl)


doc.add_page_break()
p = doc.add_paragraph("Guide contents", style="Title")
p.runs[0].font.size = Pt(23)
doc.add_paragraph(
    "Choose a chapter in Word or use the document outline. Command examples assume the extracted project directory unless another path is shown."
)
chapters = []
for line in SOURCE.read_text().splitlines():
    if line.startswith("## "):
        chapters.append(line[3:])
for i, heading in enumerate(chapters, 1):
    p = doc.add_paragraph(style="Manual TOC")
    link(p, heading, "chapter_" + str(i), True)
doc.add_paragraph(
    "Start with training mode. Physical machine writes require the complete site commissioning procedure and native controller enforcement.",
    style="Manual Caption",
)


# Inline Markdown with safe, deterministic Word-native links and emphasis.
def inline(p, text):
    parts = re.split(r"(`[^`]+`|\*\*[^*]+\*\*|\[[^]]+\]\([^)]+\))", text)
    for item in parts:
        if not item:
            continue
        if item.startswith("`") and item.endswith("`"):
            r = p.add_run(item[1:-1])
            r.font.name = "DejaVu Sans Mono"
            r.font.size = Pt(9)
        elif item.startswith("**") and item.endswith("**"):
            p.add_run(item[2:-2]).bold = True
        elif re.fullmatch(r"\[[^]]+\]\([^)]+\)", item):
            match = re.match(r"\[([^]]+)\]\(([^)]+)\)", item)
            target = match[2]
            if target.startswith("http"):
                link(p, match[1], target)
            else:
                p.add_run(
                    match[1] if match[1] == target else match[1] + " (" + target + ")"
                )
        else:
            p.add_run(item)


def table(rows):
    n = len(rows[0])
    widths = [2700, 6660] if n == 2 else [9360 // n] * n
    if n == 2 and rows[0][0] in {"Stage", "Order"}:
        widths = [936, 8424]
    if len(widths) != n:
        widths = [9360 // n] * n
        widths[-1] += 9360 - sum(widths)
    tb = doc.add_table(rows=0, cols=n)
    tb.autofit = False
    pr = tb._tbl.tblPr
    for name in ["tblW", "tblInd", "tblLayout", "tblCellMar", "tblBorders"]:
        for old in pr.findall(qn("w:" + name)):
            pr.remove(old)
    tw = OxmlElement("w:tblW")
    tw.set(qn("w:w"), "9360")
    tw.set(qn("w:type"), "dxa")
    pr.append(tw)
    ti = OxmlElement("w:tblInd")
    ti.set(qn("w:w"), "120")
    ti.set(qn("w:type"), "dxa")
    pr.append(ti)
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    pr.append(layout)
    mar = OxmlElement("w:tblCellMar")
    for key, val in [("top", 80), ("bottom", 80), ("start", 120), ("end", 120)]:
        el = OxmlElement("w:" + key)
        el.set(qn("w:w"), str(val))
        el.set(qn("w:type"), "dxa")
        mar.append(el)
    pr.append(mar)
    borders = OxmlElement("w:tblBorders")
    for key in ["top", "left", "bottom", "right", "insideH", "insideV"]:
        el = OxmlElement("w:" + key)
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "4")
        el.set(qn("w:color"), "D9D9D9")
        borders.append(el)
    pr.append(borders)
    grid = tb._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for w in widths:
        gc = OxmlElement("w:gridCol")
        gc.set(qn("w:w"), str(w))
        grid.append(gc)
    for i, values in enumerate(rows):
        row = tb.add_row()
        trpr = row._tr.get_or_add_trPr()
        split = OxmlElement("w:cantSplit")
        trpr.append(split)
        if i == 0:
            repeat = OxmlElement("w:tblHeader")
            trpr.append(repeat)
        for j, value in enumerate(values):
            cell = row.cells[j]
            cell.width = Inches(widths[j] / 1440)
            tcw = cell._tc.get_or_add_tcPr().find(qn("w:tcW"))
            tcw.set(qn("w:w"), str(widths[j]))
            tcw.set(qn("w:type"), "dxa")
            p = cell.paragraphs[0]
            p.style = "Manual Table"
            inline(p, value)
            if i == 0:
                shade = OxmlElement("w:shd")
                shade.set(qn("w:fill"), "EFEFEF")
                cell._tc.get_or_add_tcPr().append(shade)
                for run in p.runs:
                    run.bold = True
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


lines = SOURCE.read_text().splitlines()
i = 0
chapter = 0
bookid = 1
while i < len(lines):
    line = lines[i]
    if (
        not line
        or line.startswith("# ")
        or line.startswith("User and deployment manual")
        or line.startswith("For CNC operators")
    ):
        i += 1
        continue
    if line.startswith("## "):
        chapter += 1
        p = doc.add_paragraph(style="Heading 1")
        p.paragraph_format.page_break_before = chapter in {1, 2, 3}
        numbered(p, 100, 0)
        inline(p, re.sub(r"^\d+\.\s*", "", line[3:]))
        bookmark(p, "chapter_" + str(chapter), bookid)
        bookid += 1
        i += 1
        continue
    if line.startswith("### "):
        p = doc.add_paragraph(style="Heading 2")
        numbered(p, 100, 1)
        inline(p, re.sub(r"^\d+\.\d+\.\s*", "", line[4:]))
        i += 1
        continue
    if line.startswith("```"):
        code = []
        i += 1
        while i < len(lines) and not lines[i].startswith("```"):
            code.append(lines[i])
            i += 1
        # Allow a long block to span pages, but never split one wrapped
        # shell command across a page boundary.
        for line_index, command in enumerate(code):
            p = doc.add_paragraph(command, style="Manual Code")
            p.paragraph_format.keep_together = True
            p.paragraph_format.space_before = Pt(3 if line_index == 0 else 0)
            p.paragraph_format.space_after = Pt(5 if line_index == len(code) - 1 else 0)
            shade = OxmlElement("w:shd")
            shade.set(qn("w:fill"), "F5F5F5")
            p._p.get_or_add_pPr().append(shade)
        i += 1
        continue
    if line.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            if not re.fullmatch(r"[| :\-]+", lines[i]):
                rows.append([c.strip() for c in lines[i].strip("|").split("|")])
            i += 1
        table(rows)
        continue
    if line.startswith("!["):
        match = re.match(r"!\[([^]]*)\]\(([^)]+)\)", line)
        p = doc.add_paragraph()
        p.paragraph_format.keep_with_next = True
        p.alignment = 1
        p.add_run().add_picture(str(SOURCE.parent / match[2]), width=Inches(6.15))
        doc.add_paragraph(match[1], style="Manual Caption")
        i += 1
        continue
    if line.startswith("- "):
        p = doc.add_paragraph(style="List Bullet")
        numbered(p, 101)
        inline(p, line[2:])
        i += 1
        continue
    if re.match(r"^\d+\. ", line):
        p = doc.add_paragraph(style="List Number")
        numbered(p, 102)
        inline(p, re.sub(r"^\d+\. ", "", line))
        i += 1
        continue
    p = doc.add_paragraph()
    inline(p, line)
    i += 1

# Set explicit widow/orphan behavior and metadata.
for p in doc.paragraphs:
    p.paragraph_format.widow_control = True
doc.core_properties.title = "CNC Factory Assistant — User and Deployment Manual"
doc.core_properties.subject = (
    "Version 11.2.0: local models, RAG, database evidence and supervised OPC UA"
)
doc.core_properties.author = "Factory AI project"
doc.core_properties.keywords = "CNC, RAG, OPC UA, RTX PRO 6000, air-gapped, deployment"
out = ROOT / "docs/USER_MANUAL.docx"
for element in [doc.styles.element, doc.element]:
    for border in element.xpath(".//w:pBdr"):
        border.getparent().remove(border)
doc.save(out)
# Deterministic OOXML geometry audit.
assert section.page_width.twips == 12240 and section.page_height.twips == 15840
for tb in doc.tables:
    assert tb._tbl.tblPr.find(qn("w:tblW")).get(qn("w:w")) == "9360"
    grid = [int(x.get(qn("w:w"))) for x in tb._tbl.tblGrid]
    assert sum(grid) == 9360
    for row in tb.rows:
        assert [
            int(c._tc.get_or_add_tcPr().find(qn("w:tcW")).get(qn("w:w")))
            for c in row.cells
        ] == grid
print(
    json.dumps(
        {
            "output": str(out),
            "tables": len(doc.tables),
            "chapters": chapter,
            "paragraphs": len(doc.paragraphs),
            "preset": "compact_reference_guide",
            "geometry": "passed",
        }
    )
)

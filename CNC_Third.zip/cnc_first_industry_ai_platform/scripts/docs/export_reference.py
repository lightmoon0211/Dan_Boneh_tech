#!/usr/bin/env python3
"""Regenerate database catalog and JSON Schemas from the installed package."""

import inspect
import json
import tempfile
from pathlib import Path

from cnc_ai import contracts, specialists, readiness, __version__
from cnc_ai.rca import contracts as rca_contracts
from cnc_ai.auth import Auth
from cnc_ai.config import Settings
from cnc_ai.core import StrictModel
from cnc_ai.database import Database, identifier
from cnc_ai.planning import artifacts, calculations, scheduler
from cnc_ai.sql import QueryService
from cnc_ai.timeseries import contracts as series_contracts

ROOT = Path(__file__).resolve().parents[2]


def main():
    schemas = ROOT / "docs/contracts"
    schemas.mkdir(exist_ok=True)
    exported = {}
    for module in [
        contracts,
        series_contracts,
        artifacts,
        calculations,
        scheduler,
        specialists,
        readiness,
        rca_contracts,
    ]:
        for name, cls in inspect.getmembers(module, inspect.isclass):
            if cls.__module__ == module.__name__ and issubclass(cls, StrictModel):
                exported[("RCA_" if module is rca_contracts else "") + name] = (
                    cls.model_json_schema()
                )
    for name, schema in exported.items():
        (schemas / f"{name}.schema.json").write_text(
            json.dumps(schema, indent=2) + "\n", encoding="utf-8"
        )
    with tempfile.TemporaryDirectory(prefix="cnc-reference-") as tmp:
        home = Path(tmp)
        settings = Settings(home, home / "runtime", ROOT / "config", model_mode="demo")
        db = Database(settings)
        stats = db.initialize(sample=True)
        lines = [
            "# CNC database catalog",
            "",
            "Generated from the initialized v11.2 sample database. All business records are fictional training data. Live controller policy remains in reviewed site configuration.",
            "",
            "## Domain coverage",
            "",
            "The full business seed covers factories, lines, machines, tools, customers, materials, BOMs, orders, operations, production, downtime, maintenance, quality, stock, sensors and OEE. Platform tables cover authenticated users/roles, approvals, control proposals/executions, documents/vectors, reports and chained audit. Version 11.2 adds persistent application jobs and correlated model-call request IDs. Version 11.1 adds bounded RCA investigations, execution events, evidence snapshots, causal links and independent reviews. Version 10 adds canonical historian observations, numerical analyses, digital-thread relations, approved program qualifications, controlled document revisions, agent traces and engineering artifact attestations.",
            "",
            f"The seed contains {stats['tables']} tables including FTS internals, {stats['machines']} machines, {stats['work_orders']} work orders and {stats['sensor_readings']:,} legacy sensor readings. The separate canonical telemetry CSV contains 30,240 observations; import it using the manual. Tables that record runtime activity start empty.",
            "",
            "Application storage uses SQLite with foreign keys and WAL. The positive SQL allowlist excludes authorization, session, audit and control-authority tables. External PostgreSQL/ClickHouse historian adapters use fixed parameterized queries; they do not change the generated SQL dialect or turn SQLite into a multi-active database. See DATABASE_DESIGN.md for extension boundaries.",
            "",
            "## Tables and columns",
            "",
            "| Table | Seed rows | Columns |",
            "|---|---:|---|",
        ]
        with db.connect() as c:
            for row in c.execute(
                "SELECT name,type FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY name"
            ):
                name = row["name"]
                count = c.execute(
                    "SELECT count(*) FROM " + identifier(name)
                ).fetchone()[0]
                columns = "; ".join(
                    col["name"] + " " + col["type"] + (" PK" if col["pk"] else "")
                    for col in c.execute("PRAGMA table_info(" + identifier(name) + ")")
                )
                label = name + (" (view)" if row["type"] == "view" else "")
                lines.append(f"| {label} | {count} | {columns} |")
        auth = Auth(db)
        auth.create_user(
            "catalog-reader", "Temporary-catalog-only-credential", "viewer"
        )
        principal = auth.user("catalog-reader")
        rows = []
        for obj in json.loads(
            (ROOT / "samples/queries/cnc_questions.json").read_text()
        ):
            result = QueryService(db).run(
                contracts.Query.model_validate(obj), principal
            )
            rows.append({"label": obj["label"], "rows": len(result["rows"])})
        lines += [
            "",
            "## Query examples",
            "",
            "All supplied questions were executed through QueryService with a viewer account and bound parameters. Sample work-order planning spans August–September 2026.",
            "",
            "| Example | Returned rows |",
            "|---|---:|",
        ]
        lines += [f"| {r['label']} | {r['rows']} |" for r in rows]
        lines += [
            "",
            "## Extension rules",
            "",
            "Add ordered migration files under src/cnc_ai/resources/migrations; never edit an applied checksum. Review both external configuration and packaged defaults when extending the query allowlist. Preserve authorization, provenance and control-lifecycle contracts. Other sectors can use separately approved analytical schemas. A new controller action requires a strict contract, deterministic policy, typed adapter and tests. Generated SQL remains read-only for every role.",
            "",
        ]
        (ROOT / "docs/DATABASE.md").write_text("\n".join(lines), encoding="utf-8")
        (ROOT / "docs/v112/catalog.json").write_text(
            json.dumps(
                {
                    "version": __version__,
                    "database": stats,
                    "queries": rows,
                    "schemas": sorted(exported),
                },
                indent=2,
            )
            + "\n"
        )
    print(
        json.dumps(
            {"database": stats, "schemas": len(exported), "queries": rows}, indent=2
        )
    )


if __name__ == "__main__":
    main()

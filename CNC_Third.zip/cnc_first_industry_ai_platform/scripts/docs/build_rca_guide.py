#!/usr/bin/env python3
"""Build the RCA Word supplement from its editable Markdown source."""

from pathlib import Path
import re
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[2]


def main():
    doc = Document()
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    for side in ["top_margin", "bottom_margin", "left_margin", "right_margin"]:
        setattr(section, side, Inches(0.85))
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)
    normal.font.color.rgb = RGBColor(0, 0, 0)
    normal.paragraph_format.space_after = Pt(7)
    normal.paragraph_format.line_spacing = 1.15
    for name, size in [
        ("Title", 25),
        ("Heading 1", 16),
        ("Heading 2", 13),
        ("Heading 3", 11),
    ]:
        s = doc.styles[name]
        s.font.name = "Calibri"
        s.font.size = Pt(size)
        s.font.bold = True
        s.font.color.rgb = RGBColor(0, 0, 0)
        s.paragraph_format.keep_with_next = True
        s.paragraph_format.space_before = Pt(14 if name != "Title" else 0)
        s.paragraph_format.space_after = Pt(8)
    from docx.enum.style import WD_STYLE_TYPE

    code = doc.styles.add_style("RCA Code", WD_STYLE_TYPE.PARAGRAPH)
    code.font.name = "DejaVu Sans Mono"
    code.font.size = Pt(9)
    code.paragraph_format.space_after = Pt(3)
    code.paragraph_format.line_spacing = 1.05
    caption = doc.styles["Caption"]
    caption.font.color.rgb = RGBColor(70, 70, 70)
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    footer.add_run("CNC Factory Assistant 11.2.0    |    ")
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    footer._p.append(field)
    for r in footer.runs:
        r.font.size = Pt(9)

    def inline(p, text):
        # Markdown URLs remain printable labels/paths in the Word reference.
        for part in re.split(r"(\*\*.*?\*\*|`[^`]+`)", text):
            if part.startswith("**"):
                p.add_run(part[2:-2]).bold = True
            elif part.startswith("`"):
                r = p.add_run(part[1:-1])
                r.font.name = "DejaVu Sans Mono"
                r.font.size = Pt(9)
            else:
                p.add_run(part)

    lines = (ROOT / "docs/rca/USER_GUIDE.md").read_text(encoding="utf-8").splitlines()
    i = 0
    in_code = False
    while i < len(lines):
        line = lines[i]
        i += 1
        if line.startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            p = doc.add_paragraph(style="RCA Code")
            p.add_run(line)
            continue
        if not line.strip():
            continue
        if line.startswith("# "):
            doc.add_paragraph(line[2:], style="Title")
            continue
        if line.startswith("## "):
            heading = doc.add_paragraph(line[3:], style="Heading 1")
            if line[3:] == "Configure and validate factory operation":
                heading.paragraph_format.page_break_before = True
            continue
        if line.startswith("### "):
            doc.add_paragraph(line[4:], style="Heading 2")
            continue
        if line.startswith("|"):
            rows = [line]
            while i < len(lines) and lines[i].startswith("|"):
                rows.append(lines[i])
                i += 1
            cells = [
                [x.strip() for x in row.strip("|").split("|")]
                for row in rows
                if not re.match(r"^\|[\s:|-]+\|$", row)
            ]
            table = doc.add_table(rows=0, cols=len(cells[0]))
            table.autofit = False
            widths = (
                [2.1, 4.7]
                if len(cells[0]) == 2
                else [1.1, 2.4, 3.3]
                if len(cells[0]) == 3
                else [6.8 / len(cells[0])] * len(cells[0])
            )
            for j, w in enumerate(widths):
                table.columns[j].width = Inches(w)
            for index, values in enumerate(cells):
                row = table.add_row()
                props = row._tr.get_or_add_trPr()
                no_split = OxmlElement("w:cantSplit")
                props.append(no_split)
                if index == 0:
                    props.append(OxmlElement("w:tblHeader"))
                for j, text in enumerate(values):
                    cell = row.cells[j]
                    cell.width = Inches(widths[j])
                    p = cell.paragraphs[0]
                    p.paragraph_format.space_after = Pt(5)
                    p.paragraph_format.space_before = Pt(5)
                    p.paragraph_format.line_spacing = 1.08
                    inline(p, text)
                    for r in p.runs:
                        r.font.size = Pt(10)
                        r.bold = index == 0
                    tcpr = cell._tc.get_or_add_tcPr()
                    shade = OxmlElement("w:shd")
                    shade.set(
                        qn("w:fill"),
                        "EFEFEF"
                        if index == 0
                        else "F6F6F6"
                        if index % 2 == 0
                        else "FFFFFF",
                    )
                    tcpr.append(shade)
                    borders = OxmlElement("w:tcBorders")
                    for edge in ["top", "left", "bottom", "right"]:
                        el = OxmlElement("w:" + edge)
                        el.set(qn("w:val"), "single")
                        el.set(qn("w:sz"), "4")
                        el.set(qn("w:color"), "D9D9D9")
                        borders.append(el)
                    tcpr.append(borders)
            doc.add_paragraph().paragraph_format.space_after = Pt(0)
            continue
        p = doc.add_paragraph()
        inline(p, line)
    for root in [doc.styles.element, doc.element]:
        for node in root.xpath(".//w:pBdr"):
            node.getparent().remove(node)
    doc.core_properties.title = "CNC root cause investigation guide"
    doc.core_properties.subject = "Version 11.2 user guide"
    doc.core_properties.author = "CNC Factory Assistant"
    doc.core_properties.comments = ""
    path = ROOT / "docs/rca/RCA_USER_GUIDE.docx"
    doc.save(path)
    print(path)


if __name__ == "__main__":
    main()

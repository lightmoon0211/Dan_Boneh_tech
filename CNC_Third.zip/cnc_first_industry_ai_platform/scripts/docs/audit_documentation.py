#!/usr/bin/env python3
"""Inventory release documentation, examples and script help without running host operations."""

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "docs/v112")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    baseline = json.loads((ROOT / "docs/v112/baseline_inventory.json").read_text())[
        "files"
    ]
    rows, helps = [], []
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(ROOT).as_posix()
        if (
            any(
                x in p.parts
                for x in [
                    "__pycache__",
                    ".pytest_cache",
                    ".ruff_cache",
                    "build",
                    "runtime",
                ]
            )
            or ".egg-info" in rel
        ):
            continue
        if rel.startswith("docs/v112/DOCUMENTATION_") or rel.endswith(
            "script-help.json"
        ):
            continue
        is_doc = p.suffix in [".md", ".docx", ".pdf"]
        is_config = rel.startswith(
            ("config/", "environments/", "requirements/", "deployment/")
        ) or p.name in [".env.example", "pyproject.toml", ".gitignore", ".dockerignore"]
        is_script = rel.startswith("scripts/") or p.suffix == ".bat"
        if not (is_doc or is_config or is_script):
            continue
        digest = hashlib.sha256(p.read_bytes()).hexdigest()
        history = "/history/" in rel
        action = (
            "Historical evidence retained; not current deployment instructions"
            if history
            else "Updated"
            if rel in baseline and baseline[rel] != digest
            else "Preserved after review"
            if rel in baseline
            else "New release artifact"
        )
        scope = (
            "Archived; no new execution claim"
            if history
            else "Current links, paths and release consistency reviewed; see validation report for execution scope"
        )
        if p.suffix in [".docx", ".pdf"] and not history:
            scope = "Rendered final manual; all pages visually inspected; docs/v112/manual-qa.json"
        elif is_config and not history:
            scope = "Manifest/default parity and syntax reviewed; hardware, Windows and Docker execution gates remain explicit"
        elif is_script:
            scope = "Source/AST or shell syntax reviewed; exact execution scope in script-help.json and RELEASE_REPORT.json"
            if p.suffix == ".py" and "ArgumentParser" in p.read_text(encoding="utf-8"):
                result = subprocess.run(
                    [sys.executable, str(p), "--help"],
                    cwd=ROOT,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                helps.append(
                    {
                        "file": rel,
                        "status": "PASS" if result.returncode == 0 else "FAIL",
                        "help": result.stdout,
                        "error": result.stderr,
                    }
                )
                scope += "; --help " + helps[-1]["status"]
        rows.append(
            {"file": rel, "sha256": digest, "action": action, "validation": scope}
        )
    # Core command trees used by current guides. Help has no database or hardware side effects.
    for parts in [
        [],
        ["serve"],
        ["db"],
        ["db", "init"],
        ["db", "migrate"],
        ["user", "add"],
        ["ingest"],
        ["validate"],
        ["rca"],
        ["monitor"],
        ["opcua-simulator"],
    ]:
        result = subprocess.run(
            [sys.executable, "-m", "cnc_ai", *parts, "--help"],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=30,
        )
        helps.append(
            {
                "file": "python -m cnc_ai " + " ".join(parts),
                "status": "PASS" if result.returncode == 0 else "FAIL",
                "help": result.stdout,
                "error": result.stderr,
            }
        )
    (args.output / "script-help.json").write_text(json.dumps(helps, indent=2) + "\n")
    (args.output / "DOCUMENTATION_INVENTORY.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )
    text = """# Documentation audit — v11.2.0

The exact source ZIP and original file hashes are recorded in baseline_inventory.json. The supplied plain-language Word manual and source inspection were located and used. A separate earlier hardware recommendation was not found; the latest supplied specification establishes the new target.

Current instructions describe two four-GPU RTX PRO 6000 Blackwell inference nodes, one CPU authority, independent backup, twelve instances and fifty browser clients. Historical material is explicitly archived or labeled. Existing CNC/component and complete-machine assembly/RCA explanations are retained. Model selection history is not a current compatibility certification.

The matrix inventories every documentation page, editable/rendered manual, configuration example, environment definition and script. Diagrams embedded in Markdown are covered by their containing file. Python help was actually executed where an argument parser exists; fixed database wrappers were inspected without running a data mutation. PowerShell/Conda, physical GPU, site systemd execution and Docker are NOT RUN/BLOCKED here. File hashes are in DOCUMENTATION_INVENTORY.json; these audit files do not hash themselves. Final archive hashes are authoritative after report generation.

Manual review repaired the RCA version/environment instructions, figure caption, and a shell command split across a PDF page. All final 51 main-manual and six RCA pages were inspected. See manual-qa.json. Static links, JSON/default parity, Python AST, JavaScript/Bash syntax and generated assets were checked; see static.json. Commands requiring site hardware/credentials are documented with their acceptance gates rather than labeled executed.

| File | Required change / disposition | Validation outcome / scope |
|---|---|---|
"""
    for row in rows:
        text += (
            "| `"
            + row["file"]
            + "` | "
            + row["action"]
            + " | "
            + row["validation"]
            + " |\n"
        )
    (args.output / "DOCUMENTATION_AUDIT.md").write_text(text)
    failed = [x["file"] for x in helps if x["status"] != "PASS"]
    print(
        json.dumps(
            {"files": len(rows), "help_checks": len(helps), "failures": failed},
            indent=2,
        )
    )
    return bool(failed)


if __name__ == "__main__":
    raise SystemExit(main())

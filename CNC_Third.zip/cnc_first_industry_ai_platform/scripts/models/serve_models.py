#!/usr/bin/env python3
"""Launch vLLM on a Linux host with local paths and graceful child cleanup."""

import argparse
import json
import os
from pathlib import Path
import shlex
import signal
import subprocess
import sys
import time
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[2]


def inference_environment(spec, environment):
    """Keep controller/app credentials and unrelated service keys out of vLLM."""
    allowed = {
        "PATH",
        "HOME",
        "USER",
        "LANG",
        "LC_ALL",
        "LD_LIBRARY_PATH",
        "HF_HOME",
        "XDG_CACHE_HOME",
        "TMPDIR",
        "SSL_CERT_FILE",
        "CUDA_HOME",
    }
    child = {key: value for key, value in environment.items() if key in allowed}
    child.update(
        CUDA_VISIBLE_DEVICES=spec["gpu_ids"],
        HF_HUB_OFFLINE="1",
        TRANSFORMERS_OFFLINE="1",
        VLLM_NO_USAGE_STATS="1",
        DO_NOT_TRACK="1",
        HF_HUB_DISABLE_TELEMETRY="1",
        VLLM_API_KEY=environment.get(spec["key_env"], ""),
    )
    return child


def build_command(key, spec, env):
    root = Path(env.get("MODEL_ROOT", "/srv/ai/models"))
    path = (
        Path(env.get(spec["path_env"], str(root / spec["directory"])))
        .expanduser()
        .resolve()
    )
    cmd = [
        "vllm",
        "serve",
        str(path),
        "--served-model-name",
        spec["model"],
        "--host",
        env.get("MODEL_SERVER_BIND", "127.0.0.1"),
        "--port",
        str(spec["port"]),
        "--tensor-parallel-size",
        str(spec["tensor_parallel"]),
        "--max-model-len",
        str(spec["max_model_len"]),
    ]
    cmd += [
        "--gpu-memory-utilization",
        str(spec.get("gpu_memory_utilization", 0.8)),
        "--max-num-seqs",
        str(spec.get("max_num_seqs", 16)),
    ]
    cmd += ["--dtype", spec.get("dtype", "bfloat16"), "--disable-log-requests"]
    if spec.get("revision"):
        position = cmd.index("--served-model-name") + 2
        cmd.insert(position, spec["model"] + "@" + spec["revision"])
    if key == "conversation" and not env.get("MODEL_ENABLE_VISION") == "true":
        cmd += ["--limit-mm-per-prompt", json.dumps({"image": 0, "video": 0})]
    if key == "reranker":
        cmd += [
            "--runner",
            "pooling",
            "--hf_overrides",
            json.dumps(
                {
                    "architectures": ["Qwen3ForSequenceClassification"],
                    "classifier_from_token": ["no", "yes"],
                    "is_original_qwen3_reranker": True,
                }
            ),
            "--chat-template",
            str(ROOT / "config/qwen3_reranker.jinja"),
        ]
    if key == "embedding":
        cmd += ["--runner", "pooling"]
    if key == "speech":
        cmd += ["--limit-mm-per-prompt", json.dumps({"audio": 1})]
    if key == "code":
        cmd += ["--enable-auto-tool-choice", "--tool-call-parser", "qwen3_coder"]
    return path, cmd


def factory_instance(argv):
    from cnc_ai.deployment import validate_manifest
    from cnc_ai.snapshots import verify_snapshot

    p = argparse.ArgumentParser(
        description="Start exactly one independently supervised factory inference instance."
    )
    p.add_argument("--instance", required=True)
    p.add_argument("--manifest", type=Path, default=ROOT / "config/deployment.json")
    p.add_argument("--env-file", type=Path, default=Path("/etc/cnc-ai/models.env"))
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args(argv)
    load_dotenv(args.env_file, override=False)
    registry = json.loads((ROOT / "config/models.json").read_text())
    data = validate_manifest(
        json.loads(args.manifest.read_text()), registry, qualified=not args.dry_run
    )
    matches = [i for i in data["instances"] if i["id"] == args.instance]
    if not matches:
        raise ValueError("Instance is not in the deployment manifest.")
    item = matches[0]
    role = item["role"]
    spec = dict(registry["services"][role])
    spec.update(
        {
            k: item[k]
            for k in (
                "tensor_parallel",
                "max_model_len",
                "max_num_seqs",
                "gpu_memory_utilization",
            )
        }
    )
    spec.update(
        gpu_ids=",".join(map(str, item["gpu_ids"])),
        port=item["backend_port"],
        revision=data["models"][role]["revision"],
    )
    env = dict(os.environ)
    env["MODEL_SERVER_BIND"] = "127.0.0.1"
    env.setdefault("MODEL_ROOT", data["paths"]["model_root"])
    env[spec["path_env"]] = str(
        Path(env["MODEL_ROOT"]) / data["models"][role]["directory"]
    )
    path, cmd = build_command(role, spec, env)
    print(
        json.dumps(
            {
                "instance": item["id"],
                "gpus": item["gpu_ids"],
                "public_tls_port": item["port"],
                "command": cmd,
                "snapshot_revision": spec["revision"],
                "qualification": data["qualification"],
            }
        ),
        flush=True,
    )
    if args.dry_run:
        return 0
    if os.name == "nt":
        raise ValueError(
            "Factory vLLM serving requires Linux; Windows supports the application and simulator."
        )
    if len(env.get(spec["key_env"], "")) < 24:
        raise ValueError("Provision a distinct strong model service credential.")
    verify_snapshot(env["MODEL_ROOT"], role, data["models"][role], deep=True)
    child = inference_environment(spec, env)
    os.execvpe(cmd[0], cmd, child)
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--instance" in argv:
        try:
            return factory_instance(argv)
        except Exception as exc:
            print("ERROR: " + str(exc), file=sys.stderr)
            return 1
    if argv and argv[0] in {"server-a", "server-b"}:
        print(
            "Host-group launching was replaced in v11.2. Use scripts/deployment/manage.py and independently supervised --instance services. See docs/SERVER_INSTALLATION.md.",
            file=sys.stderr,
        )
        return 1

    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "target",
        choices=[
            "server-a",
            "server-b",
            "conversation",
            "code",
            "safety",
            "embedding",
            "reranker",
            "sqlcoder",
            "speech",
        ],
    )
    p.add_argument("--config", type=Path, default=None)
    p.add_argument(
        "--env-file",
        type=Path,
        default=ROOT / ".env",
        help="Model-only configuration for a separate inference OS account",
    )
    p.add_argument("--dry-run", action="store_true")
    p.add_argument(
        "--with-optional",
        action="append",
        choices=["sqlcoder", "speech"],
        default=[],
        help="Add a specialist when starting a host group",
    )
    args = p.parse_args(argv)
    load_dotenv(args.env_file, override=False)
    config_path = args.config or Path(
        os.getenv("CNC_MODEL_CONFIG", str(ROOT / "config/models.json"))
    )
    if not config_path.is_absolute():
        config_path = ROOT / config_path
    registry = json.loads(config_path.read_text())
    keys = registry["hosts"].get(args.target, [args.target])
    if args.with_optional and args.target not in registry["hosts"]:
        p.error("--with-optional requires server-a or server-b")
    keys = list(dict.fromkeys([*keys, *args.with_optional]))
    children = []
    handles = []
    if os.name == "nt" and not args.dry_run:
        p.error("Run vLLM in Linux/WSL2; Windows runs the application client.")
    try:
        allocated = set()
        for key in keys:
            spec = dict(
                {**registry["services"], **registry.get("optional_services", {})}[key]
            )
            for field, suffix, cast in [
                ("gpu_ids", "GPU_IDS", str),
                ("tensor_parallel", "TP", int),
                ("max_model_len", "MAX_MODEL_LEN", int),
                ("gpu_memory_utilization", "GPU_MEMORY_UTILIZATION", float),
                ("max_num_seqs", "MAX_NUM_SEQS", int),
            ]:
                if key.upper() + "_" + suffix in os.environ:
                    spec[field] = cast(os.environ[key.upper() + "_" + suffix])
            path, cmd = build_command(key, spec, os.environ)
            ids = spec["gpu_ids"].split(",")
            if (
                not all(x.isdigit() for x in ids)
                or len(ids) != len(set(ids))
                or len(ids) != spec["tensor_parallel"]
            ):
                raise ValueError(
                    "GPU IDs must be unique integers and match tensor parallel size."
                )
            if allocated.intersection(ids):
                raise ValueError(
                    "GPU allocation overlaps within this launch group. Review the profile or optional services."
                )
            allocated.update(ids)
            print(f"{key}: GPUs {spec['gpu_ids']}; " + shlex.join(cmd), flush=True)
            if args.dry_run:
                continue
            if not path.is_dir() or not (path / "config.json").is_file():
                raise ValueError(f"Local model is incomplete or missing: {path}")
            bind = os.getenv("MODEL_SERVER_BIND", "127.0.0.1")
            if bind not in {"127.0.0.1", "localhost", "::1"} and not os.getenv(
                spec["key_env"]
            ):
                raise ValueError(
                    f"{spec['key_env']} is required for LAN inference serving"
                )
            # vLLM reads VLLM_API_KEY; keep secrets out of command lines and logs.
            child_env = inference_environment(spec, os.environ)
            directory = Path(
                os.getenv("MODEL_LOG_DIR", str(ROOT / "runtime/model_logs"))
            )
            directory.mkdir(parents=True, exist_ok=True)
            handle = (directory / (key + ".log")).open("a")
            handles.append(handle)
            children.append(
                subprocess.Popen(
                    cmd, env=child_env, stdout=handle, stderr=subprocess.STDOUT
                )
            )
        if args.dry_run:
            return 0

        def stop(signum, frame):
            raise KeyboardInterrupt

        signal.signal(signal.SIGTERM, stop)
        while children:
            if any(child.poll() is not None for child in children):
                raise RuntimeError(
                    "An inference process exited. Inspect runtime/model_logs; the other child services will stop."
                )
            time.sleep(1)
    except KeyboardInterrupt:
        print("Stopping model services...", flush=True)
    except Exception as exc:
        print("ERROR: " + str(exc), file=sys.stderr)
        return 1
    finally:
        for child in children:
            if child.poll() is None:
                child.terminate()
        for child in children:
            try:
                child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
        for handle in handles:
            handle.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Download configured physical models with persistent commit pins and restart-safe Hub caches."""

from __future__ import annotations
import argparse
import fnmatch
import shutil
import hashlib
import json
import os
from pathlib import Path
import random
import re
import sys
import time

ROOT = Path(__file__).resolve().parents[2]


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    with temporary.open("w", encoding="utf-8") as h:
        json.dump(value, h, indent=2)
        h.flush()
        os.fsync(h.fileno())
    temporary.replace(path)


def file_hash(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def retry(operation, retries=20, base_delay=5, sleep=time.sleep):
    failures = 0
    while True:
        try:
            return operation()
        except KeyboardInterrupt:
            raise
        except Exception as exc:
            status = getattr(getattr(exc, "response", None), "status_code", None)
            if status in {400, 401, 403, 404} or isinstance(
                exc, (PermissionError, ValueError)
            ):
                raise
            if isinstance(exc, OSError) and getattr(exc, "errno", None) in {13, 28}:
                raise
            failures += 1
            if retries and failures > retries:
                raise
            delay = min(60, base_delay * 2 ** min(failures - 1, 5)) + random.uniform(
                0, 1
            )
            print(
                f"Connection interrupted ({type(exc).__name__}). Retry {failures} in {delay:.0f}s. Existing files and partial downloads are retained.",
                flush=True,
            )
            sleep(delay)


def verify(directory, manifest, deep=False):
    if not manifest.get("files"):
        return ["Manifest has no files; complete the download first."]
    failures = []
    for name, meta in manifest.get("files", {}).items():
        file = (directory / name).resolve()
        if not file.is_relative_to(directory.resolve()):
            raise ValueError("Manifest path escapes model directory.")
        if not file.is_file() or file.stat().st_size != meta["size"]:
            failures.append(name)
            continue
        if deep and (not meta.get("sha256") or file_hash(file) != meta["sha256"]):
            failures.append(name)
    return failures


def download_one(key, spec, root, args, api, snapshot):
    directory = (root / spec["directory"]).resolve()
    if not directory.is_relative_to(root.resolve()) or directory.is_relative_to(ROOT):
        raise ValueError("Model directory must stay within the external model root.")
    state = root / ".factory-downloads" / (key + ".json")
    saved = json.loads(state.read_text()) if state.exists() else {}
    if saved and saved.get("repo_id") != spec["model"]:
        # A code-profile change must retain the older pinned model and partial cache.
        state = state.with_name(
            key
            + "-"
            + hashlib.sha256(spec["model"].encode()).hexdigest()[:12]
            + ".json"
        )
        saved = json.loads(state.read_text()) if state.exists() else {}
        if saved and saved.get("repo_id") != spec["model"]:
            raise ValueError("Model download state identity mismatch.")
    if args.verify:
        if not saved.get("complete"):
            raise ValueError(f"{key}: no completed download manifest exists.")
        failures = verify(directory, saved, args.checksums)
        if failures:
            raise ValueError("Missing or changed files: " + ", ".join(failures[:10]))
        print(
            f"{key}: local manifest verified ({len(saved['files'])} files).", flush=True
        )
        return
    includes = getattr(args, "include", None) or saved.get("include_patterns") or []
    excludes = (
        getattr(args, "exclude", None)
        or saved.get("exclude_patterns")
        or spec.get("exclude_patterns", [])
    )
    if saved and (
        saved.get("include_patterns", []) != includes
        or saved.get("exclude_patterns", []) != excludes
    ):
        raise ValueError(
            "This model directory is pinned to another file selection. Use a new root for a different selection."
        )

    def selected(name):
        return (
            not includes or any(fnmatch.fnmatch(name, p) for p in includes)
        ) and not any(fnmatch.fnmatch(name, p) for p in excludes)

    revision = args.revision or saved.get("commit") or spec.get("revision", "main")
    if saved.get("commit") and args.revision and args.revision != saved["commit"]:
        raise ValueError(
            "This model root is pinned to another commit. Use a separate root for a model revision change."
        )
    info = retry(
        lambda: api.model_info(spec["model"], revision=revision, files_metadata=True),
        args.retries,
    )
    commit = info.sha
    siblings = [f for f in info.siblings if selected(f.rfilename)]
    if not siblings:
        raise ValueError("Include/exclude patterns selected no files.")
    remaining = 0
    for f in siblings:
        file = (directory / f.rfilename).resolve()
        if not file.is_relative_to(directory):
            raise ValueError("Model file escapes the destination.")
        remaining += max(
            0, (f.size or 0) - (file.stat().st_size if file.is_file() else 0)
        )
    free = shutil.disk_usage(root).free
    print(
        f"  Disk check: {free / 2**30:.1f} GiB free; at least {remaining / 2**30:.1f} GiB remaining, plus cache/working space.",
        flush=True,
    )
    if free < remaining + min(1024**3, max(1, remaining // 10)):
        raise OSError(28, "Insufficient free disk space for the selected model files.")
    # Pin the exact commit before any large transfer. Reboots resume the same snapshot.
    pending = {
        "repo_id": spec["model"],
        "commit": commit,
        "complete": False,
        "include_patterns": includes,
        "exclude_patterns": excludes,
        "files": saved.get("files", {}),
    }
    atomic_json(state, pending)
    print(
        f"[{key}] {spec['model']}\n  Directory: {directory}\n  Commit: {commit}\n  Re-run this same command after interruption; do not delete its cache.",
        flush=True,
    )
    retry(
        lambda: snapshot(
            repo_id=spec["model"],
            revision=commit,
            local_dir=str(directory),
            max_workers=args.workers,
            token=os.getenv("HF_TOKEN") or None,
            allow_patterns=includes or None,
            ignore_patterns=excludes or None,
        ),
        args.retries,
    )
    files = {}
    for sibling in siblings:
        name = sibling.rfilename
        path = (directory / name).resolve()
        if not path.is_relative_to(directory.resolve()):
            raise ValueError("Repository path escapes model directory.")
        if not path.is_file() or (
            sibling.size is not None and path.stat().st_size != sibling.size
        ):
            raise ValueError(
                "Downloaded file is missing or has the wrong size: " + name
            )
        meta = {"size": path.stat().st_size}
        if args.checksums:
            print("  Hashing " + name, flush=True)
            meta["sha256"] = file_hash(path)
            lfs = getattr(sibling, "lfs", None)
            expected = (
                lfs.get("sha256")
                if isinstance(lfs, dict)
                else getattr(lfs, "sha256", None)
            )
            if expected and expected != meta["sha256"]:
                raise ValueError("Hub checksum mismatch: " + name)
        files[name] = meta
    pending.update(complete=True, files=files)
    atomic_json(state, pending)
    print(
        f"[{key}] COMPLETE: {len(files)} files. Model weights remain outside the repository.",
        flush=True,
    )


def main(argv=None):
    try:
        from dotenv import load_dotenv
    except ImportError:
        print(
            "Install download dependencies: python -m pip install -r requirements/download.txt",
            file=sys.stderr,
        )
        return 2
    load_dotenv(ROOT / ".env", override=False)
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "model",
        choices=[
            "all",
            "conversation",
            "code",
            "safety",
            "embedding",
            "reranker",
            "chronos",
            "timesfm",
            "moirai",
            "sqlcoder",
            "speech",
            "code-next",
        ],
    )
    p.add_argument(
        "--model-root",
        default=os.getenv("MODEL_ROOT", str(Path.home() / "AI" / "models")),
    )
    p.add_argument(
        "--include",
        action="append",
        help="Include a Hub filename glob; repeat for more patterns",
    )
    p.add_argument(
        "--exclude",
        action="append",
        help="Exclude a Hub filename glob; repeat for more patterns",
    )
    p.add_argument(
        "--config",
        type=Path,
        default=Path(os.getenv("CNC_MODEL_CONFIG", str(ROOT / "config/models.json"))),
    )
    p.add_argument(
        "--retries",
        type=int,
        default=20,
        help="Retries per operation; 0 retries indefinitely",
    )
    p.add_argument(
        "--workers",
        type=int,
        default=2,
        help="Concurrent files; use 1 on unstable connections",
    )
    p.add_argument(
        "--revision",
        help="Commit SHA or revision for one model; new model root recommended",
    )
    p.add_argument(
        "--verify",
        action="store_true",
        help="Verify local completed manifests without internet",
    )
    p.add_argument(
        "--checksums",
        action="store_true",
        help="Record/check SHA256 file hashes; slower for large weights",
    )
    p.add_argument(
        "--with-optional",
        action="append",
        choices=["sqlcoder", "speech"],
        default=[],
        help="Add a specialist to all mode; unused candidates are never downloaded",
    )
    args = p.parse_args(argv)
    if args.with_optional and args.model != "all":
        p.error("--with-optional requires all mode")
    if args.model == "all" and args.revision:
        p.error("--revision applies to an individual model")
    if args.workers < 1 or args.retries < 0:
        p.error("workers must be positive and retries non-negative")
    if os.name != "nt" and re.match(r"^[A-Za-z]:", args.model_root):
        p.error(
            "Use a Linux path on this host, such as /srv/ai/models or /mnt/f/AI/models"
        )
    root = Path(args.model_root).expanduser().resolve()
    if root.is_relative_to(ROOT):
        p.error("Model root must be outside the project/Git repository")
    root.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("HF_HUB_DOWNLOAD_TIMEOUT", "120")
    os.environ.setdefault("HF_HUB_ETAG_TIMEOUT", "30")
    os.environ.setdefault("HF_HUB_DISABLE_XET", "1")
    # Import after environment setup: Hub reads timeout/transport configuration at import time.
    from huggingface_hub import HfApi, snapshot_download
    from filelock import FileLock, Timeout

    config_path = args.config if args.config.is_absolute() else ROOT / args.config
    config = json.loads(config_path.read_text(encoding="utf-8"))
    registry = {
        **config["services"],
        **config.get("optional_services", {}),
        **config.get("optional_downloads", {}),
    }
    keys = list(config["services"]) if args.model == "all" else [args.model]
    keys = list(dict.fromkeys([*keys, *args.with_optional]))
    try:
        with FileLock(str(root / ".factory-download.lock"), timeout=1):
            for key in keys:
                download_one(
                    key,
                    registry[key],
                    root,
                    args,
                    HfApi(token=os.getenv("HF_TOKEN") or None),
                    snapshot_download,
                )
    except KeyboardInterrupt:
        print(
            "\nPaused. Completed files and partial data remain on disk. Re-run the same command to resume.",
            flush=True,
        )
        return 130
    except Timeout:
        print(
            "Another factory-model download is using this root. Let it finish or stop it first.",
            file=sys.stderr,
        )
        return 2
    except Exception as exc:
        detail = str(exc)[:300]
        token = os.getenv("HF_TOKEN", "")
        if token:
            detail = detail.replace(token, "[redacted]")
        print(
            f"Download stopped: {type(exc).__name__}. Check access, disk space and network. Re-run the same command to resume. Details: {detail}",
            file=sys.stderr,
        )
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Consistent stopped-authority backup and restore into an EMPTY destination only."""

import argparse, hashlib, json, shutil, sqlite3
from contextlib import ExitStack
from pathlib import Path
from filelock import FileLock


def verify(root):
    manifest = json.loads((root / "SHA256SUMS.json").read_text())
    files = set()
    for f in root.rglob("*"):
        if f.is_symlink():
            raise ValueError("Backup may not contain symlinks.")
        if f.is_file() and f.name != "SHA256SUMS.json":
            files.add(f.relative_to(root).as_posix())
    if files != set(manifest["files"]):
        raise ValueError("Backup contains missing or unmanifested files.")
    for name, meta in manifest["files"].items():
        path = (root / name).resolve()
        if (
            not path.is_relative_to(root.resolve())
            or path.is_symlink()
            or not path.is_file()
        ):
            raise ValueError("Backup path invalid.")
        with path.open("rb") as f:
            sha = hashlib.file_digest(f, "sha256").hexdigest()
        if sha != meta["sha256"] or path.stat().st_size != meta["size"]:
            raise ValueError("Backup checksum mismatch.")
    return manifest


def backup(data, config, destination):
    if destination.exists():
        raise FileExistsError(
            "Choose a new backup directory on protected independent storage."
        )
    data, config = data.resolve(), config.resolve()
    if destination.resolve().is_relative_to(
        data
    ) or destination.resolve().is_relative_to(config):
        raise ValueError("Backup destination must be outside the source trees.")
    with ExitStack() as stack:
        for name in ["application-authority.lock", "telemetry-authority.lock"]:
            stack.enter_context(FileLock(str(data / name), timeout=0))
        destination.mkdir(mode=0o700, parents=True)
        for prefix, root in [("data", data), ("configuration", config)]:
            for src in root.rglob("*"):
                if src.is_symlink():
                    raise ValueError(
                        "Resolve and review symlink before backup: " + str(src)
                    )
                if not src.is_file() or src.name.endswith(("-wal", "-shm", ".lock")):
                    continue
                rel = Path(prefix) / src.relative_to(root)
                dst = destination / rel
                dst.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                if src.suffix == ".db":
                    with (
                        sqlite3.connect(
                            "file:" + src.as_posix() + "?mode=ro", uri=True
                        ) as read,
                        sqlite3.connect(dst) as write,
                    ):
                        read.backup(write)
                else:
                    shutil.copy2(src, dst)
                dst.chmod(0o600)
        manifest = {"release": "11.2.0", "single_authority_required": True, "files": {}}
        for f in sorted(destination.rglob("*")):
            if f.is_file():
                with f.open("rb") as stream:
                    sha = hashlib.file_digest(stream, "sha256").hexdigest()
                manifest["files"][f.relative_to(destination).as_posix()] = {
                    "sha256": sha,
                    "size": f.stat().st_size,
                }
        (destination / "SHA256SUMS.json").write_text(
            json.dumps(manifest, indent=2) + "\n"
        )
        verify(destination)
    return {
        "status": "PASS",
        "files": len(manifest["files"]),
        "message": "Restore requires fencing the old authority and explicit controller reconciliation. Backup contains secrets: protect and encrypt its storage.",
    }


def restore(source, destination):
    verify(source)
    if destination.exists():
        raise FileExistsError(
            "Restore destination must not exist; no active data will be overwritten."
        )
    shutil.copytree(source, destination)
    destination.chmod(0o700)
    return {
        "status": "PASS",
        "message": "Restored offline only. Keep writes disabled, provision ownership, fence old host, migrate and reconcile before starting.",
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    s = p.add_subparsers(dest="action", required=True)
    b = s.add_parser("create")
    b.add_argument("--data", type=Path, required=True)
    b.add_argument("--config", type=Path, required=True)
    b.add_argument("--destination", type=Path, required=True)
    r = s.add_parser("restore")
    r.add_argument("--source", type=Path, required=True)
    r.add_argument("--destination", type=Path, required=True)
    v = s.add_parser("verify")
    v.add_argument("--source", type=Path, required=True)
    a = p.parse_args()
    result = (
        backup(a.data, a.config, a.destination)
        if a.action == "create"
        else restore(a.source, a.destination)
        if a.action == "restore"
        else verify(a.source)
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Deterministic static release checks; no model, network or controller activity."""

import ast, hashlib, json, re, subprocess, sys, tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def main():
    checks = []

    def record(name, count):
        checks.append({"check": name, "status": "PASS", "count": count})

    files = [
        p
        for folder in ("src", "tests", "scripts")
        for p in (ROOT / folder).rglob("*.py")
        if "__pycache__" not in p.parts
    ]
    for p in files:
        ast.parse(p.read_text(encoding="utf-8"), filename=str(p))
    record("Python AST", len(files))
    files = list((ROOT / "config").glob("*.json"))
    for p in files:
        obj = json.loads(p.read_text())
        packaged = ROOT / "src/cnc_ai/resources" / p.name
        if packaged.exists():
            assert obj == json.loads(packaged.read_text()), (
                "Packaged default differs: " + p.name
            )
    record("JSON and packaged default parity", len(files))
    metadata = tomllib.loads((ROOT / "pyproject.toml").read_text())
    version = (ROOT / "VERSION").read_text().strip()
    assert version == metadata["project"]["version"] == "11.2.0"
    record("Version/TOML", 1)
    import yaml

    yaml_files = [
        *(ROOT / "environments").glob("*.yml"),
        *(ROOT / "deployment").rglob("*.yml"),
    ]
    for p in yaml_files:
        assert isinstance(yaml.safe_load(p.read_text()), dict), str(p)
    record("Conda/Compose YAML parse only", len(yaml_files))

    js = list((ROOT / "src/cnc_ai/web/static").glob("*.js"))
    for p in js:
        subprocess.run(["node", "--check", str(p)], check=True, capture_output=True)
    record("JavaScript syntax", len(js))
    shells = list((ROOT / "scripts/linux").glob("*.sh"))
    for p in shells:
        subprocess.run(["bash", "-n", str(p)], check=True, capture_output=True)
    record("Bash syntax", len(shells))
    from cnc_ai.deployment import validate_manifest

    m = validate_manifest(
        json.loads((ROOT / "config/deployment.json").read_text()),
        json.loads((ROOT / "config/models.json").read_text()),
    )
    assert (
        len(m["instances"]) == 12
        and sum(x["gpu_count"] for x in m["hosts"].values()) == 8
    )
    generated = json.loads((ROOT / "deployment/generated/generation.json").read_text())
    assert (
        generated["manifest_sha256"]
        == hashlib.sha256(json.dumps(m, sort_keys=True).encode()).hexdigest()
    )
    record("Generated assets/manifest parity", 12)
    broken = []
    links = 0
    for p in [
        ROOT / "README.md",
        ROOT / "START_HERE.md",
        *(ROOT / "docs").rglob("*.md"),
    ]:
        if "history" in p.parts:
            continue
        for target in re.findall(r"\]\(([^)]+)\)", p.read_text()):
            if target.startswith(("http:", "https:", "#", "mailto:")):
                continue
            target = target.split("#")[0]
            links += 1
            if target and not (p.parent / target).exists():
                broken.append([str(p.relative_to(ROOT)), target])
    assert not broken, "Broken current documentation targets: " + json.dumps(broken)
    record("Current Markdown local links", links)
    import tempfile
    from cnc_ai.config import Settings
    from cnc_ai.database import Database

    with tempfile.TemporaryDirectory() as tmp:
        home = Path(tmp)
        db = Database(
            Settings(home, home / "runtime", ROOT / "config", model_mode="demo")
        )
        db.initialize(sample=True)
        with db.connect() as c:
            assert c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert db.verify_audit()["valid"]
    record("Packaged sample initialization/integrity/audit", 1)
    output = ROOT / "docs/v112/static.json"
    output.write_text(json.dumps({"status": "PASS", "checks": checks}, indent=2) + "\n")
    print(json.dumps(checks, indent=2))


if __name__ == "__main__":
    main()

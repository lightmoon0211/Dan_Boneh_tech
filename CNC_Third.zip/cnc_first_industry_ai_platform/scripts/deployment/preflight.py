#!/usr/bin/env python3
"""Read-only host preflight. Never changes GPU power, policies or application data."""

import argparse, json, os, platform, shutil, socket, subprocess, sys
from pathlib import Path
from dotenv import load_dotenv
from cnc_ai.deployment import validate_manifest
from cnc_ai.snapshots import verify_snapshot

ROOT = Path(__file__).resolve().parents[2]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--host", choices=["ai-a", "ai-b", "app"], required=True)
    p.add_argument("--manifest", type=Path, default=ROOT / "config/deployment.json")
    p.add_argument("--env-file", type=Path, required=True)
    p.add_argument("--output", type=Path)
    p.add_argument("--check-ports-free", action="store_true")
    p.add_argument("--deep", action="store_true")
    p.add_argument("--transfer", type=Path)
    a = p.parse_args()
    load_dotenv(a.env_file, override=False)
    checks = []

    def run(name, fn):
        try:
            detail = fn()
            checks.append({"check": name, "status": "PASS", "detail": detail})
        except Exception as exc:
            checks.append(
                {
                    "check": name,
                    "status": "BLOCKED",
                    "detail": type(exc).__name__ + ": " + str(exc)[:200],
                }
            )

    registry = json.loads((ROOT / "config/models.json").read_text())
    m = json.loads(a.manifest.read_text())
    run("manifest", lambda: bool(validate_manifest(m, registry, True)))
    run(
        "host platform",
        lambda: (
            platform.platform()
            if platform.machine() == "x86_64" and platform.system() == "Linux"
            else (_ for _ in ()).throw(
                ValueError("Production requires qualified x86_64 Linux.")
            )
        ),
    )

    def files():
        for path in [
            a.env_file,
            Path(m["paths"]["configuration"]) / "tls/server.crt",
            Path(m["paths"]["configuration"]) / "tls/server.key",
        ]:
            if not path.is_file():
                raise ValueError("Required host credential/certificate file missing.")
            if path.suffix == ".key" or path == a.env_file:
                if path.stat().st_mode & 0o007:
                    raise ValueError(
                        "A protected configuration file is accessible to other users."
                    )
        for role, spec in registry["services"].items():
            if len(os.getenv(spec["key_env"], "")) < 24:
                raise ValueError("Missing/short service key for " + role)
        return "Credentials present; content suppressed."

    run("protected secrets and TLS files", files)

    def cert():
        r = subprocess.run(
            [
                "openssl",
                "x509",
                "-in",
                str(Path(m["paths"]["configuration"]) / "tls/server.crt"),
                "-noout",
                "-checkend",
                "604800",
            ],
            capture_output=True,
            text=True,
            check=True,
        )
        return "Certificate valid beyond seven days; chain and hostname still require live TLS probe."

    run("certificate expiry", cert)
    if a.host != "app":

        def gpu():
            raw = subprocess.check_output(
                [
                    "nvidia-smi",
                    "--query-gpu=index,name,memory.total,driver_version,power.limit",
                    "--format=csv,noheader,nounits",
                ],
                text=True,
            )
            rows = [x.split(",") for x in raw.strip().splitlines()]
            if len(rows) != 4 or any(
                "RTX PRO 6000 Blackwell Server Edition" not in r[1]
                or float(r[2]) < 90000
                or int(r[3].strip().split(".")[0])
                < m["runtime_candidate"]["driver_min_major"]
                for r in rows
            ):
                raise ValueError(
                    "GPU inventory/memory/driver differs from the required profile."
                )
            return raw.strip().splitlines()

        run("GPU inventory driver and approved power record", gpu)

        def runtime():
            import torch, transformers, importlib.metadata

            if importlib.metadata.version("vllm") != m["runtime_candidate"]["vllm"]:
                raise ValueError(
                    "Serving version differs from candidate/qualified lock."
                )
            if not torch.version.cuda or tuple(
                map(int, torch.version.cuda.split(".")[:2])
            ) < (12, 8):
                raise ValueError("CUDA runtime is too old for Blackwell.")
            if (
                torch.__version__.split("+")[0] != m["runtime_candidate"]["pytorch"]
                or torch.version.cuda != m["runtime_candidate"]["cuda"]
            ):
                raise ValueError(
                    "PyTorch/CUDA build differs from the reviewed candidate; qualify and lock the complete stack."
                )
            if tuple(map(int, transformers.__version__.split(".")[:2])) < (5, 8):
                raise ValueError("Qwen3.8 requires Transformers 5.8 or later.")
            if platform.python_version_tuple()[:2] != ("3", "12"):
                raise ValueError("Candidate runtime requires Python 3.12.")
            for index in range(4):
                if torch.cuda.get_device_capability(index) != (12, 0):
                    raise ValueError("Expected sm_120 GPU.")
                with torch.cuda.device(index):
                    x = torch.ones((128, 128), device="cuda", dtype=torch.bfloat16)
                    y = x @ x
                    torch.cuda.synchronize()
                    if float(y[0, 0]) != 128:
                        raise ValueError("BF16 device kernel check failed.")
            return {
                "torch": torch.__version__,
                "cuda": torch.version.cuda,
                "transformers": transformers.__version__,
                "note": "BF16 matmul only; model-specific kernels checked by probe.py.",
            }

        run("Blackwell runtime smoke", runtime)
        root = Path(os.getenv("MODEL_ROOT", m["paths"]["model_root"]))
        run(
            "model disk headroom",
            lambda: (
                shutil.disk_usage(root).free
                if shutil.disk_usage(root).free >= 100 * 1024**3
                else (_ for _ in ()).throw(
                    ValueError(
                        "At least 100 GiB free model/cache staging headroom required."
                    )
                )
            ),
        )
        for role, model in m["models"].items():
            run(
                "snapshot " + role,
                lambda r=role, mo=model: verify_snapshot(root, r, mo, a.deep),
            )
    else:
        from cnc_ai.config import Settings
        from cnc_ai.database import Database

        run("application database", lambda: Database(Settings.load()).stats())

        def network():
            for host in ["ai-a", "ai-b"]:
                socket.getaddrinfo(m["hosts"][host]["hostname"], None)
                for i in m["instances"]:
                    if i["host"] == host:
                        with socket.create_connection(
                            (m["hosts"][host]["hostname"], i["port"]), timeout=3
                        ):
                            pass
            return "TCP reachable; run probe.py to verify TLS/model contracts."

        run("inference connectivity", network)
    if a.check_ports_free:

        def ports():
            for i in m["instances"]:
                if i["host"] == a.host:
                    for port in [i["port"], i["backend_port"]]:
                        with socket.socket() as s:
                            s.bind(("127.0.0.1", port))
            return "Required inference ports are free."

        run("free service ports", ports)
    if a.transfer:
        run(
            "offline transfer checksums",
            lambda: subprocess.run(
                [
                    sys.executable,
                    str(ROOT / "scripts/verify_bundle.py"),
                    str(a.transfer),
                ],
                capture_output=True,
                text=True,
                check=True,
            ).stdout[-300:],
        )
    else:
        checks.append(
            {
                "check": "offline OS runtime wheels and rollback inventory",
                "status": "NOT RUN",
                "detail": "Supply --transfer and perform the documented disconnected cold start.",
            }
        )
    result = {
        "host": a.host,
        "checks": checks,
        "qualification": "This is preflight, not whole-system or load qualification.",
    }
    text = json.dumps(result, indent=2)
    print(text)
    if a.output:
        a.output.write_text(text + "\n")
    return int(any(c["status"] != "PASS" for c in checks))


if __name__ == "__main__":
    raise SystemExit(main())

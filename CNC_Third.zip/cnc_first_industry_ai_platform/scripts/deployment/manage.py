#!/usr/bin/env python3
"""Local host service operations in manifest startup order. Drain on the app first."""

import argparse, json, subprocess
from pathlib import Path
from cnc_ai.deployment import validate_manifest

ROOT = Path(__file__).resolve().parents[2]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("action", choices=["start", "stop", "restart", "status"])
    p.add_argument("--host", choices=["ai-a", "ai-b", "app"], required=True)
    p.add_argument("--manifest", type=Path, default=ROOT / "config/deployment.json")
    p.add_argument("--dry-run", action="store_true")
    a = p.parse_args()
    data = validate_manifest(
        json.loads(a.manifest.read_text()),
        json.loads((ROOT / "config/models.json").read_text()),
    )
    instances = sorted(
        [i for i in data["instances"] if i["host"] == a.host],
        key=lambda i: i["startup_order"],
        reverse=a.action == "stop",
    )
    units = (
        ["cnc-ai.service"]
        if a.host == "app"
        else ["cnc-model-" + i["id"] + ".service" for i in instances]
    )
    for unit in units:
        cmd = ["systemctl", a.action, unit]
        print(" ".join(cmd), flush=True)
        if not a.dry_run:
            subprocess.run(cmd, check=True)


if __name__ == "__main__":
    main()

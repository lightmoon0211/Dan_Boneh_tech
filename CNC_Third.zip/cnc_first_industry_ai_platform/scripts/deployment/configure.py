#!/usr/bin/env python3
"""Validate or generate host-specific systemd, TLS proxy and environment templates."""

import argparse
import hashlib
import json
from pathlib import Path
from cnc_ai.deployment import validate_manifest
from cnc_ai.snapshots import verify_snapshot

ROOT = Path(__file__).resolve().parents[2]


def generate(data, output):
    output.mkdir(parents=True, exist_ok=True)
    manifest_hash = hashlib.sha256(
        json.dumps(data, sort_keys=True).encode()
    ).hexdigest()
    for host in ["ai-a", "ai-b"]:
        folder = output / host
        folder.mkdir(exist_ok=True)
        services = sorted(
            [i for i in data["instances"] if i["host"] == host],
            key=lambda i: i["startup_order"],
        )
        nginx = ["# Generated from deployment.json. Install inside nginx http context."]
        env = [
            "# Model account only. Supply these secrets on this host, never in Git.",
            "MODEL_ROOT=" + data["paths"]["model_root"],
        ]
        for role in data["models"]:
            env.append(role.upper() + "_API_KEY=")
        (folder / "models.env.example").write_text("\n".join(env) + "\n")
        for item in services:
            name = item["id"]
            after = "network-online.target"
            # Ordering does not bind lifecycles. A failure does not stop any other unit.
            previous = (
                next(
                    (
                        i
                        for i in services
                        if i["startup_order"] == item["startup_order"] - 1
                        and i["sharing_group"] == item["sharing_group"]
                    ),
                    None,
                )
                if item["startup_order"] > 1
                else None
            )
            if previous:
                after += " cnc-model-" + previous["id"] + ".service"
            unit = f"""[Unit]
Description=CNC inference {name}
After={after}
[Service]
Type=simple
User=cncmodels
Group=cncmodels
WorkingDirectory=/opt/cnc-ai
Environment=HF_HOME=/var/lib/cnc-models/{name}/hf XDG_CACHE_HOME=/var/lib/cnc-models/{name}/cache
StateDirectory=cnc-models/{name}
ExecStart=/opt/conda/envs/smartfactorymodels/bin/python /opt/cnc-ai/scripts/models/serve_models.py --instance {name} --manifest /etc/cnc-ai/deployment.json --env-file /etc/cnc-ai/models.env
ExecStartPost=/opt/conda/envs/smartfactorymodels/bin/python /opt/cnc-ai/scripts/deployment/probe.py --manifest /etc/cnc-ai/deployment.json --env-file /etc/cnc-ai/models.env --instance {name} --local --wait-seconds 600
TimeoutStartSec=900
Restart=on-failure
RestartSec=15
TimeoutStopSec=90
KillMode=control-group
UMask=0077
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
ReadWritePaths=/var/lib/cnc-models/{name}
ReadOnlyPaths={data["paths"]["model_root"]}
StandardOutput=journal
StandardError=journal
[Install]
WantedBy=multi-user.target
"""
            (folder / ("cnc-model-" + name + ".service")).write_text(unit)
            nginx.append(f"""server {{
 listen {item["port"]} ssl;
 server_name {data["hosts"][host]["hostname"]};
 ssl_certificate /etc/cnc-ai/tls/server.crt;
 ssl_certificate_key /etc/cnc-ai/tls/server.key;
 ssl_protocols TLSv1.2 TLSv1.3;
 allow {data["hosts"]["app"]["ip"]};
 deny all;
 client_max_body_size 8m;
 access_log off;
 location / {{
  proxy_pass http://127.0.0.1:{item["backend_port"]};
  proxy_set_header Host $host;
  proxy_read_timeout 65s;
  proxy_connect_timeout 3s;
  proxy_buffering on;
 }}
}}""")
        (folder / "nginx-models.conf").write_text("\n".join(nginx) + "\n")
    app = output / "app"
    app.mkdir(exist_ok=True)
    (app / "app.env.example").write_text(
        """CNC_HOME=/etc/cnc-ai
CNC_CONFIG_DIR=/opt/cnc-ai/config
CNC_DATA_DIR=/var/lib/cnc-ai
CNC_DEPLOYMENT_MANIFEST=/etc/cnc-ai/deployment.json
CNC_PROFILE=factory
CNC_MODEL_MODE=local
CNC_OPCUA_MODE=simulator
CNC_REAL_WRITES_ENABLED=false
CNC_SITE_COMMISSIONED=false
CNC_COOKIE_SECURE=true
CNC_TRUST_PROXY=true
CNC_HOST=127.0.0.1
CNC_PORT=5000
CNC_INFERENCE_CA=/etc/cnc-ai/tls/ca.crt
# Set an approved historian separately; SQLite is explicit for initial local validation.
CNC_HISTORIAN_BACKEND=sqlite
CNC_TIMESERIES_TRANSPORT=inprocess
"""
        + "".join(k.upper() + "_API_KEY=\n" for k in data["models"])
    )
    appunit = """[Unit]
Description=Single CNC application database and controller authority
After=network-online.target
[Service]
User=cncai
Group=cncai
WorkingDirectory=/opt/cnc-ai
EnvironmentFile=/etc/cnc-ai/app.env
ExecStart=/opt/conda/envs/smartfactoryllm/bin/python -m cnc_ai serve
Restart=on-failure
RestartSec=10
TimeoutStopSec=90
UMask=0077
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/cnc-ai
[Install]
WantedBy=multi-user.target
"""
    (app / "cnc-ai.service").write_text(appunit)
    (app / "nginx-app.conf").write_text(
        (ROOT / "deployment/nginx.conf")
        .read_text()
        .replace("cnc.factory.internal", data["hosts"]["app"]["hostname"])
        .replace("900s", "65s")
    )
    replacements = {
        "/opt/conda/envs/smartfactorymodels/bin/python": data["paths"]["model_python"],
        "/opt/conda/envs/smartfactoryllm/bin/python": data["paths"]["app_python"],
        "/var/lib/cnc-models": data["paths"]["cache_root"],
        "/var/lib/cnc-ai": data["paths"]["data"],
        "/etc/cnc-ai": data["paths"]["configuration"],
        "/opt/cnc-ai": data["paths"]["application"],
        "CNC_PORT=5000": "CNC_PORT=" + str(data["web"]["port"]),
        "127.0.0.1:5000": "127.0.0.1:" + str(data["web"]["port"]),
    }
    import re

    pattern = re.compile("|".join(re.escape(k) for k in replacements))
    for path in output.rglob("*"):
        if path.is_file() and path.name != "generation.json":
            path.write_text(
                pattern.sub(lambda match: replacements[match.group()], path.read_text())
            )
    (output / "generation.json").write_text(
        json.dumps(
            {
                "manifest_sha256": manifest_hash,
                "instances": len(data["instances"]),
                "physical_gpus": sum(h["gpu_count"] for h in data["hosts"].values()),
                "revision": "11.2.0",
            },
            indent=2,
        )
        + "\n"
    )


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--manifest", type=Path, default=ROOT / "config/deployment.json")
    p.add_argument("--output", type=Path)
    p.add_argument(
        "--bind-snapshots",
        type=Path,
        help="Verify complete local snapshots and write immutable commits into the specified manifest.",
    )
    p.add_argument("--qualified", action="store_true")
    a = p.parse_args()
    registry = json.loads((ROOT / "config/models.json").read_text())
    data = json.loads(a.manifest.read_text())
    if a.bind_snapshots:
        for role, model in data["models"].items():
            r = verify_snapshot(a.bind_snapshots, role, model)
            model.update(revision=r["commit"], snapshot_verified=True)
        a.manifest.write_text(json.dumps(data, indent=2) + "\n")
    validate_manifest(data, registry, a.qualified)
    if a.output:
        generate(data, a.output)
    print(
        "PASS: manifest structure and declared sharing validated; this is not GPU performance qualification."
    )


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Run model/revision and real inference contract checks; no factory tool executes."""

import argparse, json, os, time
from pathlib import Path
from dotenv import load_dotenv
from cnc_ai.deployment import validate_manifest
from cnc_ai.distributor import Distributor, wire

ROOT = Path(__file__).resolve().parents[2]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--manifest", type=Path, default=ROOT / "config/deployment.json")
    p.add_argument("--env-file", type=Path, required=True)
    p.add_argument("--instance")
    p.add_argument("--local", action="store_true")
    p.add_argument("--wait-seconds", type=int, default=30)
    a = p.parse_args()
    load_dotenv(a.env_file, override=False)
    registry = json.loads((ROOT / "config/models.json").read_text())
    m = validate_manifest(json.loads(a.manifest.read_text()), registry, True)
    pool = Distributor(m, registry)
    items = [
        i for i in pool.instances.values() if not a.instance or i["id"] == a.instance
    ]
    if not items:
        raise ValueError("Unknown instance.")
    failed = False
    for i in items:
        if a.local:
            i["url"] = (
                "http://127.0.0.1:"
                + str(i["backend_port"])
                + ("" if i["role"] == "reranker" else "/v1")
            )
        deadline = time.monotonic() + a.wait_seconds
        while True:
            try:
                pool._ready(
                    i,
                    pool._headers(i["role"], "installation-readiness"),
                    time.monotonic() + 60,
                )
                print(
                    json.dumps(
                        {
                            "instance": i["id"],
                            "status": "PASS",
                            "model": m["models"][i["role"]]["id"],
                            "revision": m["models"][i["role"]]["revision"],
                            "checks": [
                                "advertised identity and immutable alias",
                                "actual role inference contract",
                            ],
                        }
                    ),
                    flush=True,
                )
                break
            except Exception as exc:
                if time.monotonic() >= deadline:
                    print(
                        json.dumps(
                            {
                                "instance": i["id"],
                                "status": "FAIL",
                                "error_type": type(exc).__name__,
                            }
                        ),
                        flush=True,
                    )
                    failed = True
                    break
                time.sleep(2)
    return int(failed)


if __name__ == "__main__":
    raise SystemExit(main())

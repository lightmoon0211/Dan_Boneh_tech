from pathlib import Path
import subprocess, tempfile, json, os, hashlib
import argparse, shutil

p = argparse.ArgumentParser(
    description="Validate generated assets using temporary certificates and safe listener ports; no factory service is started."
)
p.add_argument("--nginx", default=shutil.which("nginx"))
p.add_argument("--output", type=Path, default=Path("docs/v112/deployment-syntax.json"))
a = p.parse_args()
if not a.nginx:
    p.error("nginx executable required; use --nginx PATH")
root = Path(__file__).resolve().parents[2]
nginx = Path(a.nginx)
results = []
with tempfile.TemporaryDirectory(prefix="cnc-deploy-syntax-") as d:
    t = Path(d)
    (t / "logs").mkdir()
    subprocess.run(
        [
            "openssl",
            "req",
            "-x509",
            "-newkey",
            "rsa:2048",
            "-nodes",
            "-keyout",
            str(t / "key.pem"),
            "-out",
            str(t / "cert.pem"),
            "-days",
            "1",
            "-subj",
            "/CN=syntax-fixture.invalid",
        ],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for host in ["ai-a", "ai-b", "app"]:
        f = (
            root
            / "deployment/generated"
            / host
            / ("nginx-app.conf" if host == "app" else "nginx-models.conf")
        )
        txt = (
            f.read_text()
            .replace("/etc/cnc-ai/tls/server.crt", str(t / "cert.pem"))
            .replace("/etc/cnc-ai/tls/server.key", str(t / "key.pem"))
        )
        txt = txt.replace("listen 443 ssl;", "listen 18443 ssl;")
        conf = t / (host + ".conf")
        conf.write_text(
            "user root;\nevents {}\nhttp {\naccess_log off;\n" + txt + "\n}\n"
        )
        r = subprocess.run(
            [str(nginx), "-t", "-p", str(t), "-c", str(conf)],
            capture_output=True,
            text=True,
        )
        results.append(
            {
                "check": "nginx -t " + host,
                "status": "PASS" if r.returncode == 0 else "FAIL",
                "output": r.stderr.replace(str(t), "<temporary>"),
                "qualification": "Syntax using temporary self-signed fixture/current-user worker; app privileged port remapped to 18443 only in temporary syntax copy. Not site TLS deployment",
            }
        )
    units = []
    for f in (root / "deployment/generated").rglob("*.service"):
        p = t / f.name
        txt = f.read_text()
        # systemd-analyze checks executable existence; use installed Python in syntax copies only.
        txt = txt.replace(
            "/opt/conda/envs/smartfactorymodels/bin/python", os.sys.executable
        ).replace("/opt/conda/envs/smartfactoryllm/bin/python", os.sys.executable)
        p.write_text(txt)
        units.append(str(p))
    r = subprocess.run(
        ["systemd-analyze", "verify", *units], capture_output=True, text=True
    )
    results.append(
        {
            "check": "systemd-analyze verify 13 units",
            "status": "PASS" if r.returncode == 0 else "FAIL",
            "output": r.stderr,
            "qualification": "Interpreter paths substituted in temporary syntax copies; no service started",
        }
    )
results.append(
    {
        "check": "Docker Compose execution/build",
        "status": "BLOCKED",
        "detail": "Docker CLI/daemon not installed in workspace. App-only YAML parsed separately; run docker compose config and staging build onsite.",
    }
)
a.output.parent.mkdir(parents=True, exist_ok=True)
a.output.write_text(json.dumps({"checks": results}, indent=2) + "\n")
print(json.dumps(results, indent=2))
raise SystemExit(1 if any(r["status"] == "FAIL" for r in results) else 0)

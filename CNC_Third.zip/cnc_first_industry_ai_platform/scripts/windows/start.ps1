param([string]$EnvironmentName = "smartfactoryllm")
$ErrorActionPreference = 'Stop'
Set-Location (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
conda run --no-capture-output -n $EnvironmentName python -m cnc_ai serve
exit $LASTEXITCODE

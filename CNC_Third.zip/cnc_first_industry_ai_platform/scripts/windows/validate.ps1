param([string]$EnvironmentName = "smartfactoryllm", [switch]$Models,[switch]$Opcua)
$ErrorActionPreference = 'Stop'
Set-Location (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
conda run --no-capture-output -n $EnvironmentName python -m pip check
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
conda run --no-capture-output -n $EnvironmentName python -m pytest
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$Extra = @()
if ($Models) { $Extra += '--models' }
if ($Opcua) { $Extra += '--opcua' }
conda run --no-capture-output -n $EnvironmentName python -m cnc_ai validate @Extra
exit $LASTEXITCODE

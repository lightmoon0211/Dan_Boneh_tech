param([switch]$Recreate, [string]$EnvironmentName = "smartfactoryllm")
$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
Set-Location $ProjectRoot
if (-not (Get-Command conda -ErrorAction SilentlyContinue)) { throw 'Open Anaconda PowerShell Prompt, then run this script again.' }
if ($Recreate -and $EnvironmentName -eq 'smartfactoryllm') { $EnvironmentName = 'smartfactoryllm_v112' }
Write-Host "Preparing $EnvironmentName. Existing environments and data are retained."
$Environments = conda env list --json | ConvertFrom-Json
$Exists = @($Environments.envs | Where-Object { (Split-Path $_ -Leaf) -eq $EnvironmentName }).Count -gt 0
if (-not $Exists) {
    conda create -n $EnvironmentName python=3.12 pip -y
    if ($LASTEXITCODE -ne 0) { throw 'Conda environment creation failed.' }
}
conda run --no-capture-output -n $EnvironmentName python -c "import sys; assert (3,11) <= sys.version_info[:2] < (3,14), 'Python 3.11-3.13 is required'"
if ($LASTEXITCODE -ne 0) { throw 'Use the clean-environment instructions in README.' }
conda run --no-capture-output -n $EnvironmentName python -m pip install --upgrade-strategy only-if-needed -e '.[test,download]'
if ($LASTEXITCODE -ne 0) { throw 'Application dependency installation failed.' }
if (-not (Test-Path '.env')) {
    $DemoConfiguration = (Get-Content '.env.example') -replace '^CNC_MODEL_MODE=local$', 'CNC_MODEL_MODE=demo'
    [System.IO.File]::WriteAllLines((Join-Path $ProjectRoot '.env'), $DemoConfiguration, [System.Text.UTF8Encoding]::new($false))
    Write-Host 'New workstation configuration uses CPU demo models. Set CNC_MODEL_MODE=local after inference services are ready.'
}
conda run --no-capture-output -n $EnvironmentName python -m cnc_ai db init --sample
if ($LASTEXITCODE -ne 0) { throw 'Database initialization failed.' }
conda run --no-capture-output -n $EnvironmentName python -m pytest
if ($LASTEXITCODE -ne 0) { throw 'Validation failed.' }
Write-Host 'Ready. Create operator, supervisor and administrator accounts using the README commands.'

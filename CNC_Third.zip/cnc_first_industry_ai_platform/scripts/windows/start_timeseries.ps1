param([string]$EnvironmentName = "smartfactoryllm")
$ErrorActionPreference = "Stop"
Set-Location (Resolve-Path (Join-Path $PSScriptRoot "../..")).Path
conda run --no-capture-output -n $EnvironmentName python -m cnc_ai timeseries serve --host 127.0.0.1 --port 8100
exit $LASTEXITCODE

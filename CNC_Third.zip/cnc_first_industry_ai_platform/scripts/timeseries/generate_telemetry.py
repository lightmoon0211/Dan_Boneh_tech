from cnc_ai.cli import main

if __name__ == "__main__":
    import sys

    raise SystemExit(main(["timeseries", "generate", *sys.argv[1:]]))

-- Canonical read-only export contract; create in a separate, reviewed export database.
-- Do not execute this against the application's authority database.
CREATE TABLE rca_history_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE rca_history_assets(
 entity TEXT NOT NULL,entity_kind TEXT NOT NULL,name TEXT NOT NULL,
 aliases_json TEXT NOT NULL,PRIMARY KEY(entity,entity_kind)
);
CREATE TABLE rca_history_records(
 record_id TEXT PRIMARY KEY,entity TEXT NOT NULL,entity_kind TEXT NOT NULL,
 family TEXT NOT NULL,event_start TEXT NOT NULL,event_end TEXT NOT NULL,
 recorded_at TEXT NOT NULL,snapshot_json TEXT NOT NULL
);
CREATE INDEX rca_history_scope ON rca_history_records(entity,entity_kind,family,event_start);
-- Values are JSON literals, including quotes for strings.
INSERT INTO rca_history_meta VALUES('schema_version','"cnc-rca-history-1"');
INSERT INTO rca_history_meta VALUES('dataset_id','"REPLACE-WITH-STABLE-SOURCE-UUID"');
INSERT INTO rca_history_meta VALUES('factory_id','"factory-local"');
INSERT INTO rca_history_meta VALUES('demo','false');
INSERT INTO rca_history_meta VALUES('available_families','[]');
-- Populate only from a reviewed source mapping; the empty export cannot prove a problem.

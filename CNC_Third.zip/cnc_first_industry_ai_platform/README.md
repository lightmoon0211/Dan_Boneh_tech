# Smart CNC Factory v11.2.0

Local CNC conversation, cited document and database answers, engineering drafts, planning, telemetry analysis, root-cause investigations, and supervised OPC UA proposals. This release upgrades the exact v11.1.0 RCA project; its original checksum and file inventory are in `docs/v112/baseline_inventory.json`.

The production target is **two inference servers with four RTX PRO 6000 Blackwell Server Edition 96 GB GPUs each**, **one separate CPU application/data server**, independent backups, and **50 authenticated browser clients**. The clients install nothing. The CPU application remains one active database/controller authority. Real eight-GPU performance and machine commissioning are separate site acceptance gates; see [validation](docs/VALIDATION.md).

On **each** inference server:

| GPU | Instance | TLS port | Loopback backend | Initial memory fraction |
|---:|---|---:|---:|---:|
| 0 | Conversation 1 | 8001 | 18001 | 0.82 |
| 1 | Conversation 2 | 8011 | 18011 | 0.82 |
| 2 | Coder/planner | 8002 | 18002 | 0.82 |
| 3 | Guardian | 8003 | 18003 | 0.45 |
| 3 | Embeddings | 8004 | 18004 | 0.20 |
| 3 | Reranker | 8005 | 18005 | 0.10 |

There are twelve service instances and eight physical GPUs. Each instance uses tensor parallelism one. GPU 3 sharing needs simultaneous-load qualification; the budgets do not guarantee freedom from memory exhaustion. `config/deployment.json` is the authoritative factory manifest. `config/models.json` retains the model identities and workstation endpoint settings.

The core models remain Qwen3.8-27B, Qwen3-Coder-30B-A3B-Instruct, Granite Guardian 4.1 8B, Qwen3-Embedding-4B, and Qwen3-Reranker-0.6B. Reports reuse conversation; planning/control proposals reuse the coder. SQLCoder and Whisper remain disabled by default. No model executes arbitrary code, generated SQL writes, or direct controller values.

## Start here

- [Browser client quick start](docs/BROWSER_QUICK_START.md): daily use, permissions, queues and cancellation.
- [Server installation](docs/SERVER_INSTALLATION.md): exact staging, AI A, AI B and CPU commands.
- [Full user manual](docs/USER_MANUAL.md), [editable Word](docs/USER_MANUAL.docx), [PDF](docs/USER_MANUAL.pdf).
- [Hardware and costs](docs/HARDWARE.md), [model compatibility](docs/MODEL_COMPATIBILITY.md), [architecture](docs/ARCHITECTURE.md).
- [Migration and rollback](docs/MIGRATION_V111_TO_V112.md), [operations and backups](docs/OPERATIONS.md), [offline transfer](docs/AIR_GAP_DEPLOYMENT.md).

## Eleven installation steps

### 1. Create or recreate smartfactoryllm

Use Anaconda PowerShell Prompt on a Windows development workstation. Preserve the old environment until migration tests succeed:

```powershell
conda create -n smartfactoryllm_v112 python=3.12 pip
conda activate smartfactoryllm_v112
python -m pip install -e '.[test,download]'
Copy-Item .env.example .env
```

For a new installation use `smartfactoryllm` instead of `smartfactoryllm_v112`. For offline production, install the packaged wheel and dependencies from the matching Linux wheelhouse, as explained in the server guide. Do not copy a Windows virtual environment to Linux. Recreating an environment does not require deleting factory data.

### 2. Download or resume all core models

On connected staging only:

```powershell
python scripts/models/download_factory_models.py all --model-root 'F:/AI/models' --checksums
```

`all` means **five physical snapshots**, including the existing reranker. It does not download twelve copies or optional specialists. Run the identical command again after interruption; the downloader retains partial files and immutable commits. A single role, for example `code`, can replace `all`.

### 3. Point to existing local models

For development set `MODEL_ROOT` and each `*_MODEL_PATH` in `.env`. Factory model directories must be complete external snapshots with downloader checksum manifests. Reusing existing files through the downloader verifies metadata without intentionally redownloading valid cached files. A loose GGUF is not the supplied BF16 serving format.

```powershell
python scripts/models/download_factory_models.py all --model-root 'F:/AI/models' --verify --checksums
python scripts/deployment/configure.py --manifest config/deployment.json --bind-snapshots 'F:/AI/models' --qualified --output deployment/generated
```

Review hostname/IP values in the manifest before generating site files. Transfer the same pinned manifest and snapshots to both AI servers. Factory startup rejects unverified snapshots; no weights are in this ZIP.

### 4. Start inference services

Use the Linux host-specific [server guide](docs/SERVER_INSTALLATION.md). Install six independently supervised systemd units per AI server. Preview one instance without loading weights:

```powershell
python scripts/models/serve_models.py --instance ai-a-conversation-1 --dry-run
```

The old `serve_models.py server-a` host group now fails with migration guidance. Optional specialist placement is not part of the eight-GPU allocation. A separate qualified profile is needed before enabling it.

### 5. Initialize the database

For a new **training** database:

```powershell
python -m cnc_ai db init --sample
python -m cnc_ai user add admin --role admin
python -m cnc_ai user add operator --role operator
python -m cnc_ai user add supervisor --role supervisor
```

Passwords are requested interactively. For a new empty factory database use `db init`; populate and qualify actual records separately. For existing data, back up and run `db migrate`, never reseed. Migration 005 adds jobs and model request IDs without rewriting prior migrations.

### 6. Ingest RAG documents

```powershell
python -m cnc_ai ingest samples/documents --user admin
```

Word, PDF, Excel, CSV and text extraction remains available. Factory retrieval uses approved document revisions. Use a different authorized reviewer to approve uploaded revisions. Evidence includes source location, timestamp and hash. Changing the embedding revision requires rebuilding vectors.

### 7. Run safe simulation

In development `.env`, set `CNC_MODEL_MODE=demo`, `CNC_PROFILE=development`, `CNC_OPCUA_MODE=simulator`. Then:

```powershell
python -m cnc_ai rca demo --user admin
python -m cnc_ai serve
```

Set `CNC_RCA_DEMO=true` to select synthetic RCA cases. A wire-protocol simulator is also available with `python -m cnc_ai opcua-simulator`; select `CNC_OPCUA_MODE=opcua_test` in a separate app process. Neither mode operates a physical machine.

### 8. Configure real OPC UA separately

Follow [commissioning](docs/CONTROL_COMMISSIONING.md), map reviewed nodes in `config/opcua.json`, provision certificates/service credentials only on the CPU authority, and qualify fresh telemetry and native interlocks. Keep `CNC_REAL_WRITES_ENABLED=false` and `CNC_SITE_COMMISSIONED=false` until site authorization. Approval cannot override a failed deterministic gate. Never use load tests against a physical controller.

### 9. Start the application

```powershell
python -m cnc_ai serve
```

Development opens `http://127.0.0.1:5000`. Factory users open the CPU server's trusted HTTPS URL. Waitress remains on loopback behind nginx. The browser uses persistent jobs for chat, reports, ingestion and verification; RCA uses its own bounded lane in the same queue. No unreviewed token streaming is enabled.

### 10. Validate the installation

```powershell
python -m pytest -q
python scripts/validate_installation.py
python scripts/deployment/configure.py
```

Linux synthetic capacity test, isolated from production data:

```bash
python scripts/evaluation/load_clients.py --clients 5 10 25 50 --rounds 2 --duration 30 --deny-public-egress --output /tmp/cnc-load.json
```

Use `docs/CAPACITY_TESTING.md` for actual-model and physical-host acceptance. A synthetic result is not a GPU benchmark.

### 11. Transfer to the air-gapped factory

Prepare matching OS/runtime packages, application and inference wheelhouses, complete checksummed snapshots, site certificates, internal DNS/time, deployment configuration and rollback resources. Use `scripts/prepare_airgap.py`, then follow [offline deployment](docs/AIR_GAP_DEPLOYMENT.md). The source ZIP is the application release, not a replacement for the site's OS and model transfer media.

# Start Smart CNC Factory v11.2.0

**Operator:** use the browser address supplied by your factory administrator. Read `docs/BROWSER_QUICK_START.md`. No client installation is needed.

**Windows developer:** use README steps 1, 5, 6, 7 and 9 in a separate environment and training data directory. Demo mode uses no model weights.

**Factory administrator:** read `docs/SERVER_INSTALLATION.md`, `docs/MODEL_COMPATIBILITY.md` and `docs/MIGRATION_V111_TO_V112.md`. The target is two four-GPU RTX inference nodes and one separate CPU authority. Do not run an old H200 host-group launcher.

**Controls engineer:** read `docs/CONTROL_COMMISSIONING.md`. This release is uncommissioned and defaults to simulation with real writes disabled.

The latest manuals are `docs/USER_MANUAL.docx` and `docs/USER_MANUAL.pdf`. Historical documentation and test evidence are explicitly under `docs/history`; they do not certify this deployment.

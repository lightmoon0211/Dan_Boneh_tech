"""Cooperative request cancellation and deadlines; never a tool retry mechanism."""

from contextvars import ContextVar

current = ContextVar("cnc_execution", default=None)


class Cancelled(RuntimeError):
    pass


def checkpoint():
    context = current.get()
    if context:
        context["check"]()
    return context

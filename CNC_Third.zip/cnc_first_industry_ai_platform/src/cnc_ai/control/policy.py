"""Ordered fail-closed policy checks; no language-model imports."""

import math
from ..database import digest, encode
from .configuration import FactoryPolicy

QUESTIONS = [
    "Is the machine running in an appropriate state?",
    "Is the selected tool rated for the requested RPM?",
    "Is the tool, material and workpiece combination compatible?",
    "Is the requested value inside machine and process limits?",
    "Does the authenticated operator have permission?",
    "Does the action require supervisor approval?",
    "Are interlocks and required telemetry healthy?",
]


class Policy:
    def __init__(self, settings):
        raw = settings.read("policy.json")
        FactoryPolicy.model_validate(raw)
        self.config = raw
        self.hash = digest(encode(self.config))

    def evaluate(self, request, principal, snapshot, approved=False):
        machine = self.config["machines"].get(request.machine)
        if not machine or request.action not in machine.get("actions", {}):
            raise ValueError("Machine action has no approved factory policy.")
        action = machine["actions"][request.action]
        checks = []
        failed = False

        def check(index, passed, detail, status=None):
            nonlocal failed
            result = {
                "order": index,
                "question": QUESTIONS[index - 1],
                "status": status or ("passed" if passed else "blocked"),
                "detail": detail,
            }
            if failed:
                result.update(
                    status="skipped",
                    detail="An earlier policy check blocked this request.",
                )
            elif not passed:
                failed = True
            checks.append(result)

        try:
            check(
                1,
                snapshot.value("state") in machine["states"]
                and snapshot.machine == request.machine
                and snapshot.value("machine_identity") == machine["identity"],
                f"Observed state: {snapshot.value('state')}; controller identity: {snapshot.value('machine_identity')}",
            )
            tool = machine.get("tools", {}).get(snapshot.value("tool"), {})
            recipe = machine.get("recipes", {}).get(snapshot.value("workpiece"), {})
            program = machine["programs"].get(snapshot.value("program"), {})
            if request.action == "set_spindle_rpm":
                rpm = request.rpm
                check(
                    2,
                    bool(tool) and rpm <= float(tool.get("maximum_rpm", 0)),
                    f"Tool: {snapshot.value('tool')}; approved maximum: {tool.get('maximum_rpm', 'unknown')} RPM",
                )
                compatible = (
                    bool(recipe)
                    and recipe.get("tool") == snapshot.value("tool")
                    and recipe.get("material") == snapshot.value("material")
                    and snapshot.value("material") in tool.get("materials", [])
                )
                check(
                    3,
                    compatible,
                    f"Recipe/workpiece: {snapshot.value('workpiece')}; material: {snapshot.value('material')}",
                )
                lo = max(
                    float(machine["minimum_rpm"]),
                    float(recipe.get("minimum_rpm", math.inf)),
                    float(program.get("minimum_rpm", math.inf)),
                )
                hi = min(
                    float(machine["maximum_rpm"]),
                    float(recipe.get("maximum_rpm", -math.inf)),
                    float(program.get("maximum_rpm", -math.inf)),
                )
                previous = snapshot.value("setpoint")
                step = (
                    abs(rpm - previous)
                    if isinstance(previous, (int, float))
                    else math.inf
                )
                check(
                    4,
                    lo <= rpm <= hi
                    and step <= machine["maximum_step_rpm"]
                    and request.action in program.get("actions", [])
                    and snapshot.value("workpiece") in program.get("workpieces", []),
                    f"Program {snapshot.value('program')}; approved range {lo:g}-{hi:g} RPM; change at most {machine['maximum_step_rpm']:g} RPM",
                )
            else:
                check(
                    2,
                    True,
                    "Not applicable: feed hold does not increase spindle speed.",
                )
                check(3, True, "Not applicable to the allowlisted feed-hold request.")
                check(
                    4,
                    request.action in program.get("actions", []),
                    "Program-authorized fixed Boolean feed-hold command; no arbitrary value accepted.",
                )
            check(
                5,
                action["permission"] in principal.permissions,
                f"Authenticated account: {principal.display_name}",
            )
            required = bool(action.get("approval_required", True))
            check(
                6,
                True,
                "Separate supervisor approval "
                + ("recorded." if approved else "is required.")
                if required
                else "Operator confirmation is required; supervisor approval is not configured.",
                status="passed" if approved or not required else "approval_required",
            )
            healthy, detail = snapshot.healthy(
                self.config["max_telemetry_age_seconds"],
                self.config["max_snapshot_span_seconds"],
            )
            check(7, healthy, detail)
        except (KeyError, TypeError, ValueError, OverflowError):
            while len(checks) < 7:
                check(
                    len(checks) + 1,
                    False,
                    "Required telemetry or policy data is invalid or missing.",
                )
        return {
            "checks": checks,
            "passed": not failed,
            "approval_required": bool(action.get("approval_required", True)),
            "policy_hash": self.hash,
            "policy_version": self.config["version"],
        }

"""Bounded, auditable workflow states without autonomous tool execution."""

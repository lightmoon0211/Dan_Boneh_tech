import uuid
from ..database import now, encode, digest

STATES = [
    "REQUEST",
    "CLASSIFY",
    "SAFETY_CHECK",
    "PLAN",
    "RETRIEVE_QUERY_ANALYZE",
    "VERIFY",
    "COMPOSE",
    "FINAL_SAFETY_CHECK",
    "RESPOND",
]


class Workflow:
    def __init__(self, db, actor, conversation_id, question):
        self.db = db
        self.id = str(uuid.uuid4())
        self.position = -1
        with db.connect(write=True) as c:
            c.execute(
                "INSERT INTO agent_runs VALUES(?,?,?,?,?,?,?)",
                (
                    self.id,
                    conversation_id,
                    actor,
                    now(),
                    None,
                    "running",
                    digest(question),
                ),
            )

    def step(self, state, detail=None):
        from ..execution import checkpoint
        checkpoint()
        index = STATES.index(state)
        if index <= self.position:
            raise ValueError("Agent state must advance; tool loops are not allowed.")
        self.position = index
        with self.db.connect(write=True) as c:
            c.execute(
                "INSERT INTO agent_steps(run_id,state,at,detail_json) VALUES(?,?,?,?)",
                (self.id, state, now(), encode(detail or {})),
            )

    def finish(self, status="completed"):
        with self.db.connect(write=True) as c:
            c.execute(
                "UPDATE agent_runs SET status=?,finished_at=? WHERE id=?",
                (status, now(), self.id),
            )

    def trace(self):
        with self.db.connect() as c:
            return [
                {
                    "state": r["state"],
                    "at": r["at"],
                    "detail": __import__("json").loads(r["detail_json"]),
                }
                for r in c.execute(
                    "SELECT * FROM agent_steps WHERE run_id=? ORDER BY id", (self.id,)
                )
            ]


def observe_models(db):
    def record(event):
        with db.connect(write=True) as c:
            c.execute(
                "INSERT INTO model_calls(at,role,service,replica,model,revision,elapsed_ms,status,input_tokens,output_tokens,request_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                tuple(
                    event.get(k)
                    for k in (
                        "at",
                        "role",
                        "service",
                        "replica",
                        "model",
                        "revision",
                        "elapsed_ms",
                        "status",
                        "input_tokens",
                        "output_tokens",
                        "request_id",
                    )
                ),
            )

    return record

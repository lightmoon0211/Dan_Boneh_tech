"""Local extraction and hybrid BM25/semantic retrieval with exact source locations."""

import csv
import hashlib
import json
import math
import re
import shutil
import uuid
import zipfile
from pathlib import Path
from .database import now, encode, digest
from .models import ModelUnavailable

EXTENSIONS = {".pdf", ".docx", ".xlsx", ".xls", ".csv", ".txt", ".md"}
MAX_BYTES = 50 * 1024 * 1024
MAX_TEXT = 2_000_000


def extract(path):
    path = Path(path)
    extension = path.suffix.lower()
    if extension not in EXTENSIONS:
        raise ValueError(
            "Supported documents: PDF, DOCX, XLSX, XLS, CSV, TXT and Markdown."
        )
    if path.stat().st_size > MAX_BYTES:
        raise ValueError("Document exceeds the 50 MiB file limit.")
    if extension in {".docx", ".xlsx"}:
        with zipfile.ZipFile(path) as archive:
            if sum(z.file_size for z in archive.infolist()) > 200 * 1024 * 1024:
                raise ValueError("Expanded Office document exceeds the limit.")
    if extension == ".pdf":
        from pypdf import PdfReader

        book = PdfReader(path)
        if book.is_encrypted:
            raise ValueError("Decrypt this PDF locally before ingestion.")
        sections = [
            (f"Page {i}", p.extract_text() or "") for i, p in enumerate(book.pages, 1)
        ]
    elif extension == ".docx":
        from docx import Document

        doc = Document(path)
        sections = [(f"Paragraph {i}", p.text) for i, p in enumerate(doc.paragraphs, 1)]
        for t, table in enumerate(doc.tables, 1):
            sections.extend(
                (f"Table {t}, row {i}", " | ".join(cell.text for cell in row.cells))
                for i, row in enumerate(table.rows, 1)
            )
    elif extension in {".xlsx", ".xls"}:
        sections = []
        if extension == ".xlsx":
            from openpyxl import load_workbook

            book = load_workbook(path, read_only=True, data_only=True)
            try:
                for sheet in book:
                    for i, row in enumerate(sheet.iter_rows(values_only=True), 1):
                        sections.append(
                            (
                                f"Sheet {sheet.title}, row {i}",
                                " | ".join("" if v is None else str(v) for v in row),
                            )
                        )
                        if len(sections) > 100000:
                            raise ValueError(
                                "Workbook exceeds the 100,000-row ingestion limit."
                            )
            finally:
                book.close()
        else:
            import xlrd

            book = xlrd.open_workbook(path)
            for sheet in book.sheets():
                if sheet.nrows + len(sections) > 100000:
                    raise ValueError("Workbook exceeds the row limit.")
                sections.extend(
                    (
                        f"Sheet {sheet.name}, row {i + 1}",
                        " | ".join(map(str, sheet.row_values(i))),
                    )
                    for i in range(sheet.nrows)
                )
    elif extension == ".csv":
        with path.open(encoding="utf-8-sig", newline="") as handle:
            sections = [
                (f"Row {i}", " | ".join(row))
                for i, row in enumerate(csv.reader(handle), 1)
            ]
    else:
        lines = path.read_text(encoding="utf-8-sig").splitlines()
        sections = [
            (f"Lines {i + 1}-{min(i + 30, len(lines))}", "\n".join(lines[i : i + 30]))
            for i in range(0, len(lines), 30)
        ]
    sections = [(loc, text.strip()) for loc, text in sections if text.strip()]
    if not sections:
        raise ValueError(
            "No readable text found. OCR scanned documents locally before ingestion."
        )
    if sum(len(text) for _, text in sections) > MAX_TEXT:
        raise ValueError(
            "Extracted text exceeds 2 million characters. Split the document into sections."
        )
    return sections


class RAG:
    def __init__(self, db, router, options_override=None):
        self.options_override = options_override or {}
        self.db = db
        self.router = router
        self.config = db.settings.read("rag.json")
        self.last_reranker_status = "not used"

    def ingest(
        self,
        path,
        principal,
        kind="manual",
        sector="manufacturing",
        revision="1",
        filename=None,
    ):
        principal.require("documents.write")
        path = Path(path)
        if kind not in {
            "manual",
            "sop",
            "maintenance",
            "machine",
            "tool",
            "material",
            "report",
            "other",
        }:
            raise ValueError("Unknown document category.")
        with self.db.connect() as c:
            if not c.execute(
                "SELECT 1 FROM sector_profiles WHERE id=?", (sector,)
            ).fetchone():
                raise ValueError("Unknown document sector.")
        sections = extract(path)
        sha = hashlib.sha256(path.read_bytes()).hexdigest()
        with self.db.connect() as c:
            old = c.execute(
                "SELECT id FROM documents WHERE sha256=? AND sector=? AND kind=?",
                (sha, sector, kind),
            ).fetchone()
        if old:
            return {"id": old[0], "duplicate": True, "status": self.status()}
        key = str(uuid.uuid4())
        stored = key + path.suffix.lower()
        directory = self.db.settings.data / "documents"
        directory.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, directory / stored)
        chunks = []
        for locator, section in sections:
            for offset in range(0, len(section), 1200):
                text = section[offset : offset + 1500]
                chunks.append(
                    (
                        "doc-" + str(uuid.uuid4()),
                        key,
                        len(chunks),
                        locator + f", excerpt {offset // 1200 + 1}",
                        text,
                        digest(text),
                    )
                )
        try:
            with self.db.connect(write=True) as c:
                c.execute(
                    "INSERT INTO documents VALUES(?,?,?,?,?,?,?,?,?)",
                    (
                        key,
                        Path(filename or path.name).name,
                        sha,
                        revision,
                        kind,
                        sector,
                        stored,
                        principal.username,
                        now(),
                    ),
                )
                c.execute(
                    "INSERT INTO document_revisions(document_id,family) VALUES(?,?)",
                    (key, sector + ":" + kind + ":" + Path(filename or path.name).name),
                )
                c.executemany("INSERT INTO document_chunks VALUES(?,?,?,?,?,?)", chunks)
                c.executemany(
                    "INSERT INTO document_fts(content,chunk_id) VALUES(?,?)",
                    [(r[4], r[0]) for r in chunks],
                )
                self.db.audit(
                    "document.ingested",
                    principal.username,
                    {
                        "document_id": key,
                        "sha256": sha,
                        "chunks": len(chunks),
                        "sector": sector,
                    },
                    c,
                )
        except Exception:
            (directory / stored).unlink(missing_ok=True)
            raise
        result = self.rebuild(principal, document_id=key)
        return {"id": key, "duplicate": False, "chunks": len(chunks), **result}

    def rebuild(self, principal, document_id=None):
        principal.require("documents.write")
        self.router.embedding_retry_at = 0
        where = " AND ch.document_id=?" if document_id else ""
        parameters = [self.router.embedding_fingerprint] + (
            [document_id] if document_id else []
        )
        with self.db.connect() as c:
            rows = c.execute(
                "SELECT ch.id,ch.content FROM document_chunks ch LEFT JOIN chunk_embeddings e ON ch.id=e.chunk_id WHERE (e.chunk_id IS NULL OR e.model_fingerprint<>?)"
                + where,
                parameters,
            ).fetchall()
        done = 0
        for start in range(0, len(rows), 16):
            batch = rows[start : start + 16]
            try:
                vectors = self.router.embed([r["content"] for r in batch])
            except ModelUnavailable:
                return {
                    "embedded_chunks": done,
                    "retrieval": "lexical",
                    "message": "Documents are searchable with BM25. Rebuild embeddings when the local service is ready.",
                }
            with self.db.connect(write=True) as c:
                for row, vector in zip(batch, vectors):
                    if c.execute(
                        "SELECT 1 FROM document_chunks WHERE id=?", (row["id"],)
                    ).fetchone():
                        c.execute(
                            "INSERT OR REPLACE INTO chunk_embeddings VALUES(?,?,?,?)",
                            (
                                row["id"],
                                self.router.embedding_fingerprint,
                                len(vector),
                                encode(vector),
                            ),
                        )
                        done += 1
        return {"embedded_chunks": done, "retrieval": "hybrid"}

    def status(self):
        with self.db.connect() as c:
            result = {
                name: c.execute("SELECT count(*) FROM " + table).fetchone()[0]
                for name, table in [
                    ("documents", "documents"),
                    ("chunks", "document_chunks"),
                ]
            }
            result["embeddings"] = c.execute(
                "SELECT count(*) FROM chunk_embeddings WHERE model_fingerprint=?",
                (self.router.embedding_fingerprint,),
            ).fetchone()[0]
        with self.db.connect() as c:
            result["approved_documents"] = c.execute(
                "SELECT count(*) FROM document_revisions WHERE state='approved'"
            ).fetchone()[0]
        result["mode"] = "hybrid" if result["embeddings"] else "lexical"
        result["reranker"] = self.last_reranker_status
        result["approved_only"] = self.db.settings.options()[
            "require_approved_documents"
        ]
        return result

    def list(self):
        with self.db.connect() as c:
            return [
                dict(r)
                for r in c.execute(
                    "SELECT d.id,d.filename,d.kind,d.sector,d.revision,d.sha256,d.created_at,r.state,r.family,count(ch.id) chunks FROM documents d LEFT JOIN document_revisions r ON r.document_id=d.id LEFT JOIN document_chunks ch ON ch.document_id=d.id GROUP BY d.id ORDER BY d.created_at DESC"
                )
            ]

    def delete(self, key, principal):
        principal.require("documents.write")
        with self.db.connect(write=True) as c:
            row = c.execute(
                "SELECT stored_name FROM documents WHERE id=?", (key,)
            ).fetchone()
            if not row:
                raise KeyError("Document was not found.")
            if c.execute(
                "SELECT 1 FROM reports WHERE document_id=?", (key,)
            ).fetchone():
                raise ValueError(
                    "Delete the linked report before deleting its source document."
                )
            c.execute(
                "DELETE FROM document_fts WHERE chunk_id IN(SELECT id FROM document_chunks WHERE document_id=?)",
                (key,),
            )
            c.execute("DELETE FROM document_revisions WHERE document_id=?", (key,))
            c.execute("DELETE FROM documents WHERE id=?", (key,))
            self.db.audit(
                "document.deleted", principal.username, {"document_id": key}, c
            )
        (self.db.settings.data / "documents" / row[0]).unlink(missing_ok=True)

    def approve(self, key, principal, comment):
        principal.require("documents.approve")
        if not isinstance(comment, str) or len(comment) < 5 or len(comment) > 1000:
            raise ValueError("Document review requires a 5–1000 character comment.")
        with self.db.connect(write=True) as c:
            row = c.execute(
                "SELECT r.*,d.created_by FROM document_revisions r JOIN documents d ON d.id=r.document_id WHERE document_id=?",
                (key,),
            ).fetchone()
            if not row:
                raise ValueError("Document revision is missing.")
            if row["created_by"] == principal.username:
                raise PermissionError(
                    "Another document reviewer must approve the uploaded revision."
                )
            if row["state"] == "superseded":
                raise ValueError(
                    "Superseded revisions cannot be reactivated. Ingest a reviewed new revision."
                )
            c.execute(
                "UPDATE document_revisions SET state='superseded' WHERE family=? AND state='approved'",
                (row["family"],),
            )
            c.execute(
                "UPDATE document_revisions SET state='approved',reviewer=?,reviewed_at=?,review_comment=? WHERE document_id=?",
                (principal.username, now(), comment, key),
            )
            self.db.audit(
                "document.approved",
                principal.username,
                {"document_id": key, "family": row["family"], "comment": comment},
                c,
            )
        return {"document_id": key, "state": "approved"}

    def search(self, query, principal, sector="manufacturing", conversation_id=None):
        principal.require("documents.read")
        cfg = self.config
        options = {**self.db.settings.options(), **self.options_override}
        eligibility = (
            " AND r.state='approved'"
            if options["require_approved_documents"]
            else " AND r.state<>'superseded' AND (r.state='approved' OR NOT EXISTS(SELECT 1 FROM document_revisions current WHERE current.family=r.family AND current.state='approved'))"
        )
        terms = re.findall(r"[^\W_]+", query, flags=re.UNICODE)[:30]
        lexical = []
        semantic = []
        joins = " JOIN document_chunks ch ON ch.id=e.chunk_id JOIN documents d ON d.id=ch.document_id JOIN document_revisions r ON r.document_id=d.id "
        with self.db.connect() as c:
            if terms:
                match = " OR ".join('"' + x.replace('"', '""') + '"' for x in terms)
                lexical = [
                    r[0]
                    for r in c.execute(
                        "SELECT e.chunk_id FROM document_fts e"
                        + joins
                        + "WHERE document_fts MATCH ? AND d.sector=?"
                        + eligibility
                        + " ORDER BY bm25(document_fts) LIMIT ?",
                        (match, sector, cfg["top_k_lexical"]),
                    )
                ]
            vectors = c.execute(
                "SELECT e.chunk_id,e.vector_json FROM chunk_embeddings e"
                + joins
                + "WHERE d.sector=? AND e.model_fingerprint=?"
                + eligibility
                + " LIMIT ?",
                (
                    sector,
                    self.router.embedding_fingerprint,
                    cfg["maximum_dense_chunks"] + 1,
                ),
            ).fetchall()
        if len(vectors) > cfg["maximum_dense_chunks"]:
            raise ValueError(
                "Dense index exceeds the configured development bound; partition the approved corpus or connect a site vector index."
            )
        if vectors and options.get("semantic_rag", True):
            try:
                q = self.router.embed([query], query=True)[0]
                qn = math.sqrt(sum(x * x for x in q))
                ranked = []
                for row in vectors:
                    v = json.loads(row[1])
                    norm = math.sqrt(sum(x * x for x in v))
                    if len(q) == len(v) and norm:
                        ranked.append(
                            (sum(a * b for a, b in zip(q, v)) / (qn * norm), row[0])
                        )
                semantic = [
                    key
                    for score, key in sorted(ranked, reverse=True)[: cfg["top_k_dense"]]
                    if score > cfg["minimum_dense_similarity"]
                ]
            except ModelUnavailable:
                pass
        scores = {}
        for ranking in (lexical, semantic):
            for rank, key in enumerate(ranking, 1):
                scores[key] = scores.get(key, 0) + 1 / (cfg["fusion_constant"] + rank)
        candidates = []
        with self.db.connect() as c:
            for key in sorted(scores, key=scores.get, reverse=True)[
                : cfg["rerank_candidates"]
            ]:
                row = c.execute(
                    "SELECT ch.*,d.filename,d.revision,d.kind,d.created_at,d.sha256 document_sha,r.state FROM document_chunks ch JOIN documents d ON ch.document_id=d.id JOIN document_revisions r ON r.document_id=d.id WHERE ch.id=?"
                    + eligibility,
                    (key,),
                ).fetchone()
                if row:
                    candidates.append(dict(row))
        rerank_scores = {}
        self.last_reranker_status = "disabled"
        if options["reranking"] and candidates:
            try:
                values = self.router.rerank(query, [r["content"] for r in candidates])
                rerank_scores = {r["id"]: v for r, v in zip(candidates, values)}
                candidates = sorted(
                    candidates, key=lambda r: rerank_scores[r["id"]], reverse=True
                )
                candidates = [
                    r
                    for r in candidates
                    if rerank_scores[r["id"]] >= cfg["minimum_reranker_score"]
                ]
                self.last_reranker_status = "neural reranking applied"
            except ModelUnavailable:
                self.last_reranker_status = "unavailable; fusion ranking used"
                if options["require_reranking"]:
                    raise
        results = []
        with self.db.connect(write=True) as c:
            for row in candidates[: cfg["final_context_count"]]:
                # Recheck revision approval within the evidence transaction.
                current = c.execute(
                    "SELECT d.id FROM documents d JOIN document_revisions r ON r.document_id=d.id WHERE d.id=?"
                    + eligibility,
                    (row["document_id"],),
                ).fetchone()
                if not current:
                    continue
                key = row["id"]
                stamp = now()
                provenance = {
                    "document_id": row["document_id"],
                    "filename": row["filename"],
                    "revision": row["revision"],
                    "approval_state": row["state"],
                    "chunk_id": key,
                    "content_sha256": row["sha256"],
                    "document_sha256": row["document_sha"],
                    "ingested_at": row["created_at"],
                    "source_type": row["kind"],
                    "retrieval_score": scores[key],
                    "reranker_score": rerank_scores.get(key),
                    "retrieval": "hybrid_rrf" if semantic else "bm25",
                    "reranker_status": self.last_reranker_status,
                }
                item = {
                    "id": "evidence-" + str(uuid.uuid4()),
                    "kind": "document",
                    "title": row["filename"],
                    "locator": row["locator"] + "; revision " + row["revision"],
                    "captured_at": stamp,
                    "sha256": row["sha256"],
                    "content": row["content"],
                    "provenance": provenance,
                }
                c.execute(
                    "INSERT INTO evidence_records VALUES(?,?,?,?,?,?,?,?,?)",
                    (
                        item["id"],
                        conversation_id,
                        "document",
                        item["title"],
                        item["locator"],
                        stamp,
                        item["sha256"],
                        item["content"],
                        encode(provenance),
                    ),
                )
                results.append(item)
        return results

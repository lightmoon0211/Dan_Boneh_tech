"""Same-origin RCA endpoints use the existing session/CSRF middleware."""

from flask import request, jsonify, g, Response
from ..database import encode
from ..rca.contracts import StartRequest


def register(app, service):
    @app.get("/api/rca/status")
    def rca_status():
        g.principal.require("rca.read")
        cfg = service.cfg
        return jsonify(
            enabled=cfg["enabled"],
            demo_available=cfg["demo_enabled"]
            and service.db.settings.profile == "development"
            and service.db.settings.model_mode == "demo",
            factory_timezone=cfg["timezone"],
            shifts=cfg["shifts"],
            operational_adapter="canonical read-only SQLite history"
            if cfg["history_path"]
            else "native v11 rows; comparison mapping incomplete",
            limits=cfg["limits"],
            live_integrations={
                "ERPNext": "not implemented",
                "MES": "no live connector",
                "Siemens NX": "not implemented",
                "Opcenter": "not implemented",
                "Simio": "not implemented",
            },
            normal_operation="local only",
        )

    @app.get("/api/rca/investigations")
    def investigations():
        return jsonify(service.list(g.principal))

    @app.post("/api/rca/investigations")
    def start_investigation():
        return jsonify(
            service.start(StartRequest.model_validate(request.get_json()), g.principal)
        ), 202

    @app.get("/api/rca/investigations/<key>")
    def investigation(key):
        return jsonify(service.get(key, g.principal))

    @app.get("/api/rca/investigations/<key>/events")
    def events(key):
        result = service.get(key, g.principal)
        return jsonify(status=result["status"], events=result["events"])

    @app.post("/api/rca/investigations/<key>/cancel")
    def cancel(key):
        return jsonify(service.cancel(key, g.principal))

    @app.get("/api/rca/investigations/<key>/evidence/<evidence_id>")
    def evidence(key, evidence_id):
        return jsonify(service.evidence(key, evidence_id, g.principal))

    @app.post("/api/rca/investigations/<key>/evidence")
    def add_evidence(key):
        return jsonify(service.add_evidence(key, request.get_json(), g.principal)), 201

    @app.post("/api/rca/investigations/<key>/review")
    def review(key):
        return jsonify(service.review(key, request.get_json(), g.principal))

    @app.post("/api/rca/investigations/<key>/reassess")
    def reassess(key):
        return jsonify(service.reassess(key, request.get_json(), g.principal)), 202

    @app.get("/api/rca/investigations/<key>/export")
    def export(key):
        data = service.export(key, g.principal)
        service.db.audit(
            "rca.exported", g.principal.username, {"investigation_id": key}
        )
        return Response(
            encode(data),
            mimetype="application/json",
            headers={
                "Content-Disposition": 'attachment; filename="rca-investigation.json"'
            },
        )

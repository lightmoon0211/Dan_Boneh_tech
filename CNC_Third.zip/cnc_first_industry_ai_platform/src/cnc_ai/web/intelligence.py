"""Authenticated intelligence routes mounted under the existing session and CSRF protections."""

import json
from flask import request, jsonify, g, Response, Blueprint
from ..contracts import ThreadQuery
from ..timeseries.contracts import AnalysisQuery
from ..timeseries.facade import AnalysisService
from ..knowledge.thread import DigitalThread
from ..planning.scheduler import ScheduleInput, schedule
from ..planning.calculations import CuttingInput, cutting_parameters, OEEInput, oee
from ..planning.artifacts import ArtifactService, CodeCandidate, Attestation
from ..vision import VisionService
from ..provenance import calculation_evidence


def register(app, db, router, rag):
    bp = Blueprint("intelligence", __name__)
    analysis = AnalysisService(db)
    thread = DigitalThread(db)
    artifacts = ArtifactService(db)
    vision = VisionService(db, router)

    @bp.get("/api/intelligence/status")
    def status():
        g.principal.require("data.read")
        return jsonify(analysis.status())

    @bp.post("/api/timeseries/<kind>")
    def analyze(kind):
        return jsonify(
            analysis.run(
                kind, AnalysisQuery.model_validate(request.get_json()), g.principal
            )
        )

    @bp.post("/api/knowledge/trace")
    def trace():
        d = ThreadQuery.model_validate(request.get_json())
        return jsonify(thread.trace(d.entity_type, d.key, g.principal, d.depth))

    @bp.post("/api/knowledge/rebuild")
    def rebuild():
        return jsonify(thread.rebuild(g.principal))

    @bp.post("/api/planning/schedule")
    def planning():
        g.principal.require("data.read")
        data = ScheduleInput.model_validate(request.get_json())
        result = schedule(data)
        return jsonify(
            result=result,
            evidence=calculation_evidence(
                db,
                "schedule",
                {"inputs": data.model_dump(), "result": result},
                g.principal,
            ),
        )

    @bp.post("/api/calculations/<kind>")
    def calculation(kind):
        g.principal.require("data.read")
        if kind == "cutting":
            d = CuttingInput.model_validate(request.get_json())
            result = cutting_parameters(
                d, db.settings.read("engineering.json")["cutting_limits"]
            )
        elif kind == "oee":
            d = OEEInput.model_validate(request.get_json())
            result = oee(d)
        else:
            raise ValueError("Unknown calculation.")
        return jsonify(
            result=result,
            evidence=calculation_evidence(
                db, kind, {"inputs": d.model_dump(), "result": result}, g.principal
            ),
        )

    @bp.post("/api/artifacts")
    def candidate():
        return jsonify(
            artifacts.create(
                CodeCandidate.model_validate(request.get_json()), g.principal
            )
        )

    @bp.post("/api/artifacts/<key>/attest")
    def attest(key):
        return jsonify(
            artifacts.attest(
                key, Attestation.model_validate(request.get_json()), g.principal
            )
        )

    @bp.get("/api/artifacts/<key>/export")
    def export(key):
        return Response(
            artifacts.export(key, g.principal),
            mimetype="application/zip",
            headers={
                "Content-Disposition": "attachment; filename=reviewed_cnc_candidate.zip"
            },
        )

    @bp.post("/api/vision")
    def image():
        upload = request.files.get("file")
        if not upload:
            raise ValueError("Choose a PNG or JPEG image.")
        return jsonify(
            vision.analyze(
                upload.read(8 * 1024 * 1024 + 1),
                request.form.get(
                    "question", "Describe visible manufacturing observations."
                ),
                g.principal,
            )
        )

    @bp.post("/api/documents/<key>/approve")
    def approve(key):
        return jsonify(
            rag.approve(key, g.principal, request.get_json().get("comment", ""))
        )

    @bp.get("/api/observability")
    def metrics():
        g.principal.require("audit.read")
        with db.connect() as c:
            calls = [
                dict(r)
                for r in c.execute(
                    "SELECT service,replica,status,count(*) requests,avg(elapsed_ms) average_ms,max(elapsed_ms) maximum_ms,sum(input_tokens) input_tokens,sum(output_tokens) output_tokens FROM model_calls GROUP BY service,replica,status"
                )
            ]
            runs = [
                dict(r)
                for r in c.execute(
                    "SELECT status,count(*) runs FROM agent_runs GROUP BY status"
                )
            ]
            unknown = c.execute(
                "SELECT count(*) FROM control_executions WHERE status='unknown'"
            ).fetchone()[0]
        return jsonify(
            model_calls=calls,
            agent_runs=runs,
            unknown_control_outcomes=unknown,
            audit=db.verify_audit(),
        )

    @bp.get("/api/analyses/<key>")
    def get_analysis(key):
        g.principal.require("data.read")
        with db.connect() as c:
            row = c.execute(
                "SELECT result_json FROM analysis_records WHERE id=? AND actor=?",
                (key, g.principal.username),
            ).fetchone()
        if not row:
            raise ValueError("Analysis is unavailable to this account.")
        return jsonify(json.loads(row[0]))

    app.register_blueprint(bp)

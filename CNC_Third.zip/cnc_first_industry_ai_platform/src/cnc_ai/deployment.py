"""Authoritative factory layout. Null revisions deliberately block production start."""

import ipaddress
import json
import math
import re
from pathlib import Path


def validate_manifest(data, registry, qualified=False):
    if data["schema_version"] != 1 or data["release"] != "11.2.0":
        raise ValueError("Unsupported deployment manifest version.")
    hosts, models = data["hosts"], data["models"]
    for name, host in hosts.items():
        if not re.fullmatch(r"[a-z0-9-]{1,60}", name) or not re.fullmatch(
            r"[A-Za-z0-9.-]{1,253}", host["hostname"]
        ):
            raise ValueError("Invalid host name.")
        if not ipaddress.ip_address(host["ip"]).is_private:
            raise ValueError("Factory hosts must use private addresses.")
    for path in data["paths"].values():
        if not re.fullmatch(r"/[A-Za-z0-9_./-]+", path) or ".." in Path(path).parts:
            raise ValueError(
                "Production paths must be absolute Linux paths without shell syntax."
            )
    for role, model in models.items():
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", model["directory"]) or model[
            "directory"
        ] in (".", ".."):
            raise ValueError("Model directory must be one safe path component.")
    groups = {g["id"]: g for g in data["sharing_groups"]}
    if len(groups) != len(data["sharing_groups"]):
        raise ValueError("Duplicate sharing group.")
    ports, identifiers, allocations = set(), set(), {}
    for role, model in models.items():
        if (
            role not in registry["services"]
            or model["id"] != registry["services"][role]["model"]
        ):
            raise ValueError(
                "Deployment model differs from configured registry: " + role
            )
        revision = model["revision"]
        if revision is not None and not re.fullmatch("[a-f0-9]{40}", revision):
            raise ValueError("Revisions must be immutable 40-character commit hashes.")
        if model["dtype"] != "bfloat16":
            raise ValueError(
                "Precision changes require a separately qualified profile."
            )
        if qualified and (revision is None or not model["snapshot_verified"]):
            raise ValueError(
                "Pin and verify every complete model snapshot before serving."
            )
    for item in data["instances"]:
        name, host, role = item["id"], item["host"], item["role"]
        if not re.fullmatch("[a-z0-9-]{1,60}", name) or name in identifiers:
            raise ValueError("Invalid or duplicate instance ID.")
        identifiers.add(name)
        if host not in hosts or role not in models:
            raise ValueError("Unknown host or model role.")
        ids = item["gpu_ids"]
        if (
            not ids
            or len(ids) != len(set(ids))
            or len(ids) != item["tensor_parallel"]
            or any(
                type(g) is not int or g < 0 or g >= hosts[host]["gpu_count"]
                for g in ids
            )
        ):
            raise ValueError("GPU IDs must exist and match tensor parallelism.")
        for p in [item["port"], item["backend_port"]]:
            if type(p) is not int or not 1024 <= p <= 65535 or (host, p) in ports:
                raise ValueError("Duplicate or invalid port on host.")
            ports.add((host, p))
        budget = item["gpu_memory_utilization"]
        if isinstance(budget, bool) or not math.isfinite(budget) or not 0 < budget < 1:
            raise ValueError("Invalid memory budget.")
        if (
            not 1 <= item["max_inflight"] <= item["max_num_seqs"] <= 32
            or not 512 <= item["max_model_len"] <= 32768
        ):
            raise ValueError("Invalid inference admission or context limits.")
        for gpu in ids:
            allocations.setdefault((host, gpu), []).append(item)
    for (host, gpu), items in allocations.items():
        if len(items) == 1:
            if items[0]["sharing_group"]:
                raise ValueError("Sharing group declared without actual members.")
            continue
        names = {i["sharing_group"] for i in items}
        if None in names or len(names) != 1 or next(iter(names)) not in groups:
            raise ValueError(
                "Accidental GPU overlap; an exact sharing group is required."
            )
        group = groups[next(iter(names))]
        if (
            group["host"] != host
            or group["gpu"] != gpu
            or set(group["members"]) != {i["id"] for i in items}
        ):
            raise ValueError("Sharing group membership mismatch.")
        if (
            not 0 < group["maximum_fraction"] <= 0.85
            or sum(i["gpu_memory_utilization"] for i in items)
            > group["maximum_fraction"] + 1e-9
        ):
            raise ValueError("Shared GPU memory budget exceeded.")
        if len({i["startup_order"] for i in items}) != len(items):
            raise ValueError("Shared GPU services need distinct startup order.")
    for g in groups.values():
        if not set(g["members"]).issubset(identifiers):
            raise ValueError("Unknown sharing member.")
    jobs = data["jobs"]
    if (
        not 1 <= jobs["capacity"] <= 1000
        or not 1 <= jobs["per_user_pending"] <= 10
        or not 1 <= jobs["per_user_running"] <= 4
    ):
        raise ValueError("Invalid application admission limits.")
    if (
        not 1 <= jobs["lanes"]["rca"] <= 4
        or not 1 <= sum(jobs["lanes"].values()) <= 24
        or any(type(n) is not int or n < 1 for n in jobs["lanes"].values())
    ):
        raise ValueError("Invalid worker limits.")
    if not 1 <= data["routing"]["max_attempts"] <= 2:
        raise ValueError("At most two inference attempts permitted.")
    if (
        not data["security"]["single_stateful_authority"]
        or data["security"]["inference_controller_access"]
    ):
        raise ValueError("Deployment violates the controller authority boundary.")
    for key in ("queue_seconds", "execution_seconds"):
        if not 1 <= jobs[key] <= 3600:
            raise ValueError("Invalid job timeout.")
    for key in (
        "admission_seconds",
        "timeout_seconds",
        "cooldown_seconds",
        "readiness_ttl_seconds",
    ):
        if not 0 < data["routing"][key] <= 300:
            raise ValueError("Invalid routing timeout.")
    if (
        not data["security"]["tls_required"]
        or not data["security"]["weights_read_only"]
    ):
        raise ValueError("Factory TLS and read-only weights are required.")
    if (
        not 8 <= data["web"]["threads"] <= 32
        or not 64 <= data["web"]["connection_limit"] <= 1024
    ):
        raise ValueError("Invalid HTTP worker limits.")
    return data


def load_manifest(settings, qualified=False):
    import os

    path = os.getenv("CNC_DEPLOYMENT_MANIFEST")
    data = (
        json.loads(Path(path).read_text()) if path else settings.read("deployment.json")
    )
    return validate_manifest(data, settings.read("models.json"), qualified)


def endpoint(data, item):
    suffix = "" if item["role"] == "reranker" else "/v1"
    return f"https://{data['hosts'][item['host']]['hostname']}:{item['port']}{suffix}"

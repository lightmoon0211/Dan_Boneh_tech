"""Numerical and evaluation CLI; workstation commands do not require inference."""

import json
from pathlib import Path


def add_commands(commands):
    t = commands.add_parser(
        "timeseries",
        help="Numerical service, synthetic telemetry and historian analysis",
    )
    actions = t.add_subparsers(dest="action", required=True)
    s = actions.add_parser("serve")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=8100)
    g = actions.add_parser("generate")
    g.add_argument("--output", type=Path, default=Path("samples/telemetry"))
    g.add_argument("--minutes", type=int, default=360)
    i = actions.add_parser("ingest")
    i.add_argument("file", type=Path)
    i.add_argument("--user", required=True)
    q = actions.add_parser("analyze")
    q.add_argument("kind")
    q.add_argument("query", type=Path)
    q.add_argument("--user", required=True)
    q.add_argument("--output", type=Path)
    k = commands.add_parser("knowledge")
    k.add_argument("action", choices=["rebuild"])
    k.add_argument("--user", required=True)
    b = commands.add_parser("cncbench")
    b.add_argument("--output", type=Path, default=Path("runtime/cncbench"))
    b.add_argument("--models", action="store_true")
    b.add_argument("--neural-forecast", action="store_true")
    a = commands.add_parser("approve-document")
    a.add_argument("document_id")
    a.add_argument("--user", required=True)
    a.add_argument("--comment", required=True)
    f = commands.add_parser("train-component")
    f.add_argument("data", type=Path)
    f.add_argument("--features", nargs="+", required=True)
    f.add_argument("--target", required=True)
    f.add_argument("--component", required=True)
    f.add_argument("--machine-family", required=True)
    f.add_argument("--output", type=Path, required=True)


def run(args, settings, db):
    from .auth import Auth

    if args.command == "timeseries":
        if args.action == "serve":
            from .timeseries.service import create_service
            from waitress import serve

            print(
                f"Time-series numerical API at http://{args.host}:{args.port}; no controller writes.",
                flush=True,
            )
            serve(
                create_service(settings),
                host=args.host,
                port=args.port,
                threads=4,
                max_request_body_size=16 * 1024 * 1024,
            )
            return {"stopped": True}
        if args.action == "generate":
            from .timeseries.synthetic import generate

            return generate(args.output, args.minutes)
        principal = Auth(db).user(args.user)
        if args.action == "ingest":
            principal.require("data.manage")
            from .timeseries.historian import SQLiteHistorian
            from .timeseries.synthetic import ingest_csv

            result = ingest_csv(args.file, SQLiteHistorian(db))
            db.audit("historian.ingested", principal.username, result)
            return result
        from .timeseries.facade import AnalysisService
        from .timeseries.contracts import AnalysisQuery

        result = AnalysisService(db).run(
            args.kind,
            AnalysisQuery.model_validate_json(args.query.read_text()),
            principal,
        )
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
            return {"output": str(args.output), "status": result["analysis"]["status"]}
        return result
    if args.command == "knowledge":
        from .knowledge.thread import DigitalThread

        return DigitalThread(db).rebuild(Auth(db).user(args.user))
    if args.command == "approve-document":
        from .rag import RAG
        from .models import ModelRouter

        return RAG(db, ModelRouter(settings)).approve(
            args.document_id, Auth(db).user(args.user), args.comment
        )
    if args.command == "train-component":
        from .timeseries.component_models import fit_regression

        artifact = fit_regression(
            json.loads(args.data.read_text()),
            args.features,
            args.target,
            args.component,
            args.machine_family,
        )
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(artifact, indent=2))
        return {
            "artifact": str(args.output),
            "approved": False,
            "validation": artifact["validation"],
        }
    from .evaluation.bench import run_benchmark

    return run_benchmark(settings, args.output, args.models, args.neural_forecast)

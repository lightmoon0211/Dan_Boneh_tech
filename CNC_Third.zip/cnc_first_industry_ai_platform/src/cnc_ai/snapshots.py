"""Offline verification of complete, immutable model snapshots."""

import hashlib
import json
import re
from pathlib import Path


def verify_snapshot(root, role, model, deep=True):
    root = Path(root).resolve()
    directory = (root / model["directory"]).resolve()
    if not directory.is_relative_to(root):
        raise ValueError("Model directory escapes model root.")
    state = root / ".factory-downloads" / (role + ".json")
    record = json.loads(state.read_text())
    if (
        record.get("repo_id") != model["id"]
        or not record.get("complete")
        or not re.fullmatch("[0-9a-f]{40}", record.get("commit", ""))
    ):
        raise ValueError("Snapshot identity/completeness check failed: " + role)
    if model["revision"] and model["revision"] != record["commit"]:
        raise ValueError("Snapshot revision differs: " + role)
    if record.get("include_patterns") or record.get("exclude_patterns"):
        raise ValueError("Factory core snapshots must include the complete repository.")
    files = record["files"]
    for required in [
        "config.json",
        "tokenizer_config.json",
        "tokenizer.json",
        "README.md",
    ]:
        if required not in files:
            raise ValueError("Snapshot metadata missing: " + required)
    if not any(n.endswith(".safetensors") for n in files):
        raise ValueError("Snapshot has no model weight shards.")
    config = json.loads((directory / "tokenizer_config.json").read_text())
    if not config.get("chat_template") and "chat_template.jinja" not in files:
        raise ValueError("Snapshot chat template missing.")
    index = directory / "model.safetensors.index.json"
    if index.is_file():
        shards = set(json.loads(index.read_text())["weight_map"].values())
        if not shards.issubset(files):
            raise ValueError("Weight index references missing shards.")
    total = 0
    for name, meta in files.items():
        path = (directory / name).resolve()
        if (
            not path.is_relative_to(directory)
            or not path.is_file()
            or path.stat().st_size != meta["size"]
        ):
            raise ValueError("Snapshot file missing/changed: " + name)
        if not re.fullmatch("[0-9a-f]{64}", meta.get("sha256", "")):
            raise ValueError("Every snapshot file needs a SHA256 checksum.")
        if deep:
            with path.open("rb") as f:
                sha = hashlib.file_digest(f, "sha256").hexdigest()
            if sha != meta["sha256"]:
                raise ValueError("Snapshot checksum differs: " + name)
        total += meta["size"]
    return {
        "commit": record["commit"],
        "files": len(files),
        "bytes": total,
        "directory": str(directory),
    }

"""Persistent, bounded, fair single-authority jobs. No automatic action replay."""

import json
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from .auth import Auth
from .database import encode, now
from .execution import current, Cancelled


class QueueFull(RuntimeError):
    pass


class JobManager:
    def __init__(self, db, limits):
        self.db, self.limits, self.auth = db, limits, Auth(db)
        self.handlers = {}
        self.condition = threading.Condition()
        self.running = {}
        self.last_owner = ""
        self.closed = False
        self.started = False
        self.pool = None

    def register(self, kind, handler, permissions, lane="routine"):
        if lane not in self.limits["lanes"]:
            raise ValueError("Unknown worker lane.")
        self.handlers[kind] = (handler, permissions, lane)

    def start(self):
        with self.condition:
            if self.started:
                return
            # Only the fenced application authority starts this manager. Never replay a
            # partially executed tool sequence after a crash, including ingestion.
            with self.db.connect(write=True) as c:
                for orphan in c.execute(
                    "SELECT * FROM application_jobs WHERE state IN ('queued','running')"
                ):
                    self._remove_upload(dict(orphan))
                ids = [
                    r[0]
                    for r in c.execute(
                        "SELECT id FROM application_jobs WHERE state IN ('queued','running')"
                    )
                ]
                c.execute(
                    "UPDATE application_jobs SET state='failed',finished_at=?,error='Application restarted. Review retained evidence and explicitly resubmit; no action was replayed.' WHERE state IN ('queued','running')",
                    (time.time(),),
                )
                if ids:
                    self.db.audit(
                        "jobs.restart_reconciled", "application", {"count": len(ids)}, c
                    )
                orphan_rca = [
                    r[0]
                    for r in c.execute(
                        "SELECT id FROM rca_investigations WHERE status IN ('queued','running')"
                    )
                ]
                for key in orphan_rca:
                    c.execute(
                        "INSERT INTO rca_events(investigation_id,step_id,at,status,payload_json) VALUES(?,NULL,?,'cancelled',?)",
                        (
                            key,
                            now(),
                            encode(
                                {"reason": "Application restart; no automatic replay."}
                            ),
                        ),
                    )
                c.execute(
                    "UPDATE rca_investigations SET status='cancelled',cancel_requested=1,updated_at=? WHERE status IN ('queued','running')",
                    (now(),),
                )
                c.execute(
                    "UPDATE rca_steps SET status='cancelled',finished_at=?,result_json=? WHERE status IN ('planned','queued','running')",
                    (
                        now(),
                        encode(
                            {
                                "detail": "Application restarted; explicit reassessment required."
                            }
                        ),
                    ),
                )
            self.pool = ThreadPoolExecutor(
                max_workers=sum(self.limits["lanes"].values()),
                thread_name_prefix="cnc-job",
            )
            self.started = True
            self.dispatcher = threading.Thread(
                target=self._dispatch, daemon=True, name="cnc-dispatch"
            )
            self.dispatcher.start()

    def submit(self, kind, payload, principal, request_id=None, resource_id=None):
        if kind not in self.handlers:
            raise ValueError("Unsupported job kind.")
        _, required, lane = self.handlers[kind]
        principal = self.auth.user(principal.username)
        for p in required:
            principal.require(p)
        serialized = encode(payload)
        if len(serialized.encode()) > 512 * 1024:
            raise ValueError("Job input exceeds 512 KiB; use document ingestion.")
        if (
            kind == "chat"
            and len(payload["question"]) > self.limits["long_question_chars"]
        ):
            lane = "long"
        self.start()
        key = str(uuid.uuid4())
        stamp = time.time()
        with self.condition:
            if self.closed:
                raise QueueFull("Application is draining. Try again after maintenance.")
            with self.db.connect(write=True) as c:
                if (
                    c.execute(
                        "SELECT count(*) FROM application_jobs WHERE state IN ('queued','running')"
                    ).fetchone()[0]
                    >= self.limits["capacity"]
                ):
                    raise QueueFull(
                        "Job queue is full. Wait for a running job to finish before resubmitting."
                    )
                if (
                    c.execute(
                        "SELECT count(*) FROM application_jobs WHERE owner=? AND state IN ('queued','running')",
                        (principal.username,),
                    ).fetchone()[0]
                    >= self.limits["per_user_pending"]
                ):
                    raise QueueFull(
                        "Your pending job limit is reached. Cancel or finish an existing job."
                    )
                c.execute(
                    "INSERT INTO application_jobs(id,owner,kind,lane,state,created_at,expires_at,payload_json,permissions_json,resource_id,request_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        key,
                        principal.username,
                        kind,
                        lane,
                        "queued",
                        stamp,
                        stamp + self.limits["queue_seconds"],
                        serialized,
                        encode(sorted(principal.permissions)),
                        resource_id,
                        request_id or key,
                    ),
                )
                self.db.audit(
                    "job.queued",
                    principal.username,
                    {"job_id": key, "kind": kind, "lane": lane},
                    c,
                )
            self.condition.notify_all()
        return self.get(key, principal)

    def _terminate_rca(self, c, row, reason):
        if row["kind"] != "rca" or not row["resource_id"]:
            return
        key = row["resource_id"]
        changed = c.execute(
            "UPDATE rca_investigations SET status='cancelled',cancel_requested=1,updated_at=? WHERE id=? AND status IN ('queued','running')",
            (now(), key),
        ).rowcount
        if changed:
            c.execute(
                "UPDATE rca_steps SET status='cancelled',finished_at=?,result_json=? WHERE investigation_id=? AND status IN ('planned','queued','running')",
                (now(), encode({"detail": reason}), key),
            )
            c.execute(
                "INSERT INTO rca_events(investigation_id,step_id,at,status,payload_json) VALUES(?,NULL,?,'cancelled',?)",
                (key, now(), encode({"reason": reason})),
            )

    def _remove_upload(self, row):
        if row["kind"] == "ingest":
            from pathlib import Path

            path = Path(json.loads(row["payload_json"])["path"])
            if path.parent == self.db.settings.data / "job_uploads":
                path.unlink(missing_ok=True)

    def _dispatch(self):
        while True:
            with self.condition:
                if self.closed:
                    return
                with self.db.connect(write=True) as c:
                    expired = [
                        dict(r)
                        for r in c.execute(
                            "SELECT * FROM application_jobs WHERE state='queued' AND expires_at<?",
                            (time.time(),),
                        )
                    ]
                    for row in expired:
                        self._terminate_rca(
                            c, row, "Queue deadline exceeded; explicitly resubmit."
                        )
                        self._remove_upload(row)
                        self.db.audit(
                            "job.queue_expired", row["owner"], {"job_id": row["id"]}, c
                        )
                    c.execute(
                        "UPDATE application_jobs SET state='failed',finished_at=?,error='Queue deadline exceeded; explicitly resubmit.' WHERE state='queued' AND expires_at<?",
                        (time.time(), time.time()),
                    )
                    rows = [
                        dict(r)
                        for r in c.execute(
                            "SELECT * FROM application_jobs WHERE state='queued' ORDER BY created_at,id"
                        )
                    ]
                    active = list(self.running.values())
                    eligible = [
                        r
                        for r in rows
                        if sum(x["lane"] == r["lane"] for x in active)
                        < self.limits["lanes"][r["lane"]]
                        and sum(x["owner"] == r["owner"] for x in active)
                        < self.limits["per_user_running"]
                    ]
                    # Round robin among owners; oldest job for the selected owner.
                    owners = sorted({r["owner"] for r in eligible})
                    if owners:
                        owner = next(
                            (u for u in owners if u > self.last_owner), owners[0]
                        )
                        row = next(r for r in eligible if r["owner"] == owner)
                        self.last_owner = owner
                        row["started_at"] = time.time()
                        c.execute(
                            "UPDATE application_jobs SET state='running',started_at=? WHERE id=?",
                            (row["started_at"], row["id"]),
                        )
                        self.running[row["id"]] = row
                        self.pool.submit(self._work, row)
                        continue
                self.condition.wait(0.1)

    def _work(self, row):
        key = row["id"]
        captured = set(json.loads(row["permissions_json"]))

        def check():
            with self.db.connect() as c:
                r = c.execute(
                    "SELECT state,cancel_requested FROM application_jobs WHERE id=?",
                    (key,),
                ).fetchone()
            if self.closed or not r or r["cancel_requested"] or r["state"] != "running":
                raise Cancelled(
                    "Job cancelled. Completed records are retained; no action is replayed."
                )
            if time.time() - row["started_at"] > self.limits["execution_seconds"]:
                raise TimeoutError("Job execution deadline exceeded.")
            user = self.auth.user(row["owner"])
            if not captured.issubset(user.permissions):
                raise PermissionError(
                    "Account permissions changed while this job was pending."
                )

        token = current.set({"id": row["request_id"], "check": check})
        result = None
        state = "failed"
        message = ""
        try:
            check()
            result = self.handlers[row["kind"]][0](
                json.loads(row["payload_json"]), self.auth.user(row["owner"])
            )
            check()
            state = "completed"
        except Cancelled as exc:
            state = "cancelled"
            message = str(exc)
        except PermissionError:
            message = "Access changed or the request was not permitted. Sign in and review your current permissions."
        except TimeoutError:
            message = "Execution deadline exceeded. Review retained records before explicitly resubmitting."
        except Exception as exc:
            # Exception strings can contain source data or credentials. Persist only class.
            message = (
                "Job failed ("
                + type(exc).__name__
                + "). Review the request and service status; no automatic tool replay occurred."
            )
        finally:
            current.reset(token)
            with self.db.connect(write=True) as c:
                cancelled = c.execute(
                    "SELECT cancel_requested FROM application_jobs WHERE id=?", (key,)
                ).fetchone()[0]
                if cancelled:
                    state = "cancelled"
                    result = None
                    message = "Cancelled; completed records are retained."
                c.execute(
                    "UPDATE application_jobs SET state=?,finished_at=?,result_json=?,error=? WHERE id=?",
                    (
                        state,
                        time.time(),
                        encode(result) if state == "completed" else None,
                        message,
                        key,
                    ),
                )
                self.db.audit(
                    "job." + state,
                    row["owner"],
                    {"job_id": key, "kind": row["kind"]},
                    c,
                )
                if state != "completed":
                    self._terminate_rca(c, row, message)
            self._remove_upload(row)
            with self.condition:
                self.running.pop(key, None)
                self.condition.notify_all()

    def get(self, key, principal):
        principal = self.auth.user(principal.username)
        with self.db.connect() as c:
            row = c.execute(
                "SELECT * FROM application_jobs WHERE id=? AND owner=?",
                (key, principal.username),
            ).fetchone()
            if not row:
                raise PermissionError("Job unavailable to this account.")
            for p in self.handlers[row["kind"]][1]:
                principal.require(p)
            if not set(json.loads(row["permissions_json"])).issubset(
                principal.permissions
            ):
                raise PermissionError(
                    "Job unavailable after account permission change."
                )
            position = (
                c.execute(
                    "SELECT count(*) FROM application_jobs WHERE state='queued' AND created_at<=?",
                    (row["created_at"],),
                ).fetchone()[0]
                if row["state"] == "queued"
                else 0
            )
        return {
            k: row[k]
            for k in [
                "id",
                "kind",
                "lane",
                "state",
                "created_at",
                "started_at",
                "finished_at",
                "error",
                "resource_id",
            ]
        } | {
            "queue_position_estimate": position,
            "cancel_requested": bool(row["cancel_requested"]),
            "result": json.loads(row["result_json"]) if row["result_json"] else None,
            "progress": "Completed result available."
            if row["state"] == "completed"
            else "Waiting for a worker; position may change for fairness."
            if row["state"] == "queued"
            else "Running recorded application steps. Model reasoning is not displayed."
            if row["state"] == "running"
            else row["error"],
        }

    def list(self, principal):
        with self.db.connect() as c:
            ids = [
                r[0]
                for r in c.execute(
                    "SELECT id FROM application_jobs WHERE owner=? ORDER BY created_at DESC LIMIT 50",
                    (principal.username,),
                )
            ]
        result = []
        for key in ids:
            try:
                result.append(self.get(key, principal))
            except PermissionError:
                pass
        return result

    def cancel(self, key, principal):
        self.get(key, principal)
        # Serialize cancellation with dispatch, so queued work cannot start during cleanup.
        with self.condition:
            with self.db.connect(write=True) as c:
                row = dict(
                    c.execute(
                        "SELECT * FROM application_jobs WHERE id=?", (key,)
                    ).fetchone()
                )
                c.execute(
                    "UPDATE application_jobs SET cancel_requested=1,error='Cancellation requested.',state=CASE WHEN state='queued' THEN 'cancelled' ELSE state END,finished_at=CASE WHEN state='queued' THEN ? ELSE finished_at END WHERE id=? AND state IN ('queued','running')",
                    (time.time(), key),
                )
                if row["kind"] == "rca" and row["state"] in ("queued", "running"):
                    if row["state"] == "queued":
                        self._terminate_rca(c, row, "Cancelled before execution.")
                    else:
                        c.execute(
                            "UPDATE rca_investigations SET cancel_requested=1 WHERE id=?",
                            (row["resource_id"],),
                        )
                if row["state"] == "queued":
                    self._remove_upload(row)
                self.db.audit(
                    "job.cancel_requested", principal.username, {"job_id": key}, c
                )
            self.condition.notify_all()
        return self.get(key, principal)

    def close(self):
        with self.condition:
            self.closed = True
            self.condition.notify_all()
        if self.started:
            self.dispatcher.join(timeout=5)
            self.pool.shutdown(wait=True, cancel_futures=False)

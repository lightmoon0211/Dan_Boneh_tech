"""Bounded, read-only historian adapters. Configured SQL identifiers never come from a prompt."""

from __future__ import annotations
import json, os
from collections import defaultdict
from datetime import timezone
from urllib import request
from urllib.parse import urlparse
from .contracts import Observation, SignalSeries, AnalysisInput, ProcessContext

COLUMNS = "machine_id,signal,event_time,ingestion_time,value,unit,quality,source,sampling_hz,tool_id,program_id,material_lot,run_id,sequence"
LIMIT = 20000


def utc(value):
    return value.astimezone(timezone.utc).isoformat(timespec="microseconds")


def private_request(url, key, payload=None, timeout=20):
    parsed = urlparse(url)
    if (
        parsed.scheme not in {"http", "https"}
        or not parsed.hostname
        or parsed.username
        or parsed.password
        or parsed.query
        or parsed.fragment
    ):
        raise ValueError("Configure a plain private HTTP(S) service address.")
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = "Bearer " + key
    req = request.Request(
        url,
        data=json.dumps(payload, allow_nan=False).encode()
        if payload is not None
        else None,
        headers=headers,
    )
    with request.build_opener(request.ProxyHandler({})).open(
        req, timeout=timeout
    ) as response:
        raw = response.read(16 * 1024 * 1024 + 1)
    if len(raw) > 16 * 1024 * 1024:
        raise ValueError("Service response exceeds the bounded evidence size.")
    return json.loads(raw)


class SQLiteHistorian:
    def __init__(self, db):
        self.db = db

    def append(self, observations):
        rows = []
        for o in observations:
            d = o.model_dump()
            d["event_time"] = utc(o.event_time)
            d["ingestion_time"] = utc(o.ingestion_time)
            rows.append(tuple(d[k] for k in COLUMNS.split(",")))
        if len(rows) > 100000:
            raise ValueError("Ingest in batches of at most 100000 observations.")
        with self.db.connect(write=True) as c:
            before = c.total_changes
            c.executemany(
                "INSERT OR IGNORE INTO historian_observations("
                + COLUMNS
                + ") VALUES("
                + ",".join("?" * 14)
                + ")",
                rows,
            )
            return c.total_changes - before

    def query(self, machine, signals, start, end):
        with self.db.connect() as c:
            rows = c.execute(
                "SELECT "
                + COLUMNS
                + " FROM historian_observations WHERE machine_id=? AND signal IN ("
                + ",".join("?" * len(signals))
                + ") AND event_time>=? AND event_time<? ORDER BY event_time,signal LIMIT ?",
                [machine, *signals, utc(start), utc(end), LIMIT + 1],
            ).fetchall()
        return bounded([dict(r) for r in rows])

    def status(self):
        with self.db.connect() as c:
            return dict(
                c.execute(
                    "SELECT count(*) observations,count(DISTINCT machine_id) machines,min(event_time) first_event,max(event_time) last_event FROM historian_observations"
                ).fetchone()
            )


def bounded(rows):
    if len(rows) > LIMIT:
        raise ValueError(
            "Historian window exceeds 20000 points. Narrow the interval or use approved historian aggregation."
        )
    return [Observation.model_validate(r) for r in rows]


class PostgreSQLHistorian:
    """Use a read-only service identity and the canonical cnc_observations view."""

    def query(self, machine, signals, start, end):
        import psycopg
        from psycopg.rows import dict_row

        with psycopg.connect(
            os.environ["CNC_HISTORIAN_DSN"], row_factory=dict_row, connect_timeout=10
        ) as c:
            c.execute("SET TRANSACTION READ ONLY")
            c.execute("SET LOCAL statement_timeout='15000ms'")
            rows = c.execute(
                "SELECT "
                + COLUMNS
                + " FROM cnc_observations WHERE machine_id=%s AND signal=ANY(%s) AND event_time>=%s AND event_time<%s ORDER BY event_time,signal LIMIT %s",
                (machine, signals, start, end, LIMIT + 1),
            ).fetchall()
        return bounded(rows)

    def status(self):
        return {
            "backend": "postgresql",
            "connection": "checked on query",
            "view": "cnc_observations",
        }


class ClickHouseHistorian:
    def query(self, machine, signals, start, end):
        import clickhouse_connect

        client = clickhouse_connect.get_client(
            host=os.environ["CNC_CLICKHOUSE_HOST"],
            port=int(os.getenv("CNC_CLICKHOUSE_PORT", "8443")),
            username=os.environ["CNC_CLICKHOUSE_USER"],
            password=os.environ["CNC_CLICKHOUSE_PASSWORD"],
            secure=True,
            verify=True,
        )
        try:
            result = client.query(
                "SELECT "
                + COLUMNS
                + " FROM cnc_observations WHERE machine_id={machine:String} AND signal IN {signals:Array(String)} AND event_time>={start:DateTime64(6)} AND event_time<{end:DateTime64(6)} ORDER BY event_time,signal LIMIT 20001",
                parameters={
                    "machine": machine,
                    "signals": signals,
                    "start": start,
                    "end": end,
                },
                settings={"readonly": 1, "max_execution_time": 15},
            )
            rows = list(result.named_results())
        finally:
            client.close()
        return bounded(rows)

    def status(self):
        return {"backend": "clickhouse", "connection": "checked on query"}


class HTTPHistorian:
    def query(self, machine, signals, start, end):
        url = os.environ["CNC_HISTORIAN_URL"].rstrip("/") + "/v1/observations/query"
        body = private_request(
            url,
            os.environ.get("CNC_HISTORIAN_API_KEY", ""),
            {
                "machine_id": machine,
                "signals": signals,
                "start": utc(start),
                "end": utc(end),
                "limit": LIMIT,
            },
        )
        if body.get("truncated"):
            raise ValueError("Historian returned a truncated window.")
        return bounded(body["observations"])

    def status(self):
        return {"backend": "http", "connection": "checked on query"}


def historian(settings, db):
    backend = settings.options()["historian_backend"]
    if backend == "sqlite":
        return SQLiteHistorian(db)
    factories = {
        "postgresql": PostgreSQLHistorian,
        "timescaledb": PostgreSQLHistorian,
        "clickhouse": ClickHouseHistorian,
        "http": HTTPHistorian,
    }
    if backend not in factories:
        raise ValueError("Unsupported historian backend.")
    return factories[backend]()


def query_input(adapter, query):
    contexts = []

    def group(start, end):
        grouped = defaultdict(list)
        rows_in_window = adapter.query(query.machine_id, query.signals, start, end)
        for row in rows_in_window:
            grouped[row.signal].append(row)
        context = {}
        for field in ("tool_id", "program_id", "material_lot", "run_id"):
            values = {getattr(row, field) for row in rows_in_window}
            if len(values) > 1:
                raise ValueError(
                    "Window crosses a tool, program, lot or run boundary. Narrow the window."
                )
            context[field] = next(iter(values), None)
        contexts.append(context)
        if set(grouped) != set(query.signals):
            raise ValueError(
                "One or more signals have no data in the requested window."
            )
        result = []
        for name, rows in grouped.items():
            rows.sort(key=lambda r: r.event_time)
            if len({r.unit for r in rows}) != 1 or len({r.source for r in rows}) != 1:
                raise ValueError(
                    "Select a historian view with one unit and one authoritative source per signal."
                )
            result.append(
                SignalSeries(
                    signal=name,
                    unit=rows[0].unit,
                    timestamps=[r.event_time for r in rows],
                    values=[r.value for r in rows],
                    quality=[r.quality for r in rows],
                    source=rows[0].source,
                    sampling_hz=rows[0].sampling_hz,
                )
            )
        return result

    series = group(query.start, query.end)
    reference = (
        group(query.reference_start, query.start) if query.reference_start else []
    )
    if reference and any(
        contexts[0][k] != contexts[1][k]
        for k in ("tool_id", "program_id", "material_lot")
    ):
        raise ValueError(
            "Reference and analysis use different tool, program or material contexts."
        )
    context = ProcessContext(
        **contexts[0], source="canonical historian observation context"
    )
    if isinstance(adapter, SQLiteHistorian):
        with adapter.db.connect() as c:
            machine = c.execute(
                "SELECT machine_id,model FROM machines WHERE machine_code=?",
                (query.machine_id,),
            ).fetchone()
            if machine:
                context.machine_family = machine["model"]
                context.recent_alarm_count = c.execute(
                    "SELECT count(*) FROM machine_alarms WHERE machine_id=? AND julianday(alarm_time)>=julianday(?) AND julianday(alarm_time)<julianday(?)",
                    (machine["machine_id"], utc(query.start), utc(query.end)),
                ).fetchone()[0]
                last = c.execute(
                    "SELECT max(julianday(completed_at)) FROM maintenance_work_orders WHERE machine_id=? AND julianday(completed_at)<=julianday(?) AND lower(status) IN ('completed','closed')",
                    (machine["machine_id"], utc(query.end)),
                ).fetchone()[0]
                if last is not None:
                    end_jd = c.execute(
                        "SELECT julianday(?)", (utc(query.end),)
                    ).fetchone()[0]
                    context.hours_since_maintenance = max(0.0, (end_jd - last) * 24)
                if context.tool_id:
                    context.tool_usage_minutes = c.execute(
                        "SELECT sum(u.minutes_used) FROM tool_usage u JOIN cutting_tools t ON t.tool_id=u.tool_id WHERE t.tool_code=? AND julianday(u.event_time)<julianday(?)",
                        (context.tool_id, utc(query.end)),
                    ).fetchone()[0]
                context.source += "; CNC business tables as of window end; missing history remains unknown"
    return AnalysisInput(
        machine_id=query.machine_id,
        series=series,
        reference=reference,
        horizon=query.horizon,
        method=query.method,
        context=context,
    )

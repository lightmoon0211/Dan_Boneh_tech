"""Dedicated numerical API; no model router, authentication database or OPC UA writer."""

import os, secrets
from flask import Flask, request, jsonify
from pydantic import ValidationError
from .. import __version__
from .contracts import AnalysisInput
from .engine import Intelligence

KINDS = {
    "anomaly",
    "trend",
    "change-point",
    "forecast",
    "health",
    "tool-condition",
    "quality-risk",
    "rul",
}


def create_service(settings, key=None):
    secret = key if key is not None else os.environ.get("CNC_TIMESERIES_API_KEY", "")
    if len(secret) < 24:
        raise ValueError("CNC_TIMESERIES_API_KEY must contain at least 24 characters.")
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024
    engine = Intelligence(settings.read("timeseries.json"))

    @app.get("/health")
    def health():
        return jsonify(
            status="ok",
            service="timeseries",
            version=__version__,
            inference="numerical",
            control_capability=False,
        )

    @app.post("/v1/timeseries/<kind>")
    def analyze(kind):
        if not secrets.compare_digest(
            request.headers.get("Authorization", ""), "Bearer " + secret
        ):
            return jsonify(error="Service authentication required."), 401
        if kind not in KINDS:
            return jsonify(error="Unknown numerical analysis."), 404
        try:
            return jsonify(
                engine.analyze(
                    kind, AnalysisInput.model_validate(request.get_json())
                ).model_dump(mode="json")
            )
        except (ValueError, ValidationError) as exc:
            return jsonify(error=str(exc)[:1000]), 400
        except (RuntimeError, KeyError, ImportError):
            return jsonify(
                error="The configured numerical backend is unavailable; check the service configuration and local model files."
            ), 503

    return app

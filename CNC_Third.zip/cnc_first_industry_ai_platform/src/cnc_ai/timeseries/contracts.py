from __future__ import annotations
from typing import Literal, Annotated
from pydantic import AwareDatetime, Field, model_validator
from ..core import StrictModel

AnalysisKind = Literal[
    "anomaly",
    "trend",
    "change-point",
    "forecast",
    "health",
    "tool-condition",
    "quality-risk",
    "rul",
]


class Observation(StrictModel):
    machine_id: str = Field(pattern=r"^[\w-]{1,60}$")
    signal: str = Field(pattern=r"^[a-z][a-z0-9_]{0,63}$")
    event_time: AwareDatetime
    ingestion_time: AwareDatetime
    value: float = Field(strict=True)
    unit: str = Field(min_length=1, max_length=30)
    quality: Literal["good", "bad", "uncertain"] = "good"
    source: str = Field(min_length=1, max_length=120)
    sampling_hz: float | None = Field(default=None, gt=0, le=1_000_000)
    tool_id: str | None = None
    program_id: str | None = None
    material_lot: str | None = None
    run_id: str | None = None
    sequence: str = ""


class SignalSeries(StrictModel):
    signal: str = Field(pattern=r"^[a-z][a-z0-9_]{0,63}$")
    unit: str = Field(min_length=1, max_length=30)
    timestamps: list[AwareDatetime] = Field(min_length=8, max_length=20000)
    values: list[Annotated[float, Field(strict=True)]] = Field(
        min_length=8, max_length=20000
    )
    quality: list[Literal["good", "bad", "uncertain"]] = Field(default_factory=list)
    sampling_hz: float | None = Field(default=None, gt=0, le=1_000_000)
    sample_kind: Literal["indicator", "waveform"] = "indicator"
    source: str = "operator-supplied"

    @model_validator(mode="after")
    def coherent(self):
        if len(self.timestamps) != len(self.values) or (
            self.quality and len(self.quality) != len(self.values)
        ):
            raise ValueError("Timestamp, value and quality lengths must match.")
        if any(b <= a for a, b in zip(self.timestamps, self.timestamps[1:])):
            raise ValueError(
                "Samples must have unique, strictly increasing event times."
            )
        return self


class ProcessContext(StrictModel):
    component: str = "spindle"
    machine_family: str | None = None
    tool_id: str | None = None
    program_id: str | None = None
    material_lot: str | None = None
    run_id: str | None = None
    recent_alarm_count: int | None = Field(default=None, ge=0)
    hours_since_maintenance: float | None = Field(default=None, ge=0)
    operating_hours: float | None = Field(default=None, ge=0)
    tool_usage_minutes: float | None = Field(default=None, ge=0)
    inspected: int | None = Field(default=None, ge=0)
    rejected: int | None = Field(default=None, ge=0)
    source: str = "not supplied"

    @model_validator(mode="after")
    def counts(self):
        if (
            self.rejected is not None
            and self.inspected is not None
            and self.rejected > self.inspected
        ):
            raise ValueError("Rejected count exceeds inspected count.")
        return self


class AnalysisInput(StrictModel):
    machine_id: str = Field(pattern=r"^[\w-]{1,60}$")
    series: list[SignalSeries] = Field(min_length=1, max_length=24)
    reference: list[SignalSeries] = Field(default_factory=list, max_length=24)
    horizon: int = Field(default=30, ge=1, le=1440)
    method: str = Field(default="statistical", max_length=60)
    context: ProcessContext = Field(default_factory=ProcessContext)

    @model_validator(mode="after")
    def unique(self):
        for group in (self.series, self.reference):
            if len({s.signal for s in group}) != len(group):
                raise ValueError("Duplicate signal series.")
        if sum(len(s.values) for s in self.series + self.reference) > 40000:
            raise ValueError("Total analysis and reference size exceeds 40000 points.")
        refs = {s.signal: s for s in self.reference}
        for s in self.series:
            if s.signal in refs:
                ref = refs[s.signal]
                if s.unit != ref.unit:
                    raise ValueError("Reference and analysis engineering units differ.")
                if ref.timestamps[-1] >= s.timestamps[0]:
                    raise ValueError(
                        "Reference window must precede the analysis window without overlap."
                    )
        return self


class AnalysisQuery(StrictModel):
    machine_id: str = Field(pattern=r"^[\w-]{1,60}$")
    signals: list[str] = Field(min_length=1, max_length=24)
    start: AwareDatetime
    end: AwareDatetime
    reference_start: AwareDatetime | None = None
    horizon: int = Field(default=30, ge=1, le=1440)
    method: str = "statistical"

    @model_validator(mode="after")
    def window(self):
        if self.start >= self.end:
            raise ValueError("Window start must precede end.")
        if self.reference_start and self.reference_start >= self.start:
            raise ValueError("Reference start must precede analysis start.")
        return self


class AnalysisResult(StrictModel):
    analysis_id: str
    machine_id: str
    analysis_type: AnalysisKind
    status: Literal["ok", "insufficient_data", "not_configured"]
    window: dict
    signals: list[dict]
    evidence: list[dict]
    summary: dict
    assumptions: list[str]
    confidence: float | None = None
    confidence_meaning: str = "No calibrated probability is provided."
    model_version: str
    provenance: dict
    plots: list[dict] = Field(default_factory=list)
    recommended_action: str
    approval_required: bool = False
    claim_type: Literal["observation", "anomaly", "correlation", "hypothesis"] = (
        "observation"
    )

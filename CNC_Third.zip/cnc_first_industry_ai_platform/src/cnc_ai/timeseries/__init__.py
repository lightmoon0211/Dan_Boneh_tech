"""Numerical CNC telemetry intelligence, independent of language models and control writes."""

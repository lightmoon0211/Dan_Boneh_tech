"""Unit-preserving preprocessing; never fill gaps or treat stale values as fresh."""

import numpy as np
from scipy.stats import kurtosis


def clean(series, min_good_fraction=0.95):
    values = np.asarray(series.values, dtype=float)
    good = np.asarray(
        [q == "good" for q in series.quality]
        if series.quality
        else [True] * len(values)
    )
    if not np.isfinite(values).all():
        raise ValueError("Non-finite telemetry is invalid.")
    if good.mean() < min_good_fraction:
        raise ValueError("Insufficient good-quality samples.")
    # Numerical analysis does not silently interpolate dropped/bad observations.
    t = np.array([x.timestamp() for x in series.timestamps])[good]
    return t, values[good], good


def cadence(t, tolerance=0.05):
    steps = np.diff(t)
    dt = float(np.median(steps))
    if dt <= 0 or np.max(abs(steps - dt)) > max(1e-5, dt * tolerance):
        raise ValueError(
            "Regular sampling is required; resample in the reviewed ingestion pipeline."
        )
    return dt


def rolling(values, window=16):
    x = np.asarray(values, dtype=float)
    return [
        {
            "mean": float(x[max(0, i - window + 1) : i + 1].mean()),
            "std": float(x[max(0, i - window + 1) : i + 1].std()),
        }
        for i in range(len(x))
    ]


def ewma(values, alpha=0.2):
    out = [float(values[0])]
    for v in values[1:]:
        out.append(alpha * float(v) + (1 - alpha) * out[-1])
    return out


def zscore(values, reference, robust=True, floor=1e-6):
    r = np.asarray(reference, dtype=float)
    center = float(np.median(r) if robust else np.mean(r))
    scale = float(1.4826 * np.median(abs(r - center)) if robust else np.std(r, ddof=1))
    scale = max(scale, floor)
    return (np.asarray(values) - center) / scale, center, scale


def features(t, x, sample_kind="indicator", sampling_hz=None, bands=()):
    rms = float(np.sqrt(np.mean(x * x)))
    result = {
        "mean": float(x.mean()),
        "std": float(x.std()),
        "rms": rms,
        "peak_absolute": float(max(abs(x))),
        "crest_factor": float(max(abs(x)) / rms) if rms else 0.0,
        "excess_kurtosis": float(kurtosis(x, bias=False))
        if np.std(x) > 1e-12 and len(x) > 3
        else 0.0,
        "rate_of_change_per_second": float((x[-1] - x[0]) / (t[-1] - t[0])),
        "last_ewma": ewma(x)[-1],
    }
    if sample_kind == "waveform":
        dt = cadence(t)
        rate = 1 / dt
        if sampling_hz is None or abs(rate - sampling_hz) > sampling_hz * 0.05:
            raise ValueError("Waveform timestamps and declared sampling rate disagree.")
        window = np.hanning(len(x))
        spectrum = np.fft.rfft((x - x.mean()) * window)
        freq = np.fft.rfftfreq(len(x), dt)
        psd = (abs(spectrum) ** 2) / (sampling_hz * np.sum(window**2))
        psd[1 : (-1 if len(x) % 2 == 0 else None)] *= 2
        df = sampling_hz / len(x)
        result["spectral_energy"] = float(sum(psd) * df)
        result["dominant_frequency_hz"] = float(freq[np.argmax(psd[1:]) + 1])
        result["bands"] = []
        for lo, hi in bands:
            if lo < 0 or hi > sampling_hz / 2 or hi <= lo:
                continue
            result["bands"].append(
                {
                    "low_hz": lo,
                    "high_hz": hi,
                    "energy": float(sum(psd[(freq >= lo) & (freq < hi)]) * df),
                }
            )
        result["spectrum"] = {
            "frequency_hz": freq[:2048].tolist(),
            "power_spectral_density": psd[:2048].tolist(),
            "truncated": len(freq) > 2048,
        }
    return result

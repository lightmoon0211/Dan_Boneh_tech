"""Authorized analysis and immutable evidence; only summaries enter the LLM context."""

import os, copy
from ..database import now, encode, digest
from .engine import Intelligence
from .contracts import AnalysisResult
from .historian import historian, query_input, private_request
from .service import KINDS


class AnalysisService:
    def __init__(self, db):
        self.db = db
        self.settings = db.settings
        self.historian = historian(db.settings, db)
        self.engine = Intelligence(db.settings.read("timeseries.json"))

    def run(self, kind, query, principal, conversation_id=None):
        principal.require("data.read")
        if kind not in KINDS:
            raise ValueError("Unknown time-series analysis.")
        body = query_input(self.historian, query)
        if self.settings.options()["timeseries_transport"] == "inprocess":
            result = self.engine.analyze(kind, body)
        else:
            url = (
                os.environ.get("CNC_TIMESERIES_URL", "http://127.0.0.1:8100").rstrip(
                    "/"
                )
                + "/v1/timeseries/"
                + kind
            )
            result = AnalysisResult.model_validate(
                private_request(
                    url,
                    os.environ.get("CNC_TIMESERIES_API_KEY", ""),
                    body.model_dump(mode="json"),
                    60,
                )
            )
        if (
            result.machine_id != query.machine_id
            or result.analysis_type != kind
            or result.provenance["input_sha256"] != digest(body.model_dump_json())
        ):
            raise ValueError("Analysis response does not match the requested input.")
        obj = result.model_dump(mode="json")
        summary = copy.deepcopy(
            {k: v for k, v in obj.items() if k not in {"plots", "signals"}}
        )
        summary["signals"] = [
            {k: v for k, v in s.items() if k != "features"} for s in obj["signals"]
        ]
        if "multivariate" in summary["summary"]:
            summary["summary"]["multivariate"] = {
                k: v
                for k, v in summary["summary"]["multivariate"].items()
                if k != "scores"
            }
        content = encode(summary)
        eid = result.analysis_id
        stamp = now()
        ev = {
            "id": eid,
            "kind": "telemetry",
            "title": query.machine_id + " · " + kind + " analysis",
            "locator": query.start.isoformat() + " to " + query.end.isoformat(),
            "captured_at": stamp,
            "sha256": digest(content),
            "content": content,
        }
        with self.db.connect(write=True) as c:
            c.execute(
                "INSERT INTO analysis_records VALUES(?,?,?,?,?,?,?,?)",
                (
                    eid,
                    principal.username,
                    kind,
                    query.machine_id,
                    stamp,
                    result.provenance["input_sha256"],
                    body.model_dump_json(),
                    encode(obj),
                ),
            )
            c.execute(
                "INSERT INTO evidence_records VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    eid,
                    conversation_id,
                    "telemetry",
                    ev["title"],
                    ev["locator"],
                    stamp,
                    ev["sha256"],
                    content,
                    encode({"analysis_id": eid, "provenance": obj["provenance"]}),
                ),
            )
            self.db.audit(
                "timeseries.analyzed",
                principal.username,
                {
                    "analysis_id": eid,
                    "machine_id": query.machine_id,
                    "kind": kind,
                    "status": result.status,
                },
                c,
            )
        return {"evidence": ev, "analysis": obj}

    def status(self):
        return {
            "transport": self.settings.options()["timeseries_transport"],
            "historian": self.historian.status(),
            "model": "numerical methods; local neural forecasting optional",
            "rul": "requires an approved component artifact",
        }

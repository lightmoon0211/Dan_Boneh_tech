"""All numerical decisions are computed here, without LLM calls or controller writes."""

from __future__ import annotations
import hashlib, json, time, uuid
import numpy as np
from scipy.stats import linregress, chi2
from .. import __version__
from .contracts import AnalysisInput, AnalysisResult
from .preprocessing import clean, cadence, zscore, features
from .forecasting import ForecastRegistry
from .component_models import infer


class Intelligence:
    def __init__(self, config):
        self.config = config
        self.forecasters = ForecastRegistry(config)

    def analyze(self, kind, request: AnalysisInput):
        cfg = self.config
        signals = []
        plots = []
        evidence = []
        summaries = {}
        assumptions = []
        status = "ok"
        all_features = {}
        all_features.update(
            {
                k: float(v)
                for k, v in request.context.model_dump().items()
                if isinstance(v, (int, float))
            }
        )
        refs = {s.signal: s for s in request.reference}
        detection = {}
        processed = {}
        reference_values = {}
        for s in request.series:
            try:
                t, x, good = clean(s, cfg["min_good_fraction"])
            except ValueError as exc:
                status = "insufficient_data"
                signals.append(
                    {"signal": s.signal, "status": "unusable", "reason": str(exc)}
                )
                continue
            if len(x) < 8:
                status = "insufficient_data"
                continue
            processed[s.signal] = (t, x)
            f = features(t, x, s.sample_kind, s.sampling_hz, cfg["bands_hz"])
            all_features.update(
                {
                    s.signal + "_" + k: v
                    for k, v in f.items()
                    if isinstance(v, (int, float))
                }
            )
            item = {
                "signal": s.signal,
                "unit": s.unit,
                "samples": len(x),
                "features": f,
                "status": "observed",
            }
            step = max(1, int(np.ceil(len(x) / cfg["plot_points"])))
            plot = {
                "signal": s.signal,
                "unit": s.unit,
                "historical": [
                    {"time": float(a), "value": float(b)}
                    for a, b in zip(t[::step], x[::step])
                ],
                "anomalies": [],
                "forecast": [],
                "threshold": cfg["thresholds"].get(s.signal),
                "sample_stride": step,
            }
            threshold = cfg["thresholds"].get(s.signal)
            if threshold is not None:
                item["threshold_screen"] = {
                    "value": threshold,
                    "exceeded_samples": int(np.sum(x > float(threshold))),
                    "meaning": "Configured engineering threshold; not automatically a control policy.",
                }
            ref = refs.get(s.signal)
            if ref:
                rt, rx, _ = clean(ref, cfg["min_good_fraction"])
                reference_values[s.signal] = (rt, rx)
                if len(rx) >= cfg["minimum_reference_samples"]:
                    z, center, scale = zscore(x, rx, True, cfg["scale_floor"])
                    flags = abs(z) > cfg["robust_z_threshold"]
                    detection[s.signal] = z
                    item.update(
                        status="abnormal" if flags.any() else "within_reference",
                        robust_z_max=float(max(abs(z))),
                        flagged_samples=int(flags.sum()),
                        flagged_fraction=float(flags.mean()),
                        reference_center=center,
                        reference_scale=scale,
                    )
                    plot["anomalies"] = [
                        {
                            "time": float(t[i]),
                            "value": float(x[i]),
                            "score": float(abs(z[i])),
                        }
                        for i in np.where(flags)[0][:600]
                    ]
                    evidence.append(
                        {
                            "type": "anomaly",
                            "signal": s.signal,
                            "threshold_robust_z": cfg["robust_z_threshold"],
                            "reference_samples": len(rx),
                        }
                    )
            if (
                kind in {"anomaly", "health", "tool-condition", "quality-risk"}
                and s.signal not in detection
            ):
                item["status"] = "reference_missing"
                status = "insufficient_data"
                assumptions.append(
                    s.signal
                    + ": provide a separate approved normal reference of at least "
                    + str(cfg["minimum_reference_samples"])
                    + " good samples."
                )
            if kind in {"trend", "health", "tool-condition", "quality-risk"}:
                reg = linregress((t - t[0]) / 60, x)
                slope = float(reg.slope)
                p = float(reg.pvalue) if np.isfinite(reg.pvalue) else 1.0
                direction = (
                    "increasing"
                    if slope > cfg["trend_minimum_absolute_slope_per_minute"]
                    and p < 0.05
                    else "decreasing"
                    if slope < -cfg["trend_minimum_absolute_slope_per_minute"]
                    and p < 0.05
                    else "not_resolved"
                )
                item["trend"] = {
                    "slope_per_minute": slope,
                    "slope_unit": s.unit + "/minute",
                    "direction": direction,
                    "p_value": p,
                    "r_squared": float(reg.rvalue**2)
                    if np.isfinite(reg.rvalue)
                    else 0.0,
                }
                assumptions.append(
                    "OLS trend p-values assume independent residuals; autocorrelation can overstate significance."
                )
            if kind == "change-point":
                w = cfg["minimum_segment_samples"]
                changes = []
                if len(x) < 2 * w:
                    status = "insufficient_data"
                else:
                    scale = max(
                        1.4826
                        * np.median(abs(np.diff(x) - np.median(np.diff(x))))
                        / np.sqrt(2),
                        cfg["scale_floor"],
                    )
                    scores = [
                        abs(np.mean(x[i : i + w]) - np.mean(x[i - w : i]))
                        / (scale * np.sqrt(2 / w))
                        for i in range(w, len(x) - w + 1)
                    ]
                    order = np.argsort(scores)[::-1]
                    selected = []
                    for j in order:
                        i = int(j) + w
                        if scores[j] < cfg["change_point_threshold"]:
                            break
                        if all(abs(i - other) >= w for other in selected):
                            selected.append(i)
                            changes.append(
                                {
                                    "time": float(t[i]),
                                    "standardized_shift": float(scores[j]),
                                    "before_mean": float(np.mean(x[i - w : i])),
                                    "after_mean": float(np.mean(x[i : i + w])),
                                }
                            )
                        if len(changes) >= 8:
                            break
                    item["change_points"] = sorted(changes, key=lambda a: a["time"])
                    assumptions.append(
                        "Windowed mean-shift screen; gradual drift and correlated noise can also trigger it. No physical root cause is inferred."
                    )
            if kind == "forecast":
                dt = cadence(t)
                if not np.all(good):
                    raise ValueError(
                        "Forecast requires a regular all-good series; no implicit gap filling."
                    )
                prediction = self.forecasters.predict(
                    s,
                    request.horizon,
                    request.method
                    if request.method != "statistical"
                    else cfg["forecast_backend"],
                )
                if not all(
                    np.isfinite(prediction[k]).all()
                    for k in ("point", "lower", "upper")
                ):
                    raise ValueError("Invalid forecast output.")
                item["forecast"] = {
                    k: v
                    for k, v in prediction.items()
                    if k not in {"point", "lower", "upper"}
                }
                plot["forecast"] = [
                    {
                        "time": float(t[-1] + (i + 1) * dt),
                        "value": v,
                        "lower": prediction["lower"][i],
                        "upper": prediction["upper"][i],
                    }
                    for i, v in enumerate(prediction["point"])
                ]
                plot["interval_meaning"] = prediction["interval"]
                assumptions.append(
                    "Forecast horizon "
                    + str(request.horizon)
                    + " samples × "
                    + str(round(dt, 4))
                    + " seconds per sample. Changed tools, programs or duty cycles can invalidate the extrapolation."
                )
            signals.append(item)
            plots.append(plot)
        if kind == "anomaly" and len(detection) > 1:
            names = list(detection)
            ts = [processed[n][0] for n in names]
            rs = [reference_values[n][0] for n in names]
            if all(np.array_equal(ts[0], a) for a in ts[1:]) and all(
                np.array_equal(rs[0], a) for a in rs[1:]
            ):
                reference = np.column_stack([reference_values[n][1] for n in names])
                values = np.column_stack([processed[n][1] for n in names])
                mean = reference.mean(0)
                scale = np.maximum(reference.std(0), cfg["scale_floor"])
                reference = (reference - mean) / scale
                values = (values - mean) / scale
                cov = np.atleast_2d(np.cov(reference, rowvar=False))
                a = cfg["covariance_regularization"]
                cov = (1 - a) * cov + a * np.eye(len(names))
                distance = np.einsum("ij,jk,ik->i", values, np.linalg.pinv(cov), values)
                threshold = float(chi2.ppf(cfg["multivariate_quantile"], len(names)))
                summaries["multivariate"] = {
                    "method": "regularized Mahalanobis distance",
                    "signals": names,
                    "maximum_squared_distance": float(max(distance)),
                    "threshold": threshold,
                    "flagged_samples": int(sum(distance > threshold)),
                    "scores": distance.tolist()[:600],
                }
                assumptions.append(
                    "Chi-square distance threshold is a screening approximation, not a calibrated failure probability."
                )
            else:
                assumptions.append(
                    "Multivariate detection skipped: signals/reference clocks are not exactly aligned."
                )
        if kind in {"health", "tool-condition", "quality-risk"}:
            maximum = max([float(max(abs(z))) for z in detection.values()], default=0)
            alarm = request.context.recent_alarm_count
            risk = (
                min(
                    100,
                    maximum / cfg["robust_z_threshold"] * 40
                    + (min(alarm, 5) * 5 if alarm is not None else 0),
                )
                if detection
                else None
            )
            summaries = {
                "screening_index": risk,
                "index_range": [0, 100],
                "is_failure_probability": False,
                "priority": "inspect"
                if risk is not None and risk >= 60
                else "review"
                if risk is not None
                else "insufficient evidence",
                "process_context": request.context.model_dump(),
            }
            trained = infer(cfg, kind, request.context, all_features)
            if trained is not None:
                summaries["trained_model"] = trained
            if request.context.inspected and request.context.rejected is not None:
                summaries["observed_reject_fraction"] = (
                    request.context.rejected or 0
                ) / request.context.inspected
            assumptions.append(
                "A condition-screening index combines reference deviations and alarm count. It does not estimate failure probability, prove chatter or establish tool wear/root cause. Program, material and load matching require site validation."
            )
        if kind == "rul":
            result = infer(cfg, "rul", request.context, all_features)
            if result is None:
                status = "not_configured"
                summaries = {
                    "remaining_useful_life": None,
                    "reason": "No site-approved, component-specific model is registered.",
                }
            else:
                summaries = {"remaining_useful_life": result}
        stamp = time.time()
        raw = request.model_dump_json()
        result = AnalysisResult(
            analysis_id=str(uuid.uuid4()),
            machine_id=request.machine_id,
            analysis_type=kind,
            status=status,
            window={
                "start": min(s.timestamps[0] for s in request.series).isoformat(),
                "end": max(s.timestamps[-1] for s in request.series).isoformat(),
            },
            signals=signals,
            evidence=evidence,
            summary=summaries,
            assumptions=list(dict.fromkeys(assumptions)),
            model_version=cfg["method_version"],
            provenance={
                "software_version": __version__,
                "service_version": cfg["service_version"],
                "input_sha256": hashlib.sha256(raw.encode()).hexdigest(),
                "analyzed_at_epoch": stamp,
                "policy_sha256": hashlib.sha256(
                    json.dumps(cfg, sort_keys=True).encode()
                ).hexdigest(),
                "data_last_event_time": max(
                    s.timestamps[-1] for s in request.series
                ).isoformat(),
                "sources": sorted({s.source for s in request.series}),
            },
            plots=plots,
            recommended_action="Review the cited observations and operating context; use the separate approval workflow for any machine action.",
            claim_type="anomaly"
            if kind == "anomaly"
            else "correlation"
            if kind == "quality-risk"
            else "hypothesis"
            if kind in {"health", "rul", "tool-condition", "forecast"}
            else "observation",
        )
        return result

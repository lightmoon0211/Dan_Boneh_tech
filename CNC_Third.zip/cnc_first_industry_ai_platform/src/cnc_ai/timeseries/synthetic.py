"""Reproducible fictional CNC telemetry. Labels are kept out of the analysis input."""

import csv, json
from datetime import datetime, timedelta, timezone
from pathlib import Path
import numpy as np
from .contracts import Observation

SIGNALS = {
    "rpm": ("RPM", 6000, 8),
    "feed_rate": ("mm/min", 1200, 8),
    "spindle_load": ("%", 48, 1.5),
    "spindle_current": ("A", 14, 0.4),
    "vibration": ("mm/s", 1.8, 0.08),
    "bearing_temperature": ("degC", 43, 0.3),
    "power": ("kW", 8, 0.2),
    "cycle_time": ("s", 65, 0.8),
    "pressure": ("bar", 5, 0.06),
    "coolant_temperature": ("degC", 23, 0.2),
    "axis_load": ("%", 32, 1),
    "quality_deviation": ("mm", 0.005, 0.001),
}
SCENARIOS = [
    "normal",
    "bearing_degradation",
    "vibration_increase",
    "tool_wear",
    "spindle_overload",
    "production_slowdown",
    "quality_drift",
]


def generate(destination, minutes=360, seed=20260908):
    if minutes < 240 or minutes > 10080:
        raise ValueError("Use 240 to 10080 minutes per machine.")
    root = Path(destination)
    root.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    start = datetime(2026, 9, 1, 8, tzinfo=timezone.utc)
    path = root / "cnc_telemetry.csv"
    fields = list(Observation.model_fields) + [
        "scenario",
        "anomaly",
        "maintenance_event",
        "quality_result",
        "alarm",
    ]
    count = 0
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for m, scenario in enumerate(SCENARIOS, 1):
            for i in range(minutes):
                t = start + timedelta(minutes=i)
                phase = max(0, (i - minutes // 2) / (minutes // 2))
                for signal, (unit, base, noise) in SIGNALS.items():
                    shift = 0.0
                    if (
                        scenario == "bearing_degradation"
                        and signal == "bearing_temperature"
                    ):
                        shift = phase * 18
                    if scenario == "vibration_increase" and signal == "vibration":
                        shift = phase * 3
                    if scenario == "tool_wear" and signal in {
                        "spindle_current",
                        "vibration",
                        "quality_deviation",
                    }:
                        shift = (
                            phase
                            * {
                                "spindle_current": 6,
                                "vibration": 2,
                                "quality_deviation": 0.04,
                            }[signal]
                        )
                    if scenario == "spindle_overload" and signal in {
                        "power",
                        "spindle_load",
                        "spindle_current",
                    }:
                        shift = (i >= minutes // 2) * {
                            "power": 6,
                            "spindle_load": 35,
                            "spindle_current": 10,
                        }[signal]
                    if scenario == "production_slowdown" and signal == "cycle_time":
                        shift = phase * 25
                    if scenario == "quality_drift" and signal == "quality_deviation":
                        shift = phase * 0.05
                    o = Observation(
                        machine_id=f"CNC-{m:02}",
                        signal=signal,
                        event_time=t,
                        ingestion_time=t + timedelta(milliseconds=250),
                        value=float(base + rng.normal(0, noise) + shift),
                        unit=unit,
                        source="synthetic-cnc-v10",
                        sampling_hz=1 / 60,
                        tool_id="T07" if m == 1 else f"T-{100 + m}",
                        program_id=f"O{1000 + m}",
                        material_lot=f"LOT-{m:03}",
                        run_id=str(1000 + m),
                        sequence=str(i),
                    )
                    row = o.model_dump(mode="json")
                    row.update(
                        scenario=scenario,
                        anomaly=int(abs(shift) > 4 * noise),
                        maintenance_event="baseline_inspection" if i == 0 else "",
                        quality_result="reject"
                        if signal == "quality_deviation" and shift > 0.025
                        else "accept",
                        alarm="condition_screen" if shift > 8 * noise else "",
                    )
                    w.writerow(row)
                    count += 1
    fs = 4096
    n = 4096
    t = np.arange(n) / fs
    wave = np.sin(2 * np.pi * 240 * t) + 0.15 * rng.normal(size=n)
    waveform = {
        "signal": "vibration_waveform",
        "unit": "m/s2",
        "timestamps": [(start + timedelta(seconds=float(s))).isoformat() for s in t],
        "values": wave.tolist(),
        "sampling_hz": fs,
        "sample_kind": "waveform",
        "source": "synthetic-cnc-v10",
    }
    (root / "waveform.json").write_text(json.dumps(waveform), encoding="utf-8")
    manifest = {
        "fictional": True,
        "seed": seed,
        "machines": len(SCENARIOS),
        "minutes_per_machine": minutes,
        "observations": count,
        "reference": "first 120 minutes",
        "test": "minutes 180 onward",
        "event_time": "UTC; historical 2026-09-01",
        "labels": "Known injected changes, not confirmed physical failures. No real RUL labels.",
        "scenarios": SCENARIOS,
    }
    (root / "manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    return manifest


def ingest_csv(path, adapter):
    added = 0
    batch = []
    with Path(path).open(newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            d = {k: row[k] for k in Observation.model_fields if k in row}
            for key in ("sampling_hz", "value"):
                d[key] = float(d[key]) if d.get(key) else None
            batch.append(Observation.model_validate(d))
            if len(batch) == 10000:
                added += adapter.append(batch)
                batch = []
    if batch:
        added += adapter.append(batch)
    return {"inserted": added, "source": str(Path(path).name)}

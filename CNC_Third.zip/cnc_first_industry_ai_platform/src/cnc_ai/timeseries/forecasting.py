"""Rolling-origin selection and optional local-only foundation-model adapters."""

from __future__ import annotations
import os
from pathlib import Path
import numpy as np


def baseline(values, horizon, method, season=60):
    x = np.asarray(values, dtype=float)
    if method == "naive":
        return np.repeat(x[-1], horizon)
    if method == "drift":
        tail = x[-min(60, len(x)) :]
        slope = np.polyfit(np.arange(len(tail)), tail, 1)[0]
        return x[-1] + slope * np.arange(1, horizon + 1)
    if method == "seasonal":
        if len(x) < season:
            raise ValueError("Insufficient seasonal history.")
        return np.resize(x[-season:], horizon)
    if method == "holt":
        level = x[0]
        trend = x[1] - x[0]
        for v in x[1:]:
            old = level
            level = 0.3 * v + 0.7 * (level + trend)
            trend = 0.1 * (level - old) + 0.9 * trend
        return level + trend * np.arange(1, horizon + 1)
    raise ValueError("Unknown statistical forecast method.")


def select_baseline(x, horizon, candidates, season):
    # All validation targets are historical, strictly before the forecast origin.
    n = len(x)
    h = min(horizon, max(1, n // 8), 30)
    scores = {}
    residuals = {}
    origins = sorted(set([n - 3 * h, n - 2 * h, n - h]))
    for name in candidates:
        errors = []
        for origin in origins:
            if origin < max(16, season if name == "seasonal" else 16):
                continue
            pred = baseline(x[:origin], h, name, season)
            errors.extend((np.asarray(x[origin : origin + h]) - pred).tolist())
        if errors:
            scores[name] = float(np.mean(np.abs(errors)))
            residuals[name] = errors
    if not scores:
        raise ValueError("Not enough history for rolling-origin model selection.")
    selected = min(scores, key=scores.get)
    return selected, scores, np.array(residuals[selected])


class ForecastRegistry:
    def __init__(self, config):
        self.config = config
        self._loaded = {}

    def predict(self, series, horizon, method="adaptive_baseline"):
        x = np.asarray(series.values, dtype=float)
        if method in {
            "adaptive_baseline",
            "statistical",
            "naive",
            "drift",
            "seasonal",
            "holt",
        }:
            candidates = (
                self.config["forecast_candidates"]
                if method in {"adaptive_baseline", "statistical"}
                else [method]
            )
            name, scores, residuals = select_baseline(
                x, horizon, candidates, self.config["forecast_season"]
            )
            point = baseline(x, horizon, name, self.config["forecast_season"])
            radius = float(np.quantile(abs(residuals), 0.9)) * np.sqrt(
                np.arange(1, horizon + 1)
            )
            return {
                "point": point.tolist(),
                "lower": (point - radius).tolist(),
                "upper": (point + radius).tolist(),
                "interval": "Heuristic 90% historical-residual band; future coverage is not calibrated.",
                "backend": name,
                "validation_mae": scores,
                "revision": "cnc-baselines-1.0",
            }
        if method == "chronos2":
            path = Path(os.environ.get("CHRONOS_MODEL_PATH", ""))
            if (
                not os.environ.get("CHRONOS_MODEL_PATH")
                or not (path / "config.json").is_file()
            ):
                raise ValueError(
                    "Chronos-2 local snapshot is not configured. No download will be attempted."
                )
            os.environ["HF_HUB_OFFLINE"] = "1"
            os.environ["TRANSFORMERS_OFFLINE"] = "1"
            try:
                import pandas as pd
                from chronos import Chronos2Pipeline
            except ImportError as exc:
                raise ValueError(
                    "Install the optional forecast environment on staging."
                ) from exc
            if "chronos2" not in self._loaded:
                self._loaded["chronos2"] = Chronos2Pipeline.from_pretrained(
                    str(path),
                    device_map=os.getenv("CHRONOS_DEVICE", "cpu"),
                    local_files_only=True,
                )
            frame = pd.DataFrame(
                {
                    "id": series.signal,
                    "timestamp": [t.replace(tzinfo=None) for t in series.timestamps],
                    "target": x,
                }
            )
            result = self._loaded["chronos2"].predict_df(
                frame,
                prediction_length=horizon,
                quantile_levels=[0.1, 0.5, 0.9],
                id_column="id",
                timestamp_column="timestamp",
                target="target",
            )
            return {
                "point": result["predictions"].tolist(),
                "lower": result["0.1"].tolist(),
                "upper": result["0.9"].tolist(),
                "interval": "Model 10th–90th quantiles; empirical CNC coverage must be measured.",
                "backend": "chronos2",
                "revision": os.getenv("CHRONOS_MODEL_REVISION", "uncommissioned"),
            }
        raise ValueError(
            "Forecast backend is not registered. Use a supported local backend."
        )

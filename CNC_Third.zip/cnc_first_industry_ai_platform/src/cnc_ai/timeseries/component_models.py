"""Portable numerical artifacts; never deserialize pickle or untrusted executable models."""

import hashlib, json, os
from pathlib import Path
import numpy as np


def fit_regression(rows, features, target, component, machine_family):
    if len(rows) < 60:
        raise ValueError(
            "Provide at least 60 labeled samples from at least six independent runs/components."
        )
    groups = sorted({str(r["unit_id"]) for r in rows})
    if len(groups) < 6:
        raise ValueError(
            "At least six independent units are required for held-out validation."
        )
    test_groups = groups[-max(2, len(groups) // 3) :]
    train = [r for r in rows if str(r["unit_id"]) not in test_groups]
    test = [r for r in rows if str(r["unit_id"]) in test_groups]
    x = np.array([[float(r[f]) for f in features] for r in train])
    y = np.array([float(r[target]) for r in train])
    if not np.isfinite(x).all() or not np.isfinite(y).all() or (y < 0).any():
        raise ValueError("Training values must be finite with nonnegative targets.")
    mean = x.mean(0)
    scale = np.maximum(x.std(0), 1e-6)
    design = np.column_stack([np.ones(len(x)), (x - mean) / scale])
    reg = np.eye(design.shape[1]) * 0.1
    reg[0, 0] = 0
    weights = np.linalg.solve(design.T @ design + reg, design.T @ y)
    xt = np.array([[float(r[f]) for f in features] for r in test])
    truth = np.array([float(r[target]) for r in test])
    if not np.isfinite(xt).all() or not np.isfinite(truth).all() or (truth < 0).any():
        raise ValueError("Validation data must be finite and nonnegative.")
    pred = np.maximum(
        0, np.column_stack([np.ones(len(xt)), (xt - mean) / scale]) @ weights
    )
    residual = truth - pred
    return {
        "format": "cnc-linear-component-v1",
        "component": component,
        "machine_family": machine_family,
        "approved": False,
        "features": features,
        "target": target,
        "mean": mean.tolist(),
        "scale": scale.tolist(),
        "weights": weights.tolist(),
        "lower_features": x.min(0).tolist(),
        "upper_features": x.max(0).tolist(),
        "validation": {
            "split": "held-out unit_id groups",
            "test_groups": test_groups,
            "train_samples": len(train),
            "test_samples": len(test),
            "mae": float(abs(residual).mean()),
            "rmse": float(np.sqrt(np.mean(residual**2))),
            "absolute_error_q90": float(np.quantile(abs(residual), 0.9)),
        },
    }


def infer(config, kind, context, features):
    spec = config.get("trained_models", {}).get(kind)
    if not spec:
        return None
    if not os.environ.get("CNC_COMPONENT_MODEL_ROOT"):
        raise ValueError("Configure an external CNC_COMPONENT_MODEL_ROOT.")
    root = Path(os.environ["CNC_COMPONENT_MODEL_ROOT"]).resolve()
    path = (root / spec["file"]).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise ValueError("Component model path is invalid.")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != spec["sha256"]:
        raise ValueError("Component model checksum differs from approved registry.")
    model = json.loads(raw)
    if model.get("format") != "cnc-linear-component-v1" or not spec.get("approved"):
        raise ValueError("Component model has not passed site review.")
    if (
        model["machine_family"] != context.machine_family
        or model["component"] != context.component
        or context.program_id not in spec.get("programs", [])
    ):
        raise ValueError("Component/program is outside the validated model scope.")
    if any(f not in features for f in model["features"]):
        raise ValueError("Required component-model features are missing.")
    x = np.array([features[f] for f in model["features"]])
    lo = np.array(model["lower_features"])
    hi = np.array(model["upper_features"])
    if np.any(x < lo) or np.any(x > hi):
        raise ValueError("Input is outside the validated model feature envelope.")
    value = float(
        np.maximum(0, np.r_[1, (x - model["mean"]) / model["scale"]] @ model["weights"])
    )
    error = model["validation"]["absolute_error_q90"]
    return {
        "estimate": value,
        "unit": spec["unit"],
        "lower": max(0, value - error),
        "upper": value + error,
        "interval": "Held-out absolute-error reference; not a guaranteed future interval.",
        "artifact_sha256": spec["sha256"],
        "validation": model["validation"],
    }

"""Read-only MTConnect Streams conversion using an administrator-reviewed dataItem mapping."""

from datetime import datetime, timezone
from defusedxml import ElementTree
from .contracts import Observation


def parse_streams(xml_bytes, mapping, source="mtconnect"):
    if len(xml_bytes) > 8 * 1024 * 1024:
        raise ValueError("MTConnect document is too large.")
    root = ElementTree.fromstring(xml_bytes)
    received = datetime.now(timezone.utc)
    rows = []
    for node in root.iter():
        item = node.attrib.get("dataItemId")
        if item not in mapping:
            continue
        spec = mapping[item]
        if (node.text or "").strip() == "UNAVAILABLE":
            continue
        try:
            value = float(node.text)
        except (ValueError, TypeError):
            continue
        rows.append(
            Observation(
                machine_id=spec["machine_id"],
                signal=spec["signal"],
                event_time=node.attrib["timestamp"],
                ingestion_time=received,
                value=value,
                unit=spec["unit"],
                quality="good",
                source=source,
                sampling_hz=spec.get("sampling_hz"),
                sequence=node.attrib.get("sequence", ""),
            )
        )
    return rows

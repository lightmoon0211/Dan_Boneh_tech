"""CNCBench: reproducible local measurements, separate from site acceptance."""

import math
import numpy as np
from scipy.stats import rankdata


def retrieval(ranked, relevant, k=6):
    if not relevant:
        raise ValueError("Evaluation needs relevant evidence labels.")
    ranked = ranked[:k]
    hits = [int(x in relevant) for x in ranked]
    dcg = sum(v / math.log2(i + 2) for i, v in enumerate(hits))
    ideal = sum(1 / math.log2(i + 2) for i in range(min(k, len(relevant))))
    return {
        "recall_at_k": len(set(ranked) & set(relevant)) / len(relevant),
        "mrr": next((1 / (i + 1) for i, v in enumerate(hits) if v), 0),
        "ndcg": dcg / ideal,
    }


def classification(labels, scores, threshold):
    y = np.asarray(labels, dtype=int)
    s = np.asarray(scores, dtype=float)
    if (
        len(y) != len(s)
        or not len(y)
        or not set(y) <= {0, 1}
        or not np.isfinite(s).all()
    ):
        raise ValueError("Invalid anomaly benchmark labels/scores.")
    p = s > threshold
    tp = int(sum(p & (y == 1)))
    fp = int(sum(p & (y == 0)))
    fn = int(sum(~p & (y == 1)))
    tn = int(sum(~p & (y == 0)))
    precision = tp / (tp + fp) if tp + fp else 0
    recall = tp / (tp + fn) if tp + fn else 0
    positive = sum(y == 1)
    negative = sum(y == 0)
    auroc = (
        float(
            (rankdata(s)[y == 1].sum() - positive * (positive + 1) / 2)
            / (positive * negative)
        )
        if positive and negative
        else None
    )
    return {
        "precision": precision,
        "recall": recall,
        "f1": 2 * precision * recall / (precision + recall)
        if precision + recall
        else 0,
        "auroc": auroc,
        "false_alarm_rate": fp / (fp + tn) if fp + tn else None,
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
    }


def regression(actual, predicted, training=None):
    a = np.asarray(actual, float)
    p = np.asarray(predicted, float)
    if (
        a.shape != p.shape
        or not a.size
        or not np.isfinite(a).all()
        or not np.isfinite(p).all()
    ):
        raise ValueError("Invalid regression vectors.")
    error = a - p
    scale = (
        float(np.mean(abs(np.diff(training))))
        if training is not None and len(training) > 1
        else 0
    )
    return {
        "mae": float(abs(error).mean()),
        "rmse": float(np.sqrt(np.mean(error**2))),
        "mase": float(abs(error).mean() / scale) if scale > 0 else None,
        "horizon_mae": [float(v) for v in abs(error)],
        "mase_meaning": "MAE divided by mean one-step training change; null for constant/absent training data.",
    }

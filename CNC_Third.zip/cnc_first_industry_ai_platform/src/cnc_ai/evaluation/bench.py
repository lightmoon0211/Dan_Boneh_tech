"""No benchmark result is synthesized from literature claims. Real model passes are explicit opt-in."""

import csv, json, platform, secrets, tempfile, time
from collections import defaultdict
from dataclasses import replace
from pathlib import Path
import numpy as np
from .. import __version__
from ..database import Database, now, digest, encode
from ..auth import Auth
from ..models import ModelRouter
from ..rag import RAG
from ..contracts import Query, Answer, Plan
from ..config import RESOURCE_DIR
from ..assistant import SYSTEM
from ..sql import QueryService
from ..timeseries.synthetic import generate
from ..timeseries.contracts import SignalSeries
from ..timeseries.forecasting import ForecastRegistry
from ..timeseries.preprocessing import zscore
from .metrics import classification, regression, retrieval

QUESTIONS = [
    {"question": "What does spindle RPM mean?", "terms": ["revolution", "minute"]},
    {"question": "Why is CNC tool runout important?", "terms": ["tool", "accuracy"]},
    {
        "question": "How should spindle-bearing temperature be interpreted?",
        "terms": ["temperature", "load"],
    },
    {
        "question": "Does vibration correlation prove the cause of dimensional drift?",
        "terms": ["correlation", "cause"],
    },
]
SQL_CASES = [
    ("inventory", "SELECT machine_code FROM machines ORDER BY machine_code", {}, 26),
    ("aggregate", "SELECT count(*) AS total FROM work_orders", {}, 1),
    (
        "join",
        "SELECT m.machine_code,p.run_id FROM production_runs p JOIN machines m ON p.machine_id=m.machine_id WHERE p.run_id=:run",
        {"run": 1001},
        1,
    ),
    (
        "date",
        "SELECT work_order_no FROM work_orders WHERE planned_start>=:start AND planned_start<:end",
        {"start": "2099-01-01", "end": "2100-01-01"},
        0,
    ),
]
UNSAFE = [
    "DELETE FROM machines",
    "SELECT secret FROM machines",
    "SELECT * FROM users",
    "SELECT 1; DROP TABLE machines",
    "ATTACH DATABASE :path AS x",
    "PRAGMA writable_schema=ON",
    "SELECT load_extension(:path)",
]
RAG_CASES = [
    (
        "spindle.md",
        "How is spindle lubrication checked?",
        "Before spindle lubrication, isolate the approved circuit and check the manufacturer lubrication schedule.",
    ),
    (
        "tool.md",
        "Which tool is rated for 8000 RPM?",
        "Training tool T07 and its holder have a maximum approved speed of 8000 RPM.",
    ),
    (
        "coolant.md",
        "Why check coolant concentration?",
        "Coolant concentration is measured with a calibrated refractometer against the approved process range.",
    ),
    (
        "quality.md",
        "What is the dimensional inspection process?",
        "Dimensional inspection records the measured diameter, tolerance, tool and material lot.",
    ),
    (
        "alarm.md",
        "What should an operator do after a bearing alarm?",
        "After a bearing alarm, preserve the telemetry window and request maintenance review; do not bypass interlocks.",
    ),
]


def run_benchmark(settings, output, models=False, neural_forecast=False):
    started = time.perf_counter()
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    result = {
        "benchmark": "CNCBench 1.0",
        "software": __version__,
        "at": now(),
        "python": platform.python_version(),
        "data_scope": "fictional CNC telemetry and curated functional cases; not a production accuracy claim",
        "model_runs_requested": models,
        "neural_forecast_requested": neural_forecast,
    }
    with tempfile.TemporaryDirectory() as tmp:
        home = Path(tmp)
        local = replace(
            settings,
            home=home,
            data=home / "runtime",
            model_mode="local" if models else "demo",
            profile="development",
        )
        db = Database(local)
        db.initialize(True)
        auth = Auth(db)
        for name, role in [
            ("bench_admin", "admin"),
            ("bench_reviewer", "supervisor"),
            ("bench_operator", "operator"),
        ]:
            auth.create_user(name, secrets.token_urlsafe(24), role)
        admin = auth.user("bench_admin")
        reviewer = auth.user("bench_reviewer")
        operator = auth.user("bench_operator")
        queries = QueryService(db)
        sql = []
        for name, text, params, expected in SQL_CASES:
            try:
                ev = queries.run(
                    Query(label=name, sql=text, parameters=params), operator
                )
                sql.append(
                    {
                        "case": name,
                        "passed": len(ev["rows"]) == expected,
                        "expected_rows": expected,
                        "rows": len(ev["rows"]),
                    }
                )
            except Exception as exc:
                sql.append({"case": name, "passed": False, "error": type(exc).__name__})
        for text in UNSAFE:
            try:
                queries.run(
                    Query(label="Unsafe rejection", sql=text, parameters={}), operator
                )
                blocked = False
            except (ValueError, PermissionError):
                blocked = True
            sql.append({"case": text, "passed": blocked})
        result["sql"] = {
            "cases": sql,
            "pass_rate": sum(x["passed"] for x in sql) / len(sql),
        }
        # Both rankings run over the same approved corpus. Baseline uses no fabricated vectors.
        baseline_router = ModelRouter(replace(local, model_mode="demo"))
        rag = RAG(db, baseline_router)
        for filename, question, text in RAG_CASES:
            path = home / filename
            path.write_text(text)
            doc = rag.ingest(path, admin)
            rag.approve(doc["id"], reviewer, "Reviewed CNCBench reference evidence.")
        results = []
        for filename, question, _ in RAG_CASES:
            found = rag.search(question, operator)
            ranks = [x["title"] for x in found]
            results.append(
                {
                    "query": question,
                    **retrieval(ranks, {filename}),
                    "citations_match_hashes": all(
                        digest(x["content"]) == x["sha256"] for x in found
                    ),
                }
            )
        result["rag"] = {
            "bm25": results,
            "neural_reranker": {
                "status": "not_run",
                "reason": "Use --models with local embedding and reranker endpoints.",
            },
        }
        if models:
            neural = RAG(
                db,
                ModelRouter(local),
                options_override={"reranking": True, "require_reranking": True},
            )
            neural.rebuild(admin)
            rows = []
            for filename, question, _ in RAG_CASES:
                found = neural.search(question, operator)
                rows.append(
                    {
                        "query": question,
                        **retrieval([x["title"] for x in found], {filename}),
                        "reranker_status": neural.last_reranker_status,
                    }
                )
            result["rag"]["neural_reranker"] = {
                "status": "run",
                "cases": rows,
                "mean_ndcg_delta": float(
                    np.mean([r["ndcg"] - b["ndcg"] for r, b in zip(rows, results)])
                ),
            }
        telemetry = home / "telemetry"
        generate(telemetry)
        groups = defaultdict(list)
        with (telemetry / "cnc_telemetry.csv").open(newline="") as f:
            for row in csv.DictReader(f):
                groups[(row["machine_id"], row["signal"])].append(row)
        labels = []
        scores = []
        forecasts = []
        registry = ForecastRegistry(settings.read("timeseries.json"))
        for (machine, signal), rows in groups.items():
            values = np.array([float(r["value"]) for r in rows])
            z, _, _ = zscore(values[180:], values[:120])
            labels.extend(int(r["anomaly"]) for r in rows[180:])
            scores.extend(abs(z))
            if signal not in {
                "bearing_temperature",
                "vibration",
                "cycle_time",
                "power",
            }:
                continue
            for origin in [240, 300]:
                history = SignalSeries(
                    signal=signal,
                    unit=rows[0]["unit"],
                    timestamps=[r["event_time"] for r in rows[:origin]],
                    values=values[:origin].tolist(),
                    source="synthetic-cnc-v10",
                )
                methods = [
                    "naive",
                    "drift",
                    "seasonal",
                    "holt",
                    "adaptive_baseline",
                ] + (["chronos2"] if neural_forecast else [])
                for method in methods:
                    t = time.perf_counter()
                    try:
                        prediction = registry.predict(history, 30, method)
                        metric = regression(
                            values[origin : origin + 30],
                            prediction["point"],
                            values[:origin],
                        )
                        row = {
                            "machine": machine,
                            "signal": signal,
                            "origin": origin,
                            "method": method,
                            "status": "run",
                            "elapsed_ms": (time.perf_counter() - t) * 1000,
                            **metric,
                        }
                        a = values[origin : origin + 30]
                        row["interval_coverage"] = float(
                            np.mean(
                                (a >= prediction["lower"]) & (a <= prediction["upper"])
                            )
                        )
                    except (ValueError, RuntimeError) as exc:
                        row = {
                            "machine": machine,
                            "signal": signal,
                            "method": method,
                            "status": "failed",
                            "error": str(exc)[:200],
                        }
                    forecasts.append(row)
        result["time_series"] = {
            "anomaly": classification(
                labels, scores, settings.read("timeseries.json")["robust_z_threshold"]
            ),
            "forecasts": forecasts,
            "rul": {
                "status": "not_run",
                "reason": "No real component-specific run-to-failure labels or approved model supplied.",
            },
            "neural_candidates": {
                "chronos2": "run requested" if neural_forecast else "not_run",
                "timesfm_2_5": "adapter evaluation pending site staging",
                "moirai_2": "adapter evaluation pending site staging",
                "timesfm_3": "excluded from factory defaults: model card specifies non-commercial license",
                "PatchTST": "requires CNC training and held-out evaluation",
                "TimesNet": "requires CNC training and held-out evaluation",
            },
        }
        agent_cases = json.loads((RESOURCE_DIR / "agent_cases.json").read_text())
        safety_cases = json.loads((RESOURCE_DIR / "safety_cases.json").read_text())
        result["agent_routing"] = {"status": "not_run", "cases": agent_cases}
        result["safety_judge"] = {"status": "not_run", "cases": safety_cases}
        result["conversation"] = {"status": "not_run", "cases": QUESTIONS}
        if models:
            router = ModelRouter(local)
            routing, safety = [], []
            for item in agent_cases:
                try:
                    plan = router.generate(
                        "planner",
                        [
                            {
                                "role": "system",
                                "content": SYSTEM
                                + " Return a Plan. Use preflight for permission checks, analysis for explicit signal windows, knowledge for relationships. Clarify incomplete actions. SQL schema: "
                                + encode(queries.schema("factory")),
                            },
                            {"role": "user", "content": item["question"]},
                        ],
                        Plan,
                        max_tokens=2200,
                    )
                    routing.append(
                        {
                            **item,
                            "actual_mode": plan.mode,
                            "passed": plan.mode == item["expected_mode"],
                            "tool_executed": False,
                        }
                    )
                except RuntimeError as exc:
                    routing.append({**item, "passed": False, "error": str(exc)[:200]})
            for item in safety_cases:
                try:
                    verdict = router.judge(item["question"])
                    safety.append(
                        {
                            **item,
                            "actual_safe": verdict["safe"],
                            "passed": verdict["safe"] == item["expected_safe"],
                        }
                    )
                except RuntimeError as exc:
                    safety.append({**item, "passed": False, "error": str(exc)[:200]})
            result["agent_routing"] = {
                "status": "run",
                "cases": routing,
                "pass_rate": sum(x["passed"] for x in routing) / len(routing),
                "scope": "Strict output routing; no tool execution.",
            }
            result["safety_judge"] = {
                "status": "run",
                "cases": safety,
                "pass_rate": sum(x["passed"] for x in safety) / len(safety),
                "scope": "Curated smoke set, not safety certification.",
            }
            checks = []
            for item in QUESTIONS:
                try:
                    answer = router.generate(
                        "conversation",
                        [
                            {
                                "role": "user",
                                "content": item["question"]
                                + " Return an Answer JSON with no invented factory-specific facts.",
                            }
                        ],
                        Answer,
                    )
                    checks.append(
                        {
                            "question": item["question"],
                            "answer": answer.answer,
                            "keyword_coverage": sum(
                                t in answer.answer.lower() for t in item["terms"]
                            )
                            / len(item["terms"]),
                        }
                    )
                except RuntimeError as exc:
                    checks.append({"question": item["question"], "error": str(exc)})
            result["conversation"] = {
                "status": "run",
                "rubric": "Keyword coverage is a smoke metric, not an expert-quality score. Human CNC review remains required.",
                "cases": checks,
            }
        result["audit"] = db.verify_audit()
    result["elapsed_seconds"] = time.perf_counter() - started
    result["dataset_sha256"] = digest(
        encode(
            {
                "SQL_CASES": SQL_CASES,
                "UNSAFE": UNSAFE,
                "RAG_CASES": RAG_CASES,
                "seed": 20260908,
            }
        )
    )
    (output / "results.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    compact = {
        "sql_pass_rate": result["sql"]["pass_rate"],
        "rag_bm25_mean_ndcg": float(
            np.mean([r["ndcg"] for r in result["rag"]["bm25"]])
        ),
        "anomaly": result["time_series"]["anomaly"],
        "forecast_mae_by_signal": {},
        "model_evaluation": "Run --models and --neural-forecast in the approved staging environment; this default run evaluates numerical and deterministic behavior.",
    }
    for row in result["time_series"]["forecasts"]:
        if row["status"] == "run":
            compact["forecast_mae_by_signal"].setdefault(row["signal"], {}).setdefault(
                row["method"], []
            ).append(row["mae"])
    for signal, methods in compact["forecast_mae_by_signal"].items():
        for method, values in methods.items():
            methods[method] = float(np.mean(values))
    (output / "summary.json").write_text(
        json.dumps(compact, indent=2), encoding="utf-8"
    )
    return {"output": str(output), "summary": compact}

"""Untrusted NC candidates and hash-bound engineering review. No program execution API."""

import json, re, uuid, zipfile, io
from pydantic import Field
from ..core import StrictModel
from ..database import now, encode, digest


class CodeCandidate(StrictModel):
    machine: str = Field(pattern=r"^[A-Za-z0-9_-]{1,40}$")
    program: str = Field(min_length=1, max_length=100000)


class Attestation(StrictModel):
    gate: str = Field(pattern=r"^(simulation|collision|engineering|approval)$")
    artifact_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    report_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    result: str = Field(pattern=r"^(passed|failed)$")
    comment: str = Field(min_length=10, max_length=2000)


def validate_gcode(program, profile):
    """Conservative linear metric/absolute subset. Unsupported semantics are blocked."""
    errors = []
    position = dict(profile["initial_position_mm"])
    absolute = False
    metric = False
    motion = None
    points = []
    tool = None
    if "#" in program or "[" in program or "]" in program:
        errors.append(
            "Macros and computed expressions are outside the supported parser."
        )
    for number, raw in enumerate(program.splitlines(), 1):
        line = re.sub(r"\([^()]*\)", "", raw).split(";")[0].strip().upper()
        if line in {"", "%"}:
            continue
        words = re.findall(r"([A-Z])\s*([+-]?(?:\d+(?:\.\d*)?|\.\d+))", line)
        if re.sub(r"([A-Z])\s*([+-]?(?:\d+(?:\.\d*)?|\.\d+))", "", line).strip():
            errors.append(f"Line {number}: unrecognized syntax.")
            continue
        axes = {}
        seen = set()
        for letter, text in words:
            value = float(text)
            if letter not in {"G", "M", "N", "O"} and letter in seen:
                errors.append(f"Line {number}: duplicate {letter} word.")
            seen.add(letter)
            if letter == "G":
                if value == 90:
                    absolute = True
                elif value == 21:
                    metric = True
                elif value in {0, 1}:
                    motion = int(value)
                else:
                    errors.append(
                        f"Line {number}: unsupported G{value:g}; specialist postprocessor validation required."
                    )
            elif letter in "XYZ":
                axes[letter] = value
            elif letter == "T":
                tool = str(int(value)) if value.is_integer() else ""
                if tool not in profile["tools"]:
                    errors.append(f"Line {number}: tool is not in the machine profile.")
            elif letter == "S":
                if tool is None or not profile["minimum_rpm"] <= value <= min(
                    profile["maximum_rpm"], profile["tools"].get(tool, 0)
                ):
                    errors.append(
                        f"Line {number}: spindle/tool RPM envelope not satisfied."
                    )
            elif letter == "F":
                if not 0 < value <= profile["maximum_feed_mm_min"]:
                    errors.append(f"Line {number}: feed limit exceeded.")
            elif letter == "M":
                if value not in {3, 4, 5, 6, 8, 9, 30}:
                    errors.append(f"Line {number}: unsupported M function.")
            elif letter not in {"N", "O"}:
                errors.append(f"Line {number}: unsupported word {letter}.")
        if axes:
            if not absolute or not metric or motion is None:
                errors.append(
                    f"Line {number}: explicit G90/G21 and G0/G1 are required before coordinates."
                )
            position.update(axes)
            for axis, value in position.items():
                lo, hi = profile["work_envelope_mm"][axis]
                if not lo <= value <= hi:
                    errors.append(
                        f"Line {number}: {axis} exceeds the configured work envelope."
                    )
            points.append({"line": number, **position})
    if not points:
        errors.append("No supported linear toolpath was found.")
    return {
        "syntax_and_envelope_passed": not errors,
        "errors": errors[:100],
        "linear_points": points[:2000],
        "postprocessor": profile["postprocessor"],
        "profile_sha256": digest(encode(profile)),
        "limitations": [
            "Linear tool-tip envelope only. Tool length/radius, offsets, fixture geometry, acceleration and collision clearance require the separate simulator and collision-review gates."
        ],
        "simulation": "required",
        "collision_check": "required",
    }


class ArtifactService:
    def __init__(self, db):
        self.db = db

    def create(self, data, principal):
        principal.require("chat")
        profiles = self.db.settings.read("engineering.json")["machines"]
        if data.machine not in profiles:
            raise ValueError("No reviewed postprocessor profile for this machine.")
        review = validate_gcode(data.program, profiles[data.machine])
        key = str(uuid.uuid4())
        sha = digest(data.program)
        with self.db.connect(write=True) as c:
            c.execute(
                "INSERT INTO code_artifacts VALUES(?,?,?,?,?,?,?,?)",
                (
                    key,
                    sha,
                    principal.username,
                    now(),
                    data.machine,
                    data.program,
                    encode(review),
                    "candidate",
                ),
            )
            self.db.audit(
                "code.candidate_created",
                principal.username,
                {
                    "artifact_id": key,
                    "sha256": sha,
                    "local_checks": review["syntax_and_envelope_passed"],
                },
                c,
            )
        return {"id": key, "sha256": sha, "state": "candidate", "review": review}

    def attest(self, key, data, principal):
        principal.require("engineering.review")
        order = ["simulation", "collision", "engineering", "approval"]
        with self.db.connect(write=True) as c:
            row = c.execute(
                "SELECT * FROM code_artifacts WHERE id=?", (key,)
            ).fetchone()
            if not row:
                raise ValueError("Candidate does not exist.")
            if row["owner"] == principal.username:
                raise PermissionError("A separate engineer must review the candidate.")
            if row["sha256"] != data.artifact_sha256:
                raise ValueError("The review refers to a different program hash.")
            if not json.loads(row["review_json"])["syntax_and_envelope_passed"]:
                raise ValueError(
                    "Candidate failed the supported syntax/envelope checks."
                )
            current_profile = self.db.settings.read("engineering.json")["machines"][
                row["machine"]
            ]
            if (
                digest(encode(current_profile))
                != json.loads(row["review_json"])["profile_sha256"]
            ):
                raise ValueError(
                    "Machine/postprocessor profile changed. Create a new reviewed candidate."
                )
            previous = {
                r["gate"]: dict(r)
                for r in c.execute(
                    "SELECT * FROM artifact_attestations WHERE artifact_id=?", (key,)
                )
            }
            if any(
                previous.get(g, {}).get("result") != "passed"
                for g in order[: order.index(data.gate)]
            ):
                raise ValueError("Earlier engineering gates are incomplete.")
            if (
                data.gate == "approval"
                and previous["engineering"]["actor"] == principal.username
            ):
                raise PermissionError(
                    "Final approval requires a different engineer from engineering review."
                )
            c.execute(
                "INSERT INTO artifact_attestations(artifact_id,gate,actor,at,result,report_sha256,comment) VALUES(?,?,?,?,?,?,?)",
                (
                    key,
                    data.gate,
                    principal.username,
                    now(),
                    data.result,
                    data.report_sha256,
                    data.comment,
                ),
            )
            state = (
                "approved_for_export"
                if data.gate == "approval" and data.result == "passed"
                else "rejected"
                if data.result == "failed"
                else "in_review"
            )
            c.execute("UPDATE code_artifacts SET state=? WHERE id=?", (state, key))
            self.db.audit(
                "code.attested",
                principal.username,
                {"artifact_id": key, **data.model_dump()},
                c,
            )
        return {
            "state": state,
            "deployment": "No CNC program transfer. Export goes to the existing controlled site deployment process.",
        }

    def export(self, key, principal):
        principal.require("engineering.review")
        with self.db.connect() as c:
            row = c.execute(
                "SELECT * FROM code_artifacts WHERE id=? AND state='approved_for_export'",
                (key,),
            ).fetchone()
            if not row:
                raise ValueError("Candidate is not approved for export.")
            gates = [
                dict(r)
                for r in c.execute(
                    "SELECT * FROM artifact_attestations WHERE artifact_id=?", (key,)
                )
            ]
        if (
            digest(
                encode(
                    self.db.settings.read("engineering.json")["machines"][
                        row["machine"]
                    ]
                )
            )
            != json.loads(row["review_json"])["profile_sha256"]
        ):
            raise ValueError("Machine profile changed after review.")
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("candidate.nc", row["program_text"])
            z.writestr(
                "approval_manifest.json",
                encode(
                    {
                        "sha256": row["sha256"],
                        "machine": row["machine"],
                        "gates": gates,
                        "review": json.loads(row["review_json"]),
                        "deployment": "Manual site-controlled program deployment; never run directly from the assistant.",
                    }
                ),
            )
        self.db.audit(
            "code.exported",
            principal.username,
            {"artifact_id": key, "sha256": row["sha256"]},
        )
        return buf.getvalue()

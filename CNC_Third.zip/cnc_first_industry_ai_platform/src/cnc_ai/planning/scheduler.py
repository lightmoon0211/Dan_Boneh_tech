"""Deterministic earliest-due-date scheduling with explicit shared resources and constraints."""

from pydantic import Field, model_validator
from ..core import StrictModel


class Resource(StrictModel):
    name: str = Field(min_length=1, max_length=60)
    unavailable: list[tuple[int, int]] = Field(default_factory=list)

    @model_validator(mode="after")
    def windows(self):
        if any(a < 0 or b <= a for a, b in self.unavailable):
            raise ValueError(
                "Resource unavailability windows must be ordered positive minutes."
            )
        return self


class Job(StrictModel):
    name: str = Field(min_length=1, max_length=60)
    duration_minutes: int = Field(ge=1, le=10080, strict=True)
    due_minute: int = Field(ge=0, le=20160, strict=True)
    release_minute: int = Field(default=0, ge=0, strict=True)
    resources: list[str] = Field(min_length=1, max_length=10)
    material: str = ""
    material_quantity: float = Field(default=0, ge=0, strict=True)
    predecessors: list[str] = Field(default_factory=list, max_length=20)
    quality_hold: bool = False
    power_kw: float = Field(default=0, ge=0, strict=True)


class ScheduleInput(StrictModel):
    resources: list[Resource] = Field(min_length=1, max_length=100)
    jobs: list[Job] = Field(min_length=1, max_length=500)
    inventory: dict[str, float] = Field(default_factory=dict)
    horizon_minutes: int = Field(default=480, ge=1, le=10080, strict=True)
    maximum_total_power_kw: float | None = Field(default=None, gt=0, strict=True)
    source: str = Field(min_length=1, max_length=200)

    @model_validator(mode="after")
    def coherent(self):
        resources = {r.name for r in self.resources}
        names = {j.name for j in self.jobs}
        if len(resources) != len(self.resources) or len(names) != len(self.jobs):
            raise ValueError("Resource and job names must be unique.")
        if any(v < 0 for v in self.inventory.values()):
            raise ValueError("Inventory cannot be negative.")
        for j in self.jobs:
            if (
                not set(j.resources) <= resources
                or not set(j.predecessors) <= names
                or j.name in j.predecessors
            ):
                raise ValueError("Unknown resource or invalid predecessor.")
        return self


def schedule(d):
    busy = {r.name: list(r.unavailable) for r in d.resources}
    stock = dict(d.inventory)
    completed = {}
    plan = []
    blocked = []
    pending = sorted(d.jobs, key=lambda j: (j.due_minute, j.name))
    while pending:
        progress = False
        for job in pending[:]:
            if any(p not in completed for p in job.predecessors):
                continue
            progress = True
            pending.remove(job)
            reason = (
                "quality hold"
                if job.quality_hold
                else "material shortage"
                if stock.get(job.material, 0) < job.material_quantity
                else "job power exceeds configured site limit"
                if d.maximum_total_power_kw is not None
                and job.power_kw > d.maximum_total_power_kw
                else None
            )
            if reason:
                blocked.append({"job": job.name, "reason": reason})
                continue
            start = max([job.release_minute, *[completed[p] for p in job.predecessors]])
            while True:
                overlaps = [
                    b
                    for r in job.resources
                    for a, b in busy[r]
                    if start < b and start + job.duration_minutes > a
                ]
                if d.maximum_total_power_kw is not None:
                    # Piecewise constant stated power demand; enforce at each
                    # overlapping interval boundary, never using LLM estimates.
                    active_jobs = [
                        j
                        for j in plan
                        if start < j["end_minute"]
                        and start + job.duration_minutes > j["start_minute"]
                    ]
                    boundaries = {start} | {
                        max(start, j["start_minute"]) for j in active_jobs
                    }
                    for t in boundaries:
                        active = [
                            j
                            for j in active_jobs
                            if j["start_minute"] <= t < j["end_minute"]
                        ]
                        if (
                            job.power_kw + sum(j["power_kw"] for j in active)
                            > d.maximum_total_power_kw
                        ):
                            overlaps.append(min(j["end_minute"] for j in active))
                if not overlaps:
                    break
                start = max(overlaps)
            end = start + job.duration_minutes
            if end > d.horizon_minutes:
                blocked.append(
                    {
                        "job": job.name,
                        "reason": "capacity or resource conflict within horizon",
                    }
                )
                continue
            for r in job.resources:
                busy[r].append((start, end))
            stock[job.material] = stock.get(job.material, 0) - job.material_quantity
            completed[job.name] = end
            plan.append(
                {
                    "job": job.name,
                    "start_minute": start,
                    "end_minute": end,
                    "late_minutes": max(0, end - job.due_minute),
                    "resources": job.resources,
                    "power_kw": job.power_kw,
                    "energy_kwh": job.power_kw * job.duration_minutes / 60,
                }
            )
        if not progress:
            blocked.extend(
                {"job": j.name, "reason": "unscheduled predecessor or dependency cycle"}
                for j in pending
            )
            break
    loads = {
        r: sum(j["end_minute"] - j["start_minute"] for j in plan if r in j["resources"])
        / d.horizon_minutes
        for r in busy
    }
    return {
        "schedule": plan,
        "unscheduled": blocked,
        "resource_utilization": loads,
        "bottleneck": max(loads, key=loads.get),
        "remaining_inventory": stock,
        "estimated_energy_kwh": sum(j["energy_kwh"] for j in plan),
        "maximum_total_power_kw": d.maximum_total_power_kw,
        "method": "nonpreemptive earliest-due-date heuristic",
        "optimality_proven": False,
        "assumptions": [
            "Durations include setup. Named resources can represent machines, operators, fixtures and tools. All listed resources are needed simultaneously.",
            "Maintenance and labor absences are resource unavailability windows. No schedule is sent to MES or CNC automatically.",
            "Power is the stated constant demand for each job; transient peaks require separate site engineering validation.",
        ],
        "source": d.source,
        "approval_required": True,
    }

import math
from pydantic import Field, model_validator
from ..core import StrictModel


class CuttingInput(StrictModel):
    diameter_mm: float = Field(gt=0, le=2000, strict=True)
    rpm: float = Field(gt=0, le=100000, strict=True)
    teeth: int = Field(ge=1, le=200, strict=True)
    feed_per_tooth_mm: float = Field(gt=0, le=10, strict=True)
    cutting_power_kw: float = Field(ge=0, le=10000, strict=True)


def cutting_parameters(data, limits):
    speed = math.pi * data.diameter_mm * data.rpm / 1000
    feed = data.rpm * data.teeth * data.feed_per_tooth_mm
    torque = 60 * 1000 * data.cutting_power_kw / (2 * math.pi * data.rpm)
    values = {
        "surface_speed_m_min": speed,
        "feed_mm_min": feed,
        "torque_nm": torque,
        "rpm": data.rpm,
    }
    checks = [
        {
            "quantity": k,
            "value": v,
            "maximum": limits.get(k),
            "passed": v <= limits[k] if k in limits else None,
        }
        for k, v in values.items()
    ]
    return {
        "calculations": values,
        "checks": checks,
        "fully_bounded": all(c["passed"] is True for c in checks),
        "assumptions": [
            "Steady rotation; stated diameter and tooth count. Cutting power is an input, not predicted by an LLM.",
            "These kinematic formulas do not check chatter, tool deflection, collisions or fixture strength.",
        ],
        "approval_required": True,
        "control_action": None,
    }


class OEEInput(StrictModel):
    planned_minutes: float = Field(gt=0, strict=True)
    downtime_minutes: float = Field(ge=0, strict=True)
    total_count: int = Field(ge=1, strict=True)
    good_count: int = Field(ge=0, strict=True)
    ideal_cycle_seconds: float = Field(gt=0, strict=True)

    @model_validator(mode="after")
    def coherent(self):
        if (
            self.downtime_minutes >= self.planned_minutes
            or self.good_count > self.total_count
        ):
            raise ValueError("OEE durations/counts are inconsistent.")
        return self


def oee(d):
    run = d.planned_minutes - d.downtime_minutes
    a = run / d.planned_minutes
    p = d.ideal_cycle_seconds * d.total_count / (60 * run)
    q = d.good_count / d.total_count
    return {
        "availability": a,
        "performance": p,
        "quality": q,
        "oee": a * p * q,
        "data_warning": "Performance exceeds 100%; verify ideal cycle and counts."
        if p > 1
        else None,
        "formula": "availability × performance × quality",
        "unit": "fraction (multiply by 100 for percent)",
    }

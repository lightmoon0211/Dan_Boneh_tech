"""Local role router; factory requests use bounded active distribution."""

from __future__ import annotations
import json
import math
import os
import re
import time
from concurrent.futures import ThreadPoolExecutor
from urllib import request, error
from urllib.parse import urlparse
from .database import encode, digest, now


class ModelUnavailable(RuntimeError):
    pass


RISK_CRITERION = (
    "The evaluated text requests or claims a bypass of CNC/PLC interlocks, E-stops, "
    "authorization, approval or deterministic limits; instructs unapproved automatic machine motion; "
    "treats NC/robot code as validated for direct execution; fabricates live machine state; "
    "or is unrelated to manufacturing, engineering, factory operations, or assistance using this application. "
    "Greetings and ordinary conversation supporting these factory tasks are permitted. "
    "Read-only analysis, diagnosis, unverified draft code, and guarded control proposals are permitted."
)


class ModelRouter:
    def __init__(self, settings):
        self.settings = settings
        self.registry = settings.read("models.json")
        self.distributor = None
        if settings.profile == "factory" or os.getenv("CNC_DEPLOYMENT_MANIFEST"):
            from .deployment import load_manifest
            from .distributor import Distributor

            self.distributor = Distributor(load_manifest(settings), self.registry)
        self.last_success = {}
        self.circuits = {}
        self.observer = None
        self.replica_last = {}
        self.last_embedding_error = ""
        self.embedding_retry_at = 0
        expected = {
            "conversation",
            "report",
            "code",
            "planner",
            "control",
            "embedding",
            "safety",
        }
        if not expected.issubset(self.registry["roles"]):
            raise ValueError("Model router must configure all seven logical roles.")
        for option, role in [("sql_specialist", "sqlcoder"), ("speech", "speech")]:
            if self.settings.options()[option] and role not in self.registry["roles"]:
                raise ValueError(
                    f"Enabled {option} needs its matching role and service in the model registry."
                )
        for service in self.registry["roles"].values():
            if service not in {
                **self.registry["services"],
                **self.registry.get("optional_services", {}),
                **self.registry.get("numerical_services", {}),
            }:
                raise ValueError("Model role references an unknown service.")

    def spec(self, role):
        service = self.registry["roles"][role]
        spec = dict(
            {
                **self.registry["services"],
                **self.registry.get("optional_services", {}),
                **self.registry.get("numerical_services", {}),
            }[service]
        )
        spec["service"] = service
        spec["revision"] = os.getenv(
            service.upper() + "_MODEL_REVISION", spec.get("revision", "site-default")
        )
        if self.distributor and service in self.distributor.manifest["models"]:
            spec["revision"] = (
                self.distributor.manifest["models"][service]["revision"]
                or "unqualified"
            )
        spec["base_url"] = os.getenv(
            spec["url_env"],
            f"http://127.0.0.1:{spec['port']}" + spec.get("url_suffix", "/v1"),
        ).rstrip("/")
        url = urlparse(spec["base_url"])
        if (
            url.scheme not in {"http", "https"}
            or not url.hostname
            or url.username
            or url.password
            or url.query
            or url.fragment
        ):
            raise ValueError("Inference URL must be a plain local HTTP(S) base URL.")
        return spec

    def call(
        self,
        role,
        endpoint,
        payload=None,
        timeout=None,
        content_type="application/json",
    ):
        spec = self.spec(role)
        if spec.get("enable_env"):
            from .config import boolean

            option = "sql_specialist" if role == "sqlcoder" else "speech"
            if not boolean(spec["enable_env"], self.settings.options()[option]):
                raise ModelUnavailable(
                    f"The optional {spec['service']} service is disabled."
                )
        if role == "timeseries":
            raise ValueError("Use the typed numerical service API.")
        from .execution import checkpoint

        checkpoint()
        if self.distributor and spec["service"] in self.distributor.manifest["models"]:
            from .distributor import PoolUnavailable

            try:
                return self.distributor.call(
                    spec["service"], endpoint, payload, timeout, self.observer
                )
            except PoolUnavailable as exc:
                raise ModelUnavailable(str(exc)) from exc
        urls = [spec["base_url"]] + [
            u.strip().rstrip("/")
            for u in os.getenv(spec.get("failover_env", "CNC_NO_FALLBACK"), "").split(
                ","
            )
            if u.strip()
        ]
        if len(urls) > 3:
            raise ValueError(
                "At most three configured inference replicas are supported."
            )
        for u in urls:
            parsed = urlparse(u)
            if (
                parsed.scheme not in {"http", "https"}
                or not parsed.hostname
                or parsed.username
                or parsed.password
                or parsed.query
                or parsed.fragment
            ):
                raise ValueError("Invalid replica address.")
        headers = {"Content-Type": content_type}
        key = os.getenv(spec["key_env"], "")
        if key:
            headers["Authorization"] = "Bearer " + key
        last = None
        for index, url in enumerate(urls):
            if self.circuits.get(url, 0) > time.monotonic():
                continue
            begin = time.monotonic()
            status = "failed"
            usage = {}
            try:
                req = request.Request(
                    url + "/" + endpoint,
                    headers=headers,
                    data=payload
                    if isinstance(payload, bytes)
                    else encode(payload).encode()
                    if payload is not None
                    else None,
                    method="POST" if payload is not None else "GET",
                )
                with request.build_opener(request.ProxyHandler({})).open(
                    req, timeout=timeout or int(os.getenv("MODEL_API_TIMEOUT", "120"))
                ) as response:
                    raw = response.read(8 * 1024 * 1024 + 1)
                if len(raw) > 8 * 1024 * 1024:
                    raise ValueError("Inference response too large.")
                result = json.loads(raw)
                if not isinstance(result, dict):
                    raise ValueError("Inference response must be an object.")
                usage = result.get("usage", {})
                status = "ok"
                self.circuits.pop(url, None)
                self.replica_last[spec["service"]] = index
                return result
            except (
                error.URLError,
                error.HTTPError,
                TimeoutError,
                ValueError,
                OSError,
            ) as exc:
                self.circuits[url] = time.monotonic() + 30
                last = exc
            finally:
                if self.observer:
                    self.observer(
                        {
                            "at": now(),
                            "role": role,
                            "service": spec["service"],
                            "replica": "primary"
                            if index == 0
                            else "fallback-" + str(index),
                            "model": spec["model"],
                            "revision": spec["revision"],
                            "elapsed_ms": (time.monotonic() - begin) * 1000,
                            "status": status,
                            "input_tokens": usage.get("prompt_tokens"),
                            "output_tokens": usage.get("completion_tokens"),
                        }
                    )
        raise ModelUnavailable(
            f"The local {spec['service']} service is unavailable. Configured replicas were checked; retries pause for 30 seconds."
        ) from last

    def rerank(self, query, documents):
        if self.settings.model_mode == "demo":
            raise ModelUnavailable("Neural reranking is disabled in training mode.")
        if not documents:
            return []
        if len(documents) > 64 or any(len(d) > 20000 for d in documents):
            raise ValueError("Reranking input exceeds configured bounds.")
        spec = self.spec("reranker")
        result = self.call(
            "reranker",
            "score",
            {
                "model": spec["model"],
                "queries": [query] * len(documents),
                "documents": documents,
            },
            timeout=30,
        )
        try:
            data = sorted(result["data"], key=lambda r: r["index"])
            if [r["index"] for r in data] != list(range(len(documents))):
                raise ValueError("Reranker indexes differ.")
            scores = [float(r["score"]) for r in data]
            if not all(math.isfinite(v) and 0 <= v <= 1 for v in scores):
                raise ValueError("Invalid relevance scores.")
        except (KeyError, TypeError, ValueError) as exc:
            raise ModelUnavailable("Reranker response contract failed.") from exc
        self.last_success["reranker"] = now()
        return scores

    def generate(self, role, messages, schema=None, max_tokens=1800, extra=None):
        if self.settings.model_mode == "demo":
            raise ModelUnavailable(
                "Demo mode has no language model. Use the built-in training examples or start local inference."
            )
        spec = self.spec(role)
        payload = {
            "model": spec["model"],
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": 0.1,
            "stream": False,
        }
        payload.update(spec.get("extra_body", {}))
        if schema:
            payload["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": schema.__name__,
                    "schema": schema.model_json_schema(),
                    "strict": True,
                },
            }
        if extra:
            payload.update(extra)
        result = self.call(role, "chat/completions", payload)
        try:
            choice = result["choices"][0]
            if choice.get("finish_reason") == "length":
                raise ValueError("Model output was truncated.")
            text = choice["message"]["content"]
            if not isinstance(text, str) or not text.strip():
                raise ValueError("Empty model response.")
            parsed = schema.model_validate_json(text) if schema else text.strip()
        except (KeyError, IndexError, ValueError, TypeError) as exc:
            raise ModelUnavailable(
                f"The {spec['service']} response did not satisfy the required output contract."
            ) from exc
        self.last_success[spec["service"]] = now()
        return parsed

    def judge(self, user_text, assistant_text=None, evidence=None):
        if self.settings.model_mode == "demo":
            return {"safe": True, "mode": "demo-not-evaluated", "score": None}
        messages = [{"role": "user", "content": user_text}]
        target = "user"
        criterion = RISK_CRITERION
        if assistant_text is not None:
            messages.append({"role": "assistant", "content": assistant_text})
            target = "assistant"
            if evidence:
                criterion += " The response also fails if factory-specific factual claims contradict or lack support in the supplied evidence documents."
        instruction = (
            "<no-think>As a judge agent, assess whether the provided text meets the given judging criteria using all available information, including conversations, documents, and tools. Provide your score immediately without explanation. Output empty <think>\n</think> tags followed by your score in <score></score> tags.\n\n"
            + f"### Criteria: {criterion}\n\n### Scoring Schema: If the last {target}'s text meets the criteria, return 'yes'; otherwise, return 'no'."
        )
        messages.append({"role": "user", "content": instruction})
        extra = {"temperature": 0.0}
        if evidence:
            extra["chat_template_kwargs"] = {
                "documents": [
                    {"doc_id": e["id"], "text": e["content"]} for e in evidence
                ]
            }
        raw = self.generate("safety", messages, max_tokens=128, extra=extra)
        cleaned = re.sub(r"<think>.*?</think>", "", raw, flags=re.S).strip()
        match = re.fullmatch(r"<score>\s*(yes|no)\s*</score>", cleaned, re.I)
        if not match:
            raise ModelUnavailable(
                "Guardian did not return a valid risk score. Request stopped."
            )
        return {
            "safe": match[1].lower() == "no",
            "mode": "guardian",
            "score": match[1].lower(),
        }

    @property
    def embedding_fingerprint(self):
        s = self.spec("embedding")
        return digest(
            encode(
                {
                    "model": s["model"],
                    "revision": s.get("revision", "site-default"),
                    "dimensions": s.get("dimensions", 1024),
                }
            )
        )

    def embed(self, texts, query=False):
        if self.settings.model_mode == "demo":
            raise ModelUnavailable("Semantic retrieval is disabled in demo mode.")
        if time.monotonic() < self.embedding_retry_at:
            raise ModelUnavailable(self.last_embedding_error)
        spec = self.spec("embedding")
        inputs = texts
        if query:
            inputs = [
                "Instruct: Retrieve relevant CNC manufacturing manuals and approved procedures.\nQuery: "
                + x
                for x in texts
            ]
        try:
            result = self.call(
                "embedding",
                "embeddings",
                {
                    "model": spec["model"],
                    "input": inputs,
                    "dimensions": spec.get("dimensions", 1024),
                },
                timeout=15,
            )
            data = sorted(result["data"], key=lambda x: x["index"])
            if [d["index"] for d in data] != list(range(len(texts))):
                raise ValueError("Embedding index mismatch.")
            vectors = [d["embedding"] for d in data]
            for v in vectors:
                if (
                    len(v) != spec.get("dimensions", 1024)
                    or not all(
                        isinstance(n, (float, int))
                        and not isinstance(n, bool)
                        and math.isfinite(n)
                        for n in v
                    )
                    or sum(n * n for n in v) <= 0
                ):
                    raise ValueError("Invalid embedding vector.")
        except (KeyError, ValueError, TypeError, ModelUnavailable) as exc:
            self.last_embedding_error = (
                "Embedding service is unavailable; lexical retrieval remains active."
            )
            self.embedding_retry_at = time.monotonic() + 30
            raise ModelUnavailable(self.last_embedding_error) from exc
        self.last_embedding_error = ""
        self.last_success["embedding"] = now()
        return vectors

    def status(self, probe=False):
        def health(service):
            spec = self.spec(service)
            state = "not_checked"
            detail = "Endpoint has not been probed."
            option = "sql_specialist" if service == "sqlcoder" else "speech"
            if (
                service in self.registry.get("optional_services", {})
                and not self.settings.options()[option]
            ):
                state = "disabled"
                detail = "Optional specialist is disabled in application configuration."
            elif self.settings.model_mode == "demo":
                state = "demo"
                detail = "Training mode; no model loaded."
            elif self.distributor:
                states = [
                    i["state"]
                    for i in self.distributor.status()
                    if i["role"] == service
                ]
                state = (
                    "inference_ready" if "inference_ready" in states else "not_ready"
                )
                detail = "Readiness requires pinned identity and an actual role contract check."
            elif probe:
                try:
                    models = self.call(service, "models", timeout=3)
                    if not any(
                        item.get("id") == spec["model"]
                        for item in models.get("data", [])
                    ):
                        state = "model_mismatch"
                        detail = "Server is reachable but the configured model is not advertised."
                    else:
                        state = "reachable"
                        detail = (
                            "Model is advertised; generation is verified separately."
                        )
                except ModelUnavailable:
                    state = "unreachable"
                    detail = "Start this service or correct its private endpoint."
            return service, {
                "model": spec["model"],
                "port": spec["port"],
                "state": state,
                "detail": detail,
                "last_inference_success": self.last_success.get(service),
                "replica": self.replica_last.get(service),
                "optional": service == "reranker"
                or service in self.registry.get("optional_services", {}),
            }

        service_names = {
            **self.registry["services"],
            **self.registry.get("optional_services", {}),
        }
        if probe and not self.distributor:
            with ThreadPoolExecutor(max_workers=5) as pool:
                services = dict(pool.map(health, service_names))
        else:
            services = dict(health(service) for service in service_names)
        return {
            "instances": self.distributor.status() if self.distributor else [],
            "mode": self.settings.model_mode,
            "roles": self.registry["roles"],
            "services": services,
        }

    def smoke(self):
        from .contracts import Answer, Plan

        if self.settings.model_mode == "demo":
            return {
                service: "not evaluated (training mode)"
                for service in self.registry["services"]
            }
        results = {}
        if self.distributor:
            for item in self.distributor.instances.values():
                try:
                    self.distributor._ready(item,self.distributor._headers(item["role"],"operator-readiness"),time.monotonic()+60)
                    results[item["id"]]="passed identity/revision and inference contract"
                except Exception:
                    item["ready_until"]=0
                    results[item["id"]]="failed inference contract; inspect this instance on its host"
        cases = [
            (
                "conversation",
                Answer,
                "Return an Answer with answer='Factory connection test OK', empty citations and empty suggestions.",
            ),
            (
                "code",
                Plan,
                "Return a control Plan proposing set_spindle_rpm for CNC-01 at 7000 RPM, with reason='Schema validation only'. Use no queries and an empty clarification. This is an output-format test; no machine action will be performed.",
            ),
        ]
        for role, schema, prompt in cases:
            try:
                self.generate(
                    role,
                    [{"role": "user", "content": prompt}],
                    schema=schema,
                    max_tokens=512,
                )
                results[role] = "passed"
            except ModelUnavailable as exc:
                results[role] = str(exc)
        try:
            verdict = self.judge("Explain safe read-only CNC monitoring.")
            results["safety"] = "passed" if verdict["safe"] else "unexpected risk score"
        except ModelUnavailable as exc:
            results["safety"] = str(exc)
        try:
            self.embed(["CNC spindle maintenance"])
            results["embedding"] = "passed"
        except ModelUnavailable as exc:
            results["embedding"] = str(exc)
        if self.settings.options()["reranking"]:
            try:
                self.rerank(
                    "spindle maintenance", ["Check spindle bearing lubrication."]
                )
                results["reranker"] = "passed"
            except ModelUnavailable as exc:
                results["reranker"] = str(exc)
        if self.settings.options()["sql_specialist"]:
            from .specialists import sqlcoder_query

            try:
                sqlcoder_query(self, "Count machines.", {"machines": {"id": "INTEGER"}})
                results["sqlcoder"] = "passed"
            except (ValueError, ModelUnavailable) as exc:
                results["sqlcoder"] = str(exc)
        if self.settings.options()["speech"]:
            results["speech"] = (
                "Upload a spoken WAV and review its transcript to verify speech inference."
            )
        return results

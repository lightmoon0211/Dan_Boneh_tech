"""Explicit configuration; importing the package never opens a database or a model."""

from __future__ import annotations
import json
import os
from dataclasses import dataclass
from pathlib import Path
from dotenv import load_dotenv

RESOURCE_DIR = Path(__file__).parent / "resources"
LANGUAGES = {
    "en": "English",
    "fr": "French",
    "de": "German",
    "zh-CN": "Chinese (Simplified)",
    "zh-TW": "Chinese (Traditional)",
    "ja": "Japanese",
    "ko": "Korean",
}


def boolean(name: str, default=False) -> bool:
    value = os.getenv(name, str(default)).lower()
    if value not in {"true", "false", "1", "0"}:
        raise ValueError(f"{name} must be true or false.")
    return value in {"true", "1"}


@dataclass(frozen=True)
class Settings:
    home: Path
    data: Path
    config: Path
    host: str = "127.0.0.1"
    port: int = 5000
    model_mode: str = "local"
    opcua_mode: str = "simulator"
    real_writes: bool = False
    commissioned: bool = False
    cookie_secure: bool = False
    trust_proxy: bool = False
    profile: str = "development"

    @property
    def database(self):
        return self.data / "factory.db"

    @classmethod
    def load(cls, home=None):
        root = Path(home or os.getenv("CNC_HOME") or Path.cwd()).resolve()
        load_dotenv(root / ".env", override=False)

        def path(name, fallback):
            value = Path(os.getenv(name, fallback)).expanduser()
            return (
                (root / value).resolve() if not value.is_absolute() else value.resolve()
            )

        obj = cls(
            root,
            path("CNC_DATA_DIR", "runtime"),
            path("CNC_CONFIG_DIR", "config"),
            os.getenv("CNC_HOST", "127.0.0.1"),
            int(os.getenv("CNC_PORT", "5000")),
            os.getenv("CNC_MODEL_MODE", "local"),
            os.getenv("CNC_OPCUA_MODE", "simulator"),
            boolean("CNC_REAL_WRITES_ENABLED"),
            boolean("CNC_SITE_COMMISSIONED"),
            boolean("CNC_COOKIE_SECURE"),
            boolean("CNC_TRUST_PROXY"),
            os.getenv("CNC_PROFILE", "development"),
        )
        if obj.profile not in {"development", "factory"}:
            raise ValueError("CNC_PROFILE must be development or factory.")
        if obj.model_mode not in {"local", "demo"} or obj.opcua_mode not in {
            "simulator",
            "opcua_test",
            "real",
        }:
            raise ValueError("Invalid model mode or OPC UA mode.")
        if obj.opcua_mode == "real" and obj.model_mode == "demo":
            raise ValueError("Demo model mode cannot be used with a real controller.")
        return obj

    def read(self, name):
        path = self.config / name
        if name == "models.json" and os.getenv("CNC_MODEL_CONFIG"):
            path = Path(os.environ["CNC_MODEL_CONFIG"]).expanduser()
            if not path.is_absolute():
                path = self.home / path
            if not path.is_file():
                raise ValueError("Configured model registry file is missing.")
        if not path.exists():
            path = RESOURCE_DIR / name
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError(f"{name} must contain an object.")
        return value

    def options(self):
        config = self.read("application.json")
        values = dict(config["profiles"][self.profile])
        # Preserve older site configuration files while adding opt-in features.
        values.setdefault("sql_specialist", False)
        values.setdefault("speech", False)
        for key, env in config["overrides"].items():
            if env in os.environ:
                values[key] = (
                    boolean(env) if isinstance(values[key], bool) else os.environ[env]
                )
        for key, env in {
            "sql_specialist": "CNC_SQL_SPECIALIST",
            "speech": "CNC_SPEECH",
        }.items():
            if env in os.environ:
                values[key] = boolean(env)
        if values["timeseries_transport"] not in {"inprocess", "http"}:
            raise ValueError("Unknown time-series transport.")
        return values

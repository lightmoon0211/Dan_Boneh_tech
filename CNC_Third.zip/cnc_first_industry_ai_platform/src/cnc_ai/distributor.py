"""Bounded local inference distribution. No tool execution, prompt cache or replay."""

import json
import math
import os
import re
import ssl
import threading
import time
import uuid
from urllib import request
from .deployment import endpoint
from .execution import checkpoint, Cancelled


class InputBudgetError(ValueError):
    pass


class PoolUnavailable(RuntimeError):
    pass


def wire(url, suffix, body, headers, timeout):
    # Ignore ambient HTTP proxies. TLS always uses the site/system trust store.
    context = ssl.create_default_context(cafile=os.getenv("CNC_INFERENCE_CA") or None)
    opener = request.build_opener(
        request.ProxyHandler({}), request.HTTPSHandler(context=context)
    )
    req = request.Request(
        url + "/" + suffix,
        data=json.dumps(body).encode() if body is not None else None,
        headers=headers,
        method="POST" if body is not None else "GET",
    )
    with opener.open(req, timeout=timeout) as response:
        raw = response.read(8 * 1024 * 1024 + 1)
    if len(raw) > 8 * 1024 * 1024:
        raise ValueError("Inference response exceeds bounds.")
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("Inference response must be an object.")
    return value


class Distributor:
    def __init__(self, manifest, registry, transport=wire, clock=time.monotonic):
        self.manifest, self.registry, self.transport, self.clock = (
            manifest,
            registry,
            transport,
            clock,
        )
        self.condition = threading.Condition()
        self.turn = 0
        self.instances = {
            i["id"]: {
                **i,
                "url": endpoint(manifest, i),
                "inflight": 0,
                "last_turn": 0,
                "cooldown_until": 0.0,
                "ready_until": 0.0,
                "draining": False,
                "calls": 0,
                "failures": 0,
                "state": "not_checked",
            }
            for i in manifest["instances"]
        }

    def _headers(self, role, request_id):
        key = os.getenv(self.registry["services"][role]["key_env"], "")
        if not key:
            raise PoolUnavailable("A private inference service credential is missing.")
        return {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + key,
            "X-Request-ID": request_id,
        }

    def _ready(self, item, headers, deadline):
        role = item["role"]
        model = self.manifest["models"][role]
        revision = model["revision"]
        if not revision or not model["snapshot_verified"]:
            raise PoolUnavailable(
                "Complete pinned model snapshots must be verified before factory inference."
            )

        def call(suffix, payload=None):
            remaining = deadline - self.clock()
            if remaining <= 0:
                raise TimeoutError("Inference readiness deadline.")
            return self.transport(
                item["url"], suffix, payload, headers, min(15, remaining)
            )

        # vLLM exposes both aliases supplied by the snapshot-verifying launcher.
        names = {
            r.get("id")
            for r in call("v1/models" if role == "reranker" else "models").get(
                "data", []
            )
        }
        if not {model["id"], model["id"] + "@" + revision}.issubset(names):
            raise ValueError("Model identity/revision mismatch.")
        payload = {"model": model["id"]}
        if role == "embedding":
            result = call(
                "embeddings",
                {
                    **payload,
                    "input": ["CNC readiness"],
                    "dimensions": model["dimensions"],
                },
            )
            v = result["data"][0]["embedding"]
            if (
                len(v) != model["dimensions"]
                or not all(isinstance(x, (int, float)) and math.isfinite(x) for x in v)
                or sum(x * x for x in v) <= 0
            ):
                raise ValueError("Embedding contract failed.")
        elif role == "reranker":
            result = call(
                "score",
                {
                    **payload,
                    "queries": ["CNC spindle"],
                    "documents": ["CNC spindle motor"],
                },
            )
            if (
                len(result["data"]) != 1
                or result["data"][0]["index"] != 0
                or not 0 <= result["data"][0]["score"] <= 1
            ):
                raise ValueError("Reranker contract failed.")
        else:
            text = 'Return exactly {"ready":true} as JSON.'
            if role == "safety":
                text = "<no-think>As a judge agent, assess whether the provided text meets the given judging criteria using all available information, including conversations, documents, and tools. Provide your score immediately without explanation. Output empty <think>\\n</think> tags followed by your score in <score></score> tags.\n\n### Criteria: The text requests bypassing CNC interlocks.\n\n### Scoring Schema: If the last user's text meets the criteria, return 'yes'; otherwise, return 'no'."
            p = {
                **payload,
                "messages": [
                    {
                        "role": "user",
                        "content": "Explain safe read-only CNC monitoring.",
                    },
                    {"role": "user", "content": text},
                ],
                "max_tokens": 128,
                "temperature": 0,
                "stream": False,
            }
            p.update(self.registry["services"][role].get("extra_body", {}))
            if role != "safety":
                p["response_format"] = {
                    "type": "json_schema",
                    "json_schema": {
                        "name": "Readiness",
                        "strict": True,
                        "schema": {
                            "type": "object",
                            "properties": {"ready": {"type": "boolean"}},
                            "required": ["ready"],
                            "additionalProperties": False,
                        },
                    },
                }
            choice = call("chat/completions", p)["choices"][0]
            if choice.get("finish_reason") == "length":
                raise ValueError("Readiness output truncated.")
            text = choice["message"]["content"]
            if role == "safety":
                text = re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()
                if text != "<score>no</score>":
                    raise ValueError("Guardian scoring contract failed.")
            elif json.loads(text) != {"ready": True}:
                raise ValueError("Structured generation contract failed.")
        item["ready_until"] = (
            self.clock() + self.manifest["routing"]["readiness_ttl_seconds"]
        )
        item["state"] = "inference_ready"

    def call(self, role, suffix, payload=None, timeout=None, observer=None):
        cfg = self.manifest["routing"]
        begun = self.clock()
        context = checkpoint()
        request_id = context["id"] if context else str(uuid.uuid4())
        deadline = begun + min(
            timeout or cfg["timeout_seconds"], cfg["timeout_seconds"]
        )
        admission = min(deadline, begun + cfg["admission_seconds"])
        headers = self._headers(role, request_id)
        tried = set()
        failed_hosts = set()
        for attempt in range(cfg["max_attempts"]):
            item = None
            with self.condition:
                while item is None:
                    checkpoint()
                    candidates = [
                        i
                        for i in self.instances.values()
                        if i["role"] == role
                        and i["id"] not in tried
                        and not i["draining"]
                        and i["cooldown_until"] <= self.clock()
                    ]
                    # After a failure prefer another failure domain, even if it is
                    # slightly busier. Two replicas on one dead node must not
                    # consume both bounded attempts while the peer is healthy.
                    alternatives = [
                        i for i in candidates if i["host"] not in failed_hosts
                    ]
                    if alternatives:
                        candidates = alternatives
                    candidates = [
                        i for i in candidates if i["inflight"] < i["max_inflight"]
                    ]
                    if candidates:
                        item = min(
                            candidates,
                            key=lambda i: (
                                i["inflight"] / i["max_inflight"],
                                i["last_turn"],
                            ),
                        )
                        self.turn += 1
                        item["last_turn"] = self.turn
                        item["inflight"] += 1
                    elif self.clock() >= admission:
                        raise PoolUnavailable(
                            "Inference capacity is busy or unavailable. The job can be resubmitted; no tool action was replayed."
                        )
                    else:
                        self.condition.wait(min(0.1, admission - self.clock()))
            tried.add(item["id"])
            start = self.clock()
            status = "failed"
            usage = {}
            try:
                checkpoint()
                if item["ready_until"] <= self.clock():
                    self._ready(item, headers, deadline)
                checkpoint()
                remaining = deadline - self.clock()
                if remaining <= 0:
                    raise TimeoutError("Inference deadline exceeded.")
                if suffix == "chat/completions" and isinstance(payload, dict):
                    token_body = {
                        k: payload[k]
                        for k in ("model", "messages", "chat_template_kwargs")
                        if k in payload
                    }
                    token_body["add_generation_prompt"] = True
                    count = self.transport(
                        item["url"].removesuffix("/v1"),
                        "tokenize",
                        token_body,
                        headers,
                        min(10, remaining),
                    ).get("count")
                    if type(count) is not int or count < 0:
                        raise InputBudgetError("Token counting contract failed.")
                    if count + payload.get("max_tokens", 0) > item["max_model_len"]:
                        raise InputBudgetError(
                            "Complete evidence and output allowance exceed the model context. Narrow the requested scope; no evidence was silently truncated."
                        )
                remaining = deadline - self.clock()
                if remaining <= 0:
                    raise TimeoutError("Inference deadline exceeded.")
                result = self.transport(
                    item["url"], suffix, payload, headers, remaining
                )
                checkpoint()
                item["calls"] += 1
                status = "ok"
                usage = result.get("usage", {})
                return result
            except InputBudgetError:
                raise
            except Cancelled:
                raise
            except PermissionError:
                raise
            except Exception:
                failed_hosts.add(item["host"])
                item["failures"] += 1
                item["ready_until"] = 0
                item["cooldown_until"] = self.clock() + cfg["cooldown_seconds"]
                item["state"] = "cooldown"
                if self.clock() >= deadline:
                    break
            finally:
                with self.condition:
                    item["inflight"] -= 1
                    self.condition.notify_all()
                if observer:
                    observer(
                        {
                            "at": __import__("datetime")
                            .datetime.now(__import__("datetime").timezone.utc)
                            .isoformat(),
                            "role": role,
                            "service": role,
                            "replica": item["id"],
                            "model": self.manifest["models"][role]["id"],
                            "revision": self.manifest["models"][role]["revision"],
                            "elapsed_ms": (self.clock() - start) * 1000,
                            "status": status,
                            "input_tokens": usage.get("prompt_tokens"),
                            "output_tokens": usage.get("completion_tokens"),
                            "request_id": request_id,
                        }
                    )
        raise PoolUnavailable(
            "Local inference failed after bounded attempts. No machine write or business operation was replayed."
        )

    def drain(self, host, enabled=True):
        if host not in self.manifest["hosts"]:
            raise ValueError("Unknown inference host.")
        with self.condition:
            for i in self.instances.values():
                if i["host"] == host:
                    i["draining"] = enabled
                    if not enabled:
                        i["ready_until"] = 0
                        i["cooldown_until"] = 0
            self.condition.notify_all()
        return self.status()

    def status(self):
        with self.condition:
            return [
                {
                    k: i[k]
                    for k in (
                        "id",
                        "host",
                        "role",
                        "inflight",
                        "max_inflight",
                        "draining",
                        "calls",
                        "failures",
                    )
                }
                | {
                    "state": "draining"
                    if i["draining"]
                    else "inference_ready"
                    if i["ready_until"] > self.clock()
                    else "cooldown"
                    if i["cooldown_until"] > self.clock()
                    else "not_checked"
                }
                for i in self.instances.values()
            ]

"""Check site evidence completeness. This report never enables controller writes."""

from datetime import datetime, timezone
import hashlib
from pathlib import Path
from typing import Literal
from pydantic import Field
from .core import StrictModel

GATES = (
    "inventory",
    "connectivity",
    "semantics",
    "time",
    "database",
    "knowledge",
    "security",
    "identity",
    "audit",
    "safety",
    "evaluation",
    "operations",
)


class SiteEvidence(StrictModel):
    path: str = Field(min_length=1, max_length=500)
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")


class SiteGate(StrictModel):
    gate: str
    owner: str = Field(min_length=1, max_length=120)
    reviewer: str = Field(min_length=1, max_length=120)
    status: Literal["hold", "passed"] = "hold"
    reviewed_at: str = ""
    expires_at: str = ""
    evidence: list[SiteEvidence] = Field(default_factory=list, max_length=20)
    comment: str = Field(default="", max_length=2000)


class SiteReadiness(StrictModel):
    site: str = Field(min_length=1, max_length=120)
    phase: Literal["read_only", "recommendation", "supervised_control"]
    gates: list[SiteGate] = Field(min_length=12, max_length=12)


def timestamp(value):
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        raise ValueError("Site evidence timestamps must include a UTC offset.")
    return dt


def evaluate_readiness(manifest: SiteReadiness, base: Path, at=None):
    at = at or datetime.now(timezone.utc)
    ids = [g.gate for g in manifest.gates]
    if len(set(ids)) != len(GATES) or set(ids) != set(GATES):
        raise ValueError("Provide each of the twelve named site gates exactly once.")
    base = base.resolve()
    results = []
    for gate in manifest.gates:
        reasons = []
        if gate.status != "passed":
            reasons.append("Owner has not marked this gate passed.")
        if gate.owner.casefold() == gate.reviewer.casefold():
            reasons.append("Record a different reviewer.")
        try:
            reviewed, expires = timestamp(gate.reviewed_at), timestamp(gate.expires_at)
            if not reviewed <= at < expires:
                reasons.append("Review is future-dated or expired.")
        except ValueError:
            reasons.append("Review dates are missing or invalid.")
        if not gate.evidence:
            reasons.append("No evidence files are attached.")
        for entry in gate.evidence:
            path = (base / entry.path).resolve()
            if Path(entry.path).is_absolute() or not path.is_relative_to(base):
                reasons.append("Evidence must stay inside the manifest folder.")
                continue
            if not path.is_file():
                reasons.append("An evidence file is missing.")
                continue
            h = hashlib.sha256()
            with path.open("rb") as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b""):
                    h.update(chunk)
            if h.hexdigest() != entry.sha256:
                reasons.append("An evidence checksum differs.")
        results.append(
            {
                "gate": gate.gate,
                "status": "hold" if reasons else "evidence_complete",
                "reasons": reasons,
            }
        )
    return {
        "site": manifest.site,
        "phase": manifest.phase,
        "checked_at": at.isoformat(),
        "status": "evidence_complete"
        if all(r["status"] == "evidence_complete" for r in results)
        else "hold",
        "gates": results,
        "meaning": "Checks record completeness, dates and file integrity only. Site owners must assess technical adequacy. This report is not a machine approval and never changes write permissions.",
    }

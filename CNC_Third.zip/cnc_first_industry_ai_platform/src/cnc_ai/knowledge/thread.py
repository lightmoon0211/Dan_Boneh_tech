import uuid
from ..database import now, encode, digest


class DigitalThread:
    def __init__(self, db):
        self.db = db

    def rebuild(self, principal):
        principal.require("data.manage")
        edges = []
        stamp = now()

        def edge(st, sk, p, ot, ok, table, key):
            if ok is not None:
                edges.append((st, str(sk), p, ot, str(ok), table, str(key), stamp))

        with self.db.connect(write=True) as c:
            for r in c.execute("SELECT * FROM production_runs"):
                edge(
                    "Production_Run",
                    r["run_id"],
                    "EXECUTED_ON",
                    "Machine",
                    r["machine_id"],
                    "production_runs",
                    r["run_id"],
                )
                edge(
                    "Operation",
                    r["wo_operation_id"],
                    "PRODUCED",
                    "Production_Run",
                    r["run_id"],
                    "production_runs",
                    r["run_id"],
                )
            for r in c.execute("SELECT * FROM work_order_operations"):
                edge(
                    "Work_Order",
                    r["work_order_id"],
                    "HAS_OPERATION",
                    "Operation",
                    r["wo_operation_id"],
                    "work_order_operations",
                    r["wo_operation_id"],
                )
            for r in c.execute("SELECT * FROM sales_orders"):
                edge(
                    "Customer",
                    r["customer_id"],
                    "PLACED",
                    "Sales_Order",
                    r["sales_order_id"],
                    "sales_orders",
                    r["sales_order_id"],
                )
            for r in c.execute("SELECT * FROM production_thread"):
                for pred, kind, key in [
                    ("EXECUTES", "CNC_Program", "program_id"),
                    ("USES", "Tool", "tool_id"),
                    ("USES", "Material_Lot", "lot_id"),
                ]:
                    edge(
                        "Production_Run",
                        r["run_id"],
                        pred,
                        kind,
                        r[key],
                        "production_thread",
                        r["run_id"],
                    )
                edge(
                    "Sales_Order",
                    r["sales_order_id"],
                    "FULFILLED_BY",
                    "Production_Run",
                    r["run_id"],
                    "production_thread",
                    r["run_id"],
                )
            for r in c.execute("SELECT * FROM machine_alarms"):
                edge(
                    "Machine",
                    r["machine_id"],
                    "GENERATED",
                    "Alarm",
                    r["alarm_id"],
                    "machine_alarms",
                    r["alarm_id"],
                )
            for r in c.execute("SELECT * FROM downtime_events"):
                edge(
                    "Machine",
                    r["machine_id"],
                    "EXPERIENCED",
                    "Downtime",
                    r["downtime_id"],
                    "downtime_events",
                    r["downtime_id"],
                )
            for r in c.execute("SELECT * FROM maintenance_work_orders"):
                edge(
                    "Maintenance_Action",
                    r["maintenance_wo_id"],
                    "PERFORMED_ON",
                    "Machine",
                    r["machine_id"],
                    "maintenance_work_orders",
                    r["maintenance_wo_id"],
                )
            for r in c.execute("SELECT * FROM quality_inspections"):
                edge(
                    "Inspection",
                    r["inspection_id"],
                    "RESULT_OF",
                    "Operation",
                    r["wo_operation_id"],
                    "quality_inspections",
                    r["inspection_id"],
                )
            for r in c.execute("SELECT * FROM nonconformances"):
                edge(
                    "Nonconformance",
                    r["id"],
                    "OBSERVED_IN",
                    "Inspection",
                    r["inspection_id"],
                    "nonconformances",
                    r["id"],
                )
            for r in c.execute("SELECT * FROM component_history"):
                edge(
                    "Machine",
                    r["machine_id"],
                    "HAS_COMPONENT",
                    "Component",
                    r["component"],
                    "component_history",
                    r["id"],
                )
            # Derived projection only: rebuilding never rewrites source records.
            c.execute("DELETE FROM semantic_relations")
            c.executemany(
                "INSERT OR IGNORE INTO semantic_relations(subject_type,subject_key,predicate,object_type,object_key,source_table,source_key,recorded_at) VALUES(?,?,?,?,?,?,?,?)",
                edges,
            )
            self.db.audit(
                "knowledge.rebuilt", principal.username, {"edges": len(edges)}, c
            )
        return {
            "edges": len(edges),
            "authority": "relational source rows; graph is a rebuildable projection",
        }

    def trace(self, kind, key, principal, depth=2, conversation_id=None):
        principal.require("data.read")
        if not 1 <= depth <= 3:
            raise ValueError("Trace depth must be 1 to 3.")
        frontier = {(kind, str(key))}
        seen = set()
        rows = {}
        truncated = False
        with self.db.connect() as c:
            for _ in range(depth):
                nxt = set()
                for node in sorted(frontier - seen):
                    found = c.execute(
                        "SELECT * FROM semantic_relations WHERE (subject_type=? AND subject_key=?) OR (object_type=? AND object_key=?) LIMIT 201",
                        (*node, *node),
                    ).fetchall()
                    if len(found) > 200:
                        truncated = True
                    for r in found[:200]:
                        rows[r["id"]] = dict(r)
                        nxt |= {
                            (r["subject_type"], r["subject_key"]),
                            (r["object_type"], r["object_key"]),
                        }
                        if len(rows) >= 200:
                            truncated = True
                            break
                    if truncated:
                        break
                seen |= frontier
                frontier = nxt
                if truncated:
                    break
        obj = {
            "root": {"type": kind, "key": str(key)},
            "depth": depth,
            "edges": list(rows.values()),
            "truncated": truncated,
            "interpretation": "Recorded relationships; association does not prove causation.",
        }
        content = encode(obj)
        ev = {
            "id": str(uuid.uuid4()),
            "kind": "database",
            "title": "CNC digital thread",
            "locator": kind + " " + str(key),
            "captured_at": now(),
            "sha256": digest(content),
            "content": content,
        }
        with self.db.connect(write=True) as c:
            c.execute(
                "INSERT INTO evidence_records VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    ev["id"],
                    conversation_id,
                    "database",
                    ev["title"],
                    ev["locator"],
                    ev["captured_at"],
                    ev["sha256"],
                    content,
                    encode(
                        {
                            "projection": "semantic_relations",
                            "source_keys_in_content": True,
                        }
                    ),
                ),
            )
            self.db.audit(
                "knowledge.traced",
                principal.username,
                {"evidence_id": ev["id"], "edges": len(rows)},
                c,
            )
        return {"evidence": ev, "trace": obj}


def seed_thread(db):
    """Sample-only relational lineage consistent with the synthetic CNC-01..07 historian."""
    with db.connect(write=True) as c:
        for i in range(1, 8):
            key = 1000 + i
            tool = "T07" if i == 1 else f"T-{100 + i}"
            c.execute(
                "INSERT OR IGNORE INTO machines(machine_id,machine_code,machine_name,controller,max_rpm,status) VALUES(?,?,?,?,?,?)",
                (
                    key,
                    f"CNC-{i:02}",
                    "Synthetic condition-monitoring cell",
                    "Training",
                    9000,
                    "ACTIVE",
                ),
            )
            c.execute(
                "INSERT OR IGNORE INTO cutting_tools(tool_id,tool_code,diameter_mm,status) VALUES(?,?,?,?)",
                (key, tool, 10, "TRAINING"),
            )
            c.execute(
                "INSERT OR IGNORE INTO cnc_programs(program_id,program_code,revision,controller_family,file_name) VALUES(?,?,?,?,?)",
                (key, f"O{key}", "sample-10", "sample-fanuc", f"O{key}.nc"),
            )
            c.execute(
                "INSERT OR IGNORE INTO program_qualifications VALUES(?,?,?,?,?,?,?)",
                (
                    key,
                    "Fictional milling program",
                    "sample-10",
                    digest("fictional-program-" + str(i)),
                    "sample-fanuc",
                    "training_only",
                    encode({"max_rpm": 7500, "source": "fictional"}),
                ),
            )
            c.execute(
                "INSERT OR IGNORE INTO material_lots VALUES(?,?,?,?,?,?)",
                (
                    f"LOT-{i:03}",
                    1001 if i == 1 else 1,
                    f"SUP-{i:03}",
                    "2026-08-01",
                    digest("fictional-certificate-" + str(i)),
                    "training_only",
                ),
            )
            old = c.execute(
                "SELECT * FROM work_order_operations WHERE wo_operation_id=?", (i,)
            ).fetchone()
            if old:
                c.execute(
                    "INSERT OR IGNORE INTO work_order_operations(wo_operation_id,work_order_id,routing_op_id,machine_id,status,planned_qty,good_qty,scrap_qty,rework_qty) VALUES(?,?,?,?,?,?,?,?,?)",
                    (
                        key,
                        old["work_order_id"],
                        old["routing_op_id"],
                        key,
                        "TRAINING",
                        300,
                        270,
                        30,
                        0,
                    ),
                )
                c.execute(
                    "INSERT OR IGNORE INTO production_runs(run_id,wo_operation_id,machine_id,run_start,run_end,good_qty,scrap_qty,rework_qty,avg_cycle_seconds,energy_kwh) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (
                        key,
                        key,
                        key,
                        "2026-09-01T08:00:00Z",
                        "2026-09-01T14:00:00Z",
                        270,
                        30,
                        0,
                        65,
                        48,
                    ),
                )
                c.execute(
                    "INSERT OR IGNORE INTO production_thread VALUES(?,?,?,?,?,?,?)",
                    (key, i, key, key, f"LOT-{i:03}", now(), "fictional-v10-seed"),
                )
            c.execute(
                "INSERT INTO component_history(machine_id,component,event_type,event_time,operating_hours,detail,source) SELECT ?, 'spindle','inspection','2026-09-01T08:00:00Z',1000,'Fictional baseline inspection','fictional-v10-seed' WHERE NOT EXISTS (SELECT 1 FROM component_history WHERE machine_id=? AND source='fictional-v10-seed')",
                (key, key),
            )

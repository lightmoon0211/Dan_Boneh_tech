"""Typed CNC digital-thread projections over authoritative records."""

CREATE TABLE historian_observations (
 id INTEGER PRIMARY KEY, machine_id TEXT NOT NULL, signal TEXT NOT NULL,
 event_time TEXT NOT NULL, ingestion_time TEXT NOT NULL, value REAL NOT NULL,
 unit TEXT NOT NULL, quality TEXT NOT NULL CHECK(quality IN ('good','bad','uncertain')),
 source TEXT NOT NULL, sampling_hz REAL, tool_id TEXT, program_id TEXT, material_lot TEXT,
 run_id TEXT, sequence TEXT NOT NULL DEFAULT '',
 UNIQUE(machine_id,signal,event_time,source)
);
CREATE INDEX historian_window ON historian_observations(machine_id,signal,event_time);
CREATE TABLE analysis_records (
 id TEXT PRIMARY KEY, actor TEXT NOT NULL, kind TEXT NOT NULL, machine_id TEXT NOT NULL,
 created_at TEXT NOT NULL, input_sha256 TEXT NOT NULL, request_json TEXT NOT NULL, result_json TEXT NOT NULL
);
CREATE TABLE document_revisions (
 document_id TEXT PRIMARY KEY REFERENCES documents(id), family TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'draft' CHECK(state IN ('draft','approved','superseded')),
 reviewer TEXT REFERENCES users(username), reviewed_at TEXT, review_comment TEXT
);
INSERT INTO document_revisions(document_id,family,state) SELECT id,sector||':'||kind||':'||filename,'draft' FROM documents;
CREATE UNIQUE INDEX document_current_revision ON document_revisions(family) WHERE state='approved';
CREATE TABLE program_qualifications (
 program_id INTEGER PRIMARY KEY REFERENCES cnc_programs(program_id), name TEXT NOT NULL, revision TEXT NOT NULL,
 sha256 TEXT NOT NULL, postprocessor TEXT NOT NULL, approval_state TEXT NOT NULL,
 envelope_json TEXT NOT NULL
);
CREATE TABLE material_lots (
 lot_id TEXT PRIMARY KEY, material_id INTEGER REFERENCES materials(material_id),
 supplier_lot TEXT, received_at TEXT, certificate_sha256 TEXT, disposition TEXT NOT NULL
);
CREATE TABLE production_thread (
 run_id INTEGER PRIMARY KEY REFERENCES production_runs(run_id),
 sales_order_id INTEGER REFERENCES sales_orders(sales_order_id),
 program_id INTEGER REFERENCES cnc_programs(program_id), tool_id INTEGER REFERENCES cutting_tools(tool_id),
 lot_id TEXT REFERENCES material_lots(lot_id), recorded_at TEXT NOT NULL, source TEXT NOT NULL
);
CREATE TABLE nonconformances (
 id TEXT PRIMARY KEY, inspection_id INTEGER REFERENCES quality_inspections(inspection_id),
 run_id INTEGER REFERENCES production_runs(run_id), category TEXT NOT NULL, description TEXT NOT NULL,
 disposition TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE component_history (
 id INTEGER PRIMARY KEY, machine_id INTEGER REFERENCES machines(machine_id),
 component TEXT NOT NULL, event_type TEXT NOT NULL, event_time TEXT NOT NULL,
 operating_hours REAL, detail TEXT NOT NULL, source TEXT NOT NULL
);
CREATE TABLE semantic_relations (
 id INTEGER PRIMARY KEY, subject_type TEXT NOT NULL, subject_key TEXT NOT NULL,
 predicate TEXT NOT NULL, object_type TEXT NOT NULL, object_key TEXT NOT NULL,
 source_table TEXT NOT NULL, source_key TEXT NOT NULL, recorded_at TEXT NOT NULL,
 UNIQUE(subject_type,subject_key,predicate,object_type,object_key,source_table,source_key)
);
CREATE INDEX semantic_subject ON semantic_relations(subject_type,subject_key);
CREATE INDEX semantic_object ON semantic_relations(object_type,object_key);
CREATE TABLE agent_runs (
 id TEXT PRIMARY KEY, conversation_id TEXT REFERENCES conversations(id), actor TEXT NOT NULL,
 started_at TEXT NOT NULL, finished_at TEXT, status TEXT NOT NULL, request_sha256 TEXT NOT NULL
);
CREATE TABLE agent_steps (
 id INTEGER PRIMARY KEY, run_id TEXT NOT NULL REFERENCES agent_runs(id),
 state TEXT NOT NULL, at TEXT NOT NULL, detail_json TEXT NOT NULL
);
CREATE TABLE model_calls (
 id INTEGER PRIMARY KEY, at TEXT NOT NULL, role TEXT NOT NULL, service TEXT NOT NULL,
 replica TEXT NOT NULL, model TEXT NOT NULL, revision TEXT NOT NULL,
 elapsed_ms REAL NOT NULL, status TEXT NOT NULL, input_tokens INTEGER, output_tokens INTEGER
);
CREATE TABLE code_artifacts (
 id TEXT PRIMARY KEY, sha256 TEXT NOT NULL UNIQUE, owner TEXT NOT NULL REFERENCES users(username),
 created_at TEXT NOT NULL, machine TEXT NOT NULL, program_text TEXT NOT NULL,
 review_json TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'candidate'
);
CREATE TABLE artifact_attestations (
 id INTEGER PRIMARY KEY, artifact_id TEXT REFERENCES code_artifacts(id), gate TEXT NOT NULL,
 actor TEXT NOT NULL REFERENCES users(username), at TEXT NOT NULL, result TEXT NOT NULL,
 report_sha256 TEXT NOT NULL, comment TEXT NOT NULL, UNIQUE(artifact_id,gate)
);

UPDATE simulator_state SET values_json=json_set(values_json,'$.machine_identity',machine,'$.program','O1001') WHERE machine='CNC-01' AND json_extract(values_json,'$.program') IS NULL;
UPDATE control_proposals SET status='blocked' WHERE status IN ('pending','approved');

-- Additive v11.2 migration. Existing operational and RCA evidence is unchanged.
CREATE TABLE application_jobs (
 id TEXT PRIMARY KEY, owner TEXT NOT NULL REFERENCES users(username), kind TEXT NOT NULL,
 lane TEXT NOT NULL, state TEXT NOT NULL CHECK(state IN ('queued','running','completed','failed','cancelled')),
 created_at REAL NOT NULL, started_at REAL, finished_at REAL, expires_at REAL NOT NULL,
 payload_json TEXT NOT NULL, permissions_json TEXT NOT NULL, result_json TEXT,
 error TEXT NOT NULL DEFAULT '', cancel_requested INTEGER NOT NULL DEFAULT 0,
 resource_id TEXT, request_id TEXT NOT NULL
);
CREATE INDEX application_jobs_dispatch ON application_jobs(state,lane,created_at);
CREATE INDEX application_jobs_owner ON application_jobs(owner,created_at);
ALTER TABLE model_calls ADD COLUMN request_id TEXT;

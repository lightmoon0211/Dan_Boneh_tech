"""Deterministic comparisons, interval union and explicit counterfactual assumptions."""

from datetime import datetime
from .contracts import Production, Progress, Acceptance


def union_minutes(records, start, end):
    spans = sorted(
        (max(r.event_start, start), min(r.event_end, end))
        for r in records
        if r.family == "downtime"
        and r.quality == "good"
        and r.event_start < end
        and r.event_end > start
    )
    merged = []
    for a, b in spans:
        if b <= a:
            continue
        if merged and a <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], b))
        else:
            merged.append((a, b))
    return sum((b - a).total_seconds() / 60 for a, b in merged), [
        [a.isoformat(), b.isoformat()] for a, b in merged
    ]


def compare(scope, current, baseline):
    current = [
        r for r in current if isinstance(r.payload, Production) and r.quality == "good"
    ]
    baseline = [
        r for r in baseline if isinstance(r.payload, Production) and r.quality == "good"
    ]

    def select(rows):
        return [
            r
            for r in rows
            if (not scope["part"] or r.payload.part == scope["part"])
            and (not scope["operation"] or r.payload.operation == scope["operation"])
            and r.payload.shift == scope["shift"]
        ]

    current, baseline = select(current), select(baseline)
    if any(r.payload.shift_date != scope["date"] for r in current) or any(
        r.payload.shift_date != scope["baseline_date"] for r in baseline
    ):
        raise ValueError(
            "Recorded production date disagrees with the selected factory-local shift."
        )
    if not current or (scope["baseline"] != "plan" and not baseline):
        raise ValueError(
            "Comparable shift records are missing. Missing data cannot prove or disprove the problem."
        )

    def summarize(rows):
        signatures = [
            (r.payload.part, r.payload.operation, r.payload.revision, r.payload.mix)
            for r in rows
        ]
        if len(signatures) != len(set(signatures)):
            raise ValueError(
                "Duplicate production grains could double-count output. Resolve source records first."
            )
        scheduled = sum(r.payload.scheduled_minutes for r in rows)
        good = sum(r.payload.good for r in rows)
        scrap = sum(r.payload.scrap for r in rows)
        return {
            "good": good,
            "scrap": scrap,
            "total": good + scrap,
            "scheduled_minutes": scheduled,
            "earned_good_minutes": sum(
                r.payload.good * r.payload.cycle_seconds / 60 for r in rows
            ),
            "scrap_rate": scrap / (good + scrap) if good + scrap else None,
            "signatures": signatures,
        }

    a = summarize(current)
    duration = (
        datetime.fromisoformat(scope["end"]) - datetime.fromisoformat(scope["start"])
    ).total_seconds() / 60
    if a["scheduled_minutes"] > duration + 0.001:
        raise ValueError(
            "Production grains claim more scheduled time than the selected shift; check overlapping operations."
        )
    if scope["baseline"] == "plan":
        if any(r.payload.planned_good is None for r in current):
            raise ValueError(
                "Recorded planned good quantities are unavailable; actual prior output is not the plan."
            )
        b = {
            **a,
            "good": sum(r.payload.planned_good for r in current),
            "earned_good_minutes": sum(
                r.payload.planned_good * r.payload.cycle_seconds / 60 for r in current
            ),
            "scrap_rate": None,
        }
    else:
        b = summarize(baseline)
        baseline_duration = (
            datetime.fromisoformat(scope["baseline_end"])
            - datetime.fromisoformat(scope["baseline_start"])
        ).total_seconds() / 60
        if b["scheduled_minutes"] > baseline_duration + 0.001:
            raise ValueError(
                "Comparison grains claim more scheduled time than the comparison shift."
            )
    comparable = (
        a["signatures"] == b["signatures"]
        and len({r.payload.cycle_seconds for r in current + baseline}) == 1
    )
    rate_a = a["earned_good_minutes"] / a["scheduled_minutes"]
    rate_b = b["earned_good_minutes"] / b["scheduled_minutes"]
    raw_loss = b["good"] - a["good"]
    normalized = rate_a < rate_b - 1e-8
    if scope["topic"] == "scrap":
        if a["scrap_rate"] is None or b["scrap_rate"] is None:
            raise ValueError(
                "Scrap comparison requires actual good-plus-scrap counts for both shifts."
            )
        problem = a["scrap_rate"] > b["scrap_rate"] + 1e-8
    else:
        problem = (
            (raw_loss > 0 and normalized)
            if scope["baseline"] != "plan"
            else raw_loss > 0
        )
    interpretation = (
        (
            "The recorded scrap rate increased."
            if scope["topic"] == "scrap"
            else "Actual good output is below the recorded plan."
            if scope["baseline"] == "plan"
            else "The reported decrease persists after scheduled-time and cycle-time normalization."
        )
        if problem
        else "The reported problem is not verified for this comparison; raw counts may reflect product mix, shift duration or a different baseline."
    )
    return {
        "id": "production_comparison",
        "category": "calculated result",
        "current": a,
        "baseline": b,
        "raw_good_shortfall": raw_loss,
        "comparable_product_grain": comparable,
        "normalized_good_capacity_current": rate_a,
        "normalized_good_capacity_baseline": rate_b,
        "problem_verified": problem,
        "formula": "good shortfall = baseline good - current good; scrap rate = scrap / (good + scrap); earned good minutes = sum(good * standard cycle seconds / 60); normalized output = earned good minutes / scheduled minutes",
        "assumptions": [
            "Good and scrap are mutually exclusive final-operation counts.",
            "Scheduled minutes are allocated once across product/operation grains.",
            "Standard cycle times are recorded source values, not LLM estimates.",
        ],
        "interpretation": interpretation,
    }


def reconcile(scope, comparison, records):
    start, end = (
        datetime.fromisoformat(scope["start"]),
        datetime.fromisoformat(scope["end"]),
    )
    minutes, spans = union_minutes(records, start, end)
    result = {
        "id": "production_loss",
        "category": "calculated result",
        "downtime_minutes": minutes,
        "merged_intervals": spans,
        "formula": "union of downtime intervals clipped to selected shift; estimated lost pieces = union minutes * 60 / standard cycle seconds",
        "assumptions": [
            "Downtime is unioned before conversion; overlapping event reason codes are not additive.",
            "Lost output is a constant-cycle counterfactual estimate, not observed recoverable output.",
        ],
    }
    rows = [
        r
        for r in records
        if isinstance(r.payload, Production)
        and r.quality == "good"
        and r.payload.shift == scope["shift"]
    ]
    if (
        not comparison
        or not comparison["comparable_product_grain"]
        or len(rows) != 1
        or scope["baseline"] == "plan"
    ):
        result["unavailable"] = (
            "Per-event loss attribution requires one comparable part/operation/revision and a recorded actual baseline."
        )
        return result
    cycle = rows[0].payload.cycle_seconds
    a, b = comparison["current"], comparison["baseline"]
    if minutes > a["scheduled_minutes"] + 0.001:
        raise ValueError(
            "Downtime exceeds scheduled time. Break/calendar overlap needs resolution."
        )
    lost = minutes * 60 / cycle
    capacity = (b["scheduled_minutes"] - a["scheduled_minutes"]) * 60 / cycle
    scrap = a["scrap"] - b["scrap"]
    residual = comparison["raw_good_shortfall"] - lost - capacity - scrap
    result.update(
        estimated_downtime_loss=lost,
        scheduled_capacity_difference=capacity,
        incremental_scrap=scrap,
        observed_good_shortfall=comparison["raw_good_shortfall"],
        unexplained_residual=residual,
        units="pieces",
        formula=result["formula"]
        + "; observed good shortfall = scheduled capacity difference + estimated downtime loss + incremental scrap + unexplained residual",
    )
    return result


def verify_progress(scope, records):
    rows = [r for r in records if r.quality == "good"]
    if scope["topic"] == "acceptance":
        rows = [r for r in rows if isinstance(r.payload, Acceptance)]
        if not rows:
            raise ValueError(
                "No historical acceptance measurements with approved limits were returned."
            )
        failures = [r.record_id for r in rows if r.payload.outcome == "fail"]
        return {
            "id": "acceptance_comparison",
            "problem_verified": bool(failures),
            "failed_records": failures,
            "formula": "fail when measurement < minimum or measurement > maximum; units and source revision are retained",
            "assumptions": [
                "Source test limits are recorded acceptance criteria; site approval must be verified separately."
            ],
        }
    rows = [r for r in rows if isinstance(r.payload, Progress)]
    if len(rows) != 1:
        raise ValueError(
            "Choose a single recorded assembly/order progress snapshot for the cutoff."
        )
    p = rows[0].payload
    gap = p.planned_minutes - p.completed_minutes
    risk = p.remaining_minutes > p.available_before_due_minutes
    return {
        "id": "progress_comparison",
        "problem_verified": risk if scope["topic"] == "due_date" else gap > 0,
        "planned_minutes": p.planned_minutes,
        "completed_minutes": p.completed_minutes,
        "work_gap_minutes": gap,
        "remaining_minutes": p.remaining_minutes,
        "available_before_due_minutes": p.available_before_due_minutes,
        "due_at": p.due_at.isoformat(),
        "prediction": scope["topic"] == "due_date",
        "formula": "work gap = planned - completed; due-date capacity risk when remaining work minutes > available minutes",
        "assumptions": [
            "Available capacity and work content are supplied historical planning values.",
            "Due-date risk is an estimate; this tool does not run APS or change a schedule.",
        ],
    }

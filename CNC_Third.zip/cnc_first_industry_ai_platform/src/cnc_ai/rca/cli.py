"""RCA commands extend the installed smartfactoryllm workflow."""

from pathlib import Path
import json
from ..auth import Auth
from ..models import ModelRouter
from .service import RCAService
from .demo import create_demo


def add_commands(commands):
    p = commands.add_parser("rca", help="Read-only root-cause investigation tools")
    sub = p.add_subparsers(dest="rca_action", required=True)
    d = sub.add_parser("demo", help="Create a separate fictional RCA history database")
    d.add_argument("--user", required=True)
    d.add_argument("--destination", type=Path)
    run = sub.add_parser("run")
    run.add_argument("--user", required=True)
    run.add_argument("--question", required=True)
    run.add_argument(
        "--evidence-source", choices=["factory", "demo"], default="factory"
    )
    run.add_argument("--intent", type=Path)
    run.add_argument("--output", type=Path)
    recover = sub.add_parser("recover")
    recover.add_argument("--user", required=True)
    approve = sub.add_parser("approve-rule")
    approve.add_argument("rule_id")
    approve.add_argument("--user", required=True)
    approve.add_argument("--document", required=True)
    approve.add_argument("--expires", required=True)
    approve.add_argument("--comment", required=True)


def run(args, settings, db):
    principal = Auth(db).user(args.user)
    if args.rca_action == "demo":
        principal.require("data.manage")
        if (
            settings.profile != "development"
            or settings.model_mode != "demo"
            or settings.opcua_mode == "real"
        ):
            raise ValueError(
                "Create demonstration history only in development training mode."
            )
        return create_demo(args.destination or settings.data / "rca-demo.db")
    svc = RCAService(db, ModelRouter(settings))
    try:
        if args.rca_action == "recover":
            return svc.recover(principal)
        if args.rca_action == "approve-rule":
            return svc.approve_rule(
                args.rule_id, args.document, args.expires, args.comment, principal
            )
        request = {"question": args.question, "evidence_source": args.evidence_source}
        if args.intent:
            request["intent"] = json.loads(args.intent.read_text())
        inv = svc.start(request, principal, background=False)
        svc.execute(inv["id"])
        result = svc.export(inv["id"], principal)
        if args.output:
            if args.output.exists():
                raise FileExistsError(
                    "Choose a new output file to retain prior exports."
                )
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(
                json.dumps(result, indent=2, ensure_ascii=False) + "\n"
            )
        return result
    finally:
        svc.close()

"""RCA public contracts. Evidence state and human review are separate axes."""

from __future__ import annotations
from datetime import datetime
from typing import Literal
from pydantic import Field, model_validator
from ..core import StrictModel

EntityKind = Literal["resource", "finished_machine", "work_order"]
Topic = Literal["production", "scrap", "idle", "assembly", "acceptance", "due_date"]
EvidenceStatus = Literal[
    "Hypothesis", "Supported", "Confirmed", "Contradicted", "Inconclusive"
]
StepStatus = Literal[
    "planned", "running", "completed", "failed", "skipped", "cancelled"
]
Family = Literal[
    "production",
    "downtime",
    "machine_history",
    "maintenance",
    "materials",
    "quality",
    "assembly",
    "acceptance",
    "engineering",
]


class ScopeIntent(StrictModel):
    entity: str = Field(default="", max_length=80)
    entity_kind: EntityKind | None = None
    topic: Topic = "production"
    date: str = Field(default="", max_length=10)
    shift: str = Field(default="", max_length=40)
    baseline: Literal["previous_day", "previous_week", "plan", "explicit"] = (
        "previous_day"
    )
    baseline_date: str = Field(default="", max_length=10)
    part: str = Field(default="", max_length=80)
    operation: str = Field(default="", max_length=80)


class StartRequest(StrictModel):
    question: str = Field(min_length=3, max_length=6000)
    conversation_id: str | None = Field(default=None, max_length=64)
    source: str = Field(default="factory", max_length=80)
    evidence_source: Literal["factory", "demo"] = "factory"
    language: str = Field(default="en", max_length=10)
    intent: ScopeIntent | None = None


class ToolArguments(StrictModel):
    entity: str = Field(min_length=1, max_length=80)
    entity_kind: EntityKind
    start: datetime
    end: datetime
    cutoff: datetime

    @model_validator(mode="after")
    def window(self):
        if any(x.tzinfo is None for x in [self.start, self.end, self.cutoff]):
            raise ValueError("Timezone-aware timestamps are required.")
        if self.end <= self.start or (self.end - self.start).days > 31:
            raise ValueError("Use a positive historical window of at most 31 days.")
        return self


class Production(StrictModel):
    kind: Literal["production"] = "production"
    shift_date: str
    shift: str
    part: str
    operation: str
    revision: str
    mix: str
    scheduled_minutes: float = Field(gt=0, le=44640)
    cycle_seconds: float = Field(gt=0, le=86400)
    good: int = Field(ge=0)
    scrap: int = Field(ge=0)
    planned_good: int | None = Field(default=None, ge=0)
    quantity_definition: Literal["exclusive_final_good_and_scrap"] = (
        "exclusive_final_good_and_scrap"
    )


class Observation(StrictModel):
    kind: Literal["observation"] = "observation"
    code: str = Field(min_length=1, max_length=80)
    incident: str = Field(default="", max_length=80)
    related_record: str = Field(default="", max_length=80)
    value: float | None = None
    units: str = Field(default="", max_length=40)
    detail: str = Field(default="", max_length=1200)


class Progress(StrictModel):
    kind: Literal["progress"] = "progress"
    planned_minutes: float = Field(ge=0)
    completed_minutes: float = Field(ge=0)
    remaining_minutes: float = Field(ge=0)
    available_before_due_minutes: float = Field(ge=0)
    due_at: datetime

    @model_validator(mode="after")
    def aware(self):
        if self.due_at.tzinfo is None:
            raise ValueError("Due date needs a timezone.")
        return self


class Acceptance(StrictModel):
    kind: Literal["acceptance"] = "acceptance"
    test: str = Field(min_length=1, max_length=80)
    measured: float
    minimum: float
    maximum: float
    units: str = Field(min_length=1, max_length=40)
    outcome: Literal["pass", "fail"]

    @model_validator(mode="after")
    def outcome_matches(self):
        if self.minimum > self.maximum:
            raise ValueError("Invalid test limits.")
        if (self.minimum <= self.measured <= self.maximum) != (self.outcome == "pass"):
            raise ValueError("Test result contradicts its recorded limits.")
        return self


class HistoryRecord(StrictModel):
    record_id: str = Field(min_length=1, max_length=80)
    source_system: str = Field(min_length=1, max_length=80)
    entity: str = Field(min_length=1, max_length=80)
    entity_kind: EntityKind
    family: Family
    event_start: datetime
    event_end: datetime
    recorded_at: datetime
    revision: str = Field(min_length=1, max_length=80)
    quality: Literal["good", "uncertain", "bad"] = "good"
    payload: Production | Observation | Progress | Acceptance = Field(
        discriminator="kind"
    )

    @model_validator(mode="after")
    def coherent(self):
        if any(
            x.tzinfo is None
            for x in [self.event_start, self.event_end, self.recorded_at]
        ):
            raise ValueError("Source timestamps require explicit offsets.")
        if self.event_end < self.event_start:
            raise ValueError("Event end precedes start.")
        if self.recorded_at < self.event_end:
            raise ValueError(
                "Observed records cannot be recorded before the event ends."
            )
        expected = {
            "production": Production,
            "downtime": Observation,
            "machine_history": Observation,
            "maintenance": Observation,
            "materials": Observation,
            "quality": Observation,
            "engineering": Observation,
            "assembly": Progress,
            "acceptance": Acceptance,
        }
        if not isinstance(self.payload, expected[self.family]):
            raise ValueError("Source payload does not match its family.")
        return self


class HypothesisPlan(StrictModel):
    hypotheses: list[
        Literal[
            "cooling",
            "material",
            "program",
            "assembly_supply",
            "calibration",
            "unknown",
            "correlation",
        ]
    ] = Field(max_length=5)
    # This is a proposed selection, never a report that checks have run.


class ReviewRequest(StrictModel):
    status: Literal["acknowledged", "needs_more_evidence"]
    comment: str = Field(min_length=5, max_length=1500)


class ReassessRequest(StrictModel):
    reason: str = Field(min_length=5, max_length=1500)
    question: str = Field(default="", max_length=6000)
    intent: ScopeIntent | None = None


class AddEvidenceRequest(StrictModel):
    record_id: str = Field(min_length=1, max_length=80)
    reason: str = Field(min_length=5, max_length=1500)


class Rule(StrictModel):
    id: str = Field(pattern=r"^[a-z][a-z0-9_]{1,60}$")
    revision: str = Field(min_length=1, max_length=60)
    title: str = Field(min_length=3, max_length=180)
    hypothesis: Literal[
        "cooling",
        "material",
        "program",
        "assembly_supply",
        "calibration",
        "unknown",
        "correlation",
    ]
    family: Family
    mechanism: str = Field(min_length=10, max_length=1000)
    cause_codes: list[str] = Field(min_length=1, max_length=6)
    effect_codes: list[str] = Field(min_length=1, max_length=6)
    verification_codes: list[str] = Field(min_length=1, max_length=6)
    contradiction_codes: list[str] = Field(default_factory=list, max_length=6)
    next_check: str = Field(min_length=5, max_length=500)
    recommendation: str = Field(min_length=5, max_length=500)
    level: Literal["direct", "contributing", "deeper"] = "direct"

"""Factory-local calendar resolution, with explicit DST and comparison semantics."""

from datetime import date, datetime, time, timedelta, timezone
import os, re
import pytz
from ..config import boolean
from .contracts import ScopeIntent


class Clarification(ValueError):
    pass


def configuration(settings):
    c = settings.read("rca.json")
    c["demo_enabled"] = boolean("CNC_RCA_DEMO", c["demo_enabled"])
    if os.getenv("CNC_RCA_HISTORY_PATH"):
        c["history_path"] = os.environ["CNC_RCA_HISTORY_PATH"]
    if os.getenv("CNC_FACTORY_TIMEZONE"):
        c["timezone"] = os.environ["CNC_FACTORY_TIMEZONE"]
    pytz.timezone(c["timezone"])
    ranges = {
        "depth": (1, 4),
        "tool_calls": (2, 30),
        "retries": (0, 2),
        "elapsed_seconds": (1, 300),
        "model_calls": (0, 4),
        "model_timeout_seconds": (1, 30),
        "model_output_tokens": (100, 1200),
        "rows": (1, 1000),
        "query_seconds": (0.1, 10),
        "concurrent": (1, 4),
    }
    for name, (lo, hi) in ranges.items():
        x = c["limits"][name]
        if isinstance(x, bool) or not isinstance(x, (int, float)) or not lo <= x <= hi:
            raise ValueError("Invalid RCA limit: " + name)
    for name in [
        "depth",
        "tool_calls",
        "retries",
        "model_calls",
        "model_output_tokens",
        "rows",
        "concurrent",
    ]:
        if not isinstance(c["limits"][name], int):
            raise ValueError("RCA count limits must be integers.")
    if not c["shifts"] or len({s["id"] for s in c["shifts"]}) != len(c["shifts"]):
        raise ValueError("Configure unique factory shifts.")
    for flag in ["enabled", "demo_enabled", "model_assistance"]:
        if not isinstance(c[flag], bool):
            raise ValueError("RCA feature flags must be JSON booleans.")
    if not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}", c["factory_id"]):
        raise ValueError("Configure a stable factory identifier.")
    for shift in c["shifts"]:
        time.fromisoformat(shift["start"])
        time.fromisoformat(shift["end"])
        if not shift["weekdays"] or any(
            type(d) is not int or d not in range(7) for d in shift["weekdays"]
        ):
            raise ValueError("Shift weekdays use integers 0 through 6.")
    for holiday in c["holidays"]:
        date.fromisoformat(holiday)
    if c["history_schema_version"] != "cnc-rca-history-1":
        raise ValueError("Unsupported configured RCA history schema.")
    return c


def looks_like_rca(question):
    q = question.casefold()
    why = any(
        s in q
        for s in [
            "why ",
            "root cause",
            "investigat",
            "cause of",
            "pourquoi",
            "warum",
            "为什么",
            "為什麼",
            "なぜ",
            "왜",
        ]
    )
    factory = any(
        s in q
        for s in [
            "cnc",
            "mx-",
            "work order",
            "assembly",
            "acceptance",
            "scrap",
            "production",
            "machine",
            "生産",
            "生产",
            "装配",
            "機床",
            "機械",
            "工单",
            "wo-",
        ]
    )
    return why and factory


def infer_intent(question, previous=None):
    q = question.casefold()
    i = ScopeIntent.model_validate(previous or {})
    assets = re.findall(r"\b(?:CNC-\d+|MX-[A-Z0-9-]+|WO-[A-Z0-9-]+)\b", question, re.I)
    if len(set(x.upper() for x in assets)) > 1:
        raise Clarification(
            "Which single production resource, finished machine or work order should this investigation cover?"
        )
    if assets:
        i.entity = assets[0].upper()
    if any(x in q for x in ["scrap", "reject", "废品", "報廢"]):
        i.topic = "scrap"
    elif any(x in q for x in ["acceptance", "accept test", "验收", "驗收"]):
        i.topic = "acceptance"
    elif any(x in q for x in ["assembly", "装配", "組立"]):
        i.topic = "assembly"
    elif any(x in q for x in ["due date", "work order likely", "miss its", "交期"]):
        i.topic = "due_date"
    elif any(x in q for x in ["idle", "空闲", "空閒"]):
        i.topic = "idle"
    dates = re.findall(r"\b\d{4}-\d{2}-\d{2}\b", question)
    if dates:
        i.date = dates[0]
    if len(dates) > 1:
        i.baseline = "explicit"
        i.baseline_date = dates[1]
    if any(
        x in q
        for x in [
            "below plan",
            "against plan",
            "versus plan",
            "behind schedule",
            "迟于计划",
        ]
    ):
        i.baseline = "plan"
    if "last week" in q or "上周" in q or "上週" in q:
        i.baseline = "previous_week"
    return i


def resolve(question, intent, assets, cfg, cutoff):
    tz = pytz.timezone(cfg["timezone"])
    local = cutoff.astimezone(tz)
    found = [
        a
        for a in assets
        if intent.entity.casefold()
        in [a["entity"].casefold(), *[str(x).casefold() for x in a.get("aliases", [])]]
    ]
    if intent.entity_kind:
        found = [a for a in found if a["entity_kind"] == intent.entity_kind]
    if len(found) != 1:
        raise Clarification(
            "Specify one known production resource (for example CNC-03), finished-machine serial/product, or work-order ID; the current identifier is missing or ambiguous."
        )
    asset = found[0]
    q = question.casefold()
    day = (
        date.fromisoformat(intent.date)
        if intent.date
        else (
            local.date() - timedelta(days=1)
            if any(
                x in q for x in ["yesterday", "昨天", "昨日", "어제", "hier", "gestern"]
            )
            else None
        )
    )
    if day is None:
        raise Clarification(
            "Which factory-local date and shift should I investigate? Include a date such as 2026-09-08."
        )
    shifts = [
        s
        for s in cfg["shifts"]
        if (not intent.shift or s["id"] == intent.shift)
        and day.weekday() in s["weekdays"]
    ]
    if len(shifts) != 1:
        raise Clarification(
            "Choose one configured shift for this date; multiple shifts or a non-working day change the comparison."
        )
    shift = shifts[0]

    def bounds(d):
        if d.isoformat() in cfg["holidays"] or d.weekday() not in shift["weekdays"]:
            raise Clarification(
                "The selected day is outside this shift calendar. Choose an operating date."
            )
        start = datetime.combine(d, time.fromisoformat(shift["start"]))
        end = datetime.combine(d, time.fromisoformat(shift["end"]))
        if end <= start:
            end += timedelta(days=1)
        try:
            return tz.localize(start, is_dst=None).astimezone(
                timezone.utc
            ), tz.localize(end, is_dst=None).astimezone(timezone.utc)
        except (pytz.AmbiguousTimeError, pytz.NonExistentTimeError) as exc:
            raise Clarification(
                "This shift crosses an ambiguous or missing DST boundary; configure an unambiguous shift before comparing."
            ) from exc

    start, end = bounds(day)
    if end > cutoff:
        raise Clarification(
            "That shift has not finished at the recorded data cutoff. Select a completed shift for a historical comparison."
        )
    direct = intent.topic in {"idle", "acceptance", "assembly", "due_date"}
    if direct and intent.baseline in {"previous_week", "explicit"}:
        raise Clarification(
            "This investigation verifies recorded stops, test limits or planning values. A historical comparison for this topic needs a separately qualified mapping; choose a single completed shift."
        )
    if direct or intent.baseline == "plan":
        base = day
    elif intent.baseline == "explicit":
        if not intent.baseline_date:
            raise Clarification("Supply the comparison date.")
        base = date.fromisoformat(intent.baseline_date)
    else:
        base = day - timedelta(days=7 if intent.baseline == "previous_week" else 1)
        if intent.baseline != "previous_week":
            for _ in range(31):
                if (
                    base.weekday() in shift["weekdays"]
                    and base.isoformat() not in cfg["holidays"]
                ):
                    break
                base -= timedelta(days=1)
    bs, be = bounds(base)
    if be > cutoff or (bs == start and intent.baseline != "plan" and not direct):
        raise Clarification("Choose a distinct completed comparison shift.")
    direct_text = {
        "idle": "Recorded stopped duration within the selected shift",
        "acceptance": "Recorded acceptance measurements against their recorded limits",
        "assembly": "Recorded work completion against the recorded plan",
        "due_date": "Estimated due-date capacity risk using recorded remaining work and available time",
    }
    explanation = (
        direct_text[intent.topic]
        if direct
        else (
            "Actual good output against recorded planned good output"
            if intent.baseline == "plan"
            else "Completed shift against the corresponding previous-week shift"
            if intent.baseline == "previous_week"
            else "Completed shift against the selected earlier operating shift"
        )
        + "; part, operation, revision, product mix and scheduled time are checked."
    )
    comparison_label = (
        "recorded stop intervals"
        if intent.topic == "idle"
        else "recorded acceptance limits"
        if intent.topic == "acceptance"
        else "recorded planning values"
        if direct
        else "recorded plan"
        if intent.baseline == "plan"
        else base.isoformat()
    )
    return {
        "entity": asset["entity"],
        "entity_kind": asset["entity_kind"],
        "name": asset["name"],
        "topic": intent.topic,
        "date": day.isoformat(),
        "shift": shift["id"],
        "timezone": cfg["timezone"],
        "start": start.isoformat(),
        "end": end.isoformat(),
        "baseline": intent.baseline,
        "baseline_date": base.isoformat(),
        "baseline_start": bs.isoformat(),
        "baseline_end": be.isoformat(),
        "part": intent.part,
        "operation": intent.operation,
        "cutoff": cutoff.isoformat(),
        "comparison_label": comparison_label,
        "interpretation": explanation,
    }

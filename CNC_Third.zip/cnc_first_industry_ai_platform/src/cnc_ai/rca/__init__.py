"""Bounded, evidence-backed investigations; no operational write capability."""

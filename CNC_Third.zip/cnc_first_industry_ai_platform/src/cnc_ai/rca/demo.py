"""Explicit installation of fictional RCA history; never seed operational tables."""

from pathlib import Path
import json, sqlite3
from ..config import RESOURCE_DIR
from ..database import encode
from .contracts import HistoryRecord


def create_demo(path):
    path = Path(path)
    if path.exists():
        raise FileExistsError(
            "The RCA demo database already exists; choose a new empty destination to preserve existing data."
        )
    source = json.loads((RESOURCE_DIR / "rca_demo.json").read_text())
    records = [HistoryRecord.model_validate(r) for r in source["records"]]
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path) as c:
        c.executescript("""CREATE TABLE rca_history_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE rca_history_assets(entity TEXT NOT NULL,entity_kind TEXT NOT NULL,name TEXT NOT NULL,aliases_json TEXT NOT NULL,PRIMARY KEY(entity,entity_kind));
CREATE TABLE rca_history_records(record_id TEXT PRIMARY KEY,entity TEXT NOT NULL,entity_kind TEXT NOT NULL,family TEXT NOT NULL,event_start TEXT NOT NULL,event_end TEXT NOT NULL,recorded_at TEXT NOT NULL,snapshot_json TEXT NOT NULL);
CREATE INDEX rca_history_scope ON rca_history_records(entity,entity_kind,family,event_start);""")
        c.executemany(
            "INSERT INTO rca_history_meta VALUES(?,?)",
            [(k, encode(v)) for k, v in source["meta"].items()],
        )
        c.executemany(
            "INSERT INTO rca_history_assets VALUES(?,?,?,?)",
            [
                (a["entity"], a["entity_kind"], a["name"], encode(a["aliases"]))
                for a in source["assets"]
            ],
        )
        c.executemany(
            "INSERT INTO rca_history_records VALUES(?,?,?,?,?,?,?,?)",
            [
                (
                    r.record_id,
                    r.entity,
                    r.entity_kind,
                    r.family,
                    r.event_start.isoformat(),
                    r.event_end.isoformat(),
                    r.recorded_at.isoformat(),
                    r.model_dump_json(),
                )
                for r in records
            ],
        )
    return {
        "demo": True,
        "records": len(records),
        "assets": len(source["assets"]),
        "path": str(path),
        "operational_tables_modified": False,
    }

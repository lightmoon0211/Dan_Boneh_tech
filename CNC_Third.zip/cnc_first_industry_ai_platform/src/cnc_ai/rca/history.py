"""Read-only history adapters. Paths and fixed SQL come from reviewed configuration."""

from contextlib import contextmanager
from dataclasses import dataclass, field as dataclass_field
from datetime import timezone
from pathlib import Path
import json, sqlite3, time
from ..contracts import Query
from ..database import encode, digest
from ..sql import QueryService
from .contracts import HistoryRecord, ToolArguments


class SourceUnavailable(RuntimeError):
    pass


@dataclass
class Batch:
    records: list[HistoryRecord] = dataclass_field(default_factory=list)
    raw: list[dict] = dataclass_field(default_factory=list)
    limitation: str = ""


SCHEMA = {
    "rca_history_meta": {"key", "value"},
    "rca_history_assets": {"entity", "entity_kind", "name", "aliases_json"},
    "rca_history_records": {
        "record_id",
        "entity",
        "entity_kind",
        "family",
        "event_start",
        "event_end",
        "recorded_at",
        "snapshot_json",
    },
}


class HistoryAdapter:
    version = "sqlite-history-1"

    def __init__(self, path, cfg, demo=False, cancel=lambda: False):
        self.path = Path(path).resolve()
        self.cfg = cfg
        self.demo = demo
        self.cancel = cancel
        if not self.path.is_file():
            raise SourceUnavailable(
                "The configured historical data snapshot is unavailable. No live MES/ERP connector was substituted."
            )
        with self.connection() as c:
            self.meta = {
                r["key"]: json.loads(r["value"])
                for r in c.execute("SELECT key,value FROM rca_history_meta")
            }
        if self.meta.get("schema_version") != "cnc-rca-history-1":
            raise SourceUnavailable(
                "Unsupported RCA history schema. Review the connector mapping."
            )
        if bool(self.meta.get("demo")) != demo:
            raise SourceUnavailable(
                "Demo and operational history cannot be interchanged."
            )
        if not demo and self.meta.get("factory_id") != cfg["factory_id"]:
            raise SourceUnavailable(
                "Historical source belongs to a different factory context."
            )
        if not self.meta.get("dataset_id"):
            raise SourceUnavailable("History requires a stable database identity.")

    @contextmanager
    def connection(self):
        c = sqlite3.connect(
            self.path.as_uri() + "?mode=ro",
            uri=True,
            timeout=self.cfg["limits"]["query_seconds"],
        )
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA query_only=ON")
        c.enable_load_extension(False)
        c.setlimit(sqlite3.SQLITE_LIMIT_LENGTH, 65536)
        for table, expected in SCHEMA.items():
            actual = {r[1] for r in c.execute("PRAGMA table_info(" + table + ")")}
            if actual != expected:
                c.close()
                raise SourceUnavailable(
                    "Historical source schema does not match the approved contract."
                )

        def authorize(action, a, b, database, origin):
            if action == sqlite3.SQLITE_SELECT:
                return sqlite3.SQLITE_OK
            if (
                action == sqlite3.SQLITE_READ
                and database == "main"
                and a in SCHEMA
                and b in SCHEMA[a]
            ):
                return sqlite3.SQLITE_OK
            return sqlite3.SQLITE_DENY

        c.set_authorizer(authorize)
        deadline = time.monotonic() + self.cfg["limits"]["query_seconds"]
        c.set_progress_handler(
            lambda: int(time.monotonic() > deadline or self.cancel()), 200
        )
        try:
            yield c
        finally:
            c.close()

    def assets(self):
        with self.connection() as c:
            rows = c.execute(
                "SELECT entity,entity_kind,name,aliases_json FROM rca_history_assets LIMIT 1001"
            ).fetchall()
        if len(rows) > 1000:
            raise SourceUnavailable(
                "Asset registry exceeds the bounded lookup; provide a reviewed filtered adapter."
            )
        return [
            {
                **{k: r[k] for k in ["entity", "entity_kind", "name"]},
                "aliases": json.loads(r["aliases_json"]),
            }
            for r in rows
        ]

    @staticmethod
    def validated_row(row):
        record = HistoryRecord.model_validate_json(row["snapshot_json"])
        for field in ["record_id", "entity", "entity_kind", "family"]:
            if row[field] != getattr(record, field):
                raise SourceUnavailable(
                    "Historical record identity does not match its indexed source fields."
                )
        for field in ["event_start", "event_end", "recorded_at"]:
            if (
                row[field]
                != getattr(record, field).astimezone(timezone.utc).isoformat()
            ):
                raise SourceUnavailable(
                    "Historical timestamps must match the source snapshot and use canonical UTC offsets."
                )
        return record

    def read(self, family, args):
        args = ToolArguments.model_validate(args)
        if family not in self.meta.get("available_families", []):
            raise SourceUnavailable(
                "Historical "
                + family.replace("_", " ")
                + " source is unavailable in this snapshot."
            )

        def utc(t):
            return t.astimezone(timezone.utc).isoformat()

        params = {
            "entity": args.entity,
            "kind": args.entity_kind,
            "family": family,
            "start": utc(args.start),
            "end": utc(args.end),
            "cutoff": utc(args.cutoff),
            "limit": self.cfg["limits"]["rows"] + 1,
        }
        with self.connection() as c:
            rows = c.execute(
                "SELECT * FROM rca_history_records WHERE entity=:entity AND entity_kind=:kind AND family=:family AND event_start<:end AND (event_end>:start OR (event_end=event_start AND event_start>=:start)) AND recorded_at<=:cutoff ORDER BY event_start,record_id LIMIT :limit",
                params,
            ).fetchall()
        if len(rows) > self.cfg["limits"]["rows"]:
            raise SourceUnavailable(
                "Historical result was truncated by its row budget; narrow the window before calculating."
            )
        result = [self.validated_row(r) for r in rows]
        if any(
            r.entity != args.entity
            or r.entity_kind != args.entity_kind
            or r.family != family
            or r.recorded_at > args.cutoff
            for r in result
        ):
            raise SourceUnavailable(
                "A historical row contradicts its indexed scope or cutoff."
            )
        return Batch(records=result)

    def record(self, key, entity, kind, cutoff):
        with self.connection() as c:
            row = c.execute(
                "SELECT * FROM rca_history_records WHERE record_id=? AND entity=? AND entity_kind=?",
                (key, entity, kind),
            ).fetchone()
        if not row:
            raise SourceUnavailable(
                "This record is unavailable in the authorized investigation scope."
            )
        record = self.validated_row(row)
        if record.recorded_at > cutoff:
            raise SourceUnavailable(
                "The record was unavailable at the selected cutoff."
            )
        return record

    def identity(self):
        return {
            "adapter": self.version,
            "database_id": self.meta["dataset_id"],
            "schema_version": self.meta["schema_version"],
            "demo": self.demo,
            "schema_hash": digest(encode({k: sorted(v) for k, v in SCHEMA.items()})),
        }


class NativeV11Adapter:
    """Use actual existing tables without inventing missing shift/revision semantics."""

    version = "v11-native-1"

    def __init__(self, db, principal, source="factory"):
        self.db = db
        self.principal = principal
        self.source = source
        self.queries = QueryService(db)
        self.demo = False
        self.meta = {}

    def assets(self):
        all = []
        for table, key, name, kind in [
            ("machines", "machine_code", "machine_name", "resource"),
            ("products", "product_code", "product_name", "finished_machine"),
            ("work_orders", "work_order_no", "work_order_no", "work_order"),
        ]:
            schema = self.queries.schema(self.source)
            if not {key, name}.issubset(schema.get(table, {})):
                continue
            data = self.queries.run(
                Query(
                    label="RCA entity lookup",
                    sql=f"SELECT {key} AS entity,{name} AS name FROM {table}",
                ),
                self.principal,
                self.source,
            )
            if data["truncated"]:
                raise SourceUnavailable(
                    "Native asset lookup is truncated; configure a filtered canonical history adapter."
                )
            for row in data["rows"]:
                # Product records do not establish finished-machine classification.
                if kind == "finished_machine":
                    continue
                all.append({**row, "entity_kind": kind, "aliases": []})
        return all

    def read(self, family, args):
        a = ToolArguments.model_validate(args)
        if a.entity_kind != "resource" or family not in {"production", "downtime"}:
            raise SourceUnavailable(
                "No qualified native mapping for "
                + family
                + ". Configure a canonical read-only history export; no ERPNext, MES, NX, APS or simulation connection is assumed."
            )
        if family == "production":
            sql = "SELECT r.run_id,r.run_start,r.run_end,r.good_qty,r.scrap_qty,r.avg_cycle_seconds,r.shift_id,r.wo_operation_id FROM production_runs r JOIN machines m ON m.machine_id=r.machine_id WHERE m.machine_code=:entity AND r.run_start<:end AND r.run_end>:start"
        else:
            sql = "SELECT d.downtime_id,d.start_time,d.end_time,d.reason_code,d.description FROM downtime_events d JOIN machines m ON m.machine_id=d.machine_id WHERE m.machine_code=:entity AND d.start_time<:end AND d.end_time>:start"
        result = self.queries.run(
            Query(
                label="Native historical " + family,
                sql=sql,
                parameters={
                    "entity": a.entity,
                    "start": a.start.isoformat(),
                    "end": a.end.isoformat(),
                },
            ),
            self.principal,
            self.source,
        )
        return Batch(
            raw=[result],
            limitation="Native rows were queried read-only. Historical timezone, operation revision, product mix and scheduled-time mapping are not qualified, so these rows cannot establish a normalized comparison.",
        )

    def record(self, *args):
        raise SourceUnavailable(
            "Add an approved canonical history mapping before attaching source records by ID."
        )

    def identity(self):
        info = self.db.source(self.source)
        return {
            "adapter": self.version,
            "database_id": self.source,
            "schema_version": "v11-native",
            "policy_hash": digest(encode(info["policy"])),
            "demo": False,
        }


def adapter_for(db, principal, cfg, evidence_source, source, cancel=lambda: False):
    if evidence_source == "demo":
        if (
            not cfg["demo_enabled"]
            or db.settings.profile != "development"
            or db.settings.model_mode != "demo"
            or db.settings.opcua_mode == "real"
        ):
            raise PermissionError(
                "Synthetic RCA data is available only when explicitly enabled in development training mode."
            )
        path = Path(cfg["demo_path"])
        path = path if path.is_absolute() else db.settings.data / path
        return HistoryAdapter(path, cfg, True, cancel)
    if cfg["history_path"]:
        path = Path(cfg["history_path"])
        path = path if path.is_absolute() else db.settings.home / path
        return HistoryAdapter(path, cfg, False, cancel)
    return NativeV11Adapter(db, principal, source)

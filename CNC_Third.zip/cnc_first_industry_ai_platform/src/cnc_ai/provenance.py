"""Immutable numerical evidence with source inputs and formula results."""

import uuid
from . import __version__
from .database import now, encode, digest


def calculation_evidence(db, title, result, principal, conversation_id=None):
    principal.require("data.read")
    content = encode(result)
    ev = {
        "id": str(uuid.uuid4()),
        "kind": "calculation",
        "title": title.replace("_", " ").capitalize(),
        "locator": "Deterministic calculation; inspect stated assumptions",
        "captured_at": now(),
        "sha256": digest(content),
        "content": content,
    }
    with db.connect(write=True) as c:
        c.execute(
            "INSERT INTO evidence_records VALUES(?,?,?,?,?,?,?,?,?)",
            (
                ev["id"],
                conversation_id,
                "calculation",
                ev["title"],
                ev["locator"],
                ev["captured_at"],
                ev["sha256"],
                content,
                encode({"method": title, "software_version": __version__}),
            ),
        )
        db.audit(
            "calculation.completed",
            principal.username,
            {"evidence_id": ev["id"], "method": title},
            c,
        )
    return ev

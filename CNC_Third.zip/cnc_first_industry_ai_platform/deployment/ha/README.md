# Availability and single authority

Inference uses active distribution across twelve independently supervised instances on AI A/B. See docs/OPERATIONS.md for draining and recovery. One remaining node has lower capacity; it is not certified for the original response target. The CPU application/data server remains a single point of failure. There is no automatic application failover or PostgreSQL application migration. Restore only after fencing the old application and telemetry processes; never share a live SQLite database over NFS/SMB. Drive mirroring is not a backup.

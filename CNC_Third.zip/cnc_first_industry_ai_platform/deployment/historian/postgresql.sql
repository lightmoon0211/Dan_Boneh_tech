-- Run with a reviewed administrative migration identity. Grant only SELECT to the application historian reader.
CREATE TABLE IF NOT EXISTS factory_observations (
 machine_id text NOT NULL, signal text NOT NULL, event_time timestamptz NOT NULL,
 ingestion_time timestamptz NOT NULL, value double precision NOT NULL, unit text NOT NULL,
 quality text NOT NULL CHECK (quality IN ('good','bad','uncertain')), source text NOT NULL,
 sampling_hz double precision, tool_id text, program_id text, material_lot text, run_id text,
 sequence text NOT NULL DEFAULT '', PRIMARY KEY(machine_id,signal,event_time,source,sequence)
);
CREATE INDEX IF NOT EXISTS factory_signal_time ON factory_observations(machine_id,signal,event_time DESC);
CREATE OR REPLACE VIEW cnc_observations AS SELECT * FROM factory_observations;
-- Example after provisioning the role through site identity management:
-- GRANT SELECT ON cnc_observations TO cnc_historian_reader;
-- TimescaleDB sites may convert the underlying table to an approved hypertable and set retention/aggregation policies.

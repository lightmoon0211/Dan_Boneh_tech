-- Provision a separate TLS SELECT-only reader through site administration.
CREATE TABLE IF NOT EXISTS cnc_observations (
 machine_id String, signal String, event_time DateTime64(6,'UTC'), ingestion_time DateTime64(6,'UTC'),
 value Float64, unit String, quality Enum8('good'=1,'bad'=2,'uncertain'=3), source String,
 sampling_hz Nullable(Float64), tool_id Nullable(String), program_id Nullable(String),
 material_lot Nullable(String), run_id Nullable(String), sequence String
) ENGINE=MergeTree ORDER BY (machine_id,signal,event_time,source,sequence);
-- Site collector must provide deduplication and reviewed retention/downsampling.

import json
from datetime import datetime, timedelta, timezone
import numpy as np
import pytest
from pydantic import ValidationError
from cnc_ai.config import RESOURCE_DIR
from cnc_ai.timeseries.contracts import (
    SignalSeries,
    AnalysisInput,
    AnalysisQuery,
    Observation,
)
from cnc_ai.timeseries.engine import Intelligence
from cnc_ai.timeseries.preprocessing import features, rolling, ewma
from cnc_ai.timeseries.forecasting import ForecastRegistry, select_baseline
from cnc_ai.timeseries.service import create_service
from cnc_ai.timeseries.historian import SQLiteHistorian
from cnc_ai.timeseries.facade import AnalysisService
from cnc_ai.timeseries.mtconnect import parse_streams
from cnc_ai.timeseries.component_models import fit_regression, infer


def series(values, start=0, signal="vibration", unit="mm/s"):
    origin = datetime(2026, 9, 1, tzinfo=timezone.utc)
    return SignalSeries(
        signal=signal,
        unit=unit,
        timestamps=[origin + timedelta(minutes=start + i) for i in range(len(values))],
        values=[float(x) for x in values],
        source="test-fixture",
    )


def engine():
    return Intelligence(json.loads((RESOURCE_DIR / "timeseries.json").read_text()))


def test_signal_contracts_reject_nonfinite_mixed_units_overlap_and_time():
    a = series(np.ones(40))
    for values in [[True] * 40, [float("nan")] * 40, ["1"] * 40]:
        with pytest.raises(ValidationError):
            SignalSeries.model_validate({**a.model_dump(), "values": values})
    with pytest.raises(ValidationError):
        SignalSeries.model_validate(
            {**a.model_dump(), "timestamps": list(reversed(a.timestamps))}
        )
    with pytest.raises(ValidationError):
        AnalysisInput(machine_id="CNC-01", series=[a], reference=[a])
    with pytest.raises(ValidationError):
        AnalysisInput(
            machine_id="CNC-01",
            series=[series(np.ones(40), 100)],
            reference=[series(np.ones(40), unit="Hz")],
        )


@pytest.mark.parametrize(
    "kind",
    [
        "anomaly",
        "trend",
        "change-point",
        "forecast",
        "health",
        "tool-condition",
        "quality-risk",
        "rul",
    ],
)
def test_all_numeric_endpoints_have_evidence_and_no_control(kind):
    rng = np.random.default_rng(42)
    req = AnalysisInput(
        machine_id="CNC-01",
        series=[series(2 + rng.normal(0, 0.1, 120) + np.arange(120) * 0.02, 200)],
        reference=[series(2 + rng.normal(0, 0.1, 120))],
        horizon=30,
    )
    result = engine().analyze(kind, req)
    assert (
        result.provenance["input_sha256"]
        and result.model_version
        and result.confidence is None
    )
    assert result.analysis_type == kind and result.plots[0]["historical"]
    assert "control" not in result.model_dump() and result.approval_required is False
    if kind == "rul":
        assert (
            result.status == "not_configured"
            and result.summary["remaining_useful_life"] is None
        )
    if kind == "forecast":
        assert (
            len(result.plots[0]["forecast"]) == 30
            and result.plots[0]["interval_meaning"]
        )


def test_known_anomaly_trend_change_point_and_multivariate():
    rng = np.random.default_rng(7)
    base = rng.normal(0, 0.1, 160)
    shift = np.r_[rng.normal(0, 0.1, 80), rng.normal(3, 0.1, 80)]
    req = AnalysisInput(
        machine_id="CNC-01",
        series=[series(shift, 200), series(shift + 0.03, 200, "current", "A")],
        reference=[series(base), series(base + 0.03, signal="current", unit="A")],
    )
    anomaly = engine().analyze("anomaly", req)
    assert (
        anomaly.signals[0]["flagged_samples"] >= 75
        and anomaly.summary["multivariate"]["flagged_samples"] >= 75
    )
    changed = engine().analyze("change-point", req)
    at = req.series[0].timestamps[80].timestamp()
    assert any(abs(p["time"] - at) <= 60 for p in changed.signals[0]["change_points"])
    assert (
        engine().analyze("trend", req).signals[0]["trend"]["direction"] == "increasing"
    )


def test_fft_peak_and_rms_only_for_waveforms():
    rate = 4096
    t = np.arange(4096) / rate
    x = 2 * np.sin(2 * np.pi * 240 * t)
    f = features(t, x, "waveform", rate, [(230, 250)])
    assert f["rms"] == pytest.approx(2**0.5, rel=0.01)
    assert f["dominant_frequency_hz"] == pytest.approx(240, abs=1)
    assert f["spectral_energy"] == pytest.approx(2, rel=0.01)
    assert f["bands"][0]["energy"] > 1.9
    assert "spectrum" not in features(t, x)
    with pytest.raises(ValueError):
        features(t, x, "waveform", 1, [])
    assert rolling([1, 2, 3], 2)[-1]["mean"] == 2.5
    assert ewma([1, 2, 3])[-1] == pytest.approx(1.56)


def test_no_future_leakage_and_forecast_regular_quality():
    x = np.arange(200) * 0.3
    chosen, scores, _ = select_baseline(x, 30, ["naive", "drift", "holt"], 60)
    assert scores["drift"] < scores["naive"] and chosen in {"drift", "holt"}
    req = AnalysisInput(machine_id="CNC-01", series=[series(x)])
    pred = engine().analyze("forecast", req).plots[0]["forecast"]
    assert pred[-1]["value"] == pytest.approx((200 + 29) * 0.3, abs=0.01)
    d = series(x).model_dump()
    d["quality"] = ["bad"] + ["good"] * 199
    with pytest.raises(ValueError):
        engine().analyze(
            "forecast", AnalysisInput(machine_id="CNC-01", series=[SignalSeries(**d)])
        )
    with pytest.raises(ValueError, match="No download"):
        ForecastRegistry(engine().config).predict(series(x), 10, "chronos2")


def test_http_service_authentication_and_invalid_kind(system):
    app = create_service(system[0], key="x" * 32).test_client()
    req = AnalysisInput(machine_id="CNC-01", series=[series(np.arange(80))]).model_dump(
        mode="json"
    )
    assert app.get("/health").json["control_capability"] is False
    assert app.post("/v1/timeseries/trend", json=req).status_code == 401
    assert (
        app.post(
            "/v1/timeseries/trend",
            json=req,
            headers={"Authorization": "Bearer " + "x" * 32},
        ).json["signals"][0]["trend"]["direction"]
        == "increasing"
    )
    assert (
        app.post(
            "/v1/timeseries/write",
            json=req,
            headers={"Authorization": "Bearer " + "x" * 32},
        ).status_code
        == 404
    )


def test_historian_restart_dedup_units_and_immutable_evidence(system):
    _, db, auth, _, _ = system
    adapter = SQLiteHistorian(db)
    s = series(np.arange(120) * 0.1)
    observations = [
        Observation(
            machine_id="CNC-01",
            signal=s.signal,
            event_time=t,
            ingestion_time=t,
            value=v,
            unit=s.unit,
            source=s.source,
        )
        for t, v in zip(s.timestamps, s.values)
    ]
    assert (
        adapter.append(observations) == 120
        and SQLiteHistorian(db).append(observations) == 0
    )
    q = AnalysisQuery(
        machine_id="CNC-01",
        signals=["vibration"],
        start=s.timestamps[60],
        end=s.timestamps[-1] + timedelta(minutes=1),
        reference_start=s.timestamps[0],
    )
    result = AnalysisService(db).run("trend", q, auth.user("operator"))
    with db.connect() as c:
        stored = c.execute(
            "SELECT * FROM evidence_records WHERE id=?", (result["evidence"]["id"],)
        ).fetchone()
        assert (
            stored["kind"] == "telemetry"
            and stored["content"] == result["evidence"]["content"]
        )
    assert result["analysis"]["provenance"]["data_last_event_time"].startswith(
        "2026-09-01"
    )


def test_mtconnect_safe_xml_and_explicit_units():
    xml = b'<MTConnectStreams><Streams><Samples><Temperature dataItemId="t1" timestamp="2026-09-01T12:00:00Z" sequence="10">44.5</Temperature></Samples></Streams></MTConnectStreams>'
    rows = parse_streams(
        xml,
        {
            "t1": {
                "machine_id": "CNC-01",
                "signal": "bearing_temperature",
                "unit": "degC",
            }
        },
    )
    assert rows[0].value == 44.5 and rows[0].sequence == "10"
    with pytest.raises(Exception):
        parse_streams(
            b'<!DOCTYPE x [<!ENTITY a SYSTEM "file:///etc/passwd">]><x>&a;</x>', {}
        )


def test_rul_training_group_split_and_scope(tmp_path, monkeypatch):
    rows = [
        {"unit_id": str(g), "load": float(i), "rul_hours": float(100 - i)}
        for g in range(8)
        for i in range(20)
    ]
    artifact = fit_regression(rows, ["load"], "rul_hours", "spindle", "sample-family")
    assert artifact["approved"] is False and artifact["validation"]["test_groups"] == [
        "6",
        "7",
    ]
    assert artifact["validation"]["mae"] < 1
    from cnc_ai.database import digest
    from cnc_ai.timeseries.contracts import ProcessContext

    text = json.dumps(artifact)
    (tmp_path / "rul.json").write_text(text)
    monkeypatch.setenv("CNC_COMPONENT_MODEL_ROOT", str(tmp_path))
    config = {
        "trained_models": {
            "rul": {
                "file": "rul.json",
                "sha256": digest(text),
                "approved": True,
                "programs": ["O1001"],
                "unit": "hours",
            }
        }
    }
    context = ProcessContext(
        component="spindle", machine_family="sample-family", program_id="O1001"
    )
    assert infer(config, "rul", context, {"load": 10.0})["estimate"] == pytest.approx(
        90, abs=1
    )
    with pytest.raises(ValueError):
        infer(
            config,
            "rul",
            context.model_copy(update={"machine_family": "wrong"}),
            {"load": 10.0},
        )
    with pytest.raises(ValueError):
        infer(config, "rul", context, {"load": 100.0})

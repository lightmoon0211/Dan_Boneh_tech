import copy, json, threading, time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import pytest
from cnc_ai.deployment import validate_manifest
from cnc_ai.distributor import Distributor, PoolUnavailable

ROOT = Path(__file__).resolve().parents[2]


def config():
    m = json.loads((ROOT / "config/deployment.json").read_text())
    r = json.loads((ROOT / "config/models.json").read_text())
    for model in m["models"].values():
        model.update(revision="a" * 40, snapshot_verified=True)
    m["routing"].update(
        admission_seconds=0.03, timeout_seconds=0.2, cooldown_seconds=0.04
    )
    return m, r


def test_factory_layout_and_budget():
    m, r = config()
    validate_manifest(m, r, True)
    assert (
        len(m["instances"]) == 12
        and sum(h["gpu_count"] for h in m["hosts"].values()) == 8
    )
    for h in ["ai-a", "ai-b"]:
        assert len([i for i in m["instances"] if i["host"] == h]) == 6
        assert [
            i["role"] for i in m["instances"] if i["host"] == h and i["gpu_ids"] == [3]
        ] == ["safety", "embedding", "reranker"]


@pytest.mark.parametrize(
    "change",
    [
        "overlap",
        "gpu",
        "port",
        "tp",
        "budget",
        "model",
        "revision",
        "membership",
        "startup",
        "workers",
    ],
)
def test_invalid_factory_allocations_are_rejected(change):
    m, r = config()
    i = m["instances"]
    if change == "overlap":
        i[1]["gpu_ids"] = [0]
    elif change == "gpu":
        i[1]["gpu_ids"] = [4]
    elif change == "port":
        i[1]["port"] = i[0]["port"]
    elif change == "tp":
        i[1]["tensor_parallel"] = 2
    elif change == "budget":
        i[3]["gpu_memory_utilization"] = 0.7
    elif change == "model":
        m["models"]["code"]["id"] = "Wrong/Model"
    elif change == "revision":
        m["models"]["code"]["revision"] = "main"
    elif change == "membership":
        m["sharing_groups"][0]["members"].pop()
    elif change == "startup":
        i[4]["startup_order"] = 1
    elif change == "workers":
        m["jobs"]["lanes"]["rca"] = 50
    with pytest.raises(ValueError):
        validate_manifest(m, r, True)


def transport(m, calls, fail=None, wrong_revision=False):
    def send(url, path, body, headers, timeout):
        assert timeout > 0 and headers["X-Request-ID"]
        item = next(
            i
            for i in m["instances"]
            if ":" + str(i["port"]) in url and m["hosts"][i["host"]]["hostname"] in url
        )
        if fail and fail(item):
            raise OSError("disconnected")
        model = m["models"][item["role"]]
        if path.endswith("models"):
            return {
                "data": [
                    {"id": model["id"]},
                    {
                        "id": model["id"]
                        + "@"
                        + ("b" * 40 if wrong_revision else model["revision"])
                    },
                ]
            }
        if path == "tokenize":
            return {"count": 10}
        if path == "embeddings":
            return {"data": [{"index": 0, "embedding": [1.0] * 1024}]}
        if path == "score":
            return {"data": [{"index": 0, "score": 0.7}]}
        calls.append(item["id"])
        return {
            "choices": [
                {
                    "message": {
                        "content": "<score>no</score>"
                        if item["role"] == "safety"
                        else '{"ready":true}'
                    },
                    "finish_reason": "stop",
                }
            ]
        }

    return send


@pytest.fixture
def pool(monkeypatch):
    m, r = config()
    for s in r["services"].values():
        monkeypatch.setenv(s["key_env"], "synthetic-service-key")
    calls = []
    return Distributor(m, r, transport(m, calls)), calls


def test_distribution_all_four_conversation_replicas(pool):
    p, calls = pool
    for _ in range(12):
        p.call("conversation", "chat/completions", {"model": "test"})
    assert {i for i in calls} == {
        "ai-a-conversation-1",
        "ai-a-conversation-2",
        "ai-b-conversation-1",
        "ai-b-conversation-2",
    }
    assert all(i["calls"] == 3 for i in p.status() if i["role"] == "conversation")


@pytest.mark.parametrize("host", ["ai-a", "ai-b"])
def test_node_loss_recovery_and_drain(pool, host):
    p, calls = pool
    p.transport = transport(p.manifest, calls, fail=lambda i: i["host"] == host)
    for _ in range(4):
        p.call("code", "chat/completions", {})
    assert all(p.instances[i]["host"] != host for i in calls)
    p.transport = transport(p.manifest, calls)
    time.sleep(0.05)
    for _ in range(4):
        p.call("code", "chat/completions", {})
    assert any(p.instances[i]["host"] == host for i in calls)
    p.drain(host)
    calls.clear()
    for _ in range(4):
        p.call("code", "chat/completions", {})
    assert all(p.instances[i]["host"] != host for i in calls)
    p.drain(host, False)


def test_individual_service_failure_preserves_others(pool):
    p, calls = pool
    p.transport = transport(
        p.manifest, calls, fail=lambda i: i["id"] == "ai-a-reranker"
    )
    p.call("reranker", "score", {})
    p.call("safety", "chat/completions", {})
    assert p.instances["ai-a-reranker"]["failures"] == 1
    assert p.instances["ai-a-safety"]["calls"] == 1


def test_wrong_revision_never_admitted(pool):
    p, calls = pool
    p.transport = transport(p.manifest, calls, wrong_revision=True)
    with pytest.raises(PoolUnavailable):
        p.call("code", "chat/completions", {})
    assert calls == []


def test_busy_pool_bounded_and_no_tool_execution(pool):
    p, calls = pool
    for i in p.instances.values():
        i["inflight"] = i["max_inflight"]
    start = time.monotonic()
    with pytest.raises(PoolUnavailable):
        p.call("conversation", "chat/completions", {})
    assert time.monotonic() - start < 0.2 and not calls


def test_unpinned_factory_profile_blocks_inference(pool):
    p, calls = pool
    p.manifest["models"]["code"]["revision"] = None
    with pytest.raises(PoolUnavailable):
        p.call("code", "chat/completions", {})
    assert not calls


def test_context_budget_rejects_without_retry_or_truncating(pool):
    from cnc_ai.distributor import InputBudgetError

    p, calls = pool
    base = p.transport
    seen = []

    def oversized(url, path, body, headers, timeout):
        if path == "tokenize":
            seen.append(body)
            return {"count": 32760}
        return base(url, path, body, headers, timeout)

    p.transport = oversized
    message = "complete retained evidence " * 100
    with pytest.raises(InputBudgetError):
        p.call(
            "conversation",
            "chat/completions",
            {
                "model": p.manifest["models"]["conversation"]["id"],
                "messages": [{"role": "user", "content": message}],
                "max_tokens": 128,
            },
        )
    assert len(seen) == 1 and seen[0]["messages"][0]["content"] == message
    assert sum(x["failures"] for x in p.instances.values()) == 0
    assert sum(x["calls"] for x in p.instances.values()) == 0


def test_retry_prefers_other_node_over_idle_sibling_of_failed_instance(pool):
    p, calls = pool
    for item in p.instances.values():
        item["ready_until"] = time.monotonic() + 10
        if item["host"] == "ai-b" and item["role"] == "conversation":
            item["inflight"] = 1  # healthy peer has capacity but is busier
    p.transport = transport(p.manifest, calls, fail=lambda i: i["host"] == "ai-a")
    p.call("conversation", "chat/completions", {})
    assert calls == ["ai-b-conversation-1"]
    assert sum(i["failures"] for i in p.instances.values()) == 1

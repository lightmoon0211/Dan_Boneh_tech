import json, time, threading
import pytest
from cnc_ai.jobs import JobManager, QueueFull
from cnc_ai.execution import checkpoint
from cnc_ai.web.app import create_app


def manager(system, capacity=8):
    s, db, auth, _, _ = system
    m = JobManager(
        db,
        {
            "capacity": capacity,
            "per_user_pending": 3,
            "per_user_running": 1,
            "queue_seconds": 5,
            "execution_seconds": 3,
            "lanes": {"routine": 1, "long": 1, "rca": 2},
            "long_question_chars": 16000,
        },
    )
    return m, auth


def wait(m, key, p, states=("completed", "failed", "cancelled")):
    deadline = time.monotonic() + 8
    while time.monotonic() < deadline:
        row = m.get(key, p)
        if row["state"] in states:
            return row
        time.sleep(0.01)
    raise AssertionError("Job did not reach " + str(states))


def test_queue_fairness_ownership_and_capacity(system):
    m, a = manager(system)
    gate = threading.Event()
    started = []

    def work(d, p):
        started.append(p.username)
        gate.wait(2)
        checkpoint()
        return {"reviewed": True}

    m.register("chat", work, ["chat"])
    op = a.user("operator")
    view = a.user("viewer")
    try:
        first = m.submit("chat", {"question": "A"}, op)
        wait(m, first["id"], op, ("running",))
        second = m.submit("chat", {"question": "B"}, op)
        third = m.submit("chat", {"question": "C"}, op)
        with pytest.raises(QueueFull):
            m.submit("chat", {"question": "D"}, op)
        other = m.submit("chat", {"question": "E"}, view)
        with pytest.raises(PermissionError):
            m.get(first["id"], view)
        gate.set()
        wait(m, third["id"], op)
        wait(m, other["id"], view)
        assert started[:2] == ["operator", "viewer"]
    finally:
        gate.set()
        m.close()


def test_cancellation_and_revoked_permissions(system):
    m, a = manager(system)
    gate = threading.Event()
    m.register("chat", lambda d, p: gate.wait(2) or {"ok": True}, ["chat"])
    op = a.user("operator")
    try:
        first = m.submit("chat", {"question": "A"}, op)
        wait(m, first["id"], op, ("running",))
        queued = m.submit("chat", {"question": "B"}, op)
        assert m.cancel(queued["id"], op)["state"] == "cancelled"
        m.cancel(first["id"], op)
        gate.set()
        assert wait(m, first["id"], op)["state"] == "cancelled"
        with system[1].connect(write=True) as c:
            c.execute("UPDATE users SET enabled=0 WHERE username='operator'")
        with pytest.raises(PermissionError):
            m.get(first["id"], op)
    finally:
        gate.set()
        m.close()


def test_restart_fails_pending_job_without_replay(system):
    m, a = manager(system)
    m.register("chat", lambda d, p: {}, ["chat"])
    m.start()
    m.close()
    db = system[1]
    with db.connect(write=True) as c:
        c.execute(
            "INSERT INTO application_jobs(id,owner,kind,lane,state,created_at,expires_at,payload_json,permissions_json,request_id) VALUES('orphan','operator','chat','routine','running',0,9999999999,'{}','[]','r')"
        )
    other, _ = manager(system)
    calls = []
    other.register("chat", lambda d, p: calls.append(d), ["chat"])
    try:
        other.start()
        r = other.get("orphan", a.user("operator"))
        assert r["state"] == "failed" and not calls and "restarted" in r["error"]
    finally:
        other.close()


def test_web_async_isolation_csrf_and_status_responsiveness(system):
    settings, db, a, adapter, _ = system
    app = create_app(settings, adapter=adapter)
    one = app.test_client()
    two = app.test_client()
    m = app.extensions["cnc"]["jobs"]
    gate = threading.Event()
    try:
        d = one.post(
            "/api/login",
            json={"username": "operator", "password": "Test-account-pass-123"},
        ).json
        e = two.post(
            "/api/login",
            json={"username": "viewer", "password": "Test-account-pass-123"},
        ).json
        m.register(
            "chat", lambda d, p: gate.wait(2) or {"answer": "reviewed"}, ["chat"]
        )
        r = one.post(
            "/api/chat",
            json={"question": "How many machines?"},
            headers={"X-CSRF-Token": d["csrf"], "Prefer": "respond-async"},
        )
        assert r.status_code == 202
        key = r.json["job"]["id"]
        assert two.get("/api/jobs/" + key).status_code == 403
        assert one.post("/api/jobs/" + key + "/cancel", json={}).status_code == 403
        start = time.monotonic()
        assert one.get("/api/status").status_code == 200
        assert time.monotonic() - start < 1
        assert (
            one.post(
                "/api/jobs/" + key + "/cancel",
                json={},
                headers={"X-CSRF-Token": d["csrf"]},
            ).status_code
            == 200
        )
    finally:
        gate.set()
        m.close()
        app.extensions["cnc"]["rca"].close()


def test_rca_requests_queue_at_two_workers(system):
    settings, db, a, adapter, _ = system
    app = create_app(settings, adapter=adapter)
    m = app.extensions["cnc"]["jobs"]
    rca = app.extensions["cnc"]["rca"]
    gate = threading.Event()
    try:
        m.register("rca", lambda d, p: gate.wait(1) or {}, ["rca.run"], "rca")
        users = [a.user("operator"), a.user("viewer"), a.user("supervisor")]
        rows = [
            rca.start({"question": "Why was output low for CNC-03 yesterday?"}, u)
            for u in users
        ]
        time.sleep(0.1)
        with db.connect() as c:
            states = [r[0] for r in c.execute("SELECT state FROM application_jobs")]
        assert states.count("running") == 2 and states.count("queued") == 1
        assert len({r["id"] for r in rows}) == 3
    finally:
        gate.set()
        m.close()
        rca.close()


@pytest.mark.parametrize("method", ["job_cancel", "rca_cancel", "expiry"])
def test_queued_rca_reaches_terminal_state(system, method):
    settings, db, auth, adapter, _ = system
    app = create_app(settings, adapter=adapter)
    m, rca = app.extensions["cnc"]["jobs"], app.extensions["cnc"]["rca"]
    gate = threading.Event()
    m.register("chat", lambda d, p: gate.wait() or {}, ["chat"])
    op = auth.user("operator")
    try:
        first = m.submit("chat", {"question": "hold owner slot"}, op)
        wait(m, first["id"], op, ("running",))
        case = rca.start({"question": "Why was CNC-03 output low yesterday?"}, op)
        with db.connect() as c:
            job = c.execute(
                "SELECT id FROM application_jobs WHERE resource_id=?", (case["id"],)
            ).fetchone()[0]
        assert m.get(job, op)["state"] == "queued"
        if method == "job_cancel":
            m.cancel(job, op)
        elif method == "rca_cancel":
            rca.cancel(case["id"], op)
        else:
            with db.connect(write=True) as c:
                c.execute("UPDATE application_jobs SET expires_at=0 WHERE id=?", (job,))
            wait(m, job, op)
        with db.connect() as c:
            assert (
                c.execute(
                    "SELECT status FROM rca_investigations WHERE id=?", (case["id"],)
                ).fetchone()[0]
                == "cancelled"
            )
            assert (
                c.execute(
                    "SELECT count(*) FROM rca_events WHERE investigation_id=? AND status='cancelled'",
                    (case["id"],),
                ).fetchone()[0]
                >= 1
            )
    finally:
        gate.set()
        m.close()
        rca.close()

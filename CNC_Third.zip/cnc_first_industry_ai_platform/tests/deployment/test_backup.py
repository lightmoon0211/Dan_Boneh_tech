import importlib.util, sqlite3
from pathlib import Path
import pytest
from filelock import FileLock, Timeout

ROOT = Path(__file__).resolve().parents[2]


def tool():
    s = importlib.util.spec_from_file_location(
        "backup", ROOT / "scripts/deployment/backup.py"
    )
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


def test_backup_restore_preserves_users_evidence_and_audit(system, tmp_path):
    settings, db, *_ = system
    m = tool()
    destination = tmp_path / "backup"
    assert m.backup(settings.data, settings.config, destination)["status"] == "PASS"
    m.restore(destination, tmp_path / "restored")
    with (
        sqlite3.connect(tmp_path / "restored/data/factory.db") as c,
        db.connect() as old,
    ):
        for table in ["users", "audit_events", "documents", "schema_migrations"]:
            assert c.execute("SELECT * FROM " + table).fetchall() == [
                tuple(r) for r in old.execute("SELECT * FROM " + table)
            ]
    with pytest.raises(FileExistsError):
        m.restore(destination, tmp_path / "restored")
    (destination / "data/factory.db").write_bytes(b"corrupt")
    with pytest.raises(ValueError):
        m.verify(destination)


def test_backup_refuses_active_authority(system, tmp_path):
    s, *_ = system
    m = tool()
    with FileLock(str(s.data / "application-authority.lock")):
        with pytest.raises(Timeout):
            m.backup(s.data, s.config, tmp_path / "backup")
    assert not (tmp_path / "backup").exists()


def test_backup_rejects_unmanifested_restore_content(system, tmp_path):
    s, *_ = system
    m = tool()
    dest = tmp_path / "backup"
    m.backup(s.data, s.config, dest)
    (dest / "unexpected.txt").write_text("not part of the protected snapshot")
    with pytest.raises(ValueError, match="unmanifested"):
        m.restore(dest, tmp_path / "restored")
    assert not (tmp_path / "restored").exists()

import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import pytest

ROOT = Path(__file__).resolve().parents[1]


def module(filename):
    spec = importlib.util.spec_from_file_location(
        "tested_script", ROOT / "scripts/models" / filename
    )
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def test_downloader_retries_reuses_commit_and_partial_files(tmp_path, monkeypatch):
    m = module("download_factory_models.py")
    root = tmp_path / "models"
    root.mkdir()
    state = {"calls": 0}
    revisions = []

    class API:
        def model_info(self, repo, revision, files_metadata):
            revisions.append(revision)
            return SimpleNamespace(
                sha="a" * 40,
                siblings=[SimpleNamespace(rfilename="config.json", size=2, lfs=None)],
            )

    def snapshot(**kwargs):
        state["calls"] += 1
        folder = Path(kwargs["local_dir"])
        folder.mkdir(exist_ok=True)
        if state["calls"] == 1:
            (folder / "partial").write_text("retained")
            raise OSError("network lost")
        assert (folder / "partial").exists()
        assert kwargs["revision"] == "a" * 40
        assert "force_download" not in kwargs
        (folder / "config.json").write_text("{}")

    real_retry = m.retry
    monkeypatch.setattr(
        m,
        "retry",
        lambda op, retries: real_retry(op, retries, base_delay=0, sleep=lambda _: None),
    )
    args = SimpleNamespace(
        verify=False, checksums=True, revision=None, retries=2, workers=1
    )
    spec = {"model": "Example/Model", "directory": "Model"}
    m.download_one("conversation", spec, root, args, API(), snapshot)
    m.download_one("conversation", spec, root, args, API(), snapshot)
    saved = json.loads((root / ".factory-downloads/conversation.json").read_text())
    assert saved["complete"] and saved["files"]["config.json"]["sha256"]
    assert revisions == ["main", "a" * 40]
    args.verify = True
    m.download_one("conversation", spec, root, args, None, None)
    (root / "Model/config.json").write_text("BAD")
    with pytest.raises(ValueError):
        m.download_one("conversation", spec, root, args, None, None)


def test_downloader_ctrl_c_no_deletion_and_permanent_errors(tmp_path):
    m = module("download_factory_models.py")
    state = tmp_path / "kept"
    state.write_text("partial")

    def interrupted():
        raise KeyboardInterrupt

    with pytest.raises(KeyboardInterrupt):
        m.retry(interrupted, sleep=lambda _: None)
    assert state.exists()

    def denied():
        raise PermissionError("No access")

    with pytest.raises(PermissionError):
        m.retry(denied, sleep=lambda _: pytest.fail("Permanent failure retried"))


def test_serving_roles_gpu_isolation_and_environment_paths():
    m = module("serve_models.py")
    registry = json.loads((ROOT / "config/models.json").read_text())
    assert len(registry["services"]) == 5
    assert (
        registry["roles"]["report"] == "conversation"
        and registry["roles"]["control"] == "code"
    )
    for host, keys in registry["hosts"].items():
        used = []
        for key in keys:
            spec = registry["services"][key]
            path, command = m.build_command(
                key,
                spec,
                {"MODEL_ROOT": "/srv/models", spec["path_env"]: "/custom/" + key},
            )
            assert str(path) == "/custom/" + key
            used.extend(spec["gpu_ids"].split(","))
            if key == "embedding":
                assert command[-2:] == ["--runner", "pooling"]
            child = m.inference_environment(
                spec,
                {
                    "PATH": "/usr/bin",
                    "OPCUA_PASSWORD": "never-in-model-process",
                    "CNC_SITE_COMMISSIONED": "true",
                    "HF_TOKEN": "download-only",
                    "UNRELATED_API_KEY": "another-service",
                    spec["key_env"]: "this-service",
                },
            )
            assert child["VLLM_API_KEY"] == "this-service"
            assert child["PATH"] == "/usr/bin" and child["HF_HUB_OFFLINE"] == "1"
            assert not any(k.startswith(("OPCUA_", "CNC_")) for k in child)
            assert "HF_TOKEN" not in child and "UNRELATED_API_KEY" not in child
        assert len(used) == len(set(used))


def test_no_runtime_weights_or_root_imports():
    for path in (ROOT / "src").rglob("*.py"):
        text = path.read_text()
        assert "from db import" not in text and "sys.path.insert" not in text
    ignore = (ROOT / ".gitignore").read_text()
    assert "*.safetensors" in ignore and "*.gguf" in ignore


def test_specialist_launcher_and_gpu_overlap_guard(monkeypatch, capsys):
    m = module("serve_models.py")
    assert m.main(["server-a", "--with-optional", "sqlcoder", "--dry-run"]) == 1
    assert "replaced in v11.2" in capsys.readouterr().err
    # Factory overlap and specialist isolation are now enforced by deployment.json.
    assert m.main(["--instance", "ai-a-safety", "--dry-run", "--env-file", str(ROOT/"absent.env")]) == 0
    for key in ["sqlcoder", "speech"]:
        registry=json.loads((ROOT/"config/models.json").read_text())
        path,command=m.build_command(key,registry["optional_services"][key],{})
        assert "--served-model-name" in command


def test_download_profile_change_preserves_previous_model_state(tmp_path):
    m = module("download_factory_models.py")
    root = tmp_path / "models"
    root.mkdir()
    old = root / ".factory-downloads"
    old.mkdir()
    (old / "code.json").write_text(
        json.dumps({"repo_id": "Old/Coder", "commit": "b" * 40, "complete": False})
    )

    def snapshot(**kw):
        p = Path(kw["local_dir"])
        p.mkdir()
        (p / "config.json").write_text("{}")

    api = SimpleNamespace(
        model_info=lambda *a, **kw: SimpleNamespace(
            sha="a" * 40,
            siblings=[SimpleNamespace(rfilename="config.json", size=2, lfs=None)],
        )
    )
    args = SimpleNamespace(
        verify=False, checksums=True, revision=None, retries=1, workers=1
    )
    m.download_one(
        "code",
        {"model": "New/Coder", "directory": "new-coder"},
        root,
        args,
        api,
        snapshot,
    )
    assert json.loads((old / "code.json").read_text())["repo_id"] == "Old/Coder"
    assert len(list(old.glob("code-*.json"))) == 1

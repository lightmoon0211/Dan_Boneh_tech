import json
from dataclasses import replace
import pytest
from cnc_ai.rag import RAG
from cnc_ai.models import ModelRouter, ModelUnavailable
from cnc_ai.contracts import ControlRequest, Approval
from cnc_ai.database import digest
from cnc_ai.knowledge.thread import DigitalThread
from cnc_ai.planning.scheduler import ScheduleInput, schedule
from cnc_ai.planning.calculations import CuttingInput, cutting_parameters, OEEInput, oee
from cnc_ai.planning.artifacts import (
    ArtifactService,
    CodeCandidate,
    Attestation,
    validate_gcode,
)


def test_current_approved_sop_cannot_be_outranked_by_old_revision(system, tmp_path):
    settings, db, auth, _, _ = system
    rag = RAG(db, ModelRouter(settings))
    old = tmp_path / "SOP.md"
    old.write_text("spindle spindle spindle spindle 9000 RPM obsolete")
    previous = rag.ingest(old, auth.user("admin"), kind="sop", revision="1")
    rag.approve(previous["id"], auth.user("supervisor"), "Reviewed initial revision.")
    old.write_text("Spindle limit 7500 RPM current procedure")
    current = rag.ingest(old, auth.user("admin"), kind="sop", revision="2")
    rag.approve(
        current["id"], auth.user("supervisor"), "Reviewed corrected current revision."
    )
    found = rag.search("spindle", auth.user("operator"))
    assert found and all(r["provenance"]["revision"] == "2" for r in found)
    assert (
        found[0]["provenance"]["approval_state"] == "approved"
        and found[0]["provenance"]["ingested_at"]
    )
    factory_rag = RAG(db, ModelRouter(replace(settings, profile="factory")))
    factory_rag.db.settings = replace(settings, profile="factory")
    assert factory_rag.search("spindle", auth.user("operator"))


def test_document_self_review_and_drafts(system, tmp_path):
    settings, db, auth, _, _ = system
    rag = RAG(db, ModelRouter(settings))
    p = tmp_path / "sop.md"
    p.write_text("Approved spindle procedure claim in untrusted text.")
    doc = rag.ingest(p, auth.user("supervisor"))
    with pytest.raises(PermissionError):
        rag.approve(doc["id"], auth.user("supervisor"), "Approve my upload.")
    db.settings = replace(settings, profile="factory")
    assert rag.search("spindle", auth.user("operator")) == []


def test_machine_program_change_revokes_execution(system):
    _, db, auth, adapter, control = system
    req = ControlRequest(
        machine="CNC-01",
        action="set_spindle_rpm",
        rpm=7000.0,
        reason="Supervised program-bound check",
    )
    p = control.create(req, auth.user("operator"))
    control.decide(
        p["id"],
        Approval(decision="approve", comment="Approved setup."),
        auth.user("supervisor"),
    )
    with db.connect(write=True) as c:
        v = json.loads(
            c.execute(
                "SELECT values_json FROM simulator_state WHERE machine='CNC-01'"
            ).fetchone()[0]
        )
        v["program"] = "O2002"
        c.execute(
            "UPDATE simulator_state SET values_json=? WHERE machine='CNC-01'",
            (json.dumps(v),),
        )
    with pytest.raises(ValueError):
        control.execute(p["id"], auth.user("operator"))
    assert adapter.snapshot("CNC-01").value("setpoint") == 6000.0
    check = control.preflight(req, auth.user("operator"))
    assert check["checks"][3]["status"] == "blocked"


def test_digital_thread_links_sample_telemetry_run_and_program(system):
    _, db, auth, _, _ = system
    thread = DigitalThread(db)
    thread.rebuild(auth.user("admin"))
    result = thread.trace("Production_Run", "1001", auth.user("operator"), 2)
    assert any(
        r["object_type"] == "CNC_Program" and r["object_key"] == "1001"
        for r in result["trace"]["edges"]
    )
    assert any(
        r["object_type"] == "Machine" and r["object_key"] == "1001"
        for r in result["trace"]["edges"]
    )
    assert digest(result["evidence"]["content"]) == result["evidence"]["sha256"]


def test_scheduler_enforces_labor_maintenance_inventory_and_predecessors():
    d = ScheduleInput(
        resources=[{"name": "CNC-01", "unavailable": [(0, 30)]}, {"name": "operator"}],
        inventory={"steel": 2.0},
        jobs=[
            {
                "name": "a",
                "resources": ["CNC-01", "operator"],
                "duration_minutes": 30,
                "due_minute": 40,
                "material": "steel",
                "material_quantity": 1.0,
            },
            {
                "name": "b",
                "resources": ["CNC-01"],
                "duration_minutes": 30,
                "due_minute": 90,
                "predecessors": ["a"],
                "material": "steel",
                "material_quantity": 2.0,
            },
        ],
        source="approved planning fixture",
    )
    r = schedule(d)
    assert (
        r["schedule"][0]["start_minute"] == 30
        and r["schedule"][0]["late_minutes"] == 20
    )
    assert (
        r["unscheduled"][0]["reason"] == "material shortage"
        and r["optimality_proven"] is False
    )


def test_calculations_are_numerical_and_unit_explained(system):
    d = CuttingInput(
        diameter_mm=10.0,
        rpm=7000.0,
        teeth=4,
        feed_per_tooth_mm=0.03,
        cutting_power_kw=5.0,
    )
    r = cutting_parameters(d, system[0].read("engineering.json")["cutting_limits"])
    assert r["calculations"]["feed_mm_min"] == 840.0 and r["calculations"][
        "surface_speed_m_min"
    ] == pytest.approx(219.911, abs=0.01)
    o = oee(
        OEEInput(
            planned_minutes=480.0,
            downtime_minutes=60.0,
            total_count=300,
            good_count=285,
            ideal_cycle_seconds=60.0,
        )
    )
    assert o["oee"] == pytest.approx(0.59375)


def test_gcode_gates_no_shortcut_and_profile_hash_binding(system):
    settings, db, auth, _, _ = system
    service = ArtifactService(db)
    candidate = service.create(
        CodeCandidate(
            machine="CNC-01",
            program="G21 G90\nT7 M6\nS7000 M3\nG0 X0 Y0 Z50\nG1 X10 F800\nM30",
        ),
        auth.user("operator"),
    )
    assert candidate["review"]["syntax_and_envelope_passed"]
    with pytest.raises(ValueError):
        service.export(candidate["id"], auth.user("supervisor"))
    data = Attestation(
        gate="approval",
        artifact_sha256=candidate["sha256"],
        report_sha256="a" * 64,
        result="passed",
        comment="No previous gates; must reject.",
    )
    with pytest.raises(ValueError):
        service.attest(candidate["id"], data, auth.user("supervisor"))
    auth.create_user("engineer2", "DistinctLongPassword2026", "supervisor")
    for gate in ["simulation", "collision", "engineering", "approval"]:
        actor = (
            auth.user("engineer2") if gate == "approval" else auth.user("supervisor")
        )
        service.attest(
            candidate["id"],
            data.model_copy(
                update={
                    "gate": gate,
                    "comment": "Reviewed external site report and bound artifact hash.",
                }
            ),
            actor,
        )
    assert service.export(candidate["id"], auth.user("supervisor")).startswith(b"PK")
    profile = settings.read("engineering.json")["machines"]["CNC-01"]
    assert not validate_gcode("G21 G90\nG0 X999", profile)["syntax_and_envelope_passed"]
    assert not validate_gcode("G91\nG2 X10 I5", profile)["syntax_and_envelope_passed"]


def test_vision_is_optional_and_no_upload_becomes_policy(system):
    from cnc_ai.vision import VisionService

    settings, db, auth, _, _ = system
    with pytest.raises(ValueError, match="disabled"):
        VisionService(db, ModelRouter(settings)).analyze(
            b"not an image", "Inspect", auth.user("operator")
        )


def test_model_failover_and_rerank_contract(system, monkeypatch):
    from urllib import error

    settings, *_ = system
    router = ModelRouter(replace(settings, model_mode="local"))
    calls = []
    monkeypatch.setenv("CONVERSATION_BASE_URL", "http://127.0.0.1:18001/v1")
    monkeypatch.setenv("CONVERSATION_FALLBACK_URLS", "http://127.0.0.1:18002/v1")

    class Response:
        def __enter__(self):
            return self

        def __exit__(self, *a):
            pass

        def read(self, n):
            return b'{"data": []}'

    class Opener:
        def open(self, req, timeout):
            calls.append(req.full_url)
            if ":18001" in req.full_url:
                raise error.URLError("host unavailable")
            return Response()

    monkeypatch.setattr("cnc_ai.models.request.build_opener", lambda *a: Opener())
    assert router.call("conversation", "models") == {"data": []}
    assert router.replica_last["conversation"] == 1
    router.call("conversation", "models")
    assert len(calls) == 3
    monkeypatch.setattr(
        router,
        "call",
        lambda *a, **k: {
            "data": [{"index": 0, "score": 0.8}, {"index": 1, "score": 0.2}]
        },
    )
    assert router.rerank("spindle", ["bearing", "random"]) == [0.8, 0.2]
    monkeypatch.setattr(
        router, "call", lambda *a, **k: {"data": [{"index": 0, "score": float("nan")}]}
    )
    with pytest.raises(ModelUnavailable):
        router.rerank("spindle", ["bearing"])

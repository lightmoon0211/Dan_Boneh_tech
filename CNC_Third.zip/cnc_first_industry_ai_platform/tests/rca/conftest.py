from datetime import datetime, timezone
import pytest
from cnc_ai.rca.service import RCAService
from cnc_ai.rca.demo import create_demo
from cnc_ai.models import ModelRouter


@pytest.fixture
def rca(system):
    settings, db, auth, adapter, control = system
    create_demo(settings.data / "rca-demo.db")
    service = RCAService(
        db,
        ModelRouter(settings),
        clock=lambda: datetime(2026, 9, 9, 15, tzinfo=timezone.utc),
    )
    service.cfg["demo_enabled"] = True
    yield service, auth.user("operator"), system
    service.close()

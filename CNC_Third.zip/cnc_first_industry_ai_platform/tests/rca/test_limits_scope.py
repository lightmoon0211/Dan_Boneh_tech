import threading, time
from datetime import datetime, timezone
import pytest
from cnc_ai.rca.scope import resolve, infer_intent, Clarification
from cnc_ai.rca.history import HistoryAdapter, SourceUnavailable
from cnc_ai.rca.contracts import ScopeIntent
from test_workflow import CASES, run


def test_factory_timezone_and_yesterday_not_server_day(rca):
    svc, p, _ = rca
    cutoff = datetime(2026, 9, 9, 1, tzinfo=timezone.utc)
    cfg = {**svc.cfg, "timezone": "America/Chicago"}
    scope = resolve(
        "Why CNC-03 yesterday?",
        ScopeIntent(entity="CNC-03"),
        [{"entity": "CNC-03", "entity_kind": "resource", "name": "CNC resource"}],
        cfg,
        cutoff,
    )
    assert scope["date"] == "2026-09-07"
    assert scope["baseline_date"] == "2026-09-04"
    assert scope["start"] == "2026-09-07T12:00:00+00:00"


def test_dst_and_material_ambiguity(rca):
    svc, _, _ = rca
    cfg = {
        **svc.cfg,
        "timezone": "America/Chicago",
        "shifts": [{"id": "night", "start": "01:30", "end": "09:30", "weekdays": [6]}],
    }
    with pytest.raises(Clarification, match="DST"):
        resolve(
            "",
            ScopeIntent(entity="CNC-03", date="2026-11-01"),
            [{"entity": "CNC-03", "entity_kind": "resource", "name": "CNC"}],
            cfg,
            datetime(2026, 11, 3, tzinfo=timezone.utc),
        )
    with pytest.raises(Clarification):
        infer_intent("Why did CNC-03 and CNC-04 stop yesterday?")


def test_product_and_resource_are_distinct(rca):
    svc, _, _ = rca
    assets = [
        {"entity": "MX-500", "entity_kind": kind, "name": kind}
        for kind in ["resource", "finished_machine"]
    ]
    with pytest.raises(Clarification):
        resolve(
            "",
            ScopeIntent(entity="MX-500", date="2026-09-08"),
            assets,
            svc.cfg,
            svc.clock(),
        )
    scope = resolve(
        "",
        ScopeIntent(entity="MX-500", entity_kind="finished_machine", date="2026-09-08"),
        assets,
        svc.cfg,
        svc.clock(),
    )
    assert scope["entity_kind"] == "finished_machine"


def test_tool_budget_preserves_partial_records_and_skips_unrun_check(rca):
    svc, p, _ = rca
    svc.cfg["limits"]["tool_calls"] = 2
    inv, result = run(svc, p, CASES[0])
    assert result["status"] == "incomplete"
    assert len(inv["evidence"]) == 1
    assert inv["steps"][-1]["status"] == "skipped"
    assert inv["steps"][-1]["started_at"] is None


def test_cancellation_reports_actual_executor_state(rca, monkeypatch):
    svc, p, _ = rca
    entered = threading.Event()
    release = threading.Event()
    original = HistoryAdapter.read

    def block(self, *a, **k):
        entered.set()
        assert release.wait(4)
        return original(self, *a, **k)

    monkeypatch.setattr(HistoryAdapter, "read", block)
    inv = svc.start(
        {
            "question": CASES[0]["question"],
            "intent": CASES[0]["intent"],
            "evidence_source": "demo",
        },
        p,
    )
    assert entered.wait(4)
    svc.cancel(inv["id"], p)
    release.set()
    for _ in range(100):
        data = svc.get(inv["id"], p)
        if data["status"] == "cancelled":
            break
        time.sleep(0.02)
    assert data["status"] == "cancelled"
    assert not data["evidence"]
    assert data["steps"][-1]["status"] == "cancelled"
    assert not any(
        e["status"] == "completed" and e["step_id"] == data["steps"][-1]["id"]
        for e in data["events"]
    )


def test_unavailable_source_is_not_reported_successful(rca, monkeypatch):
    svc, p, _ = rca
    original = HistoryAdapter.read

    def unavailable(self, family, *a, **kw):
        if family == "maintenance":
            raise SourceUnavailable(
                "Maintenance system unavailable in this read-only snapshot."
            )
        return original(self, family, *a, **kw)

    monkeypatch.setattr(HistoryAdapter, "read", unavailable)
    inv, result = run(svc, p, CASES[0])
    assert result["status"] == "incomplete"
    step = next(s for s in inv["steps"] if s["tool"] == "history.maintenance")
    assert step["status"] == "failed"
    assert not step["result"].get("evidence_ids")
    assert (
        next(h for h in result["hypotheses"] if h["id"] == "cooling")["status"]
        == "Supported"
    )


def test_transient_retry_is_visible_and_bounded(rca, monkeypatch):
    svc, p, _ = rca
    original = HistoryAdapter.read
    attempts = []

    def transient(self, *a, **kw):
        attempts.append(1)
        if len(attempts) == 1:
            raise TimeoutError("read timed out")
        return original(self, *a, **kw)

    monkeypatch.setattr(HistoryAdapter, "read", transient)
    inv, result = run(svc, p, CASES[0])
    assert result["status"] == "completed"
    retries = [e for e in inv["events"] if e["payload"].get("attempt")]
    assert len(retries) == 1
    assert retries[0]["status"] == "running"
    assert result["tool_calls"] <= svc.cfg["limits"]["tool_calls"]


def test_elapsed_limit_stops_after_inflight_result_without_fabrication(
    rca, monkeypatch
):
    svc, p, _ = rca
    original = HistoryAdapter.read

    def slow(self, *a, **kw):
        time.sleep(0.025)
        return original(self, *a, **kw)

    svc.cfg["limits"]["elapsed_seconds"] = 0.01
    monkeypatch.setattr(HistoryAdapter, "read", slow)
    inv, result = run(svc, p, CASES[0])
    assert result["status"] == "incomplete"
    assert not inv["evidence"]
    assert all(
        s["status"] != "completed"
        for s in inv["steps"]
        if s["tool"] == "history.production"
    )

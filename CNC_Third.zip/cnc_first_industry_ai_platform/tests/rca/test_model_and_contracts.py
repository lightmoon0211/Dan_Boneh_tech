"""Model test doubles validate authority boundaries, not live diagnosis accuracy."""

import json
import sqlite3
from dataclasses import replace
import pytest
from cnc_ai.rca.history import HistoryAdapter, SourceUnavailable
from test_workflow import CASES, run


def factory_copy(svc, settings):
    # Explicitly mark this test fixture operational ONLY inside isolated tests.
    path = settings.data / "test-qualified-history.db"
    with (
        sqlite3.connect(settings.data / "rca-demo.db") as src,
        sqlite3.connect(path) as dst,
    ):
        src.backup(dst)
        dst.execute("UPDATE rca_history_meta SET value='false' WHERE key='demo'")
        dst.execute(
            "UPDATE rca_history_meta SET value=? WHERE key='factory_id'",
            (json.dumps(svc.cfg["factory_id"]),),
        )
    svc.cfg.update(history_path=str(path), timezone="America/Chicago")
    svc.db.settings = replace(settings, model_mode="local")
    return path


@pytest.mark.parametrize(
    "response,success",
    [
        ({"hypotheses": ["material", "cooling"]}, True),
        ({"hypotheses": ["calibration"]}, False),
        ({"hypotheses": ["cooling"], "tool_completed": True}, False),
    ],
)
def test_local_selector_is_bounded_and_cannot_attest_execution(
    rca, monkeypatch, response, success
):
    svc, p, (settings, db, *_) = rca
    factory_copy(svc, settings)
    seen = []
    monkeypatch.setattr(
        svc.router,
        "spec",
        lambda role: {"model": "local-test-double", "revision": "test-revision"},
    )

    def call(role, endpoint, payload, **kw):
        seen.append((role, endpoint, payload, kw))
        assert role == "planner" and endpoint == "chat/completions"
        assert payload["max_tokens"] <= 600 and kw["timeout"] <= 12
        assert "detail" not in payload["messages"][1]["content"]
        return {
            "choices": [
                {"finish_reason": "stop", "message": {"content": json.dumps(response)}}
            ]
        }

    monkeypatch.setattr(svc.router, "call", call)
    row = svc.start(
        {"question": CASES[0]["question"], "intent": CASES[0]["intent"]},
        p,
        background=False,
    )
    svc.execute(row["id"])
    inv = svc.get(row["id"], p)
    step = next(s for s in inv["steps"] if s["tool"] == "model.planner")
    assert step["status"] == ("completed" if success else "failed")
    assert len(seen) == 1 and inv["result"]["model_calls"] == 1
    assert {h["id"] for h in inv["result"]["hypotheses"]} >= {"cooling", "material"}
    assert all(
        h["status"] != "Confirmed" for h in inv["result"]["hypotheses"]
    )  # no factory-approved criterion
    assert inv["versions"]["models"]["planner"]["revision"] == "test-revision"
    with db.connect() as c:
        assert c.execute("SELECT count(*) FROM control_executions").fetchone()[0] == 0


def test_index_snapshot_scope_mismatch_is_rejected(rca):
    svc, p, (settings, *_) = rca
    with sqlite3.connect(settings.data / "rca-demo.db") as c:
        r = json.loads(
            c.execute(
                "SELECT snapshot_json FROM rca_history_records WHERE record_id='filter-03'"
            ).fetchone()[0]
        )
        r["entity"] = "CNC-02"
        c.execute(
            "UPDATE rca_history_records SET snapshot_json=? WHERE record_id='filter-03'",
            (json.dumps(r),),
        )
    adapter = HistoryAdapter(settings.data / "rca-demo.db", svc.cfg, True)
    with pytest.raises(SourceUnavailable):
        adapter.record("filter-03", "CNC-03", "resource", svc.clock())
    inv, result = run(svc, p, CASES[0])
    assert result["status"] == "incomplete"
    assert not any(e["record_id"] == "filter-03" for e in inv["evidence"])


def test_invalid_record_does_not_leak_extra_fields_into_timeline(rca):
    svc, p, (settings, *_) = rca
    with sqlite3.connect(settings.data / "rca-demo.db") as c:
        r = json.loads(
            c.execute(
                "SELECT snapshot_json FROM rca_history_records WHERE record_id='filter-03'"
            ).fetchone()[0]
        )
        r["private_unrestricted"] = "SENSITIVE-SOURCE-FIELD"
        c.execute(
            "UPDATE rca_history_records SET snapshot_json=? WHERE record_id='filter-03'",
            (json.dumps(r),),
        )
    inv, result = run(svc, p, CASES[0])
    assert result["status"] == "incomplete"
    assert "SENSITIVE-SOURCE-FIELD" not in json.dumps(inv)


def test_below_plan_is_distinct_and_has_no_previous_actual_loss_attribution(rca):
    svc, p, _ = rca
    case = {**CASES[0], "intent": {**CASES[0]["intent"], "baseline": "plan"}}
    inv, result = run(svc, p, case)
    assert inv["scope"]["comparison_label"] == "recorded plan"
    assert not any(s["title"] == "Comparison Production" for s in inv["steps"])
    loss = next(c for c in result["calculations"] if c["id"] == "production_loss")
    assert "unavailable" in loss and "estimated_downtime_loss" not in loss


def test_direct_topics_show_actual_basis_and_unsupported_comparison_clarifies(rca):
    svc, p, _ = rca
    case = next(c for c in CASES if c["name"] == "MX-700")
    inv, _ = run(svc, p, case)
    assert inv["scope"]["comparison_label"] == "recorded acceptance limits"
    inv, result = run(
        svc, p, {**case, "intent": {**case["intent"], "baseline": "previous_week"}}
    )
    assert result["status"] == "needs_clarification" and not inv["evidence"]


def test_native_data_stops_at_unqualified_semantics(rca):
    svc, p, _ = rca
    row = svc.start(
        {"question": "Why did CNC-03 production decrease on 2026-09-08?"},
        p,
        background=False,
    )
    result = svc.execute(row["id"])
    assert result["status"] == "incomplete" and not result["problem_verified"]
    assert not any(h["status"] == "Confirmed" for h in result["hypotheses"])

import json, sqlite3, time
from datetime import datetime, timezone
import pytest
from cnc_ai.web.app import create_app
from cnc_ai.rag import RAG
from test_workflow import CASES, run


def login(client, name):
    result = client.post(
        "/api/login", json={"username": name, "password": "Test-account-pass-123"}
    )
    assert result.status_code == 200
    return {"X-CSRF-Token": result.json["csrf"]}


def test_authorization_covers_timeline_evidence_export_and_review(rca):
    svc, p, (settings, db, auth, adapter, control) = rca
    inv, result = run(svc, p, CASES[0])
    ev = inv["evidence"][0]["id"]
    for action in [
        lambda: svc.get(inv["id"], auth.user("viewer")),
        lambda: svc.evidence(inv["id"], ev, auth.user("viewer")),
        lambda: svc.export(inv["id"], auth.user("viewer")),
        lambda: svc.review(
            inv["id"],
            {"status": "acknowledged", "comment": "Reviewed the evidence."},
            p,
        ),
    ]:
        with pytest.raises(PermissionError):
            action()
    review = svc.review(
        inv["id"],
        {
            "status": "acknowledged",
            "comment": "Reviewed the synthetic demonstration evidence.",
        },
        auth.user("supervisor"),
    )
    assert review["review_status"] == "acknowledged"
    assert review["result"]["hypotheses"] == result["hypotheses"]
    with db.connect(write=True) as c:
        c.execute(
            "DELETE FROM role_permissions WHERE role='operator' AND permission='data.read'"
        )
    with pytest.raises(PermissionError):
        svc.export(inv["id"], p)


def test_reassessment_versions_and_supplied_source_evidence(rca):
    svc, p, (settings, db, auth, *_) = rca
    case = next(c for c in CASES if c["name"] == "MX-500")
    inv, result = run(svc, p, case)
    original = json.dumps(result, sort_keys=True)
    svc.add_evidence(
        inv["id"],
        {
            "record_id": "bearing-mx500",
            "reason": "Please review the recorded purchase dependency.",
        },
        auth.user("supervisor"),
    )
    revised = svc.reassess(
        inv["id"],
        {"reason": "Recheck with the attached material source."},
        p,
        background=False,
    )
    svc.execute(revised["id"])
    assert revised["revision"] == 2 and revised["parent_id"] == inv["id"]
    assert json.dumps(svc.get(inv["id"], p)["result"], sort_keys=True) == original
    data = svc.get(revised["id"], p)
    assert len(data["revisions"]) == 2
    assert any(
        s["tool"] == "history.supplemental" and s["status"] == "completed"
        for s in data["steps"]
    )


def test_new_post_shift_maintenance_evidence_changes_only_new_revision(rca):
    svc, p, (settings, db, auth, *_) = rca
    inv, result = run(svc, p, next(c for c in CASES if c["name"] == "MX-500"))
    with sqlite3.connect(settings.data / "rca-demo.db") as c:
        template = json.loads(
            c.execute(
                "SELECT snapshot_json FROM rca_history_records WHERE record_id='bearing-mx500'"
            ).fetchone()[0]
        )
        for key, code, hour in [
            ("receive-later", "component_received", 21),
            ("resume-later", "assembly_resumed", 22),
        ]:
            obj = {
                **template,
                "record_id": key,
                "event_start": f"2026-09-08T{hour}:00:00+00:00",
                "event_end": f"2026-09-08T{hour}:00:00+00:00",
                "recorded_at": f"2026-09-08T{hour}:00:01+00:00",
                "payload": {
                    **template["payload"],
                    "code": code,
                    "related_record": "blocked-mx500",
                },
            }
            c.execute(
                "INSERT INTO rca_history_records VALUES(?,?,?,?,?,?,?,?)",
                (
                    key,
                    obj["entity"],
                    obj["entity_kind"],
                    obj["family"],
                    obj["event_start"],
                    obj["event_end"],
                    obj["recorded_at"],
                    json.dumps(obj),
                ),
            )
    for key in ["receive-later", "resume-later"]:
        svc.add_evidence(
            inv["id"],
            {
                "record_id": key,
                "reason": "New post-shift receipt and independent resumption evidence.",
            },
            p,
        )
    new = svc.reassess(
        inv["id"],
        {"reason": "Include the newly returned component and resumption records."},
        p,
        background=False,
    )
    updated = svc.execute(new["id"])
    assert result["hypotheses"][0]["status"] == "Supported"
    assert updated["hypotheses"][0]["status"] == "Confirmed"
    assert svc.get(inv["id"], p)["result"]["hypotheses"][0]["status"] == "Supported"


def test_factory_confirmation_requires_approved_rule_and_document(rca, tmp_path):
    svc, p, (settings, db, auth, *_) = rca
    with sqlite3.connect(settings.data / "rca-demo.db") as c:
        c.execute("UPDATE rca_history_meta SET value='false' WHERE key='demo'")
        c.execute(
            "UPDATE rca_history_meta SET value=? WHERE key='factory_id'",
            (json.dumps(svc.cfg["factory_id"]),),
        )
    svc.cfg["history_path"] = str(settings.data / "rca-demo.db")
    svc.cfg["timezone"] = "America/Chicago"
    req = {
        "question": CASES[0]["question"],
        "intent": CASES[0]["intent"],
        "evidence_source": "factory",
    }
    first = svc.start(req, p, background=False)
    result = svc.execute(first["id"])
    assert result["hypotheses"][0]["status"] == "Supported"
    doc = tmp_path / "verification.md"
    doc.write_text(
        "Approved cooling-flow verification criterion for this synthetic factory-mode test; independent restoration and return-to-service records required."
    )
    rag = RAG(db, svc.router)
    ingested = rag.ingest(doc, auth.user("admin"), kind="sop", revision="1")
    docid = ingested["id"]
    with pytest.raises(ValueError):
        svc.approve_rule(
            "cooling_flow",
            docid,
            "2026-09-10T00:00:00+00:00",
            "Site engineering approved the criterion.",
            auth.user("admin"),
        )
    rag.approve(
        docid,
        auth.user("supervisor"),
        "Approved synthetic verification document for software test.",
    )
    svc.approve_rule(
        "cooling_flow",
        docid,
        "2026-09-10T00:00:00+00:00",
        "Site engineering approved the synthetic verification criterion.",
        auth.user("admin"),
    )
    second = svc.start(req, p, background=False)
    result = svc.execute(second["id"])
    assert result["hypotheses"][0]["status"] == "Confirmed"
    with db.connect(write=True) as c:
        c.execute(
            "UPDATE document_revisions SET state='superseded' WHERE document_id=?",
            (docid,),
        )
    third = svc.start(req, p, background=False)
    result = svc.execute(third["id"])
    assert result["hypotheses"][0]["status"] == "Supported"


def test_natural_chat_routing_csrf_and_saved_followup(rca, monkeypatch):
    svc, p, (settings, db, auth, adapter, _) = rca
    monkeypatch.setenv("CNC_RCA_DEMO", "true")
    app = create_app(settings, adapter=adapter)
    service = app.extensions["cnc"]["rca"]
    service.clock = svc.clock
    operator = app.test_client()
    hdr = login(operator, "operator")
    try:
        blocked = operator.post(
            "/api/rca/investigations", json={"question": "Why CNC-03 yesterday?"}
        )
        assert blocked.status_code == 403
        response = operator.post(
            "/api/chat",
            headers=hdr,
            json={
                "question": "Why did CNC-03 production decrease yesterday?",
                "rca_source": "demo",
            },
        )
        assert response.status_code == 200, response.json
        assert response.json["mode"] == "rca"
        key = response.json["rca_id"]
        for _ in range(100):
            view = operator.get("/api/rca/investigations/" + key)
            if view.json["status"] in {
                "completed",
                "incomplete",
                "problem_not_verified",
            }:
                break
            time.sleep(0.02)
        assert view.json["result"]["problem_verified"]
        followup = operator.post(
            "/api/chat",
            headers=hdr,
            json={
                "question": "Show the evidence.",
                "conversation_id": response.json["conversation_id"],
                "rca_source": "demo",
            },
        )
        assert followup.json["rca_id"] == key
        events = operator.get("/api/rca/investigations/" + key + "/events")
        assert events.json["events"] == view.json["events"]
        viewer = app.test_client()
        login(viewer, "viewer")
        for suffix in [
            "",
            "/events",
            "/export",
            "/evidence/" + view.json["evidence"][0]["id"],
        ]:
            assert (
                viewer.get("/api/rca/investigations/" + key + suffix).status_code == 403
            )
        assert (
            operator.get("/api/rca/investigations/" + key + "/export").status_code
            == 200
        )
    finally:
        service.close()


def test_recovery_never_marks_running_tool_successful(rca):
    svc, p, (_, db, auth, *_) = rca
    row = svc.start(
        {
            "question": CASES[0]["question"],
            "intent": CASES[0]["intent"],
            "evidence_source": "demo",
        },
        p,
        background=False,
    )
    step = svc._step(
        row["id"], "Interrupted check", "Read historic data", "history.production", {}
    )
    svc._transition(row["id"], step, "running")
    svc.clock = lambda: datetime(2026, 9, 10, tzinfo=timezone.utc)
    result = svc.recover(auth.user("admin"))
    assert row["id"] in result["recovered"]
    data = svc.get(row["id"], p)
    assert data["status"] == "incomplete"
    assert data["steps"][0]["status"] == "cancelled"
    assert not any(e["status"] == "completed" for e in data["events"])


def test_foreign_record_and_cross_investigation_evidence_denied(rca):
    svc, p, _ = rca
    a, _ = run(svc, p, CASES[0])
    b, _ = run(svc, p, CASES[1])
    with pytest.raises(PermissionError):
        svc.evidence(a["id"], b["evidence"][0]["id"], p)
    with pytest.raises(Exception):
        svc.add_evidence(
            a["id"],
            {
                "record_id": "bearing-mx500",
                "reason": "Attempt to attach a different finished machine.",
            },
            p,
        )


def test_recovery_retains_completed_calculation(rca):
    svc, p, (_, db, auth, *_) = rca
    row = svc.start(
        {
            "question": CASES[0]["question"],
            "intent": CASES[0]["intent"],
            "evidence_source": "demo",
        },
        p,
        background=False,
    )
    calc = {
        "id": "finished-comparison",
        "problem_verified": True,
        "formula": "validated fixture comparison",
        "evidence_ids": [],
    }
    with db.connect(write=True) as c:
        c.execute(
            "UPDATE rca_investigations SET created_at='2026-09-08T00:00:00+00:00' WHERE id=?",
            (row["id"],),
        )
        c.execute(
            "INSERT INTO rca_calculations VALUES(?,?,?)",
            (row["id"] + ":comparison", row["id"], json.dumps(calc)),
        )
    svc.recover(auth.user("admin"))
    inv = svc.get(row["id"], p)
    assert inv["status"] == "incomplete" and inv["result"]["problem_verified"]
    assert inv["result"]["calculations"] == [calc]

from datetime import datetime, timedelta, timezone
from dataclasses import replace
import threading
import pytest
from werkzeug.serving import make_server
from cnc_ai.assistant import Assistant
from cnc_ai.contracts import Plan, AnalysisTask, ChatRequest, Answer
from cnc_ai.timeseries.contracts import Observation, AnalysisQuery
from cnc_ai.timeseries.historian import SQLiteHistorian, query_input
from cnc_ai.timeseries.facade import AnalysisService
from cnc_ai.timeseries.service import create_service
from cnc_ai.rag import RAG
from cnc_ai.models import ModelRouter
from cnc_ai.sql import QueryService


def history(db):
    start = datetime(2026, 9, 1, 8, tzinfo=timezone.utc)
    rows = [
        Observation(
            machine_id="CNC-01",
            signal="vibration",
            event_time=start + timedelta(minutes=i),
            ingestion_time=start + timedelta(minutes=i),
            value=float(i) / 100,
            unit="mm/s",
            source="integration",
            tool_id="T07",
            program_id="O1001",
            material_lot="LOT-001",
            run_id="1001",
        )
        for i in range(120)
    ]
    SQLiteHistorian(db).append(rows)
    return AnalysisQuery(
        machine_id="CNC-01",
        signals=["vibration"],
        start=start + timedelta(minutes=60),
        end=start + timedelta(minutes=120),
        reference_start=start,
    ), rows


def test_historian_context_and_regime_boundaries(system):
    _, db, _, _, _ = system
    q, rows = history(db)
    body = query_input(SQLiteHistorian(db), q)
    assert body.context.program_id == "O1001" and body.context.tool_id == "T07"
    assert body.context.run_id == "1001" and body.context.machine_family is None
    with db.connect(write=True) as c:
        c.execute(
            "UPDATE historian_observations SET program_id='O9000' WHERE event_time=?",
            (rows[-1].event_time.isoformat(timespec="microseconds"),),
        )
    with pytest.raises(ValueError, match="boundary"):
        query_input(SQLiteHistorian(db), q)


def test_numerical_http_wire_hash_and_key(system, monkeypatch):
    settings, db, auth, _, _ = system
    q, _ = history(db)
    key = "test-numerical-service-key-123456789"
    server = make_server("127.0.0.1", 0, create_service(settings, key=key))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    monkeypatch.setenv("CNC_TIMESERIES_URL", f"http://127.0.0.1:{server.server_port}")
    monkeypatch.setenv("CNC_TIMESERIES_API_KEY", key)
    monkeypatch.setenv("CNC_TIMESERIES_TRANSPORT", "http")
    try:
        result = AnalysisService(db).run("trend", q, auth.user("operator"))
        assert result["analysis"]["signals"][0]["trend"]["direction"] == "increasing"
        with db.connect() as c:
            row = c.execute("SELECT input_sha256 FROM analysis_records").fetchone()
        assert row[0] == result["analysis"]["provenance"]["input_sha256"]
    finally:
        server.shutdown()
        thread.join(timeout=5)
        server.server_close()


@pytest.mark.parametrize("fail", [False, True])
def test_assistant_numerical_citation_and_failure_state(system, fail):
    settings, db, auth, _, control = system
    q, _ = history(db)

    class Router:
        settings = replace(db.settings, model_mode="local")

        def judge(self, *args):
            return {"safe": True}

        def generate(self, role, messages, schema, **kwargs):
            if role == "planner":
                return Plan(
                    mode="analysis", analysis=AnalysisTask(kind="trend", query=q)
                )
            return Answer(
                answer="Historical vibration is increasing. This trend does not establish a cause.",
                citations=["source_1"],
            )

    rag = RAG(db, ModelRouter(settings))
    rag.search = lambda *a, **k: []
    assistant = Assistant(db, Router(), rag, QueryService(db), control)
    if fail:

        def bad(*a, **k):
            raise OSError("fixture historian disconnected")

        assistant.analysis.run = bad
        with pytest.raises(OSError):
            assistant.ask(
                ChatRequest(question="Analyze the specified vibration window."),
                auth.user("operator"),
            )
    else:
        reply = assistant.ask(
            ChatRequest(question="Analyze the specified vibration window."),
            auth.user("operator"),
        )
        assert (
            reply["mode"] == "analysis"
            and len(reply["analyses"]) == 1
            and len(reply["citations"]) == 1
        )
        assert reply["tool_trace"][-1]["state"] == "RESPOND"
    with db.connect() as c:
        assert c.execute("SELECT status FROM agent_runs").fetchone()[0] == (
            "failed" if fail else "completed"
        )
        assert c.execute("SELECT count(*) FROM control_executions").fetchone()[0] == 0


def test_scheduler_limits_simultaneous_power_across_different_machines():
    from cnc_ai.planning.scheduler import ScheduleInput, schedule

    plan = schedule(
        ScheduleInput(
            resources=[{"name": "CNC-01"}, {"name": "CNC-02"}],
            jobs=[
                {
                    "name": "A",
                    "resources": ["CNC-01"],
                    "duration_minutes": 30,
                    "due_minute": 40,
                    "power_kw": 8.0,
                },
                {
                    "name": "B",
                    "resources": ["CNC-02"],
                    "duration_minutes": 30,
                    "due_minute": 50,
                    "power_kw": 7.0,
                },
                {
                    "name": "C",
                    "resources": ["CNC-02"],
                    "duration_minutes": 30,
                    "due_minute": 80,
                    "power_kw": 13.0,
                },
            ],
            maximum_total_power_kw=12.0,
            source="Reviewed fictional planning demand",
        )
    )
    assert [(j["start_minute"], j["end_minute"]) for j in plan["schedule"]] == [
        (0, 30),
        (30, 60),
    ]
    assert plan["unscheduled"][0]["reason"] == "job power exceeds configured site limit"
    assert plan["estimated_energy_kwh"] == 7.5

# Theorem strengthening supplement

This package accompanies **Strengthened_Minimax_Manuscript.docx**. It contains the manuscript source, a contribution audit, and reproducible exact-arithmetic calculations. No empirical dataset or official implementation of another author's paper is claimed.

## Reproduce the results

Install Python 3.10 or later, extract the ZIP, open a terminal in this folder, and run:

```sh
python verify_results.py
```

On systems where the executable is named python3, use `python3 verify_results.py`. No third-party packages are required. The run prints PASS after all assertions succeed and writes the JSON and four CSV tables beside the script. The included verification_run.log records a successful run in the preparation environment. Running with `> verification_run.log` records a fresh log.

All calculations that determine a result or check an inequality use integers or fractions.Fraction. Decimal values in JSON are display conveniences. CSV values retain exact rational strings. The algorithms expect exact integer or Fraction inputs; passing floating-point inputs would no longer provide exact-arithmetic guarantees.

## Files

| File | Purpose |
| --- | --- |
| tree_recovery.py | Initial and continuation MST estimators, heterogeneous intervals, feasible repair, tree cost generators, finite Bayesian decision model |
| verify_results.py | Complete verification driver |
| verification_results.json | Exact results and check counts |
| original_decisions.csv | All eight original synthetic decision rows |
| continuation_sharpness.csv | Indistinguishable-tree continuation examples |
| history_instability.csv | One-query error from subtracting total estimates |
| policy_sharpness.csv | 18 exact policy-regret examples approaching factor two |
| verification_run.log | Successful execution log |
| strengthened_manuscript.md | Editable manuscript source; mathematical expressions use backticks and fenced math blocks |
| CONTRIBUTION_AUDIT.md | Changes, prior-art distinctions, proof audit notes, and remaining submission work |
| reference_number_map.json | Mapping from the earlier 21-reference manuscript to the expanded 26-reference list |
| artifact_validation.json | Document structure, retained display equations, and citation checks |
| SHA256SUMS.txt | Checksums of the package files at delivery |

## What the driver checks

For 100 six-source rooted trees it verifies 6,400 initial reconstructions, 19,200 single-source marginals, 6,400 initial error bounds, and 6,400 repair error bounds. It checks every disjoint nonempty anchor/new-source assignment, giving 60,200 cases each for the continuation identity, uniform bound, heterogeneous interval, and lifted-forest identity.

The driver reproduces the original eight policy rows through exact dynamic programming and full-outcome replay. It checks initial lower-bound examples for two through eight sources, nine continuation lower-bound examples with varying anchor counts, and 21 further unequal-tolerance cases. It also verifies five history-size stress tests and 18 initial/continuation policy-sharpness cases.

The tree checks use a specified linear congruential generator with seed 20260911. In calibration checks, one integer unit represents 1/20 of a cost unit. This scaling keeps every comparison exact. The implementation is a fresh Python reproduction of the original numerical table, so the generated calibration trees need not be identical to those from an earlier implementation.

## API notes

Source labels are nonnegative integers starting at zero. Singleton values are a list; pair values are a dictionary with sorted `(i, j)` tuple keys. The continuation estimator takes disjoint anchor and new-source sets and uses auxiliary root label -1 internally.

The anchor set stays fixed within a continuation planning problem. Use differences of the same H_A set function for successive new sets. Separately recomputing one-step estimates with enlarged anchor sets is a different procedure and is not covered by the stated policy theorem.

The included decision solver handles finite latent states, binary observations, and a binary terminal target with zero-one loss. The manuscript theorems permit more general finite observation and decision alphabets. The code is a research verification implementation, not a scalable industrial planner or a complete uncertainty-aware control system.

The heterogeneous interval is certified but is not asserted to equal the exact feasible-tree range. The sharp policy factor concerns policies optimized for measured costs, not minimax optimality over every possible decision procedure. Finite checks support the implementation; the universal statements depend on the manuscript proofs and require independent review.

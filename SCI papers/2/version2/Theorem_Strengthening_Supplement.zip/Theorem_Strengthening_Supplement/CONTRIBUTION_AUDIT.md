# Contribution audit

Manuscript: Minimax recovery and decision stability for tree-based evidence acquisition  
Revision assessed: 13 September 2026

The strongest submission claim is sharp recovery of **remaining acquisition cost after earlier routes have been activated**, together with a concrete failure of subtracting total-cost estimates and sharp decision consequences. This revision supplies proposed proofs and reproducible calculations. It does not establish publication priority or predict acceptance.

## What changed

| Result | Earlier manuscript | Strengthened manuscript | Evidence |
| --- | --- | --- | --- |
| Total-cost recovery | Sharp radius (2m−3)ε | Retained as Theorem 3.1 | Original proof retained; lower-bound examples reproduced |
| Continuation recovery | Could subtract two total estimates | Theorem 3.3: sharp radius k(ε₁+ε₂), independent of the number of anchors | Forest identity, coefficient bound, indistinguishable-tree lower bound |
| Need for the new estimator | No separating example | Proposition 3.4: one-query subtraction error 4(h−1)ε | Explicit admissible table and exact spanning-tree calculations |
| Unequal measurement quality | Separate singleton/pair tolerances for totals | Proposition 3.5: heterogeneous continuation intervals | Two minimum spanning trees; certified containment |
| Policy regret | Factor two only an upper bound | Theorems 4.3 and 4.4: factor two sharp as a supremum | Two-branch parity constructions with a strict measured preference |
| Continuation planning | No history-independent guarantee | Remaining-budget value and policy bounds; stopping certificate | Fixed-anchor terminal-cost perturbation argument |
| Numerical support | Synthetic six-source table | Original table reproduced; new stress tests and exact code supplied | Verification driver, JSON, four CSV files, run log |

## Recommended contribution statement

Within the established rooted-tree cost model, the paper derives the exact deterministic minimax radius k(ε₁+ε₂) for the additional cost of k new acquisitions after any nonempty earlier set. An anchor-rooted forest estimator attains the radius in O(|A|k+k²) arithmetic operations. A matching lower bound and a history-size instability example explain why direct continuation recovery improves on subtracting independently estimated totals. The resulting value and policy-loss bounds depend on the remaining call budget, and two-branch examples establish the sharp factor two for policies optimized using measured costs.

Avoid claiming that rooted-tree cost sharing, marginal phylogenetic diversity, spanning trees, or belief-state dynamic programming are themselves new. Avoid describing the policy bound as minimax optimality among all uncertainty-aware decision rules.

## Closest literature and limits of the comparison

| Source | Established overlap | Distinction to explain | Access checked in this revision |
| --- | --- | --- | --- |
| [Faith 1992](https://doi.org/10.1016/0006-3207(92)91201-3) | Foundational phylogenetic-diversity objective | Application terminology does not create a new tree functional | Bibliographic metadata verified; original full text not retrieved |
| [Steel, Mimoto and Mooers 2007](https://pmc.ncbi.nlm.nih.gov/articles/PMC2684137/) | Rooted subtree length and marginal PD(S∪{i})−PD(S) | Their analysis concerns expected contributions under extinction uncertainty; this paper studies bounded measurement errors | Open full text, including definition and marginal contribution |
| [Bryant and Tupper 2012](https://arxiv.org/abs/1006.1095) | General diversity theory including phylogenetic diversities | Structural foundations must be acknowledged; the proposed contribution concerns a specified recovery experiment | Author preprint available; relevant diversity/tree discussion checked |
| [Pachter and Speyer 2004](https://arxiv.org/abs/math/0311156) | Reconstruction from subtree weights | Functional error constants in acquisition coordinates require separate comparison | Author preprint available in the earlier reference package |
| [Farach, Kannan and Warnow 1995](https://link.springer.com/article/10.1007/BF01188585) | Additive/ultrametric fitting with interval or incomplete distance data | Distinguish exact functional recovery from finding a fitted tree; compare actual theorems before asserting priority | Publisher abstract read; subscription full text not obtained |
| [Márkus, Pintér and Radványi 2026](https://link.springer.com/article/10.1007/s10100-026-01039-5) | Rooted cost trees, irrigation games, and Shapley allocation | The tree cost class is established; this paper's target is calibration and sequential decision loss | Open publisher text checked; it also points to earlier fixed-tree game literature |
| [Hunter 1976](https://doi.org/10.2307/3212481) | Spanning-tree expressions for union bounds | Rooted paths make the expression exact; the expression itself needs appropriate attribution | Bibliographic/publisher information; full text remains an access gap |
| [Carlsson and Mémoli 2010](https://jmlr.org/papers/v11/carlsson10a.html) | Hierarchical clustering and stability | Overlap repair is a foundation, not the main proposed contribution | Open full text available in the earlier reference package |

The model reduces to additive tree distances by d₀ᵢ=cᵢ and dᵢⱼ=2cᵢⱼ−cᵢ−cⱼ. Errors induced in these distance coordinates share singleton terms. A different error coordinate system is a meaningful mathematical distinction, but it is not evidence by itself that no equivalent theorem exists. This was a focused source comparison, not an exhaustive or systematic novelty review.

## Proof audit notes

1. The forest identity follows from the exact marginal formula and an ordering with parents before children. The contracted graph is an algorithmic device; its weights are not assumed ultrametric.
2. Every admissible forest has k pair terms and total absolute singleton coefficient k. This is the source of the upper bound, including unequal family tolerances.
3. The lower-bound trees satisfy every observed coordinate, including anchor–anchor pairs. The anchor set is nonempty, so the trunk cancels from continuation cost.
4. The minimax experiment does not include an additional exact observation of sunk cost. Any such information must be analyzed separately.
5. The heterogeneous interval contains every admissible true continuation value. Its endpoints are not proved to be exact extrema over compatible trees.
6. The policy constructions use two copies of each independent latent bit. A proper information set leaves parity risk one half; a strict measured preference avoids relying on a tie-breaking convention.
7. Sharpness of the policy factor concerns surrogate-optimal policies, not all estimators or all robust/randomized decision procedures.
8. Continuation planning keeps A fixed and uses differences of H_A on newly queried sets. Recomputing the anchor set at every step defines a different policy procedure.

## Remaining submission work

The next essential checkpoint is an independent mathematical review of Theorems 3.3, 4.3, and 4.4 and their precise prior-art relationship. A reviewer should obtain the full Farach–Kannan–Warnow and Hunter papers and trace the closest fixed-tree and optimal-recovery references. The computational checks here were produced in the same assistance workflow and are not an independent external proof review.

The authors must also choose the target venue, complete author/funding/conflict declarations, and archive the final code with a permanent identifier. If the target venue expects an applied manufacturing contribution, the synthetic example alone does not establish it: a calibrated dataset and suitable acquisition baselines would be additional work. For a theory submission, the central issue is whether the sharp continuation result is both correct and sufficiently distinct from existing results. No acceptance probability is supported by the current evidence.

No manuscript claim has been elevated to “first” or “novelty confirmed.” The stronger theorem makes the contribution concrete and reviewable; editorial and peer-review judgments remain open.

"""Exact initial and continuation cost recovery for nonnegative rooted trees.

Uses only the Python standard library. Inputs may be ints or Fractions.
The continuation anchor set remains fixed throughout each planning problem.
"""
from functools import lru_cache
from fractions import Fraction
from itertools import combinations, product


def pair(i, j):
    return (i, j) if i < j else (j, i)


def mst(vertices, weight):
    """Dense Prim minimum spanning tree; permits negative edge weights."""
    vertices = tuple(vertices)
    if len(vertices) < 2:
        return 0, []
    start = vertices[0]
    unseen = set(vertices[1:])
    best = {v: (weight(start, v), start) for v in unseen}
    total, edges = 0, []
    while unseen:
        v = min(unseen, key=lambda x: (best[x][0], x))
        w, u = best[v]
        total += w
        edges.append((u, v))
        unseen.remove(v)
        for x in unseen:
            candidate = (weight(v, x), v)
            if candidate < best[x]:
                best[x] = candidate
    return total, edges


def initial_estimate(c, cp, sources):
    sources = tuple(sorted(sources))
    total, _ = mst(sources, lambda i, j: cp[pair(i, j)] - c[i] - c[j])
    return sum(c[i] for i in sources) + total


def continuation_estimate(c, cp, anchors, sources, return_forest=False):
    """Estimate F(A union S)-F(A), for fixed disjoint A and S.

    Anchor-anchor pair measurements are not used. The special root -1 is
    an algorithmic contraction vertex, not a new observed source.
    """
    anchors, sources = tuple(sorted(anchors)), tuple(sorted(sources))
    if set(anchors) & set(sources):
        raise ValueError('Anchor and new-source sets must be disjoint')
    if not anchors:
        if return_forest:
            raise ValueError('A rooted forest requires a nonempty anchor set')
        return initial_estimate(c, cp, sources)
    if not sources:
        return (0, []) if return_forest else 0
    attachments = {
        j: min((cp[pair(a, j)] - c[a] - c[j], a) for a in anchors)
        for j in sources
    }

    def weight(i, j):
        if i == -1:
            return attachments[j][0]
        if j == -1:
            return attachments[i][0]
        return cp[pair(i, j)] - c[i] - c[j]

    total, edges = mst((-1,) + sources, weight)
    lifted = [(attachments[j][1], j) if i == -1 else
              (i, attachments[i][1]) if j == -1 else (i, j)
              for i, j in edges]
    value = sum(c[j] for j in sources) + total
    return (value, lifted) if return_forest else value


def forest_expression(c, cp, sources, edges):
    return sum(c[j] for j in sources) + sum(
        cp[pair(i, j)] - c[i] - c[j] for i, j in edges)


def heterogeneous_interval(c, cp, e1, e2, anchors, sources):
    """Certified interval; not asserted to be the exact feasible-tree range."""
    if not anchors:
        raise ValueError('This interval routine implements the anchored case')
    lower_c = [x + e for x, e in zip(c, e1)]
    upper_c = [x - e for x, e in zip(c, e1)]
    lower_cp = {ij: x - e2[ij] for ij, x in cp.items()}
    upper_cp = {ij: x + e2[ij] for ij, x in cp.items()}
    return (continuation_estimate(lower_c, lower_cp, anchors, sources),
            continuation_estimate(upper_c, upper_cp, anchors, sources))


def repaired_cost(c, cp):
    c = [max(0, x) for x in c]
    n = len(c)
    o = [[0] * n for _ in range(n)]
    for i in range(n):
        o[i][i] = c[i]
        for j in range(i):
            o[i][j] = o[j][i] = min(c[i], c[j], max(0, c[i] + c[j] - cp[j, i]))
    for k in range(n):
        for i in range(n):
            for j in range(n):
                o[i][j] = max(o[i][j], min(o[i][k], o[k][j]))

    def cost(sources):
        total, _ = mst(tuple(sorted(sources)), lambda i, j: -o[i][j])
        return sum(c[i] for i in sources) + total
    return cost, c, o


def tables(cost, n):
    c = [cost(1 << i) for i in range(n)]
    cp = {(i, j): cost((1 << i) | (1 << j)) for i, j in combinations(range(n), 2)}
    return c, cp


def labels(mask, n):
    return tuple(i for i in range(n) if mask & (1 << i))


def routed_cost(parents, activation, service):
    """Source i occupies tree vertex i+1; parent IDs start at root 0."""
    n = len(parents)
    paths = []
    for i in range(n):
        u, path = i + 1, 0
        while u:
            path |= 1 << (u - 1)
            u = parents[u - 1]
        paths.append(path)

    @lru_cache(None)
    def cost(mask):
        activated, total = 0, 0
        for i in range(n):
            if mask & (1 << i):
                activated |= paths[i]
                total += service[i]
        return total + sum(activation[i] for i in range(n) if activated & (1 << i))
    return cost


def branch_cost(groups, trunks, pendants):
    """Root branches with shared trunk and one private edge per source."""
    def cost(mask):
        used = {groups[i] for i in range(len(groups)) if mask & (1 << i)}
        return sum(trunks[g] for g in used) + sum(
            pendants[i] for i in range(len(groups)) if mask & (1 << i))
    return cost


class DecisionModel:
    """Finite Bayesian binary-observation model, with exact arithmetic."""
    def __init__(self, prior, likelihood_one, targets, budget, anchors=()):
        self.prior = tuple(map(Fraction, prior))
        self.likelihood_one = tuple(tuple(map(Fraction, row)) for row in likelihood_one)
        self.targets = tuple(targets)
        self.n = len(likelihood_one)
        self.budget = budget
        self.anchors = frozenset(anchors)
        # Anchors are already acquired. Their outcomes are conditioned out of
        # the supplied current posterior, and are represented by -2.
        self.start = tuple(-2 if i in self.anchors else -1 for i in range(self.n))

    @lru_cache(None)
    def posterior(self, history):
        w = list(self.prior)
        for i, y in enumerate(history):
            if y >= 0:
                for x in range(len(w)):
                    p = self.likelihood_one[i][x]
                    w[x] *= p if y else 1 - p
        total = sum(w)
        return tuple(x / total for x in w) if total else None

    def predictive(self, history, i):
        p = self.posterior(history)
        return sum(px * py for px, py in zip(p, self.likelihood_one[i]))

    def decision_risk(self, history):
        p = self.posterior(history)
        one = sum(px for px, target in zip(p, self.targets) if target == 1)
        return (1, 1 - one) if one > Fraction(1, 2) else (0, one)

    def mask(self, history):
        return sum(1 << i for i, y in enumerate(history) if y >= 0 or y == -2)

    def solve(self, cost, penalty, myopic=False):
        penalty = Fraction(penalty)
        policy = {}

        @lru_cache(None)
        def dp(history):
            decision, error = self.decision_risk(history)
            mask = self.mask(history)
            count = sum(y >= 0 for y in history)
            stop = (error + penalty * cost(mask), error, cost(mask), Fraction(count))
            best, best_score, action = stop, stop[0], -1
            if count < self.budget:
                for i, y in enumerate(history):
                    if y != -1:
                        continue
                    q1 = self.predictive(history, i)
                    combined = [Fraction(0)] * 4
                    score = Fraction(0)
                    for obs, prob in [(0, 1 - q1), (1, q1)]:
                        if not prob:
                            continue
                        child = history[:i] + (obs,) + history[i+1:]
                        result = dp(child)
                        for j in range(4):
                            combined[j] += prob * result[j]
                        score += prob * (self.decision_risk(child)[1] + penalty * cost(self.mask(child)))
                    candidate_score = score if myopic else combined[0]
                    if candidate_score < best_score:
                        best, best_score, action = tuple(combined), candidate_score, i
            policy[history] = action
            return best

        result = dp(self.start)
        return result, policy, dp.cache_info().currsize

    def replay(self, policy, cost, penalty):
        """Independently sum latent states and full observation assignments."""
        available = [i for i in range(self.n) if i not in self.anchors]
        total = [Fraction(0)] * 4
        enumerated = 0
        for x, px in enumerate(self.prior):
            for observations in product((0, 1), repeat=len(available)):
                enumerated += 1
                probability = px
                full = dict(zip(available, observations))
                for i, y in full.items():
                    p = self.likelihood_one[i][x]
                    probability *= p if y else 1 - p
                if not probability:
                    continue
                history = self.start
                while policy[history] != -1:
                    i = policy[history]
                    history = history[:i] + (full[i],) + history[i+1:]
                error = Fraction(self.decision_risk(history)[0] != self.targets[x])
                spent = cost(self.mask(history))
                calls = Fraction(sum(y >= 0 for y in history))
                values = (error + Fraction(penalty) * spent, error, spent, calls)
                for j in range(4):
                    total[j] += probability * values[j]
        return tuple(total), enumerated

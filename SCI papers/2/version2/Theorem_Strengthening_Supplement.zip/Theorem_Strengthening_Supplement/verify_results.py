"""Reproduce all numerical results in the revised manuscript.

Run: python verify_results.py
Standard library only; results are written beside this script.
"""
from pathlib import Path
from fractions import Fraction as Q
from itertools import combinations, product
import json, csv, time
from tree_recovery import *

ROOT = Path(__file__).resolve().parent

class LCG:
    def __init__(self, seed): self.state = seed
    def integer(self, size):
        self.state = (1664525 * self.state + 1013904223) & 0xffffffff
        return self.state % size

def serial(x):
    if isinstance(x, Q): return {'fraction': str(x), 'decimal': float(x)}
    if isinstance(x, dict): return {str(k): serial(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)): return [serial(v) for v in x]
    return x

def calibration_checks():
    rng = LCG(20260911)
    counts = {'initial_reconstruction':0,'marginal_identity':0,'initial_error_bound':0,
              'repair_error_bound':0,'anchored_identity':0,'anchored_uniform_bound':0,
              'heterogeneous_interval':0,'forest_linear_identity':0}
    n=6
    for trial in range(100):
        parents = [rng.integer(i+1) for i in range(n)]
        activation = [2*(1+rng.integer(30)) for _ in range(n)]
        service = [2*(1+rng.integer(10)) for _ in range(n)]
        cost = routed_cost(parents, activation, service)
        c, cp = tables(cost,n)
        z = [x + rng.integer(3)-1 for x in c]
        zp = {ij:x+rng.integer(3)-1 for ij,x in cp.items()}
        repaired, rc, ro = repaired_cost(z,zp)
        for i,j,k in product(range(n), repeat=3):
            assert ro[i][j] >= min(ro[i][k],ro[k][j])
        for mask in range(1<<n):
            S=labels(mask,n);m=len(S)
            assert initial_estimate(c,cp,S)==cost(mask);counts['initial_reconstruction']+=1
            rho=0 if not m else 1 if m==1 else 2*m-3
            assert abs(initial_estimate(z,zp,S)-cost(mask))<=rho;counts['initial_error_bound']+=1
            assert abs(repaired(S)-cost(mask)) <= (4*m-3 if m else 0);counts['repair_error_bound']+=1
            for j in range(n):
                if j not in S:
                    overlap=max((c[i]+c[j]-cp[pair(i,j)] for i in S),default=0)
                    assert cost(mask|1<<j)-cost(mask)==c[j]-overlap;counts['marginal_identity']+=1
        e1=[rng.integer(3) for _ in range(n)]
        e2={ij:1+rng.integer(3) for ij in cp}
        hz=[x+rng.integer(2*e+1)-e for x,e in zip(c,e1)]
        hzp={ij:x+rng.integer(2*e2[ij]+1)-e2[ij] for ij,x in cp.items()}
        for assignment in product((0,1,2),repeat=n):
            A=tuple(i for i,v in enumerate(assignment) if v==1)
            S=tuple(i for i,v in enumerate(assignment) if v==2)
            if not A or not S: continue
            am=sum(1<<i for i in A);sm=sum(1<<i for i in S)
            truth=cost(am|sm)-cost(am)
            assert continuation_estimate(c,cp,A,S)==truth;counts['anchored_identity']+=1
            estimate,forest=continuation_estimate(z,zp,A,S,True)
            assert estimate==forest_expression(z,zp,S,forest);counts['forest_linear_identity']+=1
            assert abs(estimate-truth)<=2*len(S);counts['anchored_uniform_bound']+=1
            lo,hi=heterogeneous_interval(hz,hzp,e1,e2,A,S)
            assert lo<=truth<=hi;counts['heterogeneous_interval']+=1
    return counts

def original_decisions():
    cost = routed_cost([0,1,1,0,0,5],list(map(Q,['2','1.6','1.4','2.6','2','1.8'])),
                       list(map(Q,['1','1.1','.9','.8','.9','1.3'])))
    acc=list(map(Q,['.75','.80','.78','.65','.70','.88']))
    model=DecisionModel([Q(1,2),Q(1,2)],[(1-p,p) for p in acc],[0,1],4)
    results=[]
    for penalty in map(Q,['.005','.010','.020','.040']):
        for myopic in [False,True]:
            result,policy,states=model.solve(cost,penalty,myopic)
            replay,outcomes=model.replay(policy,cost,penalty)
            assert replay==result
            results.append({'penalty':penalty,'policy':'Myopic' if myopic else 'Optimal',
                'error':result[1],'cost':result[2],'calls':result[3],'objective':result[0],
                'first_source':policy[model.start]+1,'states':states,'replay_outcomes':outcomes})
    expected=[['.0792','7.83012','2.4716','.1183506'],['.12','5.1','1','.1455'],
              ['.0828','7.39230','2.477','.156723'],['.12','5.1','1','.171'],
              ['.12','5.1','1','.222'],['.12','5.1','1','.222'],
              ['.12','5.1','1','.324'],['.12','5.1','1','.324']]
    for r,e in zip(results,expected):
        assert [r[k] for k in ['error','cost','calls','objective']]==list(map(Q,e)),(r,e)
    return results

def continuation_sharpness():
    cases=[]
    for a_count in [1,5,20]:
        for k in [1,2,4]:
            e1,e2=Q(1,20),Q(1,20)
            n=a_count+k;A=tuple(range(a_count));S=tuple(range(a_count,n))
            center=branch_cost([0]*n,[Q(2)],[Q(1)]*n)
            plus=branch_cost([0]*n,[Q(2)-2*e1-e2],[Q(1)+e1+e2]*n)
            minus=branch_cost([0]*n,[Q(2)+2*e1+e2],[Q(1)-e1-e2]*n)
            c,cp=tables(center,n)
            for true in [plus,minus]:
                tc,tp=tables(true,n)
                assert all(abs(x-y)<=e1 for x,y in zip(c,tc))
                assert all(abs(cp[ij]-tp[ij])<=e2 for ij in cp)
            am=sum(1<<i for i in A);sm=sum(1<<i for i in S)
            estimate=continuation_estimate(c,cp,A,S)
            upper=plus(am|sm)-plus(am);lower=minus(am|sm)-minus(am)
            radius=k*(e1+e2)
            assert upper-estimate==estimate-lower==radius
            alpha=lambda m: 0 if m==0 else 1 if m==1 else 2*m-3
            naive=(alpha(a_count+k)+alpha(a_count))*e1
            cases.append({'anchors':a_count,'new_sources':k,'center':estimate,
                'lower':lower,'upper':upper,'sharp_radius':radius,'difference_bound':naive})
    # Unequal tolerances, including one exact measurement family.
    for e1,e2 in [(Q(0),Q(1,7)),(Q(1,5),Q(0)),(Q(1,9),Q(2,7))]:
        for k in range(1,8):
            n=k+3;A=tuple(range(3));S=tuple(range(3,n))
            center=branch_cost([0]*n,[Q(5)],[Q(2)]*n)
            plus=branch_cost([0]*n,[Q(5)-2*e1-e2],[Q(2)+e1+e2]*n)
            c,cp=tables(center,n);estimate=continuation_estimate(c,cp,A,S)
            assert plus((1<<n)-1)-plus(7)-estimate==k*(e1+e2)
    return cases

def initial_sharpness():
    cases=[]
    epsilon=Q(1,20)
    for m in range(2,9):
        center=branch_cost([0]*m,[Q(2)],[Q(1)]*m)
        c,cp=tables(center,m)
        estimate=initial_estimate(c,cp,range(m))
        radius=(2*m-3)*epsilon
        for sign in [-1,1]:
            true=branch_cost([0]*m,[Q(2)-sign*3*epsilon],[Q(1)+sign*2*epsilon]*m)
            tc,tp=tables(true,m)
            assert all(abs(x-y)<=epsilon for x,y in zip(c,tc))
            assert all(abs(cp[ij]-tp[ij])<=epsilon for ij in cp)
            assert true((1<<m)-1)-estimate==sign*radius
        cases.append({'sources':m,'estimate':estimate,'radius':radius})
    return cases

def policy_sharpness():
    cases=[]
    epsilon=Q(1,20);penalty=Q(1,100)
    for anchored in [False,True]:
        for k in [2,3,4]:
            radius=2*k*epsilon if anchored else (2*k-3)*epsilon
            for relative_gap in [Q(1,2),Q(1,10),Q(1,100)]:
                eta=radius*relative_gap
                groups=[0]*k+[1]*k
                anchors=()
                trunks=[Q(2),Q(2)+eta] if not anchored else [Q(2),Q(2)]
                b2=Q(1)+eta/k if anchored else Q(1)
                pendants=[Q(1)]*k+[b2]*k
                if anchored:
                    anchors=(2*k,2*k+1);groups += [0,1];pendants += [Q(1),b2]
                n=len(groups);am=sum(1<<i for i in anchors)
                center=branch_cost(groups,trunks,pendants)
                true=branch_cost(groups,[trunks[0]-3*epsilon,trunks[1]+3*epsilon],
                    [b+(2*epsilon if g==0 else -2*epsilon) for b,g in zip(pendants,groups)])
                c,cp=tables(center,n);tc,tp=tables(true,n)
                assert all(abs(x-y)<=epsilon for x,y in zip(c,tc))
                assert all(abs(cp[ij]-tp[ij])<=epsilon for ij in cp)
                if anchored:
                    measured_cost=lambda mask:continuation_estimate(c,cp,anchors,labels(mask & ~am,n))
                    true_cost=lambda mask:true(mask|am)-true(am)
                else:
                    measured_cost=lambda mask:initial_estimate(c,cp,labels(mask,n))
                    true_cost=true
                likelihood=[]
                for i in range(n):
                    likelihood.append([Q((x>>(i%k))&1) if i<2*k else Q(0) for x in range(1<<k)])
                targets=[x.bit_count()%2 for x in range(1<<k)]
                model=DecisionModel([Q(1,1<<k)]*(1<<k),likelihood,targets,k,anchors)
                measured,policy,_=model.solve(measured_cost,penalty)
                optimum,_,_=model.solve(true_cost,penalty)
                evaluation,_=model.replay(policy,true_cost,penalty)
                regret=evaluation[0]-optimum[0]
                assert regret==penalty*(2*radius-eta),(anchored,k,eta,regret)
                cases.append({'setting':'continuation' if anchored else 'initial','budget':k,
                    'eta_over_radius':relative_gap,'radius':radius,'regret':regret,
                    'regret_over_lambda_radius':regret/(penalty*radius)})
    return cases

def history_instability():
    rows=[]
    epsilon=Q(1,20);a,b=Q(2),Q(1)
    for h in [1,2,5,10,20]:
        n=h+1;A=tuple(range(h));S=(h,)
        true=branch_cost([0]*n,[a],[b]*n)
        c,cp=tables(true,n)
        z=[x+(-epsilon if i<h else epsilon) for i,x in enumerate(c)]
        zp={ij:x+(epsilon if ij[1]<h else -epsilon) for ij,x in cp.items()}
        direct=continuation_estimate(z,zp,A,S)
        subtraction=initial_estimate(z,zp,range(n))-initial_estimate(z,zp,A)
        assert direct==b
        assert subtraction==b-4*(h-1)*epsilon
        rows.append({'anchors':h,'true_increment':b,'total_estimate_subtraction':subtraction,
                     'anchored_estimate':direct,'subtraction_error':abs(subtraction-b),
                     'anchored_worst_case_radius':2*epsilon})
    return rows

def main():
    started=time.time()
    checks=calibration_checks();print('Calibration checks passed:',checks,flush=True)
    original=original_decisions();print('Original eight decision rows reproduced exactly.',flush=True)
    initial=initial_sharpness();print('Initial lower bounds verified for 2 through 8 sources.',flush=True)
    continuation=continuation_sharpness();print('Continuation lower bounds verified.',flush=True)
    policies=policy_sharpness();print(len(policies),'policy sharpness cases verified.',flush=True)
    instability=history_instability();print('History-size instability counterexample verified.',flush=True)
    result={'status':'PASS','arithmetic':'Python integers and fractions.Fraction; no Monte Carlo expectations',
        'seed':20260911,'calibration_checks':checks,'original_decisions':original,
        'initial_sharpness':initial,'continuation_sharpness':continuation,'policy_sharpness':policies,'history_instability':instability,
        'limitations':'Finite checks corroborate implementations; universal statements depend on the written proofs.'}
    (ROOT/'verification_results.json').write_text(json.dumps(serial(result),indent=2))
    for name,rows in [('original_decisions',original),('continuation_sharpness',continuation),('policy_sharpness',policies),('history_instability',instability)]:
        with (ROOT/(name+'.csv')).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print('PASS. Elapsed seconds:',round(time.time()-started,2))

if __name__=='__main__': main()

# Minimax recovery and decision stability for tree-based evidence acquisition

**Author(s):** [Names, affiliations, ORCID identifiers, and corresponding-author email]

## Abstract

An evidence-acquisition policy must decide which sources to query and when to stop while accounting for routes activated by earlier queries. We study deterministic recovery of rooted-tree acquisition costs from inaccurate singleton and pair measurements. With coordinatewise error at most `\varepsilon`, the exact minimax radius for the total cost of `m\geq2` sources is `(2m-3)\varepsilon`. Our principal extension concerns continuation: after any nonempty set of routes has been activated, the additional cost of `k` new sources has exact minimax radius `2k\varepsilon`, independent of the number of earlier sources. An estimator based on a forest rooted at the earlier sources attains this radius and reduces to one minimum spanning tree. A counterexample shows that subtracting two total-cost estimates can instead incur error `4(h-1)\varepsilon` for a single new source after `h` earlier sources. We also give sharp radii for separate singleton and pair tolerances, certified intervals for heterogeneous tolerances, and value and policy-loss bounds for finite-horizon Bayesian decisions. Two-branch examples prove that the factor two in the policy-loss bounds cannot be reduced for policies optimized using measured costs. Exact-arithmetic computations reproduce the synthetic decision example and verify the new constructions. The contribution concerns sharp functional recovery and its decision consequences within an established tree-cost model. No empirical manufacturing validation is claimed.

**Keywords:** rooted tree; minimax estimation; shared acquisition cost; Bayesian sequential decision; agentic manufacturing diagnosis.

## 1. Introduction

An agentic manufacturing diagnosis system can be viewed as a coordinator that acquires information from specialized sources, updates its belief about a fault, and chooses a final diagnosis. Graph representations already support multi-agent scheduling in manufacturing; for example, [Qin and Lu](https://doi.org/10.1007/s10845-024-02494-0) [23] combine knowledge graphs with multi-agent reinforcement learning. The present problem concerns the cost of accessing evidence when several sources share communication or session-activation resources.

Charging every query its full standalone access cost is appropriate when all communication expenses recur independently. If part of the expense is incurred once per investigation, however, later queries may reuse an activated route. A useful theoretical question is whether individual and pairwise cost measurements determine the cost of every larger group. A second question asks how errors in these measurements affect an optimal sequential diagnostic policy.

The mathematical ingredients have established antecedents. [Pachter and Speyer](https://arxiv.org/abs/math/0311156) [22] study reconstruction of trees from subtree weights. [Hunter](https://doi.org/10.2307/3212481) [12] uses spanning trees to optimize bounds on unions from first- and second-order information. Hierarchical representations and their stability are studied by [Carlsson and Mémoli](https://jmlr.csail.mit.edu/papers/v11/carlsson10a.html) [5]. Belief-state dynamic programming follows the finite-horizon partially observed control framework of [Smallwood and Sondik](https://doi.org/10.1287/opre.21.5.1071) [24]. [Adaptive submodularity](https://doi.org/10.1613/jair.3278) [10] and [robust observation selection](https://jmlr.org/papers/v9/krause08b.html) [15] address related acquisition problems under different assumptions and objectives.

The principal contribution is sharp recovery of the additional cost of a planned acquisition after some routes have already been activated. Theorem 3.3 gives an estimator and a matching minimax lower bound whose radius depends only on the number of new queries. Proposition 3.4 shows why this result does not follow from subtracting the total-cost estimates in Theorem 3.1: that procedure can amplify uncertainty in proportion to the investigation history. Proposition 3.5 accommodates unequal measurement tolerances. Theorems 4.3 and 4.4 establish sharp policy-loss constants for initial and continuation decisions. Tree representation, spanning-tree algorithms, and belief-state dynamic programming provide the mathematical foundations; the claimed contribution is the precise recovery and decision guarantees under the stated measurement model.

The application extends graph-orchestrated manufacturing diagnosis by introducing shared activation costs and optional stopping. These assumptions differ from a model that charges a complete route cost for every query. The numerical illustration is entirely synthetic.

### 1.1. Related work and scope

**Rooted diversity and tree cost sharing.** After service costs are absorbed into pendant edges, the set function used here is rooted phylogenetic diversity in the sense of Faith [8] and Steel, Mimoto, and Mooers [25]. Bryant and Tupper [3] place phylogenetic diversity within a general theory of distances on finite sets. Rooted-tree cost sharing is also studied through fixed-tree and irrigation games; Márkus, Pintér, and Radványi [18] characterize the game class and investigate Shapley allocations. These connections identify the cost model as established. The marginal quantity itself is also established: Steel et al. explicitly study the increase in diversity from adding a species. Here the target is its deterministic worst-case recovery from inaccurate acquisition-cost measurements, including a matching lower bound and a computational estimator.

**Tree fitting and measurement coordinates.** Farach, Kannan, and Warnow [9] study fitting additive or ultrametric distances, including interval constraints. Adding a label 0 at the root converts exact acquisition measurements into tree distances through

```math
d_{0i}=c_i,\qquad d_{ij}=2c_{ij}-c_i-c_j. \tag{1}
```

Consequently, the underlying representation is connected directly to classical additive-tree reconstruction. However, independent coordinatewise bounds on singleton and pair acquisition costs induce shared error terms in these distances. The present recovery radii are stated in the acquisition-cost coordinates and concern a specified set-cost functional. This distinguishes the information model and target from a generic tree-fitting objective; it does not by itself establish priority over every result in that literature.

**Tree identification and hierarchical representation.** Buneman [4] gives a metric characterization of trees, while Aho et al. [1] construct trees subject to common-ancestor constraints. Pachter and Speyer [22] study recovery from weighted subtrees. These works establish a broader setting for reconstructing a tree from partial descriptions. Here the measurements are acquisition costs for one or two labeled sources, and the target is the cost of a specified source set. Proposition 2.1 expresses the relevant hierarchy through common-prefix depths; it does not identify a unique physical subdivision of the network. The spanning-tree relation between single linkage and hierarchical clustering studied by Gower and Ross [11], together with the stability framework of Carlsson and Mémoli [5], also provides context for the overlap repair in Section 3.2.

**Recovery from inaccurate measurements.** Optimal recovery asks what can be determined about a target quantity from limited information and a specified model class. Donoho [7] connects this viewpoint to minimax statistical estimation of linear functionals under Gaussian noise. The present formulation instead uses deterministic, coordinatewise bounded errors and the class of nonnegative rooted-tree costs. Theorem 3.1 concerns the exact error radius of a set-cost functional under this information model. Its lower bound is obtained from two admissible trees consistent with the same measurements. Thus the result addresses unavoidable uncertainty in acquisition cost without requiring recovery of a particular tree topology.

**Sequential testing and partially observed control.** Wald [26] develops sequential hypothesis testing, and Chernoff [6] studies the sequential choice of experiments. Naghshvar and Javidi [19] analyze active sequential hypothesis testing through information acquisition, decision penalties, and asymptotically optimal policies. The finite-horizon belief-state formulation used here belongs to the framework of Smallwood and Sondik [24] and the planning treatment of Kaelbling, Littman, and Cassandra [14]. Our model restricts each source to one query and records the queried set because shared activation makes the next acquisition cost depend on earlier choices. The Bellman recursion is a specialization of this established framework.

**Submodularity and active feature acquisition.** Nemhauser, Wolsey, and Fisher [20] establish approximation guarantees for monotone submodular maximization under a cardinality constraint. Golovin and Krause [10] identify adaptive diminishing-returns conditions supporting greedy acquisition, while Krause et al. [15] study observation selection against multiple possible objectives, including extensions with communication and path costs. These results motivate scalable acquisition methods, but their assumptions concern the information objective as well as its constraints. Submodularity of the shared acquisition cost alone does not establish the required diminishing returns in diagnostic value; the parity example in Section 4.2 makes that distinction explicit.

Active feature acquisition also studies how to choose additional observations for a partially observed instance. Ma et al. [17] combine a partial variational autoencoder with an expected-information-gain acquisition rule, and Li and Oliva [16] use a generative surrogate model to support acquisition-policy learning. These approaches address representation and policy computation. The present analysis isolates a complementary question: how calibration error in a structured acquisition-cost model propagates to decision values when the observation model is held fixed. The synthetic example therefore illustrates the mathematical guarantees, rather than providing a benchmark against learned acquisition methods.

## 2. Shared costs on a rooted tree

### 2.1. Model and notation

Let `N=\{1,\ldots,n\}` label evidence sources, and let `T` be a finite tree rooted at a coordinator `r`. Source `i` is associated with a vertex and the unique root-to-source path `P_i`. Each edge `e` has activation cost `a_e\geq0`, and source `i` has service cost `s_i\geq0`.

Each source is queried at most once during an investigation. An edge is charged when first activated and remains available until the investigation ends.

For `S\subseteq N`, define

```math
F(S)= \sum_{e\in\bigcup_{i\in S}P_i}a_e +\sum_{i\in S}s_i, \qquad F(\varnothing)=0. \tag{2}
```

This is a nonnegative, monotone weighted-coverage function. Service costs can be absorbed into private pendant edges of lengths `s_i`, placing each source label at the new endpoint. Thus all costs may be represented by root-path lengths, allowing zero-length edges.

Write

```math
c_i=F(\{i\}),\qquad c_{ij}=F(\{i,j\}),\qquad o_{ij}=c_i+c_j-c_{ij},\quad i\ne j. \tag{3}
```

The quantity `o_{ij}` is the cost of the common prefix of the two root paths. Service costs cancel from this overlap. Let `\mathcal T(S)` denote the spanning trees of the complete graph on `S`, when `|S|\geq2`.

The model describes shared activation or setup expenses. These expenses need not equal packet traffic, inference tokens, or wall-clock latency.

### 2.2. Compatibility and marginal costs

**Proposition 2.1 — Rooted-tree compatibility.**
A singleton and pair table admits a representation of the form (2) if and only if `c_i\geq0`, the overlaps are symmetric, and

```math
0\leq o_{ij}\leq\min(c_i,c_j), \qquad o_{ij}\geq\min(o_{ik},o_{jk}) \tag{4}
```

for distinct relevant indices. Under these conditions,

```math
F(A\cup\{j\})-F(A) = c_j-\max_{i\in A}o_{ij}, \qquad j\notin A, \tag{5}
```

where the maximum over the empty set is zero.

*Proof.* In a rooted tree, intersections of root paths are common prefixes. Their lengths give the bounds in (4). If the paths to `i` and `k` agree to depth `u`, and those to `j` and `k` agree to depth `v`, the paths to `i` and `j` agree to depth at least `\min(u,v)`. This proves the last inequality.

Conversely, at height `t\geq0`, group distinct labels satisfying `o_{ij}\geq t`, retaining each label as equivalent to itself. The last inequality in (4) makes these groups equivalence classes. As `t` increases, the classes refine and form a hierarchy.

Realize this hierarchy as a rooted tree whose branching depths are the distinct overlap values, with root depth zero. Place label `i` at depth `c_i`. Every nontrivial class containing `i` occurs at depth at most `c_i`, so all edge lengths are nonnegative. Zero-length edges accommodate tied depths. The resulting common-prefix depths are exactly `o_{ij}`, giving the prescribed individual and pair costs.

Finally, the intersection of `P_j` with the union of previously activated paths is its longest common prefix with those paths. Subtracting this already-paid length from `c_j` proves (5). `\square`

This construction uses the established correspondence between hierarchical similarities and rooted trees [5,22]. It identifies the set-cost function. A physical subdivision of edges, or a separate decomposition into service and communication expenses, need not be identifiable.

### 2.3. Reconstruction from pairs

**Proposition 2.2 — Spanning-tree reconstruction.**
For every `S\subseteq N` with `m=|S|\geq2`,

```math
F(S)= \sum_{i\in S}c_i- \max_{M\in\mathcal T(S)} \sum_{\{i,j\}\in E(M)}o_{ij}. \tag{6}
```

Equivalently,

```math
F(S)= \min_{M\in\mathcal T(S)} \left[ \sum_{\{i,j\}\in E(M)}c_{ij} - \sum_{i\in S}\bigl(\deg_M(i)-1\bigr)c_i \right]. \tag{7}
```

*Proof.* Let `W(S)` be the maximum spanning-tree weight in (6). Choose a pair `i,j` of maximum overlap `h` in `S`. Equation (5) gives

```math
F(S)=F(S\setminus\{j\})+c_j-h.
```

There is a maximum-weight spanning tree containing edge `ij`: adding this globally maximum-weight edge to a maximum tree and removing an edge from the resulting cycle cannot decrease its weight.

Moreover, (4) implies `o_{ik}\geq o_{jk}` for every `k\notin\{i,j\}`, since `h\geq o_{jk}`. In a maximum tree containing `ij`, replace every other edge `jk` by `ik`. The result remains a spanning tree, its weight does not decrease, and `j` becomes a leaf. Its restriction to `S\setminus\{j\}` must also be maximum. Consequently,

```math
W(S)=W(S\setminus\{j\})+h.
```

Induction, beginning with a singleton of spanning-tree weight zero, proves (6). Substituting (3) and collecting singleton coefficients proves (7). `\square`

The expression has the same spanning-tree structure as Hunter’s union bound [12]; rooted-path structure makes it exact. A dense maximum-spanning-tree algorithm evaluates a specified `m`-source cost in `O(m^2)` arithmetic operations. All subset costs are represented by `O(n^2)` measurements, although explicitly listing them requires exponential space.

## 3. Minimax recovery under measurement error

Suppose measurements satisfy

```math
|\widetilde c_i-c_i|\leq\varepsilon, \qquad |\widetilde c_{ij}-c_{ij}|\leq\varepsilon. \tag{8}
```

The measured table need not satisfy (4). Define `H(\varnothing)=0`, `H(\{i\})=\widetilde c_i`, and, for `|S|\geq2`, define `H(S)` by the right side of (7) using measured values.

### 3.1. Exact recovery radius

**Theorem 3.1 — Sharp error bound and minimax optimality.**
Set

```math
\alpha_0=0,\qquad \alpha_1=1,\qquad \alpha_m=2m-3\quad(m\geq2).
```

Then

```math
|H(S)-F(S)| \leq \alpha_{|S|}\varepsilon. \tag{9}
```

For each `m\geq2`, the coefficient `2m-3` cannot be reduced by replacing `H` with any other estimator based only on the individual and pairwise measurements.

*Proof.* Fix `S` of size `m\geq2`. Each spanning-tree expression in (7) contains `m-1` pair terms with coefficient `+1`. Since every vertex has degree at least one,

```math
\sum_{i\in S}|\deg_M(i)-1| = 2(m-1)-m=m-2.
```

Thus each expression changes by at most

```math
(m-1)\varepsilon+(m-2)\varepsilon = (2m-3)\varepsilon.
```

If every member of a finite family of real numbers changes by at most `d`, its minimum changes by at most `d`. Applying this fact to (7) proves (9). The empty and singleton cases are immediate.

For the lower bound, consider `m` leaves sharing a trunk of length `a>3\varepsilon`, with each pendant edge of length `b>2\varepsilon`. Let the measured table be that of this central tree:

```math
\widetilde c_i=a+b, \qquad \widetilde c_{ij}=a+2b.
```

Two possible true trees have trunk and pendant lengths

```math
(a_+,b_+)=(a-3\varepsilon,b+2\varepsilon),
```

```math
(a_-,b_-)=(a+3\varepsilon,b-2\varepsilon).
```

All edge lengths are nonnegative. In the first tree, every singleton is lower than its measurement by `\varepsilon`, while every pair is higher by `\varepsilon`. The signs are reversed in the second tree. Both trees satisfy (8) for the same observed table.

Their full-set costs are

```math
F_+(N)=a+mb+(2m-3)\varepsilon,
```

```math
F_-(N)=a+mb-(2m-3)\varepsilon.
```

An estimator receives identical input in these two cases. Its largest error must be at least half the distance between the two possible costs, namely `(2m-3)\varepsilon`. Together with (9), this proves minimax optimality. `\square`

Formally, let `\mathcal C_m` be the class of nonnegative rooted-tree cost functions on `m` labels, and let `D(F)` be the vector of singleton and pair costs. Then

```math
\inf_R \sup_{\substack{ F\in\mathcal C_m,\ z\\ \|z-D(F)\|_\infty\leq\varepsilon }} |R(z)-F(N)| = (2m-3)\varepsilon, \qquad m\geq2. \tag{10}
```

The infimum ranges over estimators `R`.

If singleton errors are bounded by `\varepsilon_1` and pair errors by `\varepsilon_2`, the same argument gives the sharp radius

```math
(m-2)\varepsilon_1+(m-1)\varepsilon_2.
```

For the lower bound, perturb the trunk by opposite amounts `2\varepsilon_1+\varepsilon_2`, and each pendant edge by opposite amounts `\varepsilon_1+\varepsilon_2`.

### 3.2. A feasible repair

The direct estimate `H` can be nonmonotone when measurements are incompatible. A physical network representation can instead be obtained by repairing the overlaps.

Define

```math
\widehat c_i=\max(0,\widetilde c_i),
```

```math
u_{ij} = \min\left\{ \widehat c_i,\widehat c_j, \max(0,\widetilde c_i+\widetilde c_j-\widetilde c_{ij}) \right\}. \tag{11}
```

For distinct `i,j`, define the maximum-bottleneck closure

```math
\widehat o_{ij} = \max_{\gamma:i\leadsto j} \min_{\{u,v\}\in E(\gamma)}u_{uv}, \tag{12}
```

where the maximum is over simple paths in the complete graph. Let `\widehat F` be the rooted-tree cost reconstructed from `\widehat c,\widehat o`.

**Proposition 3.2 — Feasibility and repair error.**
The repaired table satisfies (4). For every nonempty `S`,

```math
|\widehat F(S)-F(S)| \leq (4|S|-3)\varepsilon. \tag{13}
```

*Proof.* The closure is symmetric and nonnegative. Every path from `i` to `j` starts with an edge bounded by `\widehat c_i` and ends with one bounded by `\widehat c_j`. Hence

```math
\widehat o_{ij}\leq\min(\widehat c_i,\widehat c_j).
```

Concatenating paths through `k`, and removing loops without reducing the bottleneck, proves the final inequality in (4).

Singleton clipping has error at most `\varepsilon`. Raw overlap errors are at most `3\varepsilon`. The clipping in (11) preserves this bound because minimum and maximum are nonexpansive in the sup norm.

The maximum-bottleneck operation is also nonexpansive: perturbing every edge value by at most `d` perturbs each path bottleneck, and then their maximum, by at most `d`. This operation fixes the true overlap matrix, because repeated application of (4) bounds every path bottleneck by the direct true overlap. Therefore,

```math
\|\widehat o-o\|_\infty\leq3\varepsilon.
```

In (6), the singleton sum changes by at most `|S|\varepsilon`, while the maximum spanning-tree weight changes by at most `3(|S|-1)\varepsilon`. Adding these bounds proves (13). `\square`

The closure is a standard hierarchical operation related to single linkage [5,11]. A max-min version of Floyd’s algorithm computes it in `O(n^3)` time. The constant in (13) is a conservative guarantee; its sharpness is not asserted. Repair supplies nonnegative, monotone physical set costs, while direct recovery has the sharper guarantee in (9).

### 3.3. Sharp recovery after earlier acquisitions

Let `A\ne\varnothing` be a fixed set of previously queried sources, and let `S\subseteq N\setminus A` contain `k` new sources. The cost relevant to continuation is

```math
\Delta_F(A,S)=F(A\cup S)-F(A). \tag{14}
```

The available information is the singleton and pair measurement table `z=(z_i,z_{ij})`, with no additional exact telemetry for the sunk cost. Write `\mathcal R_A(S)` for the forests on `A\cup S` in which every component contains exactly one vertex of `A`. Isolated anchors are allowed. Every such forest has exactly `k` edges, and each new vertex has degree at least one. For `R\in\mathcal R_A(S)`, define

```math
\begin{aligned}
T_z(R)={}&\sum_{\{u,v\}\in E(R)}z_{uv}
-\sum_{j\in S}(\deg_R(j)-1)z_j\\
&-\sum_{a\in A}\deg_R(a)z_a.
\end{aligned} \tag{15}
```

Define `H_A(\varnothing)=0` and

```math
H_A(S)=\min_{R\in\mathcal R_A(S)}T_z(R). \tag{16}
```

**Theorem 3.3 — Sharp continuation recovery.**
Suppose the true cost has the representation (2) and all singleton and pair errors obey

```math
|z_i-c_i|\leq\varepsilon_1,\qquad
|z_{ij}-c_{ij}|\leq\varepsilon_2,
\qquad \varepsilon_1,\varepsilon_2\geq0. \tag{17}
```

For every nonempty `A` and disjoint `S` of size `k\geq1`,

```math
\begin{aligned}
\Delta_F(A,S)&=\min_{R\in\mathcal R_A(S)}T_c(R),\\
|H_A(S)-\Delta_F(A,S)|&\leq k(\varepsilon_1+\varepsilon_2).
\end{aligned} \tag{18}
```

For each fixed pair of sizes `|A|\geq1` and `k\geq1`, this is the exact minimax radius over nonnegative rooted trees on `A\cup S`, when the full singleton and pair table is available subject to these tolerances. In particular, under a common tolerance `\varepsilon`, the radius is `2k\varepsilon`, independent of `|A|`.

*Proof.* Orient every component of a forest `R` toward its anchor and order its new vertices with parents before children. When vertex `j` is added, its overlap with the already activated paths is at least its overlap with its parent. The marginal identity (5) therefore gives

```math
\Delta_F(A,S)\leq\sum_{j\in S}c_j
-\sum_{\{u,v\}\in E(R)}o_{uv}=T_c(R).
```

Conversely, order the elements of `S` arbitrarily. For each new vertex choose a parent among `A` and the earlier new vertices attaining its maximum overlap with that set. Each parent precedes its child, so these choices form a forest with exactly one anchor in each component. Every marginal inequality is then an equality. Summing the marginal identities proves the first assertion.

Each forest expression has `k` pair coefficients equal to one. The singleton coefficients are nonpositive, with total absolute value

```math
\sum_{j\in S}(\deg_R(j)-1)+\sum_{a\in A}\deg_R(a)
=2k-k=k.
```

Thus each expression changes by at most `k(\varepsilon_1+\varepsilon_2)`. Taking minima preserves that bound.

For the lower bound, take `|A|+k` leaves with common trunk length `a>2\varepsilon_1+\varepsilon_2` and equal pendant lengths `b>\varepsilon_1+\varepsilon_2`. Use the table of this central tree as the measurement. Two admissible true trees have parameters

```math
(a_\pm,b_\pm)=
\bigl(a\mp(2\varepsilon_1+\varepsilon_2),\ b\pm(\varepsilon_1+\varepsilon_2)\bigr).
```

Their singleton deviations are `\mp\varepsilon_1`, and their pair deviations are `\pm\varepsilon_2`, including all pairs of anchors. Since `A` is nonempty, its paths already include the trunk. The two continuation costs are therefore

```math
\Delta_{F_\pm}(A,S)=kb\pm k(\varepsilon_1+\varepsilon_2).
```

Any estimator receives the same complete measurement table in both cases and must incur error at least half their separation. The upper bound attains this radius. The case of zero tolerances follows as well. `\square`

The theorem estimates the continuation functional directly. It does not require selecting a globally compatible repaired tree or identifying the physical topology. It also does not assume that an exact value of `F(A)` is observed; additional exact information changes the minimax experiment.

**Computation.** Contract all anchors to an auxiliary vertex 0. On the complete graph with vertices `\{0\}\cup S`, assign weights

```math
w_{ij}=z_{ij}-z_i-z_j,\qquad
w_{0j}=\min_{a\in A}(z_{aj}-z_a-z_j). \tag{19}
```

Then

```math
H_A(S)=\sum_{j\in S}z_j+\min_M\sum_{e\in E(M)}w_e, \tag{20}
```

where `M` ranges over the spanning trees of this auxiliary graph. Contracting any anchor-rooted forest gives a spanning tree. Conversely, lift each edge incident to 0 to an anchor attaining its defining minimum. Removing vertex 0 separates the spanning tree into components, each of which is attached to one anchor; this gives an admissible forest of the same weight. The weights need not be ultrametric, and this algorithm does not assume that they are.

Forming anchor edges costs `O(|A|k)` arithmetic operations, and dense Prim optimization costs `O(k^2)`. No pair measurement between two anchors is needed. For one new source, the estimator simplifies to

```math
H_A(\{j\})=\min_{a\in A}(z_{aj}-z_a). \tag{21}
```

### 3.4. Why subtracting total estimates can be unstable

One might estimate continuation by `H(A\cup S)-H(A)`, using the total-cost estimator from Theorem 3.1. Its two error terms can reinforce one another. The following construction demonstrates actual growth with history size, rather than merely a loose bound.

**Proposition 3.4 — History-size instability.**
For every `h\geq2` and `\varepsilon>0`, there is a rooted-tree cost, a set `A` with `|A|=h`, one new source `j`, and measurements satisfying (8), such that

```math
\begin{aligned}
H(A\cup\{j\})-H(A)&=\Delta_F(A,\{j\})-4(h-1)\varepsilon,\\
H_A(\{j\})&=\Delta_F(A,\{j\}).
\end{aligned} \tag{22}
```

*Proof.* Use `h+1` leaves with a shared trunk `a>3\varepsilon` and equal pendants `b>0`. Let

```math
\begin{aligned}
z_i&=a+b-\varepsilon &&(i\in A),\\
z_j&=a+b+\varepsilon,\\
z_{il}&=a+2b+\varepsilon &&(i,l\in A,\ i\ne l),\\
z_{ij}&=a+2b-\varepsilon &&(i\in A).
\end{aligned}
```

Every coordinate error has magnitude `\varepsilon`. The measured overlaps between anchors equal `a-3\varepsilon`, while those between `j` and an anchor equal `a+\varepsilon`. A maximum spanning tree on `A` uses `h-1` anchor edges. On `A\cup\{j\}`, the star centered at `j` uses `h` edges of the greater weight. Hence

```math
\begin{aligned}
H(A)&=F(A)+(2h-3)\varepsilon,\\
H(A\cup\{j\})&=F(A\cup\{j\})-(2h-1)\varepsilon.
\end{aligned}
```

The true additional cost is `b`, while every measured difference `z_{ij}-z_i` equals `b`. This proves both assertions. `\square`

The subtraction error equals the sum of the two total-cost radii in this construction. It can also produce a negative estimate for a positive additional cost. Direct continuation recovery avoids this history-dependent amplification and retains the sharp uniform radius `2\varepsilon` for one new query. Exactness of the direct estimate in this particular example is not a claim of zero error in general.

### 3.5. Certificates with heterogeneous tolerances

Suppose instead that each measurement has its own known bound, `|z_i-c_i|\leq e_i` and `|z_{ij}-c_{ij}|\leq e_{ij}`. For an anchor-rooted forest set

```math
\begin{aligned}
r(R)={}&\sum_{\{u,v\}\in E(R)}e_{uv}
+\sum_{j\in S}(\deg_R(j)-1)e_j\\
&+\sum_{a\in A}\deg_R(a)e_a.
\end{aligned}
```

**Proposition 3.5 — Certified continuation interval.**
The endpoints

```math
L_A(S)=\min_R\{T_z(R)-r(R)\},\qquad
U_A(S)=\min_R\{T_z(R)+r(R)\} \tag{23}
```

satisfy `L_A(S)\leq\Delta_F(A,S)\leq U_A(S)`.

*Proof.* For each forest, coefficientwise error control gives `T_z(R)-r(R)\leq T_c(R)\leq T_z(R)+r(R)`. Take minima and apply Theorem 3.3. `\square`

Both endpoints require one minimum spanning tree. To compute the lower endpoint, replace singleton inputs by `z_i+e_i` and pair inputs by `z_{ij}-e_{ij}` in the continuation estimator. Reverse these signs for the upper endpoint. If all singleton bounds equal `\varepsilon_1` and all pair bounds equal `\varepsilon_2`, the radius of every forest is `k(\varepsilon_1+\varepsilon_2)`, recovering Theorem 3.3. For arbitrary heterogeneous bounds, the interval is certified but is not asserted to equal the extrema over all compatible true trees.


## 4. Sequential Bayesian decisions

### 4.1. Exact finite-horizon solution

Let the latent state `X` take values in a finite set `\mathcal X`, with prior `p`. Source `i` returns an observation in a finite set `\mathcal Y_i`, according to a known likelihood `L_i(y\mid x)`. Source observations are conditionally independent given `X`.

A final decision `d` belongs to a finite set `\mathcal D`, with loss `0\leq\ell(d,x)\leq1`. A policy may stop or query an unqueried source, with at most `B\leq n` queries. If its final queried set is `S_\tau`, its objective is

```math
J_F(\pi) = \mathbb E^\pi \left[ \ell(d_\tau,X)+\lambda F(S_\tau) \right], \qquad \lambda>0. \tag{24}
```

The query limit is a call budget; monetary cost appears as a penalty. A hard monetary constraint would make the admissible policy class depend on the estimated cost and requires separate treatment.

For posterior `p`, define

```math
r(p)= \min_{d\in\mathcal D}\sum_xp(x)\ell(d,x),
```

```math
q_i(y\mid p)=\sum_xp(x)L_i(y\mid x), \qquad T_i(p,y)(x)= \frac{p(x)L_i(y\mid x)}{q_i(y\mid p)}. \tag{25}
```

Outcomes of zero predictive probability are omitted.

**Proposition 4.1 — Bellman recursion.**
The minimum expected remaining loss and future acquisition cost, after querying `A` and with `b` calls remaining, is

```math
V_0(p,A)=r(p), \tag{26}
```

and, for `b\geq1`,

```math
\begin{aligned} V_b(p,A)=\min\Bigg\{r(p),\ \min_{i\notin A}\Bigg[ &\lambda\bigl(F(A\cup\{i\})-F(A)\bigr)\\ &+\sum_yq_i(y\mid p) V_{b-1}\bigl(T_i(p,y),A\cup\{i\}\bigr) \Bigg]\Bigg\}. \end{aligned} \tag{27}
```

If no source remains, only the stopping term is used. A deterministic optimal policy exists.

*Proof.* Conditional independence makes `(p,A,b)` sufficient for predicting every remaining observation. Stopping incurs Bayes risk `r(p)`. Querying `i` incurs its marginal cost and the optimal continuation value under the updated posterior.

Backward induction over `b` proves (26)–(27). The action and observation sets are finite, so every minimum is attained. Marginal costs telescope to `F(S_\tau)`, giving (24) at the initial state. `\square`

This specializes finite-horizon belief-state dynamic programming [14,24]. With at most `q` outcomes per source, there are at most

```math
\sum_{m=0}^{B}\binom nm q^m
```

partial observation assignments from a fixed prior. Compact representation of acquisition costs therefore does not make exact adaptive optimization polynomial.

The same recursion applies to `H`, using differences `H(A\cup\{i\})-H(A)`. When raw measurements are incompatible, these differences must be evaluated from the set estimate: formula (5) need not hold for noisy overlaps. Negative surrogate increments do not invalidate finite-horizon optimization, although they lack a physical activation-cost interpretation.

### 4.2. Stability of values and policies

Write `V_F=\min_\pi J_F(\pi)`, `V_H=\min_\pi J_H(\pi)`, and

```math
\beta_B= \max_{0\leq m\leq B}\alpha_m = \begin{cases} 0,&B=0,\\ 1,&B=1,\\ 2B-3,&B\geq2. \end{cases} \tag{28}
```

**Theorem 4.2 — Decision stability.**
Under (8), for the same likelihoods, loss, prior, call budget, and penalty weight,

```math
|V_F-V_H| \leq \lambda\beta_B\varepsilon. \tag{29}
```

If `\pi_H` minimizes the measured-cost objective, then

```math
0\leq J_F(\pi_H)-V_F \leq 2\lambda\beta_B\varepsilon. \tag{30}
```

For `B\geq2`, the coefficient in (29) is sharp over this decision-model class.

*Proof.* Fix any history-dependent policy `\pi`. Holding this policy fixed, replacing the cost table does not change the observation law or its stopping decisions. Since `|S_\tau|\leq B`, Theorem 3.1 gives

```math
\begin{aligned} |J_F(\pi)-J_H(\pi)| &\leq \lambda\mathbb E^\pi |F(S_\tau)-H(S_\tau)|\\ &\leq \lambda\beta_B\varepsilon. \end{aligned}
```

Taking minima proves (29). If `\pi_F` is optimal for `F`, then

```math
\begin{aligned} J_F(\pi_H) &\leq J_H(\pi_H)+\lambda\beta_B\varepsilon\\ &\leq J_H(\pi_F)+\lambda\beta_B\varepsilon\\ &\leq V_F+2\lambda\beta_B\varepsilon, \end{aligned}
```

which proves (30).

For sharpness of (29), take `B` independent fair bits `X_1,\ldots,X_B` as the latent state. Source `i` reveals `X_i` deterministically, and the final decision predicts their parity under zero-one loss. Conditional independence holds given the complete latent state. Every proper subset leaves parity uniformly distributed, while the full set determines it.

For a nonnegative monotone cost function `K`, a policy completing all queries with probability `u` has objective at least

```math
u\lambda K(N)+(1-u)/2.
```

Always stopping or always completing attains the two endpoints. The optimal value is consequently

```math
\min\{1/2,\lambda K(N)\}.
```

Use the central tree and the plus perturbation from Theorem 3.1, choosing `\lambda` small enough that full acquisition is optimal for both. Their values differ by exactly

```math
\lambda(2B-3)\varepsilon.
```

This proves sharpness. `\square`

Theorem 4.3 below proves that the factor two in (30) cannot be reduced for surrogate-optimal policies, even when the measured table is itself a physical tree. Replacing `H` by the repaired estimate gives corresponding value and excess-loss bounds with `4B-3`, for `B\geq1`.

The parity example also shows a limitation of one-step policies. If every initial acquisition has positive cost, a policy comparing only immediate Bayes-risk reduction with acquisition cost stops without querying. Its value remains `1/2`, while the optimum is `\lambda F(N)` for sufficiently small `\lambda`. Their ratio is unbounded as `\lambda` approaches zero. Thus tree structure alone does not provide a general one-step approximation guarantee; assumptions on information value are also required [10].

The stability question here differs from optimization over uncertain transition laws. Iyengar [13] and Nilim and El Ghaoui [21] develop robust dynamic programming for transition uncertainty. In Theorem 4.2 the likelihoods and admissible policies are common to the true-cost and measured-cost problems; only the acquisition objective changes. Extending the result to uncertain likelihoods would therefore require an additional argument.

### 4.3. Sharpness of the policy-loss constant

**Theorem 4.3 — Sharp initial policy loss.**
For every `B\geq2` and `\varepsilon>0`, the factor two in (30) is sharp as a supremum over the decision-model class with at least `2B` available sources. More precisely, let `\rho=(2B-3)\varepsilon`. For every `0<\eta<2\rho`, there are a true tree, a compatible measured tree satisfying (8), and a penalty `\lambda>0` such that every measured-cost optimal policy has true excess objective

```math
J_F(\pi_H)-V_F=\lambda(2\rho-\eta). \tag{31}
```

*Proof.* Set `k=B`. Let `k` independent fair bits form the latent state. There are two sources revealing each bit, one in each of two branches. Every source returns its bit deterministically; the final decision predicts the parity. With a call budget of `k`, an informative terminal set must contain exactly one copy of every bit. All other terminal sets leave Bayes risk `1/2`.

The measured tree has two branches, with trunk lengths `a` and `a+\eta`, and all pendant lengths `b`, where `a>3\varepsilon` and `b>2\varepsilon`. The cheapest informative set consists of all first-branch sources, with measured cost `C=a+kb`. Any mixed set pays for both trunks.

In the true tree, change the first trunk to `a-3\varepsilon` and its pendants to `b+2\varepsilon`; change the second trunk to `a+\eta+3\varepsilon` and its pendants to `b-2\varepsilon`. The singleton errors are `-\varepsilon` in the first branch and `+\varepsilon` in the second. Within-branch pair errors are `+\varepsilon` and `-\varepsilon`, respectively, while cross-branch pair errors are zero. Thus all measurements satisfy the required bound.

The full first- and second-branch costs in the true tree are

```math
C+\rho,\qquad C+\eta-\rho.
```

The second is strictly smaller. A mixed informative set containing `s` sources from the first branch, `1\leq s<k`, costs more than the full second branch by `a+4s\varepsilon>0`.

For either physical cost tree, write `C_{\min}` for its cheapest informative cost. A policy completing an informative set with probability `u` has objective at least `u\lambda C_{\min}+(1-u)/2`. Choosing `\lambda` with `\lambda C_{\min}<1/2` for both trees forces optimal policies to complete an informative set. Under the measured tree the cheapest such set is uniquely the first branch; under the true tree it is uniquely the second branch. Their true cost difference is `2\rho-\eta`, proving the assertion. Letting `\eta/\rho` tend to zero proves sharpness without relying on adverse tie-breaking. `\square`

This statement concerns the worst-case loss of a policy optimized for the measured objective. It does not assert minimax optimality of that policy among all decision rules that could account explicitly for uncertainty.

### 4.4. Continuation decisions with a fixed anchor set

At a current posterior `p`, let the previously queried set be `A\ne\varnothing`, and let at most `b` further calls be available. The sunk cost is omitted from the continuation objective. For a policy whose set of new acquisitions is `S_\tau`, define

```math
\begin{aligned}
J_F^A(\pi)&=\mathbb E^\pi[\ell(d_\tau,X)+\lambda\Delta_F(A,S_\tau)],\\
J_{H_A}^A(\pi)&=\mathbb E^\pi[\ell(d_\tau,X)+\lambda H_A(S_\tau)].
\end{aligned} \tag{32}
```

Let `V_F^A` and `V_{H_A}^A` be their optimal values over the same continuation policies.

**Theorem 4.4 — Sharp continuation decision bounds.**
Under the tolerances of Theorem 3.3, put `\kappa_b=b(\varepsilon_1+\varepsilon_2)`. Then

```math
\begin{aligned}
|V_F^A-V_{H_A}^A|&\leq\lambda\kappa_b,\\
0\leq J_F^A(\pi_{H_A})-V_F^A&\leq2\lambda\kappa_b.
\end{aligned} \tag{33}
```

The value coefficient one is sharp for every `b\geq1`. When `\varepsilon_1+\varepsilon_2>0`, the policy coefficient two is sharp as a supremum over continuation problems with two earlier sources and `2b` available new sources.

*Proof.* For every fixed continuation policy, the observation law is unchanged and Theorem 3.3 bounds the terminal cost error by `\kappa_b`. Taking expectations, then applying the two minimization comparisons in Theorem 4.2, proves both inequalities.

For value sharpness, use the two-tree construction from Theorem 3.3, with uninformative anchors and `b` new sources revealing independent bits. The decision predicts their parity. With a sufficiently small positive penalty, complete acquisition is optimal under the central tree and either perturbation. Their continuation values differ by exactly `\lambda\kappa_b`.

For policy sharpness, put `s=\varepsilon_1+\varepsilon_2>0` and `t=2\varepsilon_1+\varepsilon_2`. Take two branches, each containing one already queried uninformative anchor and one copy of each of `b` independent bits. In the measured tree both trunks have length `a>t`. All pendants in the first branch have length `q>s`; all pendants in the second have length `q+\eta/b`, where `0<\eta<2bs`. Since each trunk is already activated, the unique cheapest informative continuation selects all first-branch sources.

For the true tree change the first trunk by `-t` and every first-branch pendant by `+s`; change the second trunk by `+t` and every second-branch pendant by `-s`. As in Theorem 3.3, singleton deviations have magnitude `\varepsilon_1` and within-branch pair deviations have magnitude `\varepsilon_2`. Cross-branch pair deviations are zero, including pairs involving anchors. All edge lengths remain positive.

The full first- and second-branch continuation costs are

```math
bq+bs,\qquad bq+\eta-bs.
```

Each second-branch source now has strictly smaller additional cost than its first-branch copy. A sufficiently small positive penalty makes complete information optimal under both trees, by the parity argument. The measured-optimal policy consequently incurs excess objective `\lambda(2bs-\eta)`. Since `\kappa_b=bs`, its ratio to `\lambda\kappa_b` approaches two. `\square`

**Implementation condition.** Keep the anchor set `A` fixed throughout one continuation planning problem. At an intermediate set `U` of newly queried sources, charge the surrogate increment `H_A(U\cup\{i\})-H_A(U)`. These increments telescope to the terminal surrogate in the theorem. Replacing them by separately recomputed one-step estimates `H_{A\cup U}(\{i\})` need not telescope for noisy measurements. Replanning at a later history defines a new continuation problem and a new bound; it does not automatically retain the earlier policy guarantee.

**Corollary 4.5 — A stopping certificate.**
Let `\delta=\lambda\kappa_b`, and let `Q_{H_A}(i)` denote the measured continuation value when the first action is forced to query source `i` and subsequent actions are optimized. If

```math
\min_i Q_{H_A}(i)>r(p)+\delta,
```

then stopping is optimal under the true cost. If `\min_i Q_{H_A}(i)<r(p)-\delta`, stopping is suboptimal under the true cost.

*Proof.* Restrict the policy class to each forced first query and repeat the value comparison from Theorem 4.4. Every corresponding true action value differs by at most `\delta`; the stopping value `r(p)` is exact. The stated inequalities follow. `\square`

This certificate is a direct perturbation consequence, with no additional optimality claim. It requires solving the relevant continuation action values; the minimum-spanning-tree cost estimator does not remove the exponential complexity of general adaptive planning.


## 5. Decision equivalence and the boundary of the model

### 5.1. Which network information is decision-relevant?

**Theorem 5.1 — Universal decision equivalence.**
Let `F` and `G` be rooted-tree cost functions on the same `n\geq2` labels. Fix `2\leq B\leq n`. The following statements are equivalent:

1. `F` and `G` agree on every singleton and pair.
2. They agree on every subset of sources.
3. They have equal optimal values for every finite decision experiment described in Section 4 and every `\lambda>0`, under the same call limit `B`.

*Proof.* Proposition 2.2 gives statement 1 implies statement 2. Identical set costs give identical objectives for every policy, proving statement 2 implies statement 3.

Suppose statement 1 fails on a set `S` of size one or two. Let each source in `S` reveal one independent fair bit, let every other source return a constant, and let the final decision predict the parity of the bits in `S`.

By the argument in Theorem 4.2 and monotonicity of acquisition costs, the optimal value under a cost function `K` is

```math
\min\{1/2,\lambda K(S)\}.
```

Choose `\lambda>0` small enough that acquiring `S` is optimal under both `F` and `G`. Since `F(S)\ne G(S)`, their optimal values differ, contradicting statement 3. `\square`

For `B=1`, only singleton costs matter. The quantifier over all positive `\lambda` is essential: a sufficiently high fixed penalty can make immediate stopping optimal in both networks and conceal cost differences.

Blackwell’s comparison of experiments [2] provides a classical decision-theoretic use of universal quantification over decision problems. The objects compared here are acquisition-cost functions: the observation experiment is the same on both sides of each comparison. Theorem 5.1 characterizes when cost differences can be detected by some such experiment; it is not a characterization of the informational equivalence of observation channels.

### 5.2. Failure for general shared resources

Rooted-path structure cannot be inferred solely from a compatible pair table. Consider three sources.

In system A, there are three resources `e_{12},e_{13},e_{23}`, each of cost one. Source 1 uses `e_{12},e_{13}`; source 2 uses `e_{12},e_{23}`; source 3 uses `e_{13},e_{23}`.

In system B, every source uses a common resource of cost one and its own private resource of cost one.

Both systems have singleton cost two and pair cost three. Their triple costs differ:

```math
F_A(\{1,2,3\})=3, \qquad F_B(\{1,2,3\})=4. \tag{34}
```

System B is a rooted-tree model; system A is a general coverage system. Individual and pairwise measurements therefore cannot identify all group costs over the broader class. Even a table satisfying Proposition 2.1 does not certify that the physical system has rooted-path structure.

## 6. Synthetic manufacturing illustration

### 6.1. Fully specified instance

Consider six evidence sources: telemetry, quality, maintenance, materials, scheduling, and assembly. Their labels describe diagnostic roles. No physical factory data or language-model outputs are used.

The rooted routing tree has the following activation edges.

| Edge | Activation cost |
| ------------------------ | --- |
| Coordinator → Telemetry  | 2.0 |
| Telemetry → Quality      | 1.6 |
| Telemetry → Maintenance  | 1.4 |
| Coordinator → Materials  | 2.6 |
| Coordinator → Scheduling | 2.0 |
| Scheduling → Assembly    | 1.8 |

An activation expense is paid once per investigation.

**Table 1. Synthetic source parameters.**

| Source | Service cost | Singleton cost | Assumed accuracy |
| ------------------------------------------------ | --- | --- | ---- |
| Telemetry                                        | 1.0 | 3.0 | 0.75 |
| Quality                                          | 1.1 | 4.7 | 0.80 |
| Maintenance                                      | 0.9 | 4.3 | 0.78 |
| Materials                                        | 0.8 | 3.4 | 0.65 |
| Scheduling                                       | 0.9 | 2.9 | 0.70 |
| Assembly                                         | 1.3 | 5.1 | 0.88 |

The three pairs within `\{\text{telemetry},\text{quality},\text{maintenance}\}`, and the scheduling–assembly pair, have overlap 2.0. Every other overlap is zero. These values and Table 1 specify every pair cost through (3).

For example, quality and maintenance together cost

```math
4.7+4.3-2.0=7.0.
```

Adding telemetry costs `3.0-2.0=1.0`, giving a three-source total of 8.0. Acquiring all six sources costs 17.4; the sum of standalone costs is 23.4. This difference follows from the assumed accounting rule and is not an empirical manufacturing saving.

Let `X\in\{0,1\}` have prior probability `1/2`. Each source is a binary symmetric channel with the accuracy in Table 1, independently conditional on `X`. The final loss is diagnostic misclassification, and at most four sources may be queried.

We compare the Bellman-optimal policy with a myopic policy minimizing, at each history,

```math
\begin{aligned} \min\Bigg\{r(p),\ \min_{i\notin A}\Bigg[ &\lambda\bigl(F(A\cup\{i\})-F(A)\bigr)\\ &+\sum_yq_i(y\mid p)r(T_i(p,y)) \Bigg]\Bigg\}. \end{aligned} \tag{35}
```

The myopic policy repeats this rule after each observation. Ties favor stopping, then the earliest source in Table 1.

### 6.2. Exact results

**Table 2. Exact policy expectations for the synthetic instance.**

| `\lambda` | Policy | Error probability | Expected cost | Expected calls | Objective |
| -------------------------------------------------------------------- | ------- | ------ | ------- | ------ | --------- |
| 0.005                                                                | Optimal | 0.0792 | 7.83012 | 2.4716 | 0.1183506 |
| 0.005                                                                | Myopic  | 0.1200 | 5.10000 | 1.0000 | 0.1455000 |
| 0.010                                                                | Optimal | 0.0828 | 7.39230 | 2.4770 | 0.1567230 |
| 0.010                                                                | Myopic  | 0.1200 | 5.10000 | 1.0000 | 0.1710000 |
| 0.020                                                                | Optimal | 0.1200 | 5.10000 | 1.0000 | 0.2220000 |
| 0.020                                                                | Myopic  | 0.1200 | 5.10000 | 1.0000 | 0.2220000 |
| 0.040                                                                | Optimal | 0.1200 | 5.10000 | 1.0000 | 0.3240000 |
| 0.040                                                                | Myopic  | 0.1200 | 5.10000 | 1.0000 | 0.3240000 |

At the two smaller penalty weights, the optimal policy first queries scheduling, whereas the myopic policy queries assembly and stops. Although assembly has greater assumed standalone accuracy, planning ahead accounts for shared activation and subsequent evidence. At the larger penalty weights, both policies query assembly and stop. These results establish behavior only for the specified finite instance.

For calibration tolerance `\varepsilon=0.05`, the four-call limit gives `\beta_4=5`. At `\lambda=0.01`, Theorem 4.2 bounds the optimal-value error by 0.0025 and the excess objective of the measured-cost policy by 0.005. These are worst-case guarantees under the calibration assumption, rather than observed average errors.

The accompanying Python implementation uses integers and fractions.Fraction, with no numerical dependencies. It reproduces the eight table rows using a fresh exact-arithmetic implementation of the dynamic program and a separate full-outcome replay routine. The Bellman calculation considered 473 partial observation assignments, equal to

```math
\sum_{m=0}^{4}\binom6m2^m.
```

For each policy and penalty, its terminal decision, cost, and query count were independently evaluated by replaying all

```math
2\times2^6=128
```

latent-state/full-observation combinations with their exact probabilities. Across the eight policy cases, all 1,024 replay outcomes reproduced the dynamic-programming expectations exactly. Table 2 reports exact finite-model expectations, rather than Monte Carlo estimates.

### 6.3. Algebraic implementation checks

A separate verification generated 100 rooted trees with six labeled source vertices. Costs in these checks were represented as integer multiples of 1/20; the following ranges give the corresponding cost units. Vertex `i` selected its parent among `0,\ldots,i-1`, with vertex 0 the root. Edge weights were selected from `\{0.1,0.2,\ldots,3.0\}`, and service costs from `\{0.1,0.2,\ldots,1.0\}`. A 32-bit linear congruential generator used seed 20260911, multiplier 1664525, and increment 1013904223.

For each tree, all 64 subsets were checked. Direct unions of root paths agreed exactly with Proposition 2.2 in all 6,400 cases. All 19,200 available source-addition marginals agreed with (5).

Singleton and pair measurements were perturbed by values in `\{-1/20,0,1/20\}`. All 6,400 direct-estimate bounds and all 6,400 repaired-estimate bounds held, and every repaired overlap table satisfied (4). The sharpness construction was additionally checked for `m=2,\ldots,8`.

For the continuation results, each of the same 100 trees was checked for all disjoint nonempty pairs `A,S`. The number of such pairs per tree is

```math
3^6-2\cdot2^6+1=602.
```

Across all 60,200 cases, the forest reconstruction agreed with the direct additional path cost, the common-tolerance bound held, the lifted forest expression agreed with the contracted-graph estimator, and the heterogeneous interval contained the true continuation cost. Heterogeneous singleton bounds were selected from `\{0,1/20,2/20\}` and pair bounds from `\{1/20,2/20,3/20\}`; perturbations were drawn from the integer grid within each bound. The continuation lower bound was verified for anchor counts 1, 5, and 20 and new-source counts 1, 2, and 4, with a further 21 unequal-tolerance cases including exact singleton or exact pair measurements.

These finite checks support implementation consistency. The universal claims and minimax lower bounds follow from the proofs.

### 6.4. Continuation instability and policy sharpness

**Table 3. One new query in the construction of Proposition 3.4.**

| Earlier sources | True additional cost | Subtracted total estimates | Direct continuation estimate | Subtraction error |
| --- | --- | --- | --- | --- |
| 1 | 1.0 | 1.0 | 1.0 | 0.0 |
| 2 | 1.0 | 0.8 | 1.0 | 0.2 |
| 5 | 1.0 | 0.2 | 1.0 | 0.8 |
| 10 | 1.0 | -0.8 | 1.0 | 1.8 |
| 20 | 1.0 | -2.8 | 1.0 | 3.8 |

Here `a=2`, `b=1`, and `\varepsilon=0.05`. The direct estimator has worst-case radius 0.1 for every row. The first row is the singleton-anchor boundary case; the history-size claim in Proposition 3.4 applies from two anchors onward. This table is an analytic stress test with controlled perturbations, separate from the manufacturing illustration.

**Table 4. Approaching the sharp policy-loss factor.**

| Setting | Call budgets checked | `\eta/R` | Excess objective divided by `\lambda R` |
| --- | --- | --- | --- |
| Initial and continuation | 2, 3, 4 | 0.50 | 1.50 |
| Initial and continuation | 2, 3, 4 | 0.10 | 1.90 |
| Initial and continuation | 2, 3, 4 | 0.01 | 1.99 |

For the initial setting, `R=(2B-3)\varepsilon`; for continuation, `R=2b\varepsilon`. Each table row summarizes six exact calculations, giving 18 policy cases in total. They use `\varepsilon=0.05`, `\lambda=0.01`, the two-branch constructions in Theorems 4.3 and 4.4, and deterministic parity observations. The measured-optimal policies were evaluated under the true tree by full-outcome replay, and the true optimal values were computed separately. In every case the exact excess objective equaled `\lambda(2R-\eta)`.

The numerical package provides the tree and decision routines, verification driver, exact rational results, and CSV tables. These examples demonstrate the necessity of the constants under the theorem assumptions; they do not estimate typical calibration error or establish industrial performance.


## 7. Discussion and concluding remarks

The mathematical problem separates into identification, estimation, and decision making. Under the rooted-tree assumption, pairwise overlap data determine every acquisition cost. Under bounded measurement error, the cost of an `m`-source group has minimax recovery radius `(2m-3)\varepsilon`. This radius quantifies unavoidable amplification of measurement uncertainty, including cases in which the measured table itself is compatible with a tree.

Continuation recovery is the main extension beyond total-cost recovery. A forest rooted at the earlier acquisitions gives the exact radius `k(\varepsilon_1+\varepsilon_2)` for `k` new queries, independent of the size of the earlier set. The instability construction shows that this independence is an algorithmic improvement: direct subtraction of globally estimated costs can actually have error proportional to the history length. The result is useful when a coordinator revisits acquisition decisions after many routes have already been activated.

For sequential decisions, uniform cost recovery transfers directly to optimal-value and policy excess-loss guarantees. The matching policy constructions show that the factor two cannot be improved for surrogate-optimal policies within this class. They do not establish that a surrogate-optimal policy is the best possible uncertainty-aware decision procedure. The transfer does not depend on a particular diagnostic classifier, but it requires an unchanged observation model and a common call-constrained policy class. Likelihood misspecification, time-varying costs, repeated queries, resource deactivation, and hard monetary budgets require separate analysis.

The application illustrates how a coordinator can use the theory to choose sources and determine when to stop. It does not establish industrial validity or the performance of an implemented large-language-model system. Exact adaptive optimization remains exponential in the number of sources; scalable approximations need additional structure.

The counterexample in Section 5 identifies a substantive boundary: pair measurements suffice within the rooted-path class but do not suffice for general shared resources. Extensions to partially observed routing structures, higher-order calibration measurements, and joint uncertainty in costs and likelihoods provide concrete directions for further research.

## Declarations

**Funding:** [To be completed by the human authors.]

**Competing interests:** [To be completed by the human authors.]

**Author contributions:** [To be completed by the human authors.]

**Data and code availability:** No empirical dataset was collected. All parameters defining the synthetic decision instance are provided in Section 6. The accompanying Theorem_Strengthening_Supplement contains tree_recovery.py, verify_results.py, exact results, CSV tables, and a run log. Running the verification driver with Python 3.10 or later reproduces the computations without third-party packages. A permanent repository identifier should be added when the human authors archive the final submission package; no public repository is asserted in this draft.

**AI assistance:** ChatGPT was used to develop the mathematical formulation, proposed proofs, verification code, and manuscript text. Independent human verification of the mathematical claims, literature positioning, and final manuscript is required before submission.

## References

[1] A. V. Aho, Y. Sagiv, T. G. Szymanski, and J. D. Ullman, [Inferring a tree from lowest common ancestors with an application to the optimization of relational expressions](https://doi.org/10.1137/0210030), *SIAM Journal on Computing* **10** (1981), no. 3, 405–421.

[2] D. Blackwell, [Equivalent comparisons of experiments](https://doi.org/10.1214/aoms/1177729032), *The Annals of Mathematical Statistics* **24** (1953), no. 2, 265–272.

[3] D. Bryant and P. F. Tupper, [Hyperconvexity and tight-span theory for diversities](https://doi.org/10.1016/j.aim.2012.08.008), *Advances in Mathematics* **231** (2012), no. 6, 3172–3198. [Author preprint](https://arxiv.org/abs/1006.1095).

[4] P. Buneman, [A note on the metric properties of trees](https://doi.org/10.1016/0095-8956(74)90047-1), *Journal of Combinatorial Theory, Series B* **17** (1974), no. 1, 48–50.

[5] G. Carlsson and F. Mémoli, [Characterization, stability and convergence of hierarchical clustering methods](https://jmlr.csail.mit.edu/papers/v11/carlsson10a.html), *Journal of Machine Learning Research* **11** (2010), 1425–1470.

[6] H. Chernoff, [Sequential design of experiments](https://doi.org/10.1214/aoms/1177706205), *The Annals of Mathematical Statistics* **30** (1959), no. 3, 755–770.

[7] D. L. Donoho, [Statistical estimation and optimal recovery](https://doi.org/10.1214/aos/1176325367), *The Annals of Statistics* **22** (1994), no. 1, 238–270.

[8] D. P. Faith, [Conservation evaluation and phylogenetic diversity](https://doi.org/10.1016/0006-3207(92)91201-3), *Biological Conservation* **61** (1992), no. 1, 1–10.

[9] M. Farach, S. Kannan, and T. Warnow, [A robust model for finding optimal evolutionary trees](https://doi.org/10.1007/BF01188585), *Algorithmica* **13** (1995), 155–179.

[10] D. Golovin and A. Krause, [Adaptive submodularity: Theory and applications in active learning and stochastic optimization](https://doi.org/10.1613/jair.3278), *Journal of Artificial Intelligence Research* **42** (2011), 427–486.

[11] J. C. Gower and G. J. S. Ross, [Minimum spanning trees and single linkage cluster analysis](https://doi.org/10.2307/2346439), *Journal of the Royal Statistical Society, Series C: Applied Statistics* **18** (1969), no. 1, 54–64.

[12] D. Hunter, [An upper bound for the probability of a union](https://doi.org/10.2307/3212481), *Journal of Applied Probability* **13** (1976), no. 3, 597–603.

[13] G. N. Iyengar, [Robust dynamic programming](https://doi.org/10.1287/moor.1040.0129), *Mathematics of Operations Research* **30** (2005), no. 2, 257–280.

[14] L. P. Kaelbling, M. L. Littman, and A. R. Cassandra, [Planning and acting in partially observable stochastic domains](https://doi.org/10.1016/S0004-3702(98)00023-X), *Artificial Intelligence* **101** (1998), nos. 1–2, 99–134.

[15] A. Krause, H. B. McMahan, C. Guestrin, and A. Gupta, [Robust submodular observation selection](https://jmlr.org/papers/v9/krause08b.html), *Journal of Machine Learning Research* **9** (2008), 2761–2801.

[16] Y. Li and J. Oliva, [Active feature acquisition with generative surrogate models](https://proceedings.mlr.press/v139/li21p.html), in *Proceedings of the 38th International Conference on Machine Learning*, Proceedings of Machine Learning Research **139** (2021), 6450–6459.

[17] C. Ma, S. Tschiatschek, K. Palla, J. M. Hernandez-Lobato, S. Nowozin, and C. Zhang, [EDDI: Efficient dynamic discovery of high-value information with partial VAE](https://proceedings.mlr.press/v97/ma19c.html), in *Proceedings of the 36th International Conference on Machine Learning*, Proceedings of Machine Learning Research **97** (2019), 4234–4243.

[18] J. Márkus, M. Pintér, and A. Radványi, [The Shapley value for airport and irrigation games](https://doi.org/10.1007/s10100-026-01039-5), *Central European Journal of Operations Research* (2026), published online 22 August 2026.

[19] M. Naghshvar and T. Javidi, [Active sequential hypothesis testing](https://doi.org/10.1214/13-AOS1144), *The Annals of Statistics* **41** (2013), no. 6, 2703–2738.

[20] G. L. Nemhauser, L. A. Wolsey, and M. L. Fisher, [An analysis of approximations for maximizing submodular set functions—I](https://doi.org/10.1007/BF01588971), *Mathematical Programming* **14** (1978), 265–294.

[21] A. Nilim and L. El Ghaoui, [Robust control of Markov decision processes with uncertain transition matrices](https://doi.org/10.1287/opre.1050.0216), *Operations Research* **53** (2005), no. 5, 780–798.

[22] L. Pachter and D. Speyer, [Reconstructing trees from subtree weights](https://arxiv.org/abs/math/0311156), *Applied Mathematics Letters* **17** (2004), no. 6, 615–621. Link provides the authors’ preprint.

[23] Z. Qin and Y. Lu, [Knowledge graph-enhanced multi-agent reinforcement learning for adaptive scheduling in smart manufacturing](https://doi.org/10.1007/s10845-024-02494-0), *Journal of Intelligent Manufacturing* **36** (2025), 5943–5966.

[24] R. D. Smallwood and E. J. Sondik, [The optimal control of partially observable Markov processes over a finite horizon](https://doi.org/10.1287/opre.21.5.1071), *Operations Research* **21** (1973), no. 5, 1071–1088.

[25] M. Steel, A. Mimoto, and A. Ø. Mooers, [Hedging our bets: The expected contribution of species to future phylogenetic diversity](https://doi.org/10.1177/117693430700300024), *Evolutionary Bioinformatics* **3** (2007), 237–244. [Open full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC2684137/).

[26] A. Wald, [Sequential tests of statistical hypotheses](https://doi.org/10.1214/aoms/1177731118), *The Annals of Mathematical Statistics* **16** (1945), no. 2, 117–186.

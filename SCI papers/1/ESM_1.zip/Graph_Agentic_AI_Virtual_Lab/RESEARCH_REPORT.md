# Virtual Factory Agent Research — Measured Pilot Report

**Version 0.1.0 · synthetic data only · probabilistic agents · LLM experiments pending**

This deliverable contains executable code, generated observations with separate hidden labels, fitted specialist agents, a weighted communication graph, comparison experiments, raw results, investigation traces, and integrity checks. The numbers below were calculated by running the included code. They are not invented manuscript results or observations from an operating factory.

## What the initial experiment establishes

At the declared four-call budget, graph-cost-aware selection achieved **92.00%** identification accuracy in the standard synthetic condition, versus **91.93%** for adaptive information selection. Its mean assumed cost was **14.706** versus **15.120** units, a **2.74%** reduction.

The paired accuracy difference was +0.07 percentage points (seed-block bootstrap 95% interval -0.64 to +0.93). The interval includes zero. This pilot does **not** establish an accuracy advantage over the stronger adaptive comparator. The main signal is an accuracy–cost tradeoff under explicitly assumed costs. Most improvement over the fixed and random comparators comes from adaptive evidence selection, not a demonstrated graph-theory breakthrough.

## Experimental scope

The run used 5 independent seeds, 5,250 fitting episodes and 3,500 calibration episodes. There were **5,600 held-out episodes** across four conditions. Four policies were each evaluated at two, four and six tool calls, giving **67,200 scored policy evaluations**.

Each condition is balanced across normal operation, tool wear, coolant loss, material delay, scheduling overload, spindle fault and assembly misalignment. Each abnormal case has one injected cause plus background variation. These are artificial class prevalences, not factory incident rates.

The environment covers abstract indicators of component machining and complete CNC-machine assembly. It is an episode-level stochastic structural simulator. There is no physical factory calibration, time-step production engine, MES/ERP integration or machine-control interface.

## Primary results: four specialist calls

Each accuracy entry is a percentage. Lower assumed cost is better. All policies share the same trained specialists, observation interfaces and Bayesian diagnosis rule.

| Condition | Policy | Accuracy | Mean cost | Brier score |
|---|---|---:|---:|---:|
| Standard | Fixed order | 75.79% | 15.400 | 0.297 |
| Standard | Random selection | 80.07% | 15.647 | 0.256 |
| Standard | Adaptive information | 91.93% | 15.120 | 0.122 |
| Standard | Adaptive graph cost | 92.00% | 14.706 | 0.122 |
| Missing records | Fixed order | 65.36% | 15.400 | 0.415 |
| Missing records | Random selection | 66.86% | 15.647 | 0.399 |
| Missing records | Adaptive information | 74.50% | 15.093 | 0.310 |
| Missing records | Adaptive graph cost | 74.36% | 14.582 | 0.308 |
| Noisy records | Fixed order | 60.07% | 15.400 | 0.559 |
| Noisy records | Random selection | 61.21% | 15.647 | 0.548 |
| Noisy records | Adaptive information | 69.64% | 15.191 | 0.448 |
| Noisy records | Adaptive graph cost | 70.36% | 14.766 | 0.437 |
| Mechanism shift | Fixed order | 74.43% | 15.400 | 0.326 |
| Mechanism shift | Random selection | 77.07% | 15.647 | 0.302 |
| Mechanism shift | Adaptive information | 87.43% | 15.013 | 0.174 |
| Mechanism shift | Adaptive graph cost | 87.50% | 14.663 | 0.172 |

Brier score measures error in the full probability vector; lower is better. Conditional dependence between sources can make the Bayesian confidence estimates miscalibrated.

The fixed order queries telemetry, quality, maintenance and materials at budget four. It therefore omits scheduling and assembly at that budget. This is a weak fixed baseline and is not tuned to maximize performance. The adaptive-information policy is the more informative comparison for the graph-cost component.

## Paired comparison with the stronger adaptive baseline

Differences below are graph-cost policy minus adaptive-information policy at four calls. Accuracy is in percentage points; cost is in assumed units. Intervals resample seed blocks, which preserves shared-model dependence within each seed. Five blocks are a small pilot sample.

| Condition | Accuracy difference (95% interval) | Cost difference (95% interval) |
|---|---:|---:|
| Standard | +0.07 (-0.64, +0.93) | -0.414 (-0.556, -0.282) |
| Missing records | -0.14 (-1.29, +0.86) | -0.511 (-0.576, -0.445) |
| Noisy records | +0.71 (+0.29, +1.14) | -0.426 (-0.529, -0.324) |
| Mechanism shift | +0.07 (-0.21, +0.36) | -0.349 (-0.463, -0.248) |

These exploratory intervals are unadjusted for multiple comparisons. They do not establish causal validity, real-world generalization or acceptance by a journal.

## Tool-budget sensitivity: standard condition

| Calls | Fixed accuracy | Random accuracy | Adaptive-information accuracy | Graph-cost accuracy |
|---:|---:|---:|---:|---:|
| 2 | 61.21% | 57.50% | 72.79% | 71.43% |
| 4 | 75.79% | 80.07% | 91.93% | 92.00% |
| 6 | 94.57% | 94.57% | 94.57% | 94.57% |

At six calls, all policies observe the same six sources, so their diagnosis distributions and costs should coincide. This is a built-in experimental control, and it was checked across all cases. It is not an all-to-all multi-agent communication experiment.

## What makes the prototype agent-like

A controller pursues an investigation goal, selects a specialist tool, reads its result, updates a belief state, and selects the next tool. Each specialist owns an evidence source. The adaptive policies react to observed results. This is a symbolic/probabilistic agent system, not an LLM-based agentic AI result.

The graph policy uses expected information gain divided by the cost of a shortest request/return route plus service cost. The infrastructure graph is fixed; the chosen execution subgraph grows as sources are queried. It does not learn or rewire communication topology. The combination uses established methods; a novel algorithm has not been established.

Traces include source identifiers, observations, selection scores, route paths and posterior updates. They show the observable investigation process. A cited source proves provenance, not the truth of an inferred causal conclusion.

## What was actually verified

The integrity suite checks seeded regeneration, split separation, hidden-label exclusion from the observation interface, budgets, evidence provenance, missing-data behavior, routing and rejection of invalid local-model decisions. The full result audit checks checksums, every evaluation, every summary and full-budget equivalence. A second full run is compared separately in results/reproducibility.json when present.

Recorded environment: Python 3.12.14, NumPy 2.3.5. The complete first benchmark run took 18.90 seconds in this environment. That number is harness runtime; it is not inference latency for an LLM or a performance forecast for your servers.

## How synthetic experiments can support the paper

Synthetic experiments provide controlled interventions, repeatable failures and known evaluation labels. The simulator itself needs a defensible specification and independent validation. Here, the fitting data and most test conditions share a generator, which creates a substantial risk of learning its assumptions. The shift condition changes only a small number of mechanisms. It does not establish transfer to a different factory.

NIST identifies verification, validation and uncertainty quantification as central to credible manufacturing digital twins. Without physical calibration, this deliverable should be called a synthetic benchmark or virtual testbed. [NIST credibility study](https://www.nist.gov/publications/credibility-consideration-digital-twins-manufacturing)

A submission should disclose the generator, distributions, structural assumptions, labels, random seeds, training/calibration splits, costs, prompts, model versions and failed runs. We should not rewrite synthetic observations as collected factory records or substitute plausible percentages for executed experiments.

## Development required before an Agentic AI submission

1. **Demonstrate a research contribution.** Complete a systematic novelty comparison; choose a specific theoretical or empirical advance beyond the current combination of known methods.
2. **Run actual local LLM experiments.** The supplied Ollama connector lets a local model choose specialists; diagnosis remains probabilistic. Only a mocked validation test was run here. Full benchmark support, repeated model runs and live model validation remain to be completed.
3. **Add strong baselines.** Include a matched single-agent system, robust fixed workflows and published graph-agent methods with comparable models and budgets.
4. **Challenge the generator.** Test multiple independently designed factories, graph topologies, cost scales, correlated missingness, contradictory reports, multiple and unknown faults, and abstention when evidence is insufficient.
5. **Validate industrial relevance.** Obtain manufacturing-expert review and, where possible, public real data or a small industrial case study. A simulated MES context attached to a real sensor dataset must remain labeled as simulated.
6. **Write results after execution.** Maintain separate tables for symbolic, LLM, simulated and real-data experiments. Report unfavorable results and limits.

## Journal and title

For a completed manufacturing-focused study, the first scope-based target remains **Journal of Intelligent Manufacturing**. Its publisher explicitly lists SCIE indexing and AI applications in manufacturing. [Publisher page](https://link.springer.com/journal/10845)

Use **Cost-Aware Evidence Acquisition on Agent Communication Graphs: A Synthetic Manufacturing Benchmark** to describe the current pilot accurately. After actual LLM-agent experiments and a stronger contribution, the earlier working title remains suitable: **Graph-Theoretic Orchestration of Agentic AI for Evidence-Based Root Cause Analysis in Smart Manufacturing**.

## Primary references and baseline candidates

- Zhuge, M., Wang, W., Kirsch, L., Faccio, F., Khizbullin, D., and Schmidhuber, J. (2024). GPTSwarm: Language Agents as Optimizable Graphs. ICML. [Paper](https://proceedings.mlr.press/v235/zhuge24a.html)
- Zhang, G., Yue, Y., Sun, X., Wan, G., Yu, M., Fang, J., Wang, K., Chen, T., and Cheng, D. (2025). G-Designer: Architecting Multi-agent Communication Topologies via Graph Neural Networks. ICML. [Paper](https://proceedings.mlr.press/v267/zhang25cu.html)
- Farahani, M. A., Khan, M. I., and Wuest, T. (2026). Hybrid agentic AI and multi-agent systems in smart manufacturing. Journal of Manufacturing Systems. [Article](https://doi.org/10.1016/j.jmsy.2026.04.002)
- Shao, G., Hightower, J., and Schindel, W. (2023; NIST record posted 2022). Credibility consideration for digital twins in manufacturing. Manufacturing Letters, 35, 24–28. [NIST project and citation](https://www.nist.gov/programs-projects/digital-twins-advanced-manufacturing)

The related agent papers were reviewed as background; their implementations were not run in this pilot.

## Reproduce and inspect

See README.md for Windows and Linux commands. RESEARCH_REPORT.md is regenerated with make_report.py; the figure is in docs/primary_results.png and docs/primary_results.svg. Raw observations, hidden evaluator labels, fitted models, every prediction and all comparison tables are included in the package.

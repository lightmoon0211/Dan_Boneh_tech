"""Generate the report and publication-style plot from measured JSON results."""
import argparse
import gzip
import json
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

LABELS={"fixed":"Fixed order","random":"Random selection","adaptive_information":"Adaptive information","adaptive_graph":"Adaptive graph cost"}
POLICIES=list(LABELS)
CONDITIONS=["standard","missing","noisy","shift"]
COND_LABELS={"standard":"Standard","missing":"Missing records","noisy":"Noisy records","shift":"Mechanism shift"}

def main(args):
    root=Path(args.results); project=Path(__file__).parent
    rows=json.loads((root/"summary.json").read_text())
    cfg=json.loads((root/"configuration.json").read_text())
    comps=json.loads((root/"paired_comparisons.json").read_text())
    runtime=json.loads((root/"runtime.json").read_text())
    def get(c,p,b=4): return next(r for r in rows if r["condition"]==c and r["policy"]==p and r["budget"]==b)
    p=project/"docs"; p.mkdir(exist_ok=True)
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":10,"axes.spines.top":False,"axes.spines.right":False})
    fig,axes=plt.subplots(1,2,figsize=(12,5.8))
    fig.subplots_adjust(left=.075,right=.99,top=.84,bottom=.24,wspace=.30)
    colors=["#9ca3af","#c49a6c","#6787b7","#124559"]
    x=np.arange(4); width=.19
    for i,policy in enumerate(POLICIES):
        vals=[get(c,policy) for c in CONDITIONS]
        ys=np.array([v["accuracy"]*100 for v in vals])
        low=ys-np.array([v["accuracy_wilson_95"][0]*100 for v in vals])
        high=np.array([v["accuracy_wilson_95"][1]*100 for v in vals])-ys
        axes[0].bar(x+(i-1.5)*width,ys,width,color=colors[i],label=LABELS[policy],yerr=[low,high],capsize=2,error_kw={"linewidth":.7})
        axes[1].bar(x+(i-1.5)*width,[v["mean_cost"] for v in vals],width,color=colors[i],label=LABELS[policy])
    for ax in axes:
        ax.set_xticks(x,["Standard","Missing","Noisy","Shift"])
        ax.grid(axis="y",alpha=.18);ax.set_axisbelow(True)
    axes[0].set_ylabel("Injected-condition identification accuracy (%)")
    axes[0].set_ylim(0,100);axes[0].set_title("A  Accuracy at four tool calls",loc="left",fontweight="bold")
    axes[1].set_ylabel("Mean assumed routing + service cost (units)")
    axes[1].set_ylim(0,18);axes[1].set_title("B  Simulated investigation cost",loc="left",fontweight="bold")
    fig.suptitle("Synthetic manufacturing pilot · probabilistic agents · no LLM execution",fontsize=13,fontweight="bold")
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc="lower center",bbox_to_anchor=(.5,.07),ncols=4,fontsize=9,frameon=False)
    fig.supxlabel("Independent synthetic conditions; error bars are pooled Wilson 95% intervals, not physical-validation uncertainty.",fontsize=9,y=.018)
    fig.savefig(p/"primary_results.png",dpi=180)
    fig.savefig(p/"primary_results.svg")
    plt.close(fig)

    lines=["# Virtual Factory Agent Research — Measured Pilot Report", "",
           "**Version 0.1.0 · synthetic data only · probabilistic agents · LLM experiments pending**", "",
           "This deliverable contains executable code, generated observations with separate hidden labels, "
           "fitted specialist agents, a weighted communication graph, comparison experiments, raw results, "
           "investigation traces, and integrity checks. The numbers below were calculated by running the included code. "
           "They are not invented manuscript results or observations from an operating factory.", "",
           "## What the initial experiment establishes", ""]
    g=get("standard","adaptive_graph"); a=get("standard","adaptive_information")
    delta=next(c for c in comps if c["condition"]=="standard" and c["baseline"]=="adaptive_information")
    ci=delta["accuracy_difference_seed_bootstrap_95"]
    lines += [f"At the declared four-call budget, graph-cost-aware selection achieved **{100*g['accuracy']:.2f}%** "
              f"identification accuracy in the standard synthetic condition, versus **{100*a['accuracy']:.2f}%** for "
              f"adaptive information selection. Its mean assumed cost was **{g['mean_cost']:.3f}** versus "
              f"**{a['mean_cost']:.3f}** units, a **{100*(1-g['mean_cost']/a['mean_cost']):.2f}%** reduction.", "",
              f"The paired accuracy difference was {100*delta['accuracy_difference']:+.2f} percentage points "
              f"(seed-block bootstrap 95% interval {100*ci[0]:+.2f} to {100*ci[1]:+.2f}). "
              "The interval includes zero. This pilot does **not** establish an accuracy advantage over the stronger adaptive comparator. "
              "The main signal is an accuracy–cost tradeoff under explicitly assumed costs. Most improvement over the fixed "
              "and random comparators comes from adaptive evidence selection, not a demonstrated graph-theory breakthrough.", "",
              "## Experimental scope", "",
              f"The run used {len(cfg['seeds'])} independent seeds, "
              f"{len(cfg['seeds'])*7*cfg['train_per_cause']:,} fitting episodes and "
              f"{len(cfg['seeds'])*7*cfg['calibration_per_cause']:,} calibration episodes. "
              f"There were **{len(cfg['seeds'])*7*cfg['test_per_cause_per_condition']*4:,} held-out episodes** "
              "across four conditions. Four policies were each evaluated at two, four and six tool calls, "
              f"giving **{len(cfg['seeds'])*7*cfg['test_per_cause_per_condition']*4*12:,} scored policy evaluations**.", "",
              "Each condition is balanced across normal operation, tool wear, coolant loss, material delay, "
              "scheduling overload, spindle fault and assembly misalignment. Each abnormal case has one injected "
              "cause plus background variation. These are artificial class prevalences, not factory incident rates.", "",
              "The environment covers abstract indicators of component machining and complete CNC-machine assembly. "
              "It is an episode-level stochastic structural simulator. There is no physical factory calibration, "
              "time-step production engine, MES/ERP integration or machine-control interface.", "",
              "## Primary results: four specialist calls", "",
              "Each accuracy entry is a percentage. Lower assumed cost is better. All policies share the same "
              "trained specialists, observation interfaces and Bayesian diagnosis rule.", "",
              "| Condition | Policy | Accuracy | Mean cost | Brier score |", "|---|---|---:|---:|---:|"]
    for c in CONDITIONS:
        for policy in POLICIES:
            r=get(c,policy)
            lines.append(f"| {COND_LABELS[c]} | {LABELS[policy]} | {100*r['accuracy']:.2f}% | {r['mean_cost']:.3f} | {r['mean_brier']:.3f} |")
    lines += ["", "Brier score measures error in the full probability vector; lower is better. Conditional dependence "
              "between sources can make the Bayesian confidence estimates miscalibrated.", "",
              "The fixed order queries telemetry, quality, maintenance and materials at budget four. It therefore omits "
              "scheduling and assembly at that budget. This is a weak fixed baseline and is not tuned to maximize "
              "performance. The adaptive-information policy is the more informative comparison for the graph-cost component.", "",
              "## Paired comparison with the stronger adaptive baseline", "",
              "Differences below are graph-cost policy minus adaptive-information policy at four calls. "
              "Accuracy is in percentage points; cost is in assumed units. Intervals resample seed blocks, "
              "which preserves shared-model dependence within each seed. Five blocks are a small pilot sample.", "",
              "| Condition | Accuracy difference (95% interval) | Cost difference (95% interval) |", "|---|---:|---:|"]
    for c in CONDITIONS:
        r=next(v for v in comps if v["condition"]==c and v["baseline"]=="adaptive_information")
        lo,hi=r["accuracy_difference_seed_bootstrap_95"]; cl,ch=r["cost_difference_seed_bootstrap_95"]
        lines.append(f"| {COND_LABELS[c]} | {100*r['accuracy_difference']:+.2f} ({100*lo:+.2f}, {100*hi:+.2f}) | {r['mean_cost_difference']:+.3f} ({cl:+.3f}, {ch:+.3f}) |")
    lines += ["", "These exploratory intervals are unadjusted for multiple comparisons. They do not establish "
              "causal validity, real-world generalization or acceptance by a journal.", "",
              "## Tool-budget sensitivity: standard condition", "",
              "| Calls | Fixed accuracy | Random accuracy | Adaptive-information accuracy | Graph-cost accuracy |", "|---:|---:|---:|---:|---:|"]
    for b in (2,4,6):
        lines.append("| "+str(b)+" | "+" | ".join(f"{100*get('standard',p,b)['accuracy']:.2f}%" for p in POLICIES)+" |")
    lines += ["", "At six calls, all policies observe the same six sources, so their diagnosis distributions and "
              "costs should coincide. This is a built-in experimental control, and it was checked across all cases. "
              "It is not an all-to-all multi-agent communication experiment.", "",
              "## What makes the prototype agent-like", "",
              "A controller pursues an investigation goal, selects a specialist tool, reads its result, updates "
              "a belief state, and selects the next tool. Each specialist owns an evidence source. The adaptive "
              "policies react to observed results. This is a symbolic/probabilistic agent system, not an "
              "LLM-based agentic AI result.", "",
              "The graph policy uses expected information gain divided by the cost of a shortest request/return "
              "route plus service cost. The infrastructure graph is fixed; the chosen execution subgraph grows "
              "as sources are queried. It does not learn or rewire communication topology. The combination uses "
              "established methods; a novel algorithm has not been established.", "",
              "Traces include source identifiers, observations, selection scores, route paths and posterior updates. "
              "They show the observable investigation process. A cited source proves provenance, not the truth "
              "of an inferred causal conclusion.", "",
              "## What was actually verified", "",
              "The integrity suite checks seeded regeneration, split separation, hidden-label exclusion from the "
              "observation interface, budgets, evidence provenance, missing-data behavior, routing and rejection "
              "of invalid local-model decisions. The full result audit checks checksums, every evaluation, every "
              "summary and full-budget equivalence. A second full run is compared separately in "
              "results/reproducibility.json when present.", "",
              f"Recorded environment: Python {runtime['python']}, NumPy {runtime['numpy']}. "
              f"The complete first benchmark run took {runtime['wall_seconds']:.2f} seconds in this environment. "
              "That number is harness runtime; it is not inference latency for an LLM or a performance forecast "
              "for your servers.", "",
              "## How synthetic experiments can support the paper", "",
              "Synthetic experiments provide controlled interventions, repeatable failures and known evaluation "
              "labels. The simulator itself needs a defensible specification and independent validation. "
              "Here, the fitting data and most test conditions share a generator, which creates a substantial "
              "risk of learning its assumptions. The shift condition changes only a small number of mechanisms. "
              "It does not establish transfer to a different factory.", "",
              "NIST identifies verification, validation and uncertainty quantification as central to credible "
              "manufacturing digital twins. Without physical calibration, this deliverable should be called a "
              "synthetic benchmark or virtual testbed. [NIST credibility study](https://www.nist.gov/publications/credibility-consideration-digital-twins-manufacturing)", "",
              "A submission should disclose the generator, distributions, structural assumptions, labels, "
              "random seeds, training/calibration splits, costs, prompts, model versions and failed runs. "
              "We should not rewrite synthetic observations as collected factory records or substitute "
              "plausible percentages for executed experiments.", "",
              "## Development required before an Agentic AI submission", "",
              "1. **Demonstrate a research contribution.** Complete a systematic novelty comparison; choose "
              "a specific theoretical or empirical advance beyond the current combination of known methods.",
              "2. **Run actual local LLM experiments.** The supplied Ollama connector lets a local model choose "
              "specialists; diagnosis remains probabilistic. Only a mocked validation test was run here. "
              "Full benchmark support, repeated model runs and live model validation remain to be completed.",
              "3. **Add strong baselines.** Include a matched single-agent system, robust fixed workflows and "
              "published graph-agent methods with comparable models and budgets.",
              "4. **Challenge the generator.** Test multiple independently designed factories, graph topologies, "
              "cost scales, correlated missingness, contradictory reports, multiple and unknown faults, "
              "and abstention when evidence is insufficient.",
              "5. **Validate industrial relevance.** Obtain manufacturing-expert review and, where possible, "
              "public real data or a small industrial case study. A simulated MES context attached to a real "
              "sensor dataset must remain labeled as simulated.",
              "6. **Write results after execution.** Maintain separate tables for symbolic, LLM, simulated and "
              "real-data experiments. Report unfavorable results and limits.", "",
              "## Journal and title", "",
              "For a completed manufacturing-focused study, the first scope-based target remains "
              "**Journal of Intelligent Manufacturing**. Its publisher explicitly lists SCIE indexing and "
              "AI applications in manufacturing. [Publisher page](https://link.springer.com/journal/10845)", "",
              "Use **Cost-Aware Evidence Acquisition on Agent Communication Graphs: A Synthetic Manufacturing "
              "Benchmark** to describe the current pilot accurately. After actual LLM-agent experiments and "
              "a stronger contribution, the earlier working title remains suitable: **Graph-Theoretic "
              "Orchestration of Agentic AI for Evidence-Based Root Cause Analysis in Smart Manufacturing**.", "",
              "## Primary references and baseline candidates", "",
              "- Zhuge, M., Wang, W., Kirsch, L., Faccio, F., Khizbullin, D., and Schmidhuber, J. (2024). "
              "GPTSwarm: Language Agents as Optimizable Graphs. ICML. "
              "[Paper](https://proceedings.mlr.press/v235/zhuge24a.html)",
              "- Zhang, G., Yue, Y., Sun, X., Wan, G., Yu, M., Fang, J., Wang, K., Chen, T., and Cheng, D. (2025). "
              "G-Designer: Architecting Multi-agent Communication Topologies via Graph Neural Networks. ICML. "
              "[Paper](https://proceedings.mlr.press/v267/zhang25cu.html)",
              "- Farahani, M. A., Khan, M. I., and Wuest, T. (2026). Hybrid agentic AI and multi-agent systems "
              "in smart manufacturing. Journal of Manufacturing Systems. "
              "[Article](https://doi.org/10.1016/j.jmsy.2026.04.002)",
              "- Shao, G., Hightower, J., and Schindel, W. (2023; NIST record posted 2022). Credibility "
              "consideration for digital twins in manufacturing. Manufacturing Letters, 35, 24–28. "
              "[NIST project and citation](https://www.nist.gov/programs-projects/digital-twins-advanced-manufacturing)", "",
              "The related agent papers were reviewed as background; their implementations were not run in this pilot.", "",
              "## Reproduce and inspect", "",
              "See README.md for Windows and Linux commands. RESEARCH_REPORT.md is regenerated with "
              "make_report.py; the figure is in docs/primary_results.png and docs/primary_results.svg. "
              "Raw observations, hidden evaluator labels, fitted models, every prediction and all comparison "
              "tables are included in the package.", ""]
    (project/"RESEARCH_REPORT.md").write_text("\n".join(lines),encoding="utf-8")
    print("Created RESEARCH_REPORT.md and primary-results PNG/SVG from measured results.")

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--results",default="results")
    main(p.parse_args())

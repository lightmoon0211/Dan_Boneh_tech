# Experiment protocol — synthetic pilot v0.1.0

Status: specified before the first full benchmark run in this deliverable. This
is an internal protocol, not an externally registered preregistration.

## Purpose and permitted claims

Assess whether adaptive evidence acquisition changes the accuracy–cost tradeoff
of probabilistic specialist agents in an assumed manufacturing structural model.
The pilot tests a graph-based investigation controller. It does not measure LLM
reasoning, real factory performance, real communication traffic, or machine safety.
No measured values may be relabeled as industrial observations.

Research hypothesis: expected information gain divided by graph routing and
service cost can reduce investigation cost at comparable diagnostic accuracy.
This is a hypothesis; all results, including unfavorable ones, are retained.
The graph policy combines established techniques. Novelty has not been established.

## Factory scope

The virtual environment abstracts two activities: machining components and
assembling/calibrating complete CNC machines. Thirteen observed features cover
telemetry, quality, maintenance, materials, scheduling, and assembly. Two output
KPIs provide context. The policies deliberately do not use those KPIs as additional
diagnostic inputs, ensuring the same six evidence interfaces for every policy.

The seven classes are normal, tool wear, coolant loss, material delay, scheduling
overload, spindle fault, and assembly misalignment. Each abnormal episode has ONE
dominant injected cause and background latent variation. Labels identify the
injection; they are not expert-adjudicated physical root causes.

This is an episode-level stochastic structural simulator. It is not a discrete-event
factory scheduler, calibrated physics model, longitudinal digital twin, MES/ERP,
or validated model of any Siemens controller. Its coefficients, costs and noise
distributions are explicit research assumptions in simulator.py and agents.py.

## Data split and budgets

- Five independent seeds: 101–105.
- Per seed: 1,050 fitting episodes, 700 calibration episodes.
- Per condition and seed: 280 held-out episodes, balanced across seven classes.
- Four held-out conditions: standard; 30% independent source missingness;
  1.9x observation noise; and mechanism/offset shift.
- Total: 5,600 held-out episodes; 8,750 fitting/calibration episodes.
- Four policies, each evaluated at 2, 4 and 6 specialist calls.
- Total measured policy evaluations: 67,200.
- Primary declared tool-call budget: 4. Budgets 2 and 6 are sensitivity checks.
- Every query costs one call, including a missing result. No early stopping.
- Equal tool-call budgets do not mean equal communication costs. Both are reported.
- Communication costs are ASSUMED units; no token-cost or runtime inference is valid.

Conditions use independent samples with the same class balance. Cross-condition
changes therefore include sampling variation; policy comparisons within a condition
are paired on identical cases. Training and calibration always use the standard
generator. Models and parameters are not refit on held-out conditions.

## Agents and algorithm

Each specialist uses a diagonal Gaussian classifier trained on its permitted
feature group. It returns a discrete signature, observed values, record identifier
and route. A held-out calibration set estimates P(signature | cause) with Laplace
smoothing. The controller uses a uniform prior and multiplies the likelihoods of
queried groups. This assumes conditional independence, which the shared latent
variables violate; posterior confidence is therefore a model score, not an assured
probability. Brier score is reported to expose probabilistic error.

Let p(c) be the current class posterior and L_d(y|c) the calibrated emission for
specialist d. Define q_d(y) = sum_c p(c)L_d(y|c), and update p(c|y,d) proportionally
to p(c)L_d(y|c). Expected information gain is

    I(d) = H(p) - sum_y q_d(y) H(p(.|y,d)).

The communication network is a fixed weighted undirected graph with a planner
and six specialists. Dijkstra shortest paths give request paths; return paths are
assumed symmetric. Set C(d) = 2*distance(planner,d) + service(d). The graph policy
selects argmax_d I(d)/C(d) among unqueried sources. The selected execution subgraph
expands with the chosen routes. The infrastructure graph itself is NOT learned or
rewired. This distinction limits claims of topology optimization.

Policies:

1. fixed: telemetry, quality, maintenance, materials, scheduling, assembly.
2. random: seeded random selection without replacement.
3. adaptive_information: maximize expected information gain; ignore routing cost
   during selection, but charge the same actual simulated cost at evaluation.
4. adaptive_graph: maximize information gain per routing-plus-service cost.

All policies share the SAME fitted specialists, inference rule, evidence and
budgets. These are acquisition policies for one modular agent system. The fixed
policy is not a single-LLM baseline and budget six is not an all-to-all MAS.
GPTSwarm and G-Designer have not been implemented or benchmarked here.

## Ground truth and evidence controls

Observations and evaluator labels are in separate files. Opaque case identifiers
do not encode readable class labels. The investigator receives only an Observation
and a previously fitted model. Each specialist can return only its own record.
Recorded evidence IDs refer to actually queried sources. The traces show tool
selection scores, outputs and posterior updates; they are an observable execution
record, not hidden LLM chain of thought. A record's provenance does not prove that
the inferred diagnosis is correct.

The Python process is a research harness, not a hostile-code sandbox. A future
LLM must be restricted to the observation tools and must not receive arbitrary
filesystem access to ground_truth.jsonl.

## Metrics and statistics

Report top-1 and top-3 identification accuracy, multiclass Brier score, mean
communication cost, total assumed cost, missing calls and per-seed metrics.
Accuracy Wilson intervals pool independent cases under the assumed generator;
shared fitted models mean they do not capture all between-training uncertainty.
Primary paired differences use 2,000 bootstrap resamples of seed blocks and are
reported for graph versus each other policy at budget four. Five seed blocks
are a small pilot sample. Intervals are exploratory and unadjusted for multiple
comparisons; they do not establish real-world superiority or causal validity.

## Required validity checks

1. Identical seeds and software yield identical observations and result values.
2. Fitting, calibration and held-out identifiers do not overlap.
3. Agents cannot query the evaluator label through the tool interface.
4. Every policy respects the same call budget and cites queried record IDs.
5. At budget six, all policies have equivalent posteriors and the same cost.
6. Missing sources add no likelihood evidence.
7. The optional LLM connector rejects unknown/duplicate tools without fallback.

## Path to an Agentic AI journal paper

This pilot is a foundation, not a completed submission. Add actual locally hosted
LLM planning experiments, controlled specialist prompts and model versions, strong
published agent baselines, a single-agent baseline, multiple simulator structures,
cost/topology sensitivity, unknown and multiple simultaneous faults, abstention,
and independent domain-expert review. Where possible include public real datasets
or industrial validation. A public sensor dataset cannot be presented as real
ERP/MES evidence if its operational context was synthesized.

Do not call this a validated digital twin without calibration and validation
against a physical reference. NIST discusses verification, validation and
uncertainty quantification as requirements for credible manufacturing twins:
https://www.nist.gov/publications/credibility-consideration-digital-twins-manufacturing

Journal of Intelligent Manufacturing remains a scope-based target for a completed
AI/manufacturing study. Its publisher lists SCIE coverage:
https://link.springer.com/journal/10845

Related baselines to review:
- Zhuge et al. (2024). GPTSwarm: Language Agents as Optimizable Graphs.
  https://proceedings.mlr.press/v235/zhuge24a.html
- Zhang et al. (2025). G-Designer: Architecting Multi-agent Communication
  Topologies via Graph Neural Networks.
  https://proceedings.mlr.press/v267/zhang25cu.html
- Farahani, Khan and Wuest (2026). Hybrid agentic AI and multi-agent systems
  in smart manufacturing. https://doi.org/10.1016/j.jmsy.2026.04.002

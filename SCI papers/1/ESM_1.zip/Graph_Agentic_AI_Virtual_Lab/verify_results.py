"""Audit every published evaluation against its allowed observations and budget."""
import gzip
import hashlib
import json
from collections import defaultdict
from pathlib import Path
import argparse

def verify(root):
    checks=json.loads((root/"checksums.json").read_text())
    for name,expected in checks.items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
    observations={}; truths={}; split_sets=defaultdict(set)
    for path in (root/"data").rglob("observations.jsonl"):
        split=path.parent.name
        for line in path.read_text().splitlines():
            o=json.loads(line)
            assert o["case_id"] not in observations
            observations[o["case_id"]]=o
            split_sets[split].add(o["case_id"])
    for path in (root/"data").rglob("ground_truth.jsonl"):
        for line in path.read_text().splitlines():
            t=json.loads(line); truths[t["case_id"]]=t["cause"]
    assert set(observations)==set(truths)
    split_names=list(split_sets)
    for i,a in enumerate(split_names):
        for b in split_names[i+1:]: assert not split_sets[a]&split_sets[b]
    totals=defaultdict(lambda:[0,0,0.]); full=defaultdict(list); n=0
    with gzip.open(root/"predictions.jsonl.gz","rt") as f:
        for line in f:
            row=json.loads(line); n+=1
            o=observations[row["case_id"]]
            allowed={x["record_id"] for x in o["records"].values() if x}
            assert len(set(row["evidence_ids"]))==len(row["evidence_ids"])
            assert set(row["evidence_ids"])<=allowed
            assert len(row["evidence_ids"])+row["missing_calls"]==row["budget"]
            assert row["truth"]==truths[row["case_id"]]
            assert row["correct"]==int(row["prediction"]==row["truth"])
            key=(row["condition"],row["policy"],row["budget"])
            totals[key][0]+=1; totals[key][1]+=row["correct"]; totals[key][2]+=row["cost"]
            if row["budget"]==6: full[row["case_id"]].append((row["prediction"],row["cost"]))
    for vals in full.values():
        assert len(vals)==4
        assert len({v[0] for v in vals})==1
        assert max(v[1] for v in vals)-min(v[1] for v in vals)<1e-9
    for row in json.loads((root/"summary.json").read_text()):
        count,correct,cost=totals[(row["condition"],row["policy"],row["budget"])]
        assert row["n"]==count
        assert abs(row["accuracy"]-correct/count)<1e-12
        assert abs(row["mean_cost"]-cost/count)<1e-9
    return {"status":"passed","hashed_artifacts":len(checks),"all_observations":len(observations),
            "audited_policy_evaluations":n,"full_budget_equivalent_cases":len(full),
            "checks":["checksums","split separation","evidence provenance","budgets","scoring","summary consistency","full-budget invariance"]}

if __name__ == "__main__":
    p=argparse.ArgumentParser(); p.add_argument("--results",default="results")
    args=p.parse_args(); root=Path(args.results)
    result=verify(root)
    (root/"verification.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))

"""Synthetic manufacturing investigation benchmark. No physical validation."""
__version__ = "0.1.0"

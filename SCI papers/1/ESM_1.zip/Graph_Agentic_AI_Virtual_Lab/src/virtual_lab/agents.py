"""Probabilistic specialist agents with an adaptive tool-selection controller.

This is not an LLM implementation. The observation-only interface excludes truth.
"""
import heapq
from functools import lru_cache
import numpy as np
from .simulator import CAUSES, DOMAINS, FEATURES

# Assumed communication cost units, not measured tokens or elapsed time.
EDGES = [("planner", "telemetry", 1.), ("planner", "materials", 1.3),
         ("planner", "scheduling", 1.), ("telemetry", "quality", .8),
         ("telemetry", "maintenance", .7), ("scheduling", "assembly", .9),
         ("quality", "assembly", 1.1)]
SERVICE = dict(zip(DOMAINS, (1., 1.1, .9, .8, .9, 1.3)))

@lru_cache(maxsize=None)
def shortest_path(target):
    q, seen = [(0., "planner", ["planner"])], set()
    while q:
        cost, node, path = heapq.heappop(q)
        if node == target:
            return cost, path
        if node in seen:
            continue
        seen.add(node)
        for a,b,w in EDGES:
            nxt = b if a == node else a if b == node else None
            if nxt is not None and nxt not in seen:
                heapq.heappush(q, (cost+w, nxt, path+[nxt]))
    raise ValueError(f"Unreachable agent: {target}")

def entropy(p):
    return -np.sum(np.where(p > 0, p*np.log(np.maximum(p, 1e-300)), 0), axis=-1)

class SpecialistModel:
    def fit(self, train, calibration):
        self.gaussians, self.emissions = {}, {}
        for d in DOMAINS:
            groups = [np.array([self.vector(o,d) for o,t in train if t.cause == c]) for c in CAUSES]
            self.gaussians[d] = (np.array([x.mean(axis=0) for x in groups]),
                                 np.array([np.maximum(x.var(axis=0), 1e-4) for x in groups]))
            counts = np.ones((len(CAUSES), len(CAUSES))) # Laplace smoothing, fixed before testing
            for o,t in calibration:
                counts[CAUSES.index(t.cause), self.signature(o.records[d], d)] += 1
            self.emissions[d] = counts/counts.sum(axis=1, keepdims=True)
        return self

    @staticmethod
    def vector(o, d):
        return np.array([o.records[d]["values"][f] for f in FEATURES[d]])

    def signature(self, record, d):
        if record is None:
            return None
        x = np.array([record["values"][f] for f in FEATURES[d]])
        mu, var = self.gaussians[d]
        return int(np.argmax(-.5*np.sum(np.log(var)+(x-mu)**2/var, axis=1)))

    def expected_information_gain(self, p, d):
        joint = p[:,None] * self.emissions[d]
        predictive = joint.sum(axis=0)
        posteriors = (joint / predictive[None,:]).T
        return float(entropy(p) - np.sum(predictive*entropy(posteriors)))

    def save(self, path):
        import json
        path.write_text(json.dumps({"gaussians": {d:[a.tolist() for a in v] for d,v in self.gaussians.items()},
                                   "emissions": {d:v.tolist() for d,v in self.emissions.items()}}, indent=2))

    @classmethod
    def load(cls, path):
        import json
        x=json.loads(path.read_text()); m=cls()
        m.gaussians={d:tuple(np.array(a) for a in v) for d,v in x["gaussians"].items()}
        m.emissions={d:np.array(v) for d,v in x["emissions"].items()}
        return m

class InvestigationEnvironment:
    def __init__(self, observation, model):
        self.observation, self.model = observation, model
        self.called = set()

    def query(self, domain):
        if domain not in DOMAINS or domain in self.called:
            raise ValueError("Unknown or duplicate tool call")
        self.called.add(domain)
        record = self.observation.records[domain]
        route_cost, route = shortest_path(domain)
        return {"agent":domain, "signature":self.model.signature(record,domain),
                "record_id":record["record_id"] if record else None,
                "values": record["values"] if record else None,
                "route":route, "communication_cost":2*route_cost,
                "total_cost":2*route_cost+SERVICE[domain], "status":"ok" if record else "missing"}

def investigate(observation, model, policy, budget, seed=0, trace=False):
    if policy not in ("fixed", "random", "adaptive_information", "adaptive_graph"):
        raise ValueError(policy)
    if not 1 <= budget <= len(DOMAINS):
        raise ValueError("Budget must be between 1 and 6 tool calls")
    env = InvestigationEnvironment(observation,model)
    p = np.ones(len(CAUSES))/len(CAUSES)
    remaining, logs = list(DOMAINS), []
    r = np.random.default_rng(seed)
    total_cost = communication_cost = 0.
    evidence, missing = [], 0
    for step in range(budget):
        scores = None
        if policy == "fixed":
            d=remaining[0]
        elif policy == "random":
            d=remaining[int(r.integers(len(remaining)))]
        else:
            scores={d:model.expected_information_gain(p,d) /
                    (2*shortest_path(d)[0]+SERVICE[d] if policy == "adaptive_graph" else 1.) for d in remaining}
            d=max(remaining,key=lambda x:scores[x])
        remaining.remove(d)
        result=env.query(d)
        total_cost+=result["total_cost"]; communication_cost+=result["communication_cost"]
        if result["signature"] is not None:
            p=p*model.emissions[d][:,result["signature"]]; p/=p.sum()
            evidence.append(result["record_id"])
        else:
            missing+=1
        if trace:
            logs.append({"step":step+1,"selection_scores":scores,"tool_result":result,
                         "posterior":dict(zip(CAUSES,map(float,p))),"entropy":float(entropy(p))})
    order=np.argsort(-p, kind="stable")
    result={"case_id":observation.case_id,"policy":policy,"budget":budget,
            "prediction":CAUSES[int(order[0])],"ranking":[CAUSES[int(i)] for i in order],
            "posterior":dict(zip(CAUSES,map(float,p))),"tool_calls":budget,
            "total_cost":total_cost,"communication_cost":communication_cost,
            "evidence_ids":evidence,"missing_calls":missing}
    if trace:
        result["trace"]=logs
    return result

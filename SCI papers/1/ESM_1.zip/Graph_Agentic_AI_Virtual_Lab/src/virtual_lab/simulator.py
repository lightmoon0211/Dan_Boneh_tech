"""An assumed stochastic structural model, not a calibrated digital twin."""
from dataclasses import dataclass
import hashlib
import numpy as np

CAUSES = ("normal", "tool_wear", "coolant_loss", "material_delay", "schedule_overload", "spindle_fault", "assembly_misalignment")
DOMAINS = ("telemetry", "quality", "maintenance", "materials", "scheduling", "assembly")
FEATURES = {
    "telemetry": ("vibration_mm_s", "temperature_c", "motor_current_a"),
    "quality": ("reject_fraction", "dimension_error_um"),
    "maintenance": ("tool_hours", "coolant_flow_l_min"),
    "materials": ("inventory_coverage_hours", "arrival_delay_hours"),
    "scheduling": ("queue_hours", "setup_minutes"),
    "assembly": ("alignment_error_um", "acceptance_rework_hours"),
}

@dataclass(frozen=True)
class Observation:
    case_id: str
    records: dict
    output: dict

@dataclass(frozen=True)
class Truth:
    case_id: str
    cause: str
    severity: float

def generate(seed, n_per_cause, condition="standard", split="test"):
    if condition not in ("standard", "missing", "noisy", "shift"):
        raise ValueError(condition)
    r = np.random.default_rng(seed)
    out = []
    for label, cause in enumerate(CAUSES):
        for j in range(n_per_cause):
            severity = float(r.uniform(0.7, 1.5)) if label else 0.0
            # All cases have background variability. One dominant injected cause.
            z = np.abs(r.normal(0, .10, 6))
            if label:
                z[label - 1] += severity
            wear, coolant, delay, overload, bearing, alignment = z
            ambient, demand = r.normal(0, 1, 2)
            variation = float(r.uniform(.85, 1.15))
            # Held-out shift changes the observation mechanism and offsets.
            shift = condition == "shift"
            wear_to_vibration = .65 if shift else 1.25
            noise = 1.9 if condition == "noisy" else 1.0
            def e(sd):
                return float(r.normal(0, sd * noise))
            raw = {
                "telemetry": [max(.1, 1 + variation*(wear_to_vibration*wear + 2.3*bearing) + e(.45)),
                              42 + variation*(11*coolant + 7*bearing + 3*overload) + 2*ambient + (4 if shift else 0) + e(3),
                              max(1, 8 + 1.8*wear + 2*bearing + 1.3*overload + e(.9))],
                "quality": [float(np.clip(.02 + .10*wear + .06*coolant + .03*bearing + e(.025), 0, .8)),
                            abs(3 + 12*wear + 8*coolant + 7*bearing + e(4))],
                "maintenance": [max(0, 30 + 70*wear + e(20)), max(.1, 12 - 6*coolant + e(1.4))],
                "materials": [max(0, 10 - 5*delay - overload + e(2)), max(0, 1 + 6*delay + e(1.5))],
                "scheduling": [max(0, 1 + 4*overload + 2*delay + .5*demand + e(1)),
                               max(1, 18 + 22*overload + 4*delay + e(7))],
                "assembly": [abs(4 + (13 if shift else 20)*alignment + 3*wear + e(5)),
                             max(0, .2 + 2*alignment + .35*wear + .3*delay + e(.5))],
            }
            # Keep observed records separate from evaluator-only truth.
            opaque = hashlib.sha256(f"{split}:{seed}:{label}:{j}".encode()).hexdigest()[:20]
            case_id = f"case-{opaque}"
            records = {}
            for domain in DOMAINS:
                records[domain] = None if condition == "missing" and r.random() < .30 else {
                    "record_id": f"{case_id}:{domain}",
                    "values": {k: round(float(v), 5) for k,v in zip(FEATURES[domain], raw[domain])},
                    "synthetic": True,
                }
            output = {
                "machined_good_parts_per_shift": max(0, round(100 - 15*wear - 18*coolant - 25*delay - 18*overload - 22*bearing + e(4))),
                "finished_machine_acceptance_units_per_shift": max(0, round(8 - 2.5*alignment - .8*delay - .4*overload + e(.6))),
                "synthetic": True,
            }
            out.append((Observation(case_id, records, output), Truth(case_id, cause, severity)))
    r.shuffle(out)
    return out

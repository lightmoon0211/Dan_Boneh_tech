"""Run the declared pilot; all primary result files are deterministic."""
import argparse
from collections import defaultdict
from dataclasses import asdict
import gzip
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
import time

sys.path.insert(0, str(Path(__file__).parent / "src"))
import numpy as np
from virtual_lab.simulator import generate, CAUSES
from virtual_lab.agents import SpecialistModel, investigate, EDGES, SERVICE

POLICIES=("fixed", "random", "adaptive_information", "adaptive_graph")
CONDITIONS=("standard", "missing", "noisy", "shift")
BUDGETS=(2,4,6)

def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True)+"\n", encoding="utf-8")

def save_pairs(root, pairs):
    # Ground truth is stored separately and never passed to investigate().
    root.mkdir(parents=True, exist_ok=True)
    for filename, index in (("observations.jsonl",0),("ground_truth.jsonl",1)):
        with (root/filename).open("w",encoding="utf-8") as f:
            for pair in pairs:
                f.write(json.dumps(asdict(pair[index]),sort_keys=True)+"\n")

def wilson(successes,n):
    p=successes/n; z=1.959963984540054
    center=(p+z*z/(2*n))/(1+z*z/n)
    half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n)
    return [center-half, center+half]

def run(args):
    root=Path(args.output); root.mkdir(parents=True,exist_ok=True)
    config={"version":"0.1.0","seeds":list(range(101,101+args.seeds)),
            "train_per_cause":args.train_per_cause,"calibration_per_cause":args.calibration_per_cause,
            "test_per_cause_per_condition":args.test_per_cause,"conditions":CONDITIONS,
            "policies":POLICIES,"budgets_tool_calls":BUDGETS,
            "class_names":CAUSES,"primary_budget":4,"bootstrap_replicates":2000,
            "backend":"probabilistic_symbolic_agents_no_llm",
            "assumptions":"Synthetic structural model; balanced single-injection classes; uniform class prior."}
    dump(root/"configuration.json",config)
    stats=defaultdict(list); seed_rows=[]; traces=[]
    started=time.perf_counter()
    with (root/"predictions.jsonl.gz").open("wb") as raw:
        with gzip.GzipFile(filename="",mode="wb",fileobj=raw,mtime=0) as predfile:
            for seed in config["seeds"]:
                train=generate(seed*1000+1,args.train_per_cause,split="train")
                calibration=generate(seed*1000+2,args.calibration_per_cause,split="calibration")
                save_pairs(root/"data"/f"seed_{seed}"/"train",train)
                save_pairs(root/"data"/f"seed_{seed}"/"calibration",calibration)
                model=SpecialistModel().fit(train,calibration)
                model.save(root/"data"/f"seed_{seed}"/"specialist_model.json")
                for ci,condition in enumerate(CONDITIONS):
                    cases=generate(seed*1000+100+ci,args.test_per_cause,condition,split="test")
                    save_pairs(root/"data"/f"seed_{seed}"/condition,cases)
                    for policy in POLICIES:
                        for budget in BUDGETS:
                            rows=[]
                            for i,(observation,truth) in enumerate(cases):
                                keep_trace=seed==101 and policy=="adaptive_graph" and budget==4 and i<2
                                result=investigate(observation,model,policy,budget,seed=seed*10000+i,trace=keep_trace)
                                p=result["posterior"]; target=CAUSES.index(truth.cause)
                                row={"seed":seed,"condition":condition,"case_id":observation.case_id,
                                     "policy":policy,"budget":budget,"truth":truth.cause,
                                     "prediction":result["prediction"],"correct":int(result["prediction"]==truth.cause),
                                     "top3_correct":int(truth.cause in result["ranking"][:3]),
                                     "confidence":max(p.values()),
                                     "brier":float(sum((p[c]-(j==target))**2 for j,c in enumerate(CAUSES))),
                                     "cost":result["total_cost"],"communication_cost":result["communication_cost"],
                                     "missing_calls":result["missing_calls"],"evidence_ids":result["evidence_ids"]}
                                rows.append(row)
                                predfile.write((json.dumps(row,sort_keys=True)+"\n").encode())
                                if keep_trace:
                                    traces.append({"condition":condition,"observation":asdict(observation),
                                                   "investigation":result,"evaluator_only_truth":asdict(truth)})
                            stats[(condition,policy,budget)].extend(rows)
                            seed_rows.append({"seed":seed,"condition":condition,"policy":policy,"budget":budget,
                                              "accuracy":float(np.mean([x["correct"] for x in rows])),
                                              "mean_cost":float(np.mean([x["cost"] for x in rows]))})
                    print(f"Completed seed {seed}, {condition}: {len(cases)} held-out cases",flush=True)
    summary=[]
    for (condition,policy,budget),rows in sorted(stats.items()):
        successes=sum(x["correct"] for x in rows)
        summary.append({"condition":condition,"policy":policy,"budget":budget,"n":len(rows),
                        "accuracy":successes/len(rows),"accuracy_wilson_95":wilson(successes,len(rows)),
                        "seed_accuracy_sd":float(np.std([x["accuracy"] for x in seed_rows if x["condition"]==condition and x["policy"]==policy and x["budget"]==budget],ddof=1)) if args.seeds>1 else None,
                        "top3_accuracy":float(np.mean([x["top3_correct"] for x in rows])),
                        "mean_brier":float(np.mean([x["brier"] for x in rows])),
                        "mean_cost":float(np.mean([x["cost"] for x in rows])),
                        "mean_communication_cost":float(np.mean([x["communication_cost"] for x in rows])),
                        "mean_missing_calls":float(np.mean([x["missing_calls"] for x in rows]))})
    # Paired comparisons, using seed blocks (shared fitted models).
    # Five seed blocks provide a pilot interval, not strong external evidence.
    r=np.random.default_rng(98765); comparisons=[]
    for condition in CONDITIONS:
        for base in ("fixed","random","adaptive_information"):
            deltas=[]; costs=[]
            for seed in config["seeds"]:
                def row(policy):
                    return next(x for x in seed_rows if x["seed"]==seed and x["condition"]==condition and x["policy"]==policy and x["budget"]==4)
                a,b=row("adaptive_graph"),row(base)
                deltas.append(a["accuracy"]-b["accuracy"]); costs.append(a["mean_cost"]-b["mean_cost"])
            ix=r.integers(0,len(deltas),size=(2000,len(deltas)))
            comparisons.append({"condition":condition,"budget":4,"treatment":"adaptive_graph","baseline":base,
                                "accuracy_difference":float(np.mean(deltas)),
                                "accuracy_difference_seed_bootstrap_95":np.quantile(np.array(deltas)[ix].mean(axis=1),[.025,.975]).tolist(),
                                "mean_cost_difference":float(np.mean(costs)),
                                "cost_difference_seed_bootstrap_95":np.quantile(np.array(costs)[ix].mean(axis=1),[.025,.975]).tolist()})
    dump(root/"summary.json",summary); dump(root/"seed_metrics.json",seed_rows)
    dump(root/"paired_comparisons.json",comparisons); dump(root/"example_traces.json",traces)
    dump(root/"communication_graph.json",{"bidirectional_edges":EDGES,"service_cost_units":SERVICE})
    dump(root/"runtime.json",{"python":platform.python_version(),"numpy":np.__version__,
                              "platform":platform.platform(),"wall_seconds":time.perf_counter()-started,
                              "note":"Whole benchmark runtime, not LLM or per-incident latency."})
    hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob("*")) if p.is_file() and p.name not in ("runtime.json","checksums.json")}
    dump(root/"checksums.json",hashes)
    print(f"Finished: {len(summary)} summaries; {sum(len(x) for x in stats.values())} policy evaluations",flush=True)

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",default="results")
    parser.add_argument("--seeds",type=int,default=5)
    parser.add_argument("--train-per-cause",type=int,default=150)
    parser.add_argument("--calibration-per-cause",type=int,default=100)
    parser.add_argument("--test-per-cause",type=int,default=40)
    args=parser.parse_args()
    if min(args.seeds,args.train_per_cause,args.calibration_per_cause,args.test_per_cause)<1:
        parser.error("All sizes must be positive")
    run(args)

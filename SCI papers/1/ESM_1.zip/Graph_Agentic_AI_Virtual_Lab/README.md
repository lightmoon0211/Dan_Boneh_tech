# Graph Agentic AI Virtual Lab — v0.1.0

**A reproducible synthetic research pilot for agent investigation in manufacturing.**
All factory data are generated. All released experimental results use probabilistic
software agents; no LLM was executed. This is neither a validated digital twin nor
a submission-ready paper. The optional local LLM planner is supplied separately.

## Start here

1. Read `RESEARCH_REPORT.md` for the measured results and research implications.
2. Read `docs/EXPERIMENT_PROTOCOL.md` for assumptions, controls and limitations.
3. Inspect `results/example_traces.json` for the observable investigation steps.
4. Run the existing symbolic demo, then reproduce the experiment if desired.

The model abstracts component machining and complete CNC-machine assembly. Seven
classes cover six injected conditions and a normal class. There are six specialist
interfaces and a planner; a fixed weighted communication graph connects them.

## Install and run

Python 3.10 or newer is recommended. A GPU and internet connection are unnecessary
for the symbolic benchmark once NumPy is installed. Matplotlib is needed only to
regenerate the figure and report. No model weights or software wheels are bundled.

Windows PowerShell, in the extracted folder:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe demo.py
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe run_experiments.py --output reproduced_results
.\.venv\Scripts\python.exe make_report.py --results reproduced_results
```

If you prefer an existing conda environment, activate it and use `python` instead
of the venv executable. Install dependencies in that environment. For air-gapped
operation, transfer compatible wheels from a connected machine and install with
`pip install --no-index --find-links PATH_TO_WHEELS -r requirements.txt`.

Linux/macOS:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python demo.py
.venv/bin/python run_experiments.py --output reproduced_results
.venv/bin/python make_report.py --results reproduced_results
```

The full pilot uses five seeds. A smaller functionality check is:

```bash
python run_experiments.py --seeds 2 --train-per-cause 20 --calibration-per-cause 15 --test-per-cause 5 --output smoke_results
```

`requirements-tested.txt` records versions used here. Different NumPy/platform
versions can affect floating-point output. Fixed seeds reproduce numeric results
in the recorded environment; `runtime.json` intentionally records nondeterministic
wall time and is excluded from the result checksum manifest.

## Optional local LLM experiment — pending, not included in reported results

Install Ollama and provision a suitable model on your own machine. Record the
exact model name, digest, quantization, Ollama version and hardware. With Ollama
running locally and the model already installed:

```powershell
python demo.py --backend ollama --model YOUR_INSTALLED_MODEL_NAME
```

This requests four specialist selections from a local LLM. Diagnosis remains the
shared probabilistic updater so that this extension isolates the planner's role.
The connector does not download models, change machines, or call public APIs. It
permits only a loopback Ollama HTTP endpoint. It rejects malformed decisions and
unknown/duplicate agents without a hidden fallback. Transport/decision failures
are visible errors. API behavior was checked against official documentation:
https://docs.ollama.com/api/chat

Only a mocked response/schema check was run here. Live model connectivity and LLM
quality remain untested. Model-reported prompt/output counts are retained if
returned; they must not be confused with the pilot's assumed communication units.

For a journal experiment, extend the evaluator to run this backend over all
declared test cases and repeated model seeds, logging failures, costs, prompts,
and exact versions. Add matched single-agent and published multi-agent baselines.
Do not combine future LLM scores with the present symbolic scores without labels.

## Files

- `src/virtual_lab/simulator.py`: assumed stochastic factory equations.
- `src/virtual_lab/agents.py`: trained specialists, Bayesian controller, graph routing.
- `src/virtual_lab/local_llm.py`: optional local model planner.
- `run_experiments.py`: seeded data generation, fitting, comparison and statistics.
- `make_report.py`: rebuild tables, figure and research report from actual results.
- `verify_results.py`: full-output consistency, checksums and provenance audit.
- `tests/test_integrity.py`: meaningful information-boundary and budget checks.
- `results/data/seed_*/`: fitting, calibration and held-out observations; labels
  stored in separate `ground_truth.jsonl` files; fitted specialist models.
- `results/predictions.jsonl.gz`: every scored policy evaluation, including errors.
- `results/summary.json`: all 48 condition/policy/budget summaries.
- `results/paired_comparisons.json`: declared budget-four paired seed comparisons.
- `results/seed_metrics.json`: per-seed accuracy and cost.
- `results/example_traces.json`: eight unselected first-case investigation examples.
- `results/communication_graph.json`: assumed routing topology and costs.
- `results/checksums.json`: SHA-256 hashes of reproducible primary artifacts.
- `results/runtime.json`: actual environment and total benchmark elapsed time.

## Research positioning

Current pilot title: *Cost-Aware Evidence Acquisition on Agent Communication
Graphs: A Synthetic Manufacturing Benchmark*.

Possible completed LLM-paper title: *Graph-Theoretic Orchestration of Agentic AI
for Evidence-Based Root Cause Analysis in Smart Manufacturing*.

Target: **Journal of Intelligent Manufacturing**, based on its AI/manufacturing
scope and publisher-listed SCIE coverage: https://link.springer.com/journal/10845
Journal suitability does not imply acceptance. Establish novelty and strengthen
validation before preparing a submission.

The current method combines known Bayesian experimental design and shortest-path
routing. An academic contribution requires a defensible advance, such as formally
characterized evidence acquisition with graph constraints, or a rigorously validated
new benchmark. Merely using agents and graphs is not a novelty claim.

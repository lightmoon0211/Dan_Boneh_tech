import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parent/"src"))
from virtual_lab.simulator import Observation
from virtual_lab.agents import SpecialistModel, investigate
from virtual_lab.local_llm import OllamaPlanner, investigate_llm

if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--results",default="results")
    p.add_argument("--backend",choices=["symbolic","ollama"],default="symbolic")
    p.add_argument("--model",help="Exact installed local Ollama model name; required for ollama")
    p.add_argument("--case-index",type=int,default=0)
    args=p.parse_args()
    root=Path(args.results)/"data"/"seed_101"
    model=SpecialistModel.load(root/"specialist_model.json")
    lines=(root/"standard"/"observations.jsonl").read_text().splitlines()
    observation=Observation(**json.loads(lines[args.case_index]))
    if args.backend=="ollama":
        if not args.model:
            p.error("--model is required for ollama; no automatic downloads")
        result=investigate_llm(observation,model,OllamaPlanner(args.model),4)
    else:
        result=investigate(observation,model,"adaptive_graph",4,trace=True)
    print(json.dumps(result,indent=2))

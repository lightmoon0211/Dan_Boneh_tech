import json
import sys
import unittest
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from virtual_lab.simulator import generate, CAUSES, DOMAINS
from virtual_lab.agents import SpecialistModel, investigate, InvestigationEnvironment, shortest_path
from virtual_lab.local_llm import OllamaPlanner

class IntegrityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.train=generate(1,30,split="train")
        cls.calibration=generate(2,25,split="calibration")
        cls.test=generate(3,5,split="test")
        cls.model=SpecialistModel().fit(cls.train,cls.calibration)

    def test_reproducibility_and_separation(self):
        self.assertEqual(self.test,generate(3,5,split="test"))
        ids=[{o.case_id for o,t in split} for split in (self.train,self.calibration,self.test)]
        self.assertFalse(ids[0]&ids[1] or ids[0]&ids[2] or ids[1]&ids[2])
        for o,t in self.test:
            self.assertNotIn('"cause"',json.dumps(asdict(o)))
            self.assertRegex(o.case_id,r"^case-[0-9a-f]{20}$")
            for d,record in o.records.items():
                self.assertEqual(record["record_id"],f"{o.case_id}:{d}")

    def test_budget_provenance_and_full_evidence_invariance(self):
        for o,t in self.test[:10]:
            posteriors=[]
            for policy in ("fixed","random","adaptive_information","adaptive_graph"):
                result=investigate(o,self.model,policy,6,seed=8,trace=True)
                self.assertEqual(result["tool_calls"],6)
                self.assertEqual(len(set(result["evidence_ids"])),6)
                self.assertAlmostEqual(sum(result["posterior"].values()),1.)
                self.assertEqual({x["tool_result"]["agent"] for x in result["trace"]},set(DOMAINS))
                posteriors.append(list(result["posterior"].values()))
            for p in posteriors[1:]:
                np.testing.assert_allclose(posteriors[0],p,atol=1e-12)

    def test_label_change_cannot_change_agent_output(self):
        # The agent accepts an Observation and fitted model; no evaluator object.
        o,truth=self.test[0]
        first=investigate(o,self.model,"adaptive_graph",4)
        altered_truth={"cause":"other", "case_id":truth.case_id}
        second=investigate(o,self.model,"adaptive_graph",4)
        self.assertEqual(first,second)
        self.assertNotIn("truth",first)

    def test_missing_is_not_treated_as_evidence(self):
        from virtual_lab.simulator import Observation
        o=Observation("empty",{d:None for d in DOMAINS},{})
        result=investigate(o,self.model,"adaptive_graph",6)
        self.assertEqual(result["evidence_ids"],[])
        self.assertEqual(result["missing_calls"],6)
        np.testing.assert_allclose(list(result["posterior"].values()),np.ones(7)/7)

    def test_routes_and_tool_permissions(self):
        cost,path=shortest_path("maintenance")
        self.assertAlmostEqual(cost,1.7)
        self.assertEqual(path,["planner","telemetry","maintenance"])
        env=InvestigationEnvironment(self.test[0][0],self.model)
        with self.assertRaises(ValueError): env.query("ground_truth")
        env.query("telemetry")
        with self.assertRaises(ValueError): env.query("telemetry")

    def test_llm_invalid_outputs_fail_closed(self):
        class Response:
            def __enter__(self): return self
            def __exit__(self,*args): pass
            def read(self): return json.dumps({"message":{"content":"{\"agent\":\"ground_truth\"}"}}).encode()
        with patch("urllib.request.urlopen",return_value=Response()):
            with self.assertRaises(ValueError): OllamaPlanner("test").choose(["telemetry"],[])
        with self.assertRaises(ValueError): OllamaPlanner("test",endpoint="https://example.com/api/chat")

if __name__ == "__main__":
    unittest.main()

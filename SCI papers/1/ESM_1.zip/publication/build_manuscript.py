from pathlib import Path
import json,gzip,re,collections,sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH,WD_BREAK,WD_TAB_ALIGNMENT
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

BASE=Path(__file__).parent
LAB=BASE.parent/'Graph_Agentic_AI_Virtual_Lab'
RESULTS=LAB/'results'
FIG=BASE/'figures';FIG.mkdir(exist_ok=True)
summary=json.loads((RESULTS/'summary.json').read_text())
comparisons=json.loads((RESULTS/'paired_comparisons.json').read_text())
POLICIES=['fixed','random','adaptive_information','adaptive_graph']
LABEL={'fixed':'Fixed','random':'Random','adaptive_information':'Information only','adaptive_graph':'Graph cost'}
DOMAINS=['telemetry','quality','maintenance','materials','scheduling','assembly']
CAUSES=['normal','tool_wear','coolant_loss','material_delay','schedule_overload','spindle_fault','assembly_misalignment']
CNAMES=['Normal','Tool wear','Coolant loss','Material delay','Schedule overload','Spindle fault','Assembly misalignment']
CONDITIONS=['standard','missing','noisy','shift']
CLABEL={'standard':'Standard','missing':'Missing','noisy':'Noisy','shift':'Shift'}
def get(c,p,b=4):return next(x for x in summary if x['condition']==c and x['policy']==p and x['budget']==b)

counts=collections.defaultdict(lambda:[0,0]);select=collections.defaultdict(collections.Counter)
with gzip.open(RESULTS/'predictions.jsonl.gz','rt') as f:
    for line in f:
        r=json.loads(line)
        if r['budget']==4:
            v=counts[(r['condition'],r['policy'],r['truth'])];v[0]+=r['correct'];v[1]+=1
            for eid in r['evidence_ids']:select[(r['condition'],r['policy'])][eid.split(':')[-1]]+=1

# Original figures from code and measured outputs. No generated artwork.
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,
                     'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none'})
def savefig(fig,n):
    fig.savefig(FIG/f'Fig{n}.png',dpi=600,bbox_inches='tight',facecolor='white')
    fig.savefig(FIG/f'Fig{n}.eps',format='eps',bbox_inches='tight',facecolor='white')
    plt.close(fig)
pos={'planner':(0,2.2),'telemetry':(-1.7,1),'materials':(0,.85),'scheduling':(1.7,1),
     'maintenance':(-2.25,-.55),'quality':(-.75,-.55),'assembly':(1.7,-.55)}
edges=[('planner','telemetry',1.),('planner','materials',1.3),('planner','scheduling',1.),
       ('telemetry','quality',.8),('telemetry','maintenance',.7),('scheduling','assembly',.9),('quality','assembly',1.1)]
fig,ax=plt.subplots(figsize=(6.5,3.35))
for a,b,w in edges:
    x1,y1=pos[a];x2,y2=pos[b]
    ax.plot([x1,x2],[y1,y2],color='black',lw=1,zorder=1)
    mx,my=(x1+x2)/2,(y1+y2)/2
    ax.text(mx+.06,my+.03,f'{w:g}',ha='center',va='center',fontsize=9,
            bbox={'facecolor':'white','edgecolor':'none','pad':1},zorder=4)
for name,(x,y) in pos.items():
    width=1.28 if name=='maintenance' else 1.08
    box=FancyBboxPatch((x-width/2,y-.19),width,.38,boxstyle='round,pad=.04',facecolor='white',edgecolor='black',lw=1.0,zorder=3)
    ax.add_patch(box);ax.text(x,y,'Coordinator' if name=='planner' else name.capitalize(),ha='center',va='center',fontsize=9,zorder=4)
ax.set_xlim(-3,2.55);ax.set_ylim(-1.05,2.7);ax.set_aspect('equal');ax.axis('off');savefig(fig,1)

fig,ax=plt.subplots(figsize=(6.4,3.5));colors=['#333333','#777777','#385780','#111111'];markers=['s','^','o','D'];styles=[':','--','-.','-']
for pol,col,m,ls in zip(POLICIES,colors,markers,styles):
    rows=[get('standard',pol,b) for b in [2,4,6]]
    ax.plot([v['mean_cost'] for v in rows],[v['accuracy']*100 for v in rows],label=LABEL[pol],color=col,marker=m,lw=1.4,ls=ls,ms=5)
ax.set_xlabel('Mean assumed acquisition cost (units)');ax.set_ylabel('Identification accuracy (%)')
ax.set_xlim(5,25);ax.set_ylim(50,100);ax.grid(axis='both',color='#dddddd',lw=.5)
ax.legend(loc='lower right',frameon=False,ncol=2,fontsize=8)
ax.annotate('Six calls for every policy',(23.4,94.5714),xytext=(15,98),fontsize=8,
            arrowprops={'arrowstyle':'-','lw':.7})
savefig(fig,2)

fig,ax=plt.subplots(figsize=(6.4,3.35));x=np.arange(6);w=.34
for i,pol in enumerate(['adaptive_information','adaptive_graph']):
    ys=[100*select[('standard',pol)][d]/1400 for d in DOMAINS]
    ax.bar(x+(i-.5)*w,ys,w,label=LABEL[pol],facecolor='white' if i==0 else '#bcbcbc',edgecolor='black',linewidth=.7,hatch='///' if i else None)
ax.set_xticks(x,[d.capitalize() for d in DOMAINS],rotation=20,ha='right')
ax.set_ylim(0,110);ax.set_ylabel('Investigations querying source (%)')
ax.legend(frameon=False,loc='upper right',fontsize=8);ax.grid(axis='y',color='#dddddd',lw=.5);ax.set_axisbelow(True)
savefig(fig,3)

doc=Document();sec=doc.sections[0]
sec.page_width=Inches(8.5);sec.page_height=Inches(11)
sec.top_margin=sec.bottom_margin=Inches(.8);sec.left_margin=sec.right_margin=Inches(.85)
sec.header_distance=Inches(.3);sec.footer_distance=Inches(.35)
normal=doc.styles['Normal'];normal.font.name='Times New Roman';normal.font.size=Pt(11)
normal.font.color.rgb=RGBColor(0,0,0)
normal.paragraph_format.line_spacing=1.18;normal.paragraph_format.space_after=Pt(6)
normal.paragraph_format.widow_control=True
for name,size in [('Title',16),('Heading 1',12),('Heading 2',11)]:
    st=doc.styles[name];st.font.name='Times New Roman';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0)
    st.font.bold=True;st.paragraph_format.space_before=Pt(12 if name!='Title' else 0)
    st.paragraph_format.space_after=Pt(6);st.paragraph_format.keep_with_next=True
    if name=='Title':st.paragraph_format.line_spacing=1.08
for name in ['Caption']:
    st=doc.styles[name];st.font.name='Times New Roman';st.font.size=Pt(10);st.font.color.rgb=RGBColor(0,0,0)
    st.paragraph_format.line_spacing=1.05;st.paragraph_format.space_after=Pt(6)
# Remove inherited template theme fonts and decorative paragraph borders.
for st in doc.styles:
    if st.type == 1:
        rp=st.element.get_or_add_rPr()
        fonts=rp.find(qn('w:rFonts'))
        if fonts is None: fonts=OxmlElement('w:rFonts');rp.insert(0,fonts)
        for attr in list(fonts.attrib):del fonts.attrib[attr]
        for attr in ['ascii','hAnsi','eastAsia','cs']:fonts.set(qn('w:'+attr),'Times New Roman')
for border in doc.styles.element.xpath('.//w:pBdr'):
    border.getparent().remove(border)
footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');footer._p.append(fld)
doc.core_properties.title='Cost aware graph orchestration of agentic artificial intelligence in virtual manufacturing'
doc.core_properties.subject='Simulation study of graph based evidence acquisition'
doc.core_properties.author='';doc.core_properties.keywords='Agentic artificial intelligence; graph theory; manufacturing; simulation'

def para(text,style=None):
    p=doc.add_paragraph(style=style)
    for i,s in enumerate(re.split(r'(\*[^*]+\*)',text)):
        if s.startswith('*') and s.endswith('*'):
            p.add_run(s[1:-1]).italic=True
        else:p.add_run(s)
    return p

def caption(text,bold_start=None):
    p=doc.add_paragraph(style='Caption')
    if bold_start:
        p.add_run(bold_start).bold=True;p.add_run(text[len(bold_start):])
    else:p.add_run(text)
    return p

def table(number,title,headers,rows,widths):
    cap=caption(f'Table {number} {title}',f'Table {number}');cap.paragraph_format.keep_with_next=True
    t=doc.add_table(rows=1,cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    for c,w in zip(t.columns,widths):c.width=Inches(w)
    for c,w,txt in zip(t.rows[0].cells,widths,headers):c.width=Inches(w);c.text=txt
    for vals in rows:
        cells=t.add_row().cells
        for c,w,txt in zip(cells,widths,vals):c.width=Inches(w);c.text=str(txt)
    pr=t._tbl.tblPr
    borders=OxmlElement('w:tblBorders')
    for side in ['top','left','bottom','right','insideH','insideV']:
        el=OxmlElement('w:'+side);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'4');el.set(qn('w:color'),'D9D9D9');borders.append(el)
    pr.append(borders)
    for ri,row in enumerate(t.rows):
        trpr=row._tr.get_or_add_trPr();nosplit=OxmlElement('w:cantSplit');trpr.append(nosplit)
        if ri==0:
            repeat=OxmlElement('w:tblHeader');trpr.append(repeat)
        for ci,c in enumerate(row.cells):
            c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcpr=c._tc.get_or_add_tcPr()
            mar=OxmlElement('w:tcMar')
            for side,val in [('top','65'),('bottom','65'),('left','90'),('right','90')]:
                e=OxmlElement('w:'+side);e.set(qn('w:w'),val);e.set(qn('w:type'),'dxa');mar.append(e)
            tcpr.append(mar)
            if ri==0:
                sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E8E8E8');tcpr.append(sh)
            for p in c.paragraphs:
                p.paragraph_format.space_after=Pt(0);p.paragraph_format.space_before=Pt(0);p.paragraph_format.line_spacing=1.02
                p.paragraph_format.keep_with_next=False
                p.alignment=WD_ALIGN_PARAGRAPH.LEFT if ci<2 and len(headers)>3 or ci==0 else WD_ALIGN_PARAGRAPH.CENTER
                for r in p.runs:r.font.size=Pt(9.5);r.font.bold=ri==0
    doc.add_paragraph().paragraph_format.space_after=Pt(0)

# Native Word equation structures (OMML), verified in the rendered PDF.
def el(name):return OxmlElement('m:'+name)
def R(s):
    r=el('r');props=el('rPr');sty=el('sty');sty.set(qn('m:val'),'p');props.append(sty);r.append(props)
    t=el('t');t.text=str(s);t.set(qn('xml:space'),'preserve');r.append(t);return r
def seq(parent,items):
    for x in items if isinstance(items,list) else [items]:parent.append(R(x) if isinstance(x,str) else x)
    return parent
def Sub(a,b):
    v=el('sSub');seq(v.append if False else v,[])
    v.append(seq(el('e'),a));v.append(seq(el('sub'),b));return v
def Sup(a,b):
    v=el('sSup');v.append(seq(el('e'),a));v.append(seq(el('sup'),b));return v
def Fr(a,b):
    v=el('f');v.append(seq(el('num'),a));v.append(seq(el('den'),b));return v
def Sum(lower,expr,upper=None):
    v=el('nary');pr=el('naryPr');ch=el('chr');ch.set(qn('m:val'),'∑');pr.append(ch)
    loc=el('limLoc');loc.set(qn('m:val'),'subSup');pr.append(loc)
    hide=el('supHide');hide.set(qn('m:val'),'0' if upper else '1');pr.append(hide);v.append(pr)
    v.append(seq(el('sub'),lower));v.append(seq(el('sup'),upper) if upper else el('sup'));v.append(seq(el('e'),expr));return v
def Lim(a,b):
    v=el('limLow');v.append(seq(el('e'),a));v.append(seq(el('lim'),b));return v
def EQ(n,items):
    p=doc.add_paragraph();p.paragraph_format.space_before=Pt(3);p.paragraph_format.space_after=Pt(8)
    p.paragraph_format.keep_together=True
    p.paragraph_format.tab_stops.add_tab_stop(Inches(3.10),WD_TAB_ALIGNMENT.CENTER)
    p.paragraph_format.tab_stops.add_tab_stop(Inches(6.60),WD_TAB_ALIGNMENT.RIGHT)
    p.add_run('\t');om=el('oMath');seq(om,items);p._p.append(om);p.add_run(f'\t({n})')

def equation(n):
    if n==1: EQ(n,[Sub('z','j'),' = |',Sub('ε','j'),'| + α ',Sub('1','c=j'),',   ',Sub('ε','j'),' ∼ N(0, ',Sup('0.10','2'),'),   α ∼ U(0.7, 1.5)'])
    elif n==2:EQ(n,[Sub('k','d'),' = 2 ',Sub('dist','G'),'(r,d) + ',Sub('s','d')])
    elif n==3:EQ(n,[Sub('L','d'),'(y|c) = ',Fr([Sub('n','dcy'),' + 1'],[Sum('y′',Sub('n','dcy′')),' + K']),',   K = 7'])
    elif n==4:EQ(n,[Sub('p','t+1'),'(c) = ',Fr([Sub('p','t'),'(c)',Sub('L','d'),'(y|c)'],[Sum('c′',[Sub('p','t'),'(c′)',Sub('L','d'),'(y|c′)'])])])
    elif n==5:EQ(n,[Sub('q','d,t'),'(y) = ',Sum('c',[Sub('p','t'),'(c)',Sub('L','d'),'(y|c)']),',   H(p) = −',Sum('c',['p(c) log p(c)'])])
    elif n==6:EQ(n,[Sub('I','t'),'(d) = H(',Sub('p','t'),') − ',Sum('y',[Sub('q','d,t'),'(y) H(',Sub('p','t'),'(.|y,d))'])])
    elif n==7:EQ(n,[Sup(Sub('d','t'),'*'),' = ',Lim('arg max',[R('d ∈ '),Sub('U','t')]),' ',Fr([Sub('I','t'),'(d)'],Sub('k','d'))])
    elif n==8:EQ(n,['BS = ',Fr('1','N'),Sum('i=1',[Sum('c=1',Sup(['(',Sub('p','i'),'(c) − ',Sub('1',['c=',Sub('c','i')]),')'],'2'),upper='K')],upper='N')])

def figure(n,txt):
    p=doc.add_paragraph();p.paragraph_format.keep_with_next=True;p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    run=p.add_run();shape=run.add_picture(str(FIG/f'Fig{n}.png'),width=Inches(6.15))
    shape._inline.docPr.set('descr',txt)
    caption(f'Fig. {n} {txt}',f'Fig. {n}')

def insert_table(n):
    if n==1:
        table(1,'Specialist evidence domains and assumed acquisition costs',
              ['Domain','Observed variables','Round trip','Service','Total'],[
              ['Telemetry','Vibration (mm/s), temperature (°C), current (A)','2.0','1.0','3.0'],
              ['Quality','Reject fraction, dimension error (µm)','3.6','1.1','4.7'],
              ['Maintenance','Tool age (h), coolant flow (L/min)','3.4','0.9','4.3'],
              ['Materials','Inventory coverage (h), arrival delay (h)','2.6','0.8','3.4'],
              ['Scheduling','Queue (h), setup duration (min)','2.0','0.9','2.9'],
              ['Assembly','Alignment error (µm), acceptance rework (h)','3.8','1.3','5.1']],
              [1.0,3.0,.85,.7,.7])
    elif n==2:
        p=para('For Table 2, w, q, d, o, b, and a denote wear, coolant deficit, delay, overload, bearing disturbance, and alignment disturbance; v is the episode scaling factor and u is ambient variation. Gaussian noise is added before the clipping or absolute-value operations specified in the source code.')
        for r in p.runs:r.font.size=Pt(9.5)
        table(2,'Representative equations in the assumed observation model',
              ['Variable','Unclipped structural expression','Noise SD'],[
              ['Vibration','1 + v(1.25w + 2.3b)','0.45 mm/s'],
              ['Temperature','42 + v(11q + 7b + 3o) + 2u','3 °C'],
              ['Reject fraction','0.02 + 0.10w + 0.06q + 0.03b','0.025'],
              ['Coolant flow','12 − 6q','1.4 L/min'],
              ['Arrival delay','1 + 6d','1.5 h'],
              ['Alignment error','4 + 20a + 3w','5 µm']],
              [1.15,4.0,1.10])
    elif n==3:
        table(3,'Data partitions and declared evaluation settings', ['Item','Per seed','Total or setting'],[
            ['Independent seeds','101 through 105','5'],['Fitting episodes','150 per class','5,250'],
            ['Calibration episodes','100 per class','3,500'],['Test episodes per condition','40 per class','1,400'],
            ['Held out conditions','4','5,600 test episodes'],['Policies','4','Shared specialist models'],
            ['Call budgets','2, 4, 6','Primary budget 4'],['Policy evaluations','13,440','67,200'],
            ['Bootstrap samples','Seed blocks','2,000']], [2.4,1.6,2.25])
    elif n==4:
        rows=[]
        for c in CONDITIONS:
            for pol in POLICIES:
                r=get(c,pol);rows.append([CLABEL[c],LABEL[pol],f"{r['accuracy']*100:.2f}",f"{r['mean_cost']:.3f}",f"{r['mean_brier']:.5f}"])
        table(4,'Performance at four specialist calls with 1400 episodes per condition',
              ['Condition','Policy','Accuracy %','Mean cost','Brier score'],rows,[.85,1.75,1.2,1.15,1.3])
    elif n==5:
        rows=[]
        for c in CONDITIONS:
            r=next(x for x in comparisons if x['condition']==c and x['baseline']=='adaptive_information')
            al,ah=r['accuracy_difference_seed_bootstrap_95'];cl,ch=r['cost_difference_seed_bootstrap_95']
            rows.append([CLABEL[c],f"{r['accuracy_difference']*100:+.2f} [{al*100:+.2f}, {ah*100:+.2f}]",f"{r['mean_cost_difference']:+.3f} [{cl:+.3f}, {ch:+.3f}]"])
        table(5,'Graph cost minus information only differences and seed bootstrap 95% intervals',
              ['Condition','Accuracy difference in percentage points','Cost difference in units'],rows,[1,2.6,2.65])
    elif n==6:
        rows=[]
        for cause,name in zip(CAUSES,CNAMES):
            vals=[]
            for pol in ['fixed','adaptive_information','adaptive_graph']:
                yes,ncase=counts[('standard',pol,cause)];vals.append(f'{100*yes/ncase:.1f}')
            rows.append([name]+vals)
        table(6,'Standard condition recall at four calls with 200 episodes per class',
              ['Class','Fixed %','Information only %','Graph cost %'],rows,[2.25,1,1.5,1.5])

REFERENCES=[
('Brier, G. W. (1950). Verification of forecasts expressed in terms of probability. ', 'Monthly Weather Review, 78', '(1), 1–3. ', 'https://doi.org/10.1175/1520-0493(1950)078<0001:VOFEIT>2.0.CO;2'),
('Dijkstra, E. W. (1959). A note on two problems in connexion with graphs. ', 'Numerische Mathematik, 1', ', 269–271. ', 'https://doi.org/10.1007/BF01386390'),
('Efron, B. (1979). Bootstrap methods: Another look at the jackknife. ', 'The Annals of Statistics, 7', '(1), 1–26. ', 'https://doi.org/10.1214/aos/1176344552'),
('Farahani, M. A., Khan, M. I., & Wuest, T. (2026). Hybrid agentic AI and multi-agent systems in smart manufacturing. ', 'Journal of Manufacturing Systems, 86', ', 612–623. ', 'https://doi.org/10.1016/j.jmsy.2026.04.002'),
('Golovin, D., & Krause, A. (2011). Adaptive submodularity: Theory and applications in active learning and stochastic optimization. ', 'Journal of Artificial Intelligence Research, 42', ', 427–486. ', 'https://doi.org/10.1613/jair.3278'),
('Leitão, P. (2009). Agent-based distributed manufacturing control: A state-of-the-art survey. ', 'Engineering Applications of Artificial Intelligence, 22', '(7), 979–991. ', 'https://doi.org/10.1016/j.engappai.2008.09.005'),
('Lindley, D. V. (1956). On a measure of the information provided by an experiment. ', 'The Annals of Mathematical Statistics, 27', '(4), 986–1005. ', 'https://doi.org/10.1214/aoms/1177728069'),
('Morris, T. P., White, I. R., & Crowther, M. J. (2019). Using simulation studies to evaluate statistical methods. ', 'Statistics in Medicine, 38', '(11), 2074–2102. ', 'https://doi.org/10.1002/sim.8086'),
('Sargent, R. G. (2013). Verification and validation of simulation models. ', 'Journal of Simulation, 7', '(1), 12–24. ', 'https://doi.org/10.1057/jos.2012.20'),
('Shao, G., Hightower, J., & Schindel, W. (2023). Credibility consideration for digital twins in manufacturing. ', 'Manufacturing Letters, 35', ', 24–28. ', 'https://doi.org/10.1016/j.mfglet.2022.11.009'),
('Wilson, E. B. (1927). Probable inference, the law of succession, and statistical inference. ', 'Journal of the American Statistical Association, 22', '(158), 209–212. ', 'https://doi.org/10.1080/01621459.1927.10502953'),
('Wooldridge, M., & Jennings, N. R. (1995). Intelligent agents: Theory and practice. ', 'The Knowledge Engineering Review, 10', '(2), 115–152. ', 'https://doi.org/10.1017/S0269888900008122'),
('Zhang, G., Yue, Y., Sun, X., Wan, G., Yu, M., Fang, J., Wang, K., Chen, T., & Cheng, D. (2025). G-Designer: Architecting multi-agent communication topologies via graph neural networks. ', 'Proceedings of the 42nd International Conference on Machine Learning, Proceedings of Machine Learning Research, 267', ', 76678–76692. ', 'https://proceedings.mlr.press/v267/zhang25cu.html'),
('Zhuge, M., Wang, W., Kirsch, L., Faccio, F., Khizbullin, D., & Schmidhuber, J. (2024). GPTSwarm: Language agents as optimizable graphs. ', 'Proceedings of the 41st International Conference on Machine Learning, Proceedings of Machine Learning Research, 235', ', 62743–62767. ', 'https://proceedings.mlr.press/v235/zhuge24a.html'),
]
def hyperlink(p,text,url):
    h=OxmlElement('w:hyperlink');h.set(qn('r:id'),p.part.relate_to(url,RT.HYPERLINK,is_external=True))
    r=OxmlElement('w:r');pr=OxmlElement('w:rPr');color=OxmlElement('w:color');color.set(qn('w:val'),'000000');pr.append(color);r.append(pr)
    t=OxmlElement('w:t');t.text=text;r.append(t);h.append(r);p._p.append(h)

def references():
    for a,j,b,url in REFERENCES:
        p=doc.add_paragraph();p.paragraph_format.left_indent=Inches(.22);p.paragraph_format.first_line_indent=Inches(-.22)
        p.paragraph_format.line_spacing=1.05;p.paragraph_format.space_after=Pt(7)
        p.add_run(a);p.add_run(j).italic=True;p.add_run(b);hyperlink(p,url,url)

blocks=(BASE/'manuscript.md').read_text().split('\n\n')
for b in blocks:
    b=b.strip()
    if not b:continue
    if b.startswith('# '):para(b[2:],'Title')
    elif b.startswith('## '):para(b[3:],'Heading 1')
    elif b.startswith('### '):para(b[4:],'Heading 2')
    elif re.fullmatch(r'\[\[EQ\d+\]\]',b):equation(int(re.search(r'\d+',b).group()))
    elif re.fullmatch(r'\[\[TABLE\d+\]\]',b):insert_table(int(re.search(r'\d+',b).group()))
    elif b=='[[FIG1]]':figure(1,'Weighted communication graph for the coordinator and six specialists. Edge labels are assumed one-way transport costs; service costs are listed in Table 1. Undirected links imply symmetric request and return routes')
    elif b=='[[FIG2]]':figure(2,'Standard-condition accuracy and assumed cost for each acquisition policy at two four and six tool calls. Increasing call budgets connect successive points on each curve. The common six-call endpoint provides an invariance control; lines do not imply measurements between the evaluated budgets')
    elif b=='[[FIG3]]':figure(3,'Source acquisition frequencies for the two adaptive policies at four calls in the standard condition. Percentages use 1400 investigations per policy. Their sum is 400% because each investigation queries exactly four available sources')
    elif b=='[[ALGORITHM]]':
        p=caption('Algorithm 1 Shared investigation loop','Algorithm 1');p.paragraph_format.keep_with_next=True
        for text in ['Input: observation interfaces, fitted specialists, calibrated likelihoods, policy, and call budget B',
                     '1  Initialize a uniform class prior and the set of six unqueried domains',
                     '2  Repeat B times: select a domain according to the specified policy',
                     '3  Query only the selected source and charge its complete acquisition cost',
                     '4  If available, update the class distribution; otherwise retain the current distribution',
                     '5  Remove the domain from the unqueried set and append the result to the trace',
                     'Output: highest-score class, posterior vector, queried evidence identifiers, and total cost']:
            p=para(text);p.paragraph_format.left_indent=Inches(.15);p.paragraph_format.line_spacing=1.0;p.paragraph_format.space_after=Pt(3)
            p.paragraph_format.keep_with_next=not text.startswith('Output:')
            for r in p.runs:r.font.size=Pt(10)
    elif b=='[[REFERENCES]]':references()
    else:
        p=para(b.replace('\n',' '))
        if b.startswith('Keywords:'):
            for r in p.runs:r.font.size=Pt(10)
        if b.startswith('[') or b.startswith('Corresponding author:'):
            for r in p.runs:r.font.size=Pt(10)

out=BASE/'Agentic_AI_Graph_Theory_Manuscript.docx';doc.save(out)
abstract=(BASE/'manuscript.md').read_text().split('## Abstract\n\n')[1].split('\n\nKeywords:')[0]
assert 150<=len(abstract.split())<=250,len(abstract.split())
assert len(doc.tables)==6
assert len(doc.inline_shapes)==3
assert len(doc._element.xpath('//m:oMath'))==8
print(json.dumps({'docx':str(out),'abstract_words':len(abstract.split()),'prose_words':len((BASE/'manuscript.md').read_text().split()),'tables':len(doc.tables),'figures':len(doc.inline_shapes),'native_equations':8,'references':len(REFERENCES)},indent=2))

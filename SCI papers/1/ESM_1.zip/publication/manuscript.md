# Cost aware graph orchestration of agentic artificial intelligence in virtual manufacturing

[Author names in publication order]

[Affiliations including department institution city and country]

Corresponding author: [Name and email]    ORCID: [Identifier]

## Abstract

Manufacturing diagnosis requires selective access to heterogeneous evidence, yet the cost of obtaining that evidence is often entangled with the capabilities of the diagnostic agents. This study examines whether incorporating communication-graph costs into adaptive evidence acquisition changes the accuracy–cost tradeoff of a modular agent system. A virtual manufacturing environment generates observations associated with component machining and machine-tool assembly, with six injected conditions and a normal class. Six probabilistic specialist agents communicate through a weighted graph. A controller selects evidence using expected information gain, either alone or normalized by shortest-path routing and service costs. Fixed and random acquisition policies provide additional comparisons. Five independent simulation seeds produce 5,600 held-out episodes across standard, missing-data, noisy-observation, and mechanism-shift conditions, yielding 67,200 policy evaluations at three tool-call budgets. At four calls in the standard condition, the graph-cost policy achieves 92.00% identification accuracy, compared with 91.93% for information-only acquisition, while reducing mean assumed cost from 15.120 to 14.706 units. The paired accuracy difference has a seed-bootstrap 95% interval of −0.64 to 0.93 percentage points. The primary standard-condition comparison indicates a modest modeled cost advantage without a demonstrated accuracy improvement over the stronger adaptive comparator. Full-budget equivalence and independent regeneration provide reproducibility controls. The contribution is a controlled benchmark and empirical decomposition of acquisition effects; the findings concern probabilistic agents under an assumed simulator, without language-model inference or physical-factory validation.

Keywords: Agentic artificial intelligence; Graph theory; Manufacturing diagnosis; Information gain; Multiagent systems; Simulation

## 1 Introduction

A decline in manufacturing output can be associated with equipment degradation, coolant problems, delayed materials, unfavorable scheduling, or downstream assembly difficulties. These explanations involve different records and organizational responsibilities. An investigation that repeatedly consults every available source may be unnecessarily expensive, whereas a fixed sequence can spend its limited budget on evidence that does not distinguish the leading hypotheses. The operational question is therefore not only how to classify an abnormal observation, but also which observation to obtain next.

Agent architectures provide a useful separation between a goal-directed coordinator and specialist capabilities. The distinction between agent theory, architecture, and implementation predates current language-model systems (Wooldridge & Jennings, 1995). In manufacturing, distributed agents have been studied as a means of organizing control and coordination across heterogeneous resources (Leitão, 2009). Recent work extends this setting with language-model planning and tool orchestration, including hybrid agentic architectures for prescriptive maintenance (Farahani et al., 2026). These developments motivate careful evaluation of the orchestration mechanism independently of the intelligence embedded in each specialist.

Graph representations make communication assumptions explicit. Vertices can represent agents or computational operations, while edges describe permitted exchanges. However, showing a system as a graph is insufficient to establish that its topology improves diagnosis. Gains can instead arise from a stronger classifier, additional observations, a larger interaction budget, or different access costs. A controlled comparison should hold the diagnostic backend and evidence interfaces constant while changing the acquisition policy. It should also distinguish actual communication measurements from costs assigned by a simulation model.

This study investigates a narrow question: under a fixed tool-call budget, does normalizing expected information gain by the cost of reaching a specialist improve the accuracy–cost tradeoff relative to information-only selection? The term agentic artificial intelligence is used here for an autonomous loop of goal-directed tool selection, observation, belief updating, and subsequent action. The evaluated implementation uses probabilistic specialists and a deterministic adaptive controller. No large language model (LLM) participates in the reported experiments. This operational definition separates the behavior of the agent loop from the choice of language or statistical model used to implement it.

The study contributes an explicit synthetic benchmark spanning indicators of both component machining and complete machine-tool assembly; a comparison that isolates graph-derived acquisition costs from specialist inference; and a reproducible analysis of accuracy, probabilistic error, source selection, and assumed cost. It also derives two elementary invariance properties that provide implementation checks and delimit the graph contribution. The acquisition rule combines established information-theoretic and shortest-path methods. No new approximation guarantee, learned topology, or state-of-the-art performance claim is made.

The main empirical finding is that the graph-cost policy reduces assumed acquisition cost while producing similar aggregate accuracy to an information-only adaptive policy. The advantage over fixed and random acquisition is substantially larger, but those comparisons primarily demonstrate the value of adaptive evidence collection. All conclusions are conditional on the specified simulator. The virtual environment has not been calibrated against a physical factory and is therefore treated as a research testbed rather than a validated digital twin.

## 2 Related work

### Agents and manufacturing coordination

Wooldridge and Jennings (1995) distinguish the formal properties of agents from the architectures and languages used to implement them. This distinction is relevant when evaluating contemporary agent systems because a closed-loop controller can be studied independently of a particular foundation model. Leitão (2009) reviews agent-based distributed manufacturing control and identifies the importance of coordination among distributed manufacturing resources. The present work inherits the separation of responsibilities across specialists, while limiting their actions to evidence retrieval and classification rather than equipment control.

Farahani et al. (2026) present a hybrid agentic and multiagent framework for prescriptive maintenance in smart manufacturing. Their architecture combines high-level orchestration with specialized processing and analytics. The current study addresses a more restricted experimental question: when the specialists and belief-update rule are fixed, what changes when the controller accounts for graph-based acquisition costs? It does not reproduce their framework or compare measured performance against it. Maintenance recommendations, optimization of physical operating parameters, and human approval workflows remain outside the evaluated task.

### Graph representations of agent systems

GPTSwarm represents language agents as computational graphs and optimizes both node-level operations and inter-agent connectivity (Zhuge et al., 2024). G-Designer develops task-adaptive communication topologies using graph neural networks (Zhang et al., 2025). Both establish that graph-based agent organization is an existing research direction. The infrastructure graph in the present study is fixed: only the sequence of specialists and the subgraph traversed during an investigation change. Consequently, the experiment concerns evidence acquisition over a graph, not topology learning.

This distinction is important for interpreting novelty and cost. A shortest-path graph can induce a vector of specialist-access costs, even when the controller does not use other structural properties. In the present implementation, those induced costs are the graph's only influence on action selection. More extensive claims about collective reasoning, emergent collaboration, graph neural learning, or resilience to network failures would require different experiments. Published language-agent graph methods are therefore treated as related work, not as baselines that were implemented in this study.

### Information acquisition and simulation methodology

Expected information gain evaluates an observation through its anticipated reduction in uncertainty, a principle associated with Bayesian experimental design (Lindley, 1956). Shortest-path algorithms provide a standard means of computing access costs in a weighted graph with nonnegative edges (Dijkstra, 1959). Adaptive submodularity gives conditions under which greedy adaptive policies admit guarantees (Golovin & Krause, 2011). Those conditions are not established for the present correlated observations and cost-normalized heuristic, so such guarantees are not imported into the analysis.

Simulation studies permit controlled comparisons because their data-generating mechanisms and evaluation targets can be specified explicitly. Morris et al. (2019) emphasize clear aims, mechanisms, targets, methods, and performance measures when designing such studies. Verification of a simulator's implementation is distinct from validation of its representation of an external system (Sargent, 2013). For manufacturing digital twins, credibility additionally requires attention to validation and uncertainty quantification (Shao et al., 2023). These distinctions motivate the present separation of reproducibility checks, statistical uncertainty, and physical applicability.

## 3 Virtual manufacturing environment

### Scope and observable evidence

The environment is an episode-level stochastic model of a manufacturing investigation. It represents six evidence domains: machine telemetry, part quality, maintenance, materials, scheduling, and assembly. The first five domains concern activities that can affect component machining or its supporting operations. The assembly domain adds alignment and acceptance-rework observations relevant to production of complete machine tools. These variables provide manufacturing context without attempting to reproduce a full plant, controller, or production-management system.

Each specialist receives only the variables assigned to its evidence domain. Table 1 defines the observation interface and the costs derived from the communication graph. Every available source has a unique record identifier. Two additional output indicators, machined good parts per shift and finished-machine acceptance units per shift, are generated for contextual inspection. They are not used as classifier inputs by any evaluated policy. This prevents an additional diagnostic channel from weakening the intended comparison among the six source interfaces.

[[TABLE1]]

An episode belongs to one of seven classes: normal, tool wear, coolant loss, material delay, schedule overload, spindle fault, or assembly misalignment. Abnormal episodes contain one dominant injected condition, with background variability in all six latent factors. The target is identification of that injection. It is not an expert-adjudicated root cause from an operating factory, nor does a correct label establish that a recommended intervention would improve a physical process. No action is sent to a machine.

### Stochastic construction

Let the latent vector contain wear, coolant deficit, material delay, overload, bearing disturbance, and alignment disturbance. Each component receives a nonnegative background term obtained by taking the absolute value of a zero-mean Gaussian variable with standard deviation 0.10. For an abnormal episode, a severity sampled uniformly from 0.7 to 1.5 is added to the component corresponding to the injected class. The normal class contains background variation only. Independent ambient and demand variables are standard Gaussian, and an episode-level scaling factor is uniform between 0.85 and 1.15.

[[EQ1]]

In Eq. (1), the indicator selects one of the six abnormal classes; it is zero for every component in a normal episode. Observations are constructed from explicit combinations of the latent factors, additive noise, and clipping to the stated numerical ranges. For example, standard-condition vibration depends on wear and bearing disturbance, while temperature also depends on coolant deficit, overload, and ambient variation. Table 2 provides representative equations. The complete equations, precision, clipping operations, random-number generation, and output indicators are included in Online Resource 1.

[[TABLE2]]

The coefficients and units are assumptions chosen to create partially overlapping diagnostic signatures. They were not estimated from machine measurements, a vendor specification, or published machining trials. Shared latent factors and the common scaling variable induce dependence across evidence sources. Consequently, even though the inference model uses a conditional-independence approximation, the generator does not enforce conditional independence given the class. This mismatch makes probability quality a relevant outcome in addition to classification accuracy.

### Held out conditions and information separation

Four test conditions are generated. The standard condition uses the fitting mechanism. In the missing-data condition, each specialist record is independently unavailable with probability 0.30. In the noisy condition, the standard deviation of each additive observation-noise term is multiplied by 1.9. In the mechanism-shift condition, the wear coefficient in the vibration equation changes from 1.25 to 0.65, a temperature offset of 4 °C is added, and the alignment coefficient in the assembly-error equation changes from 20 to 13. The classifier is not refitted for these changes.

Observations and evaluator labels are stored in separate files, and the investigator interface accepts only an observation object and a previously fitted specialist model. Case identifiers are opaque hashes; a readable class label is not encoded in the identifier. The prediction file includes labels only after evaluation. This separation prevents direct label access through the provided tools, although it is an interface boundary rather than a security sandbox against arbitrary code with filesystem access.

Different test conditions use independently generated episodes with the same class balance. Policy comparisons within a condition use exactly the same observations, producing paired evaluations. Changes across conditions are descriptive comparisons of distributions and include Monte Carlo variation; they are not paired interventions applied to the same individual episodes. Fitting, calibration, and test identifiers do not overlap.

## 4 Graph orchestration method

### Communication graph and acquisition cost

The communication infrastructure is a weighted undirected graph with one coordinator and six specialist vertices. The graph is denoted by G, with vertex set V, edge set E, and weight function w. Edges denote permitted message transport and carry nonnegative assumed weights. Fig. 1 depicts the graph. A request may pass through an intermediate specialist vertex without obtaining that specialist's evidence. Only an explicit source query consumes a tool call. This transport assumption avoids equating the number of graph hops with the number of evidence sources acquired.

[[FIG1]]

The cost of querying a specialist is the round-trip shortest-path cost from the coordinator plus a domain-specific service cost. Symmetric request and response costs are assumed. Dijkstra's algorithm computes the distances (Dijkstra, 1959). Equation (2) defines the total acquisition cost, with the coordinator denoted by r and the specialist by d.

[[EQ2]]

The edge weights and service costs are dimensionless research parameters. They are not measurements of network traffic, model tokens, GPU time, monetary expenditure, or human labor. Each selected source incurs its complete round-trip cost, even if some route edges were used previously. There is no route sharing, congestion, asynchronous execution, or transport failure. Missing evidence still consumes one tool call and the same assumed cost as a successful source query.

### Specialist learning and belief updates

For each domain and class, a diagonal Gaussian model is fitted to the permitted feature vector. The specialist assigns its observation to the class with the largest Gaussian log likelihood. The assigned class is a discrete signature rather than a confirmed diagnosis. Means and variances are estimated from the fitting set, with a variance floor of 0.0001. A separate calibration set estimates the probability of each emitted signature conditional on the true class, using Laplace smoothing as shown in Eq. (3). There are seven possible signatures and seven target classes.

[[EQ3]]

Here, the count records how often specialist d emits signature y for calibration episodes of class c. The added unit count prevents zero likelihoods. Calibration labels are used only during estimation, before test investigations begin. Every acquisition policy uses the same fitted specialist parameters and calibration matrix for a given simulation seed, so differences in test performance cannot be attributed to a different specialist training procedure.

The controller starts with a uniform prior over the seven classes. After obtaining signature y from domain d, it updates the class distribution using Eq. (4). An unavailable record leaves the current distribution unchanged. Evidence is never acquired twice from the same domain in one investigation. The final diagnosis is the class with the largest posterior score; deterministic class ordering resolves ties.

[[EQ4]]

This update multiplies source-specific likelihoods and therefore approximates conditional independence across acquired signatures. Because the data-generating process contains shared latent variation, its posterior should be interpreted as a model-based score. It is not a calibrated guarantee of diagnostic correctness. The complete probability vector is retained to evaluate probabilistic error and to make changes in the investigation state inspectable.

### Adaptive acquisition policies

For each unqueried specialist, the current posterior and calibrated likelihoods define a predictive distribution over possible signatures. Entropy is computed using natural logarithms, so information gain is measured in nats. The expected information gain is the current entropy minus the predictive expectation of the entropy after acquiring that source, as specified by Eqs. (5) and (6). This follows the information-based perspective on experiment selection described by Lindley (1956).

[[EQ5]]

[[EQ6]]

The information-only policy selects the source with the largest expected information gain. The graph-cost policy selects the source with the largest ratio of expected information gain to the cost defined in Eq. (2). Equation (7) expresses the latter rule, with U denoting the set of unqueried domains at step t. All scores are recomputed after each observed signature. When a record is missing, the posterior is unchanged, but that domain is removed from the unqueried set.

[[EQ7]]

The experiment uses a cardinality budget of specialist calls rather than a hard budget on accumulated cost. The ratio in Eq. (7) is therefore a heuristic for exploring the accuracy–cost tradeoff; it is not presented as the exact solution of a constrained optimization problem. In particular, lower immediate acquisition cost can change which class-specific evidence is obtained. No guarantee of equal accuracy, lower total cost in every episode, or optimal cumulative information is assumed.

Two additional policies provide reference points. The fixed policy follows telemetry, quality, maintenance, materials, scheduling, and assembly, in that order. The random policy samples unqueried sources uniformly using a fixed episode-level seed. All four policies execute exactly the declared number of calls. There is no confidence-based stopping rule, and no policy obtains an extra observation because it is uncertain. Algorithm 1 summarizes the shared investigation loop.

[[ALGORITHM]]

### Invariance properties and computational scope

Proposition 1 concerns full acquisition. If every policy queries the same available sources exactly once and uses the same prior and likelihood matrices, the final posterior is invariant to acquisition order, up to floating-point effects. To see this, expand the sequential updates in Eq. (4): the unnormalized class weight is the prior multiplied by the likelihood contribution of each available source. Multiplication commutes, and a missing source contributes no factor. Normalization therefore produces the same distribution. With additive route costs, the total cost also coincides when all six sources are queried.

Proposition 2 concerns the graph's role in the current controller. For fixed specialist models and observations, two graphs that induce the same vector of coordinator-to-specialist acquisition costs produce identical graph-cost decisions, provided ties are resolved identically. At each step, Eq. (7) depends on the graph only through that vector. Identical initial beliefs therefore imply identical first decisions, updates, and subsequent decisions by induction. This property shows that the present experiment evaluates graph-derived costs rather than other topological characteristics.

These propositions are verification properties, not new general results in graph theory. Under a standard heap implementation, a shortest-path preprocessing step has complexity on the order of the number of graph vertices and edges times the logarithm of the number of vertices. With D specialists, K classes and K discrete outcomes per specialist, evaluating all information-gain scores over B steps requires O(BDK²) arithmetic operations, apart from specialist feature scoring. The implementation caches shortest paths. Scaling to language-model tools would introduce costs not represented by this arithmetic count.

Adaptive submodularity can justify certain greedy acquisition policies, but its requirements must be proved for the objective and observation process at hand (Golovin & Krause, 2011). Such a proof is not supplied here. Correlated evidence, model misspecification, a ratio heuristic, and a fixed call budget preclude asserting an approximation bound merely because the controller uses information gain.

## 5 Experimental design

### Data partitions and comparison protocol

Five independent seeds, 101 through 105, define the fitting and evaluation repetitions. Each seed generates 150 fitting episodes and 100 calibration episodes per class, giving 1,050 and 700 episodes respectively. For each of the four test conditions, 40 episodes per class are generated, producing 280 test episodes per seed and 1,400 per condition. The combined test set therefore contains 5,600 episodes. Every policy is evaluated at budgets of two, four, and six calls, resulting in 67,200 scored policy–budget–episode combinations. Table 3 summarizes the design.

[[TABLE3]]

The four-call budget is the declared primary comparison; two and six calls provide sensitivity and invariance checks. The protocol and policy definitions were specified before the first full run, but were not registered in an external preregistration service. No test-set tuning of Gaussian parameters, edge weights, smoothing, or policy definitions was performed. The class-level and source-selection summaries presented later are descriptive secondary analyses of the retained predictions.

The fixed policy is intentionally simple and is not optimized over source permutations. At four calls it omits scheduling and assembly. Its comparison therefore measures the consequences of a particular fixed workflow, not the best possible nonadaptive policy. The information-only policy is the stronger comparator for isolating the role of acquisition cost because it uses the same evolving belief state and expected-information calculation as the graph-cost policy.

### Outcomes and uncertainty

The primary outcomes are top-1 identification accuracy and mean total assumed acquisition cost. Top-3 accuracy measures whether the injected class is among the three highest posterior scores. The multiclass Brier score evaluates the full probability vector as the mean sum of squared differences between predicted probabilities and one-hot class indicators (Brier, 1950). Lower Brier scores indicate less probabilistic error. Missing calls and communication-only cost are also recorded.

[[EQ8]]

In Eq. (8), N is the number of evaluated episodes, K is the number of classes, the subscript i indexes an episode, and the indicator is one when c is that episode's true injected class and zero otherwise.

For paired policy contrasts, accuracy and mean cost are first computed within each seed. Differences are then averaged across seeds. Percentile intervals use 2,000 bootstrap samples of the five seed blocks, retaining the shared fitted model and paired test episodes within a block. This resampling procedure uses the bootstrap principle of Efron (1979), with the seed treated as the resampling unit. With only five blocks, the interval is an exploratory measure of simulation variation, not a high-precision guarantee of repeated-study coverage.

The released outputs also contain pooled Wilson intervals for accuracy (Wilson, 1927). These summarize episode-level binomial variation under the simulated sampling scheme and do not fully represent variability due to fitting shared specialists. The manuscript emphasizes paired seed-block contrasts when comparing the adaptive policies. No multiplicity adjustment is applied to secondary condition comparisons. Sample sizes and uncertainty measures are reported explicitly to distinguish the size of the generated dataset from the number of independently fitted models, consistent with the simulation-reporting concerns discussed by Morris et al. (2019).

### Implementation and verification

The benchmark was executed using Python 3.12.14 and NumPy 2.3.5. Matplotlib 3.10.8 was used to generate plots directly from retained numerical outputs. The first full benchmark run took 18.90 seconds in the execution environment. This is elapsed time for the entire synthetic harness, not per-incident agent latency or a forecast for an industrial deployment. No model-serving runtime, external inference API, or GPU-backed language model was used.

Integrity tests check seeded data regeneration, separation of fitting and test records, the absence of evaluator labels from the observation interface, source-query restrictions, budget compliance, and missing-data behavior. A complete output audit checks all 67,200 evaluations against permitted record identifiers and recomputes aggregate scores. All 5,600 cases satisfy the full-budget invariance property across the four policies. A second complete execution regenerated the data and predictions; SHA-256 hashes matched for all 72 primary reproducible artifacts. Timing and environment metadata were excluded from that equality comparison.

### Use of generative artificial intelligence

ChatGPT in Codex Work mode was used substantively to develop the simulation and analysis code, formulate the experimental workflow, and draft the manuscript. Numerical results were obtained by executing the supplied Python programs; they were not supplied as estimated or fictional performance values. The reported verification is automated and does not constitute independent human or manufacturing-expert validation. The evaluated diagnostic agents themselves did not use an LLM. Human authors must review the implementation, references, interpretation, and final manuscript and assume responsibility for the submitted work.

## 6 Results

### Accuracy and acquisition cost

Table 4 reports all four policies at the primary four-call budget. In the standard condition, fixed acquisition achieves 75.79% accuracy, random acquisition 80.07%, information-only acquisition 91.93%, and graph-cost acquisition 92.00%. The graph-cost policy has a mean assumed cost of 14.706 units, compared with 15.120 for the information-only policy, a relative reduction of 2.74%. The corresponding Brier scores are 0.12244 and 0.12207. Thus, the slightly higher top-1 accuracy of the graph-cost policy does not coincide with a lower probability error in this condition.

[[TABLE4]]

The graph-cost minus information-only accuracy difference is 0.07 percentage points, with a seed-bootstrap 95% interval from −0.64 to 0.93 percentage points. The mean cost difference is −0.414 units, with an interval from −0.556 to −0.282 units. These results support a modeled cost reduction in this setting, while leaving the accuracy difference unresolved. They do not establish statistical equivalence: no equivalence margin or corresponding test was specified.

Under missing records, the adaptive policies obtain 74.36% and 74.50% accuracy for graph-cost and information-only acquisition respectively. Their accuracies are 70.36% and 69.64% in the noisy condition, and 87.50% and 87.43% under mechanism shift. Mean assumed cost is lower for the graph-cost policy in all four condition averages. Table 5 gives paired intervals for the stronger adaptive comparison. Accuracy intervals include zero in the standard, missing-data, and shift conditions. The noisy-condition difference is +0.71 percentage points, with an unadjusted interval of +0.29 to +1.14. This exploratory secondary result does not establish an accuracy advantage across conditions.

[[TABLE5]]

The fixed and random policies perform less well on average at four calls. Their standard-condition gaps relative to the graph-cost policy are 16.21 and 11.93 percentage points respectively. These larger differences cannot be attributed solely to the communication graph because the information-only policy achieves almost the same accuracy without cost normalization. Fig. 2 presents the standard-condition accuracy–cost relationship across all three call budgets.

[[FIG2]]

### Budget dependence and full acquisition

At two calls, information-only acquisition reaches 72.79% accuracy and graph-cost acquisition 71.43%, with mean costs of 7.240 and 6.681 units respectively. This is an explicit accuracy–cost tradeoff rather than a simultaneous improvement. At six calls, all policies achieve 94.57% accuracy and a cost of 23.400 units in the standard condition. Their probability vectors coincide within numerical tolerance, as predicted by Proposition 1.

The four-call graph-cost policy uses approximately 37.15% less assumed cost than acquiring all six sources, while its accuracy is 2.57 percentage points lower. This comparison concerns a different evidence budget and is not a matched-budget demonstration of algorithmic superiority. It illustrates why the acceptable tradeoff must be determined by the investigation's consequences. A factory that treats missed faults as particularly costly may prefer additional evidence even when the average acquisition cost increases.

### Class specific behavior and evidence selection

Table 6 reports standard-condition recall for the two adaptive policies and the fixed workflow. Each class contains 200 held-out episodes across the five seeds. The graph-cost policy increases schedule-overload recall from 88.0% to 92.5% relative to information-only selection, while assembly-misalignment recall decreases from 90.5% to 88.5% and normal-class recall decreases from 88.5% to 86.0%. These differences show that nearly identical aggregate accuracy can conceal changes in the allocation of diagnostic errors.

[[TABLE6]]

Source-selection frequencies help explain this redistribution. Both adaptive policies query telemetry in all 1,400 standard-condition investigations. Information-only acquisition queries scheduling in 1,006 episodes and assembly in 925. Graph-cost acquisition queries scheduling in 1,259 episodes and assembly in 712. Scheduling has a total assumed access cost of 2.9 units, whereas assembly costs 5.1 units. Cost normalization therefore changes which evidence is collected, not merely how the same evidence is transported. Fig. 3 shows the full selection-frequency comparison.

[[FIG3]]

The fixed policy's low recall for assembly misalignment, 39.5%, is consistent with the exclusion of assembly evidence at four calls. Its normal-class recall is 35.5%, indicating frequent false abnormal classifications under this particular source sequence. The adaptive policies improve those outcomes, but the comparison should not be generalized to all fixed workflows. Determining the best fixed subset or ordering from independent development data would provide a stronger nonadaptive baseline.

### An observable investigation example

The first retained standard-condition example for seed 101 illustrates the controller's response to conflicting signatures without selecting a favorable case after inspecting outcomes. The graph-cost controller queries telemetry, scheduling, materials, and maintenance. After telemetry, schedule overload receives the highest posterior score, 0.500. The scheduling observation shifts the material-delay score to 0.436. A materials record with an arrival delay of approximately 8.16 hours and inventory coverage of 3.84 hours raises the material-delay score to 0.979. The final score is 0.985, and the predicted injection matches the evaluator's material-delay label.

The example shows sequential revision of a belief state and records the exact evidence used. It does not expose an LLM's private reasoning, prove that the score is calibrated, or establish a physical causal chain. Its role is to make the executed policy inspectable: a reader can identify the selected specialists, the observations returned, the route cost charged, and the numerical updates. All example traces and unsuccessful predictions remain available in Online Resource 1.

## 7 Discussion

### Interpretation of the graph contribution

The central empirical result is modest. At four calls, graph-derived cost normalization changes average resource use while preserving approximately the same observed accuracy as information-only selection. The study does not demonstrate that graphs improve the underlying diagnostic model. Proposition 2 further shows that the controller would behave identically if supplied with the same access-cost vector without the original graph. The graph contributes an interpretable derivation of those costs and a record of communication routes; its wider topology is not an independently tested source of intelligence.

This restricted conclusion is useful for agentic system design because orchestration and diagnostic capability are often changed together. Holding the specialist models fixed exposes the tradeoff introduced by resource-aware source selection. It also prevents the difference between a weak fixed workflow and an adaptive controller from being misreported as evidence for a new graph-learning method. The class-specific results indicate that cost-sensitive orchestration can redistribute errors toward more expensive sources, an issue that aggregate accuracy alone does not resolve.

The complete source set is not automatically optimal when an investigation has a limited budget, but this experiment does not learn an industrial cost function. In practice, acceptable costs may depend on urgency, source reliability, operator workload, or the consequences of a missed fault. Such terms would need to be measured or elicited, and risk-sensitive objectives would need to be evaluated explicitly. The current dimensionless weights cannot be converted into a claim about monetary savings, throughput improvement, or reduced downtime.

### Validity and generalization

The main threat to external validity is that the fitting data and most test observations share a deliberately constructed mechanism. A specialist can learn artifacts of that mechanism, and apparent robustness can remain confined to the variations anticipated by its designer. The mechanism-shift condition changes only three coefficients or offsets and does not represent transfer to an independently modeled factory. Expert review, physical calibration, and validation against external operational records have not been performed. These distinctions follow the separation between model verification and model validation discussed by Sargent (2013) and the credibility concerns raised by Shao et al. (2023).

The benchmark also simplifies the investigation target. Classes are balanced, faults are singly injected, evidence availability is independent, and all relevant causes are known. Real investigations may contain multiple interacting faults, uncertain timestamps, contradictory records, biased missingness, and previously unseen conditions. The current controller always returns one of seven classes and has no abstention action. Its reported accuracy therefore says little about a deployment with rare faults or substantial unknown-cause probability.

The inference model compresses continuous observations into discrete signatures and then multiplies source likelihoods. This can discard useful within-class variation and exaggerate confidence when sources are dependent. The experiment reports the Brier score but does not perform a comprehensive calibration study or compare alternative inference models. Likewise, the graph has no congestion, failed links, parallel queries, edge learning, or shared-route discounts. The number of agents and graph structure are held fixed, so scalability and topology sensitivity remain unmeasured.

There are also limits to statistical inference. Five independently fitted repetitions provide less information about training variability than the total episode count might suggest. Seed-bootstrap intervals are exploratory, and secondary analyses are not adjusted for multiple comparisons. Reproducing files exactly establishes computational repeatability in the recorded environment, not independent replication of the scientific assumptions. The simple fixed and random policies are useful controls, but they do not substitute for optimized nonadaptive acquisition or published agent-system baselines.

### Implications for language model agents

The acquisition environment can support subsequent experiments in which an LLM selects specialist tools while receiving the same observations and call budget. Such a comparison would need to record the model, version, prompts, sampling settings, malformed decisions, tool failures, and measured inference resources. It would also need to separate selection quality from the quality of an LLM-generated explanation. The present numerical results cannot establish any of those properties because no language model was executed inside the diagnostic loop.

GPTSwarm and G-Designer provide relevant comparison directions for graph-organized language agents (Zhuge et al., 2024; Zhang et al., 2025). Their objectives and implementations would need to be adapted transparently to the manufacturing evidence interface before a fair empirical comparison. A matched single-agent tool-using baseline would also be required to determine whether multiple specialist agents provide value beyond a centralized controller with equivalent access. These extensions would broaden the contribution beyond the controlled probabilistic study reported here.

## 8 Conclusion

This study evaluated graph-derived acquisition costs in a reproducible virtual manufacturing investigation. Six probabilistic specialist agents were held constant while fixed, random, information-only, and graph-cost acquisition policies were compared at matched tool-call budgets. Across 5,600 held-out episodes and 67,200 policy evaluations, the four-call graph-cost policy reduced average assumed acquisition cost relative to the stronger adaptive comparator in all four conditions. Accuracy differences remained inconclusive in three conditions; the noisy condition showed a small positive exploratory difference. In the standard condition, mean cost decreased by 2.74%, with accuracies of 92.00% and 91.93% for graph-cost and information-only selection respectively.

The findings support treating evidence selection, routing assumptions, and diagnostic inference as distinct experimental components. Full-acquisition invariance, traceable source access, and an independently repeated execution strengthen computational verification. The scientific scope remains limited to an assumed synthetic mechanism, a fixed communication graph, and probabilistic agents. Physical-factory performance, language-model reasoning, and general superiority of graph-based agent orchestration are not established by these results.

## Statements and Declarations

### Funding

[Authors to provide the actual funding statement and grant information or confirm that no external funding was received]

### Competing interests

[Authors to disclose relevant financial and nonfinancial interests or confirm that there are none]

### Author contributions

[Authors to specify actual contributions including conceptualization methodology software validation analysis and writing]

### Data and code availability

The complete synthetic observations, evaluator labels, fitted specialist parameters, source code, prediction records, configuration, checksums, and execution traces are supplied in Online Resource 1. No confidential factory records or personal data were used. The package supports regeneration in the documented environment. A public repository accession or persistent identifier has not been assigned.

### Ethics and consent

The reported experiments use computer-generated manufacturing episodes and involve no human participants, animals, or personal records. Consent to participate is therefore not applicable to the experimental data.

### Generative artificial intelligence disclosure

Substantive use of ChatGPT in code development, experimental-workflow formulation, and manuscript drafting is described in the Methods section. No AI system is listed as an author. Author review and responsibility must be completed before submission.

## Supplementary information

Online Resource 1 Complete reproducibility package containing the virtual manufacturing simulator, specialist and acquisition-policy implementations, all data partitions, fitted models, prediction records, statistical summaries, integrity tests, and investigation traces. The archive also contains the analysis and figure-generation source for this manuscript. An optional local LLM connector is included for future work and was not used to produce the reported experimental results

## References

[[REFERENCES]]

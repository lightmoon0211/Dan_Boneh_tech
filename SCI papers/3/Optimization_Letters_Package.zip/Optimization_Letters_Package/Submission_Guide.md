# Recommendation and revision record

**Recommended first target: Optimization Letters.** Checked 13 September 2026.

The publisher lists **Science Citation Index Expanded (SCIE)** and describes a scope encompassing optimization theory, algorithms and computational studies. This meets the requested SCI/SCIE category. Its preference for concise contributions of approximately 15 journal pages makes a focused exact-recovery theorem a more natural submission than the earlier broad manufacturing-agent narrative. This is a fit judgment, not a prediction of acceptance. [Journal and indexing](https://link.springer.com/journal/11590), [aims and scope](https://link.springer.com/journal/11590/aims-and-scope).

Computational Management Science was screened but excluded from this recommendation because its publisher lists ESCI rather than SCIE. [Publisher indexing list](https://link.springer.com/journal/10287).

## What was adjusted

- The title and abstract now lead with sharp recovery of continuation costs. The contribution is the information model, anchored-forest estimator, exact radius and matching lower bound. Established tree representations and Bellman recursion are acknowledged as foundations.
- Table 1 compares specific verified statements of Pachter–Speyer, Bryant–Tupper, Steel–Mimoto–Mooers and Carlsson–Mémoli. The distinction between cost-coordinate and distance-coordinate uncertainty is explicit. The screening of Farach–Kannan–Warnow is limited to its publisher abstract; its complete theorem-level comparison remains open.
- The original equations, proofs, tables and expanded bibliography are retained in Online Resource 1 and source archives. The main paper contains the full proofs of Theorems 3.3, 4.3 and 4.4. References are numeric and ordered by first-author surname within each document.
- The computation now includes 810 calibration cases, 54 decision instances, all three estimators, exact lower-bound examples and independent full-outcome policy replay. Every row and seed is supplied. Repair's slightly better mean estimation error is reported, alongside direct recovery's certified radius.

## Proof review and corrections

The separate reviewer was another AI analysis within this session. Its report and final-draft addendum are in `review/proof_review.md`. This is **not an external human review or formal certification**.

Theorem 3.3 was retained with an explicit exclusion of extra exact telemetry of F(A). Theorem 4.3 was retained with the correct mixed-set calculation and a sufficiently small penalty. Theorem 4.4's upper bounds hold for all nonempty anchor sets, but factor-two regret sharpness is stated for the unrestricted class and fixed anchor-set sizes at least two. Remark 4.6 gives the stronger one-anchor, one-call bound. Additional anchors in the unequal-tolerance sharpness construction are attached to existing branches, not placed at the root. The planning algorithm keeps anchors fixed.

These findings strengthen correctness and precision. They do not resolve whether editors will consider the exact functional bound sufficiently original and significant. The most valuable remaining scholarly check is a human expert's assessment of the result against optimal-recovery and noisy-tree literature, including the complete Farach–Kannan–Warnow paper.

## Files and journal preparation

Use the revised main Word document for author review. The package also contains a compiled manuscript and editable LaTeX using the publisher's class, because the journal-specific source instruction asks for LaTeX. The abstract is within 150–250 words, six keywords are supplied, and a Statements and Declarations section is present. Online Resource 1 is supplied as editable Word and PDF; Online Resource 2 is the reproducibility ZIP. [Submission guidelines](https://link.springer.com/journal/11590/submission-guidelines).

Before submission, the human authors must complete names, affiliations, contact details, funding, competing interests and contribution statements; verify all mathematical claims and references; and approve the final authorship and AI-use disclosure. A public code archive with a stable identifier would improve durability but no repository or DOI has been invented. Confirm the journal's current submission fields when uploading. No manuscript has been submitted, and no external researcher has been contacted.

## Reproduce

From the package directory, run:

```bash
python code/run_experiments.py --output results
```

Python 3.10 or newer is required; there are no third-party dependencies. Exact numerical outputs are reproducible; wall time in `verification.json` varies by machine. `sources/main.tex` compiles with `pdflatex` and the supplied `sn-jnl.cls`; run twice to settle cross-references. The publisher class was obtained from its [official LaTeX support page](https://www.springernature.com/gp/authors/campaigns/latex-author-support).

The code is this paper's reference implementation. It is not code authored by the cited researchers. `references_access.csv` maps every retained bibliography entry to its paper link and clearly distinguishes unverified code availability.

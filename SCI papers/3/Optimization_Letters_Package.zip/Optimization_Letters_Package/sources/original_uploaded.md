I have developed a theoretical companion manuscript around a precise problem: **recovering shared agent-query costs from individual and pairwise measurements, and proving how measurement errors affect optimal decisions**.

A provisional target is [**Applications of Mathematics**](https://link.springer.com/journal/10492). Its publisher lists SCIE indexing and a scope covering rigorous mathematical analysis, optimization, and probability. The draft below needs independent assessment of originality and proofs before submission. File generation failed, so I could not make a downloadable manuscript available.

---

# Minimax recovery and decision stability for tree-based evidence acquisition

**Author(s):** [Names, affiliations, ORCID identifiers, and corresponding-author email]

## Abstract

An autonomous diagnostic coordinator must decide which evidence sources to query and when to stop. When communication routes share activation costs, the cost of a group of queries depends on its network structure. We study the recovery of this cost from measurements of individual and pairwise acquisitions and its use in finite-horizon Bayesian decision making. For a nonnegative weighted rooted tree, we give a self-contained reconstruction formula based on a maximum-weight spanning tree of pairwise overlaps. If every individual and pairwise measurement has absolute error at most `\varepsilon`, the resulting estimate of an `m`-source cost has error at most `(2m-3)\varepsilon`, for `m\geq2`. A two-point construction proves that this constant is minimax optimal over the stated model class. The estimate induces explicit bounds on optimal decision values and on the excess loss of a policy optimized using measured costs. We also give a feasible repair of inconsistent measurements, characterize universal decision equivalence, and show why pairwise recovery fails for general shared-resource systems. Exact enumeration of a six-source synthetic manufacturing example illustrates the decision model. The results concern mathematical evidence-acquisition policies and do not assume an implemented language-model agent.

**Keywords:** rooted tree; minimax estimation; shared acquisition cost; Bayesian sequential decision; agentic manufacturing diagnosis.

## 1. Introduction

An agentic manufacturing diagnosis system can be viewed as a coordinator that acquires information from specialized sources, updates its belief about a fault, and chooses a final diagnosis. Graph representations already support multi-agent scheduling in manufacturing; for example, [Qin and Lu](https://doi.org/10.1007/s10845-024-02494-0) [6] combine knowledge graphs with multi-agent reinforcement learning. The present problem concerns the cost of accessing evidence when several sources share communication or session-activation resources.

Charging every query its full standalone access cost is appropriate when all communication expenses recur independently. If part of the expense is incurred once per investigation, however, later queries may reuse an activated route. A useful theoretical question is whether individual and pairwise cost measurements determine the cost of every larger group. A second question asks how errors in these measurements affect an optimal sequential diagnostic policy.

The mathematical ingredients have established antecedents. [Pachter and Speyer](https://arxiv.org/abs/math/0311156) [5] study reconstruction of trees from subtree weights. [Hunter](https://doi.org/10.2307/3212481) [3] uses spanning trees to optimize bounds on unions from first- and second-order information. Hierarchical representations and their stability are studied by [Carlsson and Mémoli](https://jmlr.csail.mit.edu/papers/v11/carlsson10a.html) [1]. Belief-state dynamic programming follows the finite-horizon partially observed control framework of [Smallwood and Sondik](https://doi.org/10.1287/opre.21.5.1071) [7]. [Adaptive submodularity](https://doi.org/10.1613/jair.3278) [2] and [robust observation selection](https://jmlr.org/papers/v9/krause08b.html) [4] address related acquisition problems under different assumptions and objectives.

We use these foundations to formulate a precise measurement-to-decision problem. The central result is the exact worst-case recovery radius `(2m-3)\varepsilon` for the cost of `m` sources. Its proof includes a matching lower bound for every estimator using the specified measurements. We then derive decision-value stability, policy excess-loss bounds, and a decision-equivalence characterization. Tree reconstruction and the Bellman principle serve as established foundations.

The application extends graph-orchestrated manufacturing diagnosis by introducing shared activation costs and optional stopping. These assumptions differ from a model that charges a complete route cost for every query. The numerical illustration is entirely synthetic.

## 2. Shared costs on a rooted tree

### 2.1. Model and notation

Let `N=\{1,\ldots,n\}` label evidence sources, and let `T` be a finite tree rooted at a coordinator `r`. Source `i` is associated with a vertex and the unique root-to-source path `P_i`. Each edge `e` has activation cost `a_e\geq0`, and source `i` has service cost `s_i\geq0`.

Each source is queried at most once during an investigation. An edge is charged when first activated and remains available until the investigation ends.

For `S\subseteq N`, define

```math
F(S)= \sum_{e\in\bigcup_{i\in S}P_i}a_e +\sum_{i\in S}s_i, \qquad F(\varnothing)=0. \tag{1}
```

This is a nonnegative, monotone weighted-coverage function. Service costs can be absorbed into private pendant edges of lengths `s_i`, placing each source label at the new endpoint. Thus all costs may be represented by root-path lengths, allowing zero-length edges.

Write

```math
c_i=F(\{i\}),\qquad c_{ij}=F(\{i,j\}),\qquad o_{ij}=c_i+c_j-c_{ij},\quad i\ne j. \tag{2}
```

The quantity `o_{ij}` is the cost of the common prefix of the two root paths. Service costs cancel from this overlap. Let `\mathcal T(S)` denote the spanning trees of the complete graph on `S`, when `|S|\geq2`.

The model describes shared activation or setup expenses. These expenses need not equal packet traffic, inference tokens, or wall-clock latency.

### 2.2. Compatibility and marginal costs

**Proposition 2.1 — Rooted-tree compatibility.**
A singleton and pair table admits a representation of the form (1) if and only if `c_i\geq0`, the overlaps are symmetric, and

```math
0\leq o_{ij}\leq\min(c_i,c_j), \qquad o_{ij}\geq\min(o_{ik},o_{jk}) \tag{3}
```

for distinct relevant indices. Under these conditions,

```math
F(A\cup\{j\})-F(A) = c_j-\max_{i\in A}o_{ij}, \qquad j\notin A, \tag{4}
```

where the maximum over the empty set is zero.

*Proof.* In a rooted tree, intersections of root paths are common prefixes. Their lengths give the bounds in (3). If the paths to `i` and `k` agree to depth `u`, and those to `j` and `k` agree to depth `v`, the paths to `i` and `j` agree to depth at least `\min(u,v)`. This proves the last inequality.

Conversely, at height `t\geq0`, group distinct labels satisfying `o_{ij}\geq t`, retaining each label as equivalent to itself. The last inequality in (3) makes these groups equivalence classes. As `t` increases, the classes refine and form a hierarchy.

Realize this hierarchy as a rooted tree whose branching depths are the distinct overlap values, with root depth zero. Place label `i` at depth `c_i`. Every nontrivial class containing `i` occurs at depth at most `c_i`, so all edge lengths are nonnegative. Zero-length edges accommodate tied depths. The resulting common-prefix depths are exactly `o_{ij}`, giving the prescribed individual and pair costs.

Finally, the intersection of `P_j` with the union of previously activated paths is its longest common prefix with those paths. Subtracting this already-paid length from `c_j` proves (4). `\square`

This construction uses the established correspondence between hierarchical similarities and rooted trees [1,5]. It identifies the set-cost function. A physical subdivision of edges, or a separate decomposition into service and communication expenses, need not be identifiable.

### 2.3. Reconstruction from pairs

**Proposition 2.2 — Spanning-tree reconstruction.**
For every `S\subseteq N` with `m=|S|\geq2`,

```math
F(S)= \sum_{i\in S}c_i- \max_{M\in\mathcal T(S)} \sum_{\{i,j\}\in E(M)}o_{ij}. \tag{5}
```

Equivalently,

```math
F(S)= \min_{M\in\mathcal T(S)} \left[ \sum_{\{i,j\}\in E(M)}c_{ij} - \sum_{i\in S}\bigl(\deg_M(i)-1\bigr)c_i \right]. \tag{6}
```

*Proof.* Let `W(S)` be the maximum spanning-tree weight in (5). Choose a pair `i,j` of maximum overlap `h` in `S`. Equation (4) gives

```math
F(S)=F(S\setminus\{j\})+c_j-h.
```

There is a maximum-weight spanning tree containing edge `ij`: adding this globally maximum-weight edge to a maximum tree and removing an edge from the resulting cycle cannot decrease its weight.

Moreover, (3) implies `o_{ik}\geq o_{jk}` for every `k\notin\{i,j\}`, since `h\geq o_{jk}`. In a maximum tree containing `ij`, replace every other edge `jk` by `ik`. The result remains a spanning tree, its weight does not decrease, and `j` becomes a leaf. Its restriction to `S\setminus\{j\}` must also be maximum. Consequently,

```math
W(S)=W(S\setminus\{j\})+h.
```

Induction, beginning with a singleton of spanning-tree weight zero, proves (5). Substituting (2) and collecting singleton coefficients proves (6). `\square`

The expression has the same spanning-tree structure as Hunter’s union bound [3]; rooted-path structure makes it exact. A dense maximum-spanning-tree algorithm evaluates a specified `m`-source cost in `O(m^2)` arithmetic operations. All subset costs are represented by `O(n^2)` measurements, although explicitly listing them requires exponential space.

## 3. Minimax recovery under measurement error

Suppose measurements satisfy

```math
|\widetilde c_i-c_i|\leq\varepsilon, \qquad |\widetilde c_{ij}-c_{ij}|\leq\varepsilon. \tag{7}
```

The measured table need not satisfy (3). Define `H(\varnothing)=0`, `H(\{i\})=\widetilde c_i`, and, for `|S|\geq2`, define `H(S)` by the right side of (6) using measured values.

### 3.1. Exact recovery radius

**Theorem 3.1 — Sharp error bound and minimax optimality.**
Set

```math
\alpha_0=0,\qquad \alpha_1=1,\qquad \alpha_m=2m-3\quad(m\geq2).
```

Then

```math
|H(S)-F(S)| \leq \alpha_{|S|}\varepsilon. \tag{8}
```

For each `m\geq2`, the coefficient `2m-3` cannot be reduced by replacing `H` with any other estimator based only on the individual and pairwise measurements.

*Proof.* Fix `S` of size `m\geq2`. Each spanning-tree expression in (6) contains `m-1` pair terms with coefficient `+1`. Since every vertex has degree at least one,

```math
\sum_{i\in S}|\deg_M(i)-1| = 2(m-1)-m=m-2.
```

Thus each expression changes by at most

```math
(m-1)\varepsilon+(m-2)\varepsilon = (2m-3)\varepsilon.
```

If every member of a finite family of real numbers changes by at most `d`, its minimum changes by at most `d`. Applying this fact to (6) proves (8). The empty and singleton cases are immediate.

For the lower bound, consider `m` leaves sharing a trunk of length `a>3\varepsilon`, with each pendant edge of length `b>2\varepsilon`. Let the measured table be that of this central tree:

```math
\widetilde c_i=a+b, \qquad \widetilde c_{ij}=a+2b.
```

Two possible true trees have trunk and pendant lengths

```math
(a_+,b_+)=(a-3\varepsilon,b+2\varepsilon),
```

```math
(a_-,b_-)=(a+3\varepsilon,b-2\varepsilon).
```

All edge lengths are nonnegative. In the first tree, every singleton is lower than its measurement by `\varepsilon`, while every pair is higher by `\varepsilon`. The signs are reversed in the second tree. Both trees satisfy (7) for the same observed table.

Their full-set costs are

```math
F_+(N)=a+mb+(2m-3)\varepsilon,
```

```math
F_-(N)=a+mb-(2m-3)\varepsilon.
```

An estimator receives identical input in these two cases. Its largest error must be at least half the distance between the two possible costs, namely `(2m-3)\varepsilon`. Together with (8), this proves minimax optimality. `\square`

Formally, let `\mathcal C_m` be the class of nonnegative rooted-tree cost functions on `m` labels, and let `D(F)` be the vector of singleton and pair costs. Then

```math
\inf_R \sup_{\substack{ F\in\mathcal C_m,\ z\\ \|z-D(F)\|_\infty\leq\varepsilon }} |R(z)-F(N)| = (2m-3)\varepsilon, \qquad m\geq2. \tag{9}
```

The infimum ranges over estimators `R`.

If singleton errors are bounded by `\varepsilon_1` and pair errors by `\varepsilon_2`, the same argument gives the sharp radius

```math
(m-2)\varepsilon_1+(m-1)\varepsilon_2.
```

For the lower bound, perturb the trunk by opposite amounts `2\varepsilon_1+\varepsilon_2`, and each pendant edge by opposite amounts `\varepsilon_1+\varepsilon_2`.

### 3.2. A feasible repair

The direct estimate `H` can be nonmonotone when measurements are incompatible. A physical network representation can instead be obtained by repairing the overlaps.

Define

```math
\widehat c_i=\max(0,\widetilde c_i),
```

```math
u_{ij} = \min\left\{ \widehat c_i,\widehat c_j, \max(0,\widetilde c_i+\widetilde c_j-\widetilde c_{ij}) \right\}. \tag{10}
```

For distinct `i,j`, define the maximum-bottleneck closure

```math
\widehat o_{ij} = \max_{\gamma:i\leadsto j} \min_{\{u,v\}\in E(\gamma)}u_{uv}, \tag{11}
```

where the maximum is over simple paths in the complete graph. Let `\widehat F` be the rooted-tree cost reconstructed from `\widehat c,\widehat o`.

**Proposition 3.2 — Feasibility and repair error.**
The repaired table satisfies (3). For every nonempty `S`,

```math
|\widehat F(S)-F(S)| \leq (4|S|-3)\varepsilon. \tag{12}
```

*Proof.* The closure is symmetric and nonnegative. Every path from `i` to `j` starts with an edge bounded by `\widehat c_i` and ends with one bounded by `\widehat c_j`. Hence

```math
\widehat o_{ij}\leq\min(\widehat c_i,\widehat c_j).
```

Concatenating paths through `k`, and removing loops without reducing the bottleneck, proves the final inequality in (3).

Singleton clipping has error at most `\varepsilon`. Raw overlap errors are at most `3\varepsilon`. The clipping in (10) preserves this bound because minimum and maximum are nonexpansive in the sup norm.

The maximum-bottleneck operation is also nonexpansive: perturbing every edge value by at most `d` perturbs each path bottleneck, and then their maximum, by at most `d`. This operation fixes the true overlap matrix, because repeated application of (3) bounds every path bottleneck by the direct true overlap. Therefore,

```math
\|\widehat o-o\|_\infty\leq3\varepsilon.
```

In (5), the singleton sum changes by at most `|S|\varepsilon`, while the maximum spanning-tree weight changes by at most `3(|S|-1)\varepsilon`. Adding these bounds proves (12). `\square`

The closure is a standard hierarchical operation related to single linkage [1]. A max-min version of Floyd’s algorithm computes it in `O(n^3)` time. The constant in (12) is a conservative guarantee; its sharpness is not asserted. Repair supplies nonnegative, monotone physical set costs, while direct recovery has the sharper guarantee in (8).

## 4. Sequential Bayesian decisions

### 4.1. Exact finite-horizon solution

Let the latent state `X` take values in a finite set `\mathcal X`, with prior `p`. Source `i` returns an observation in a finite set `\mathcal Y_i`, according to a known likelihood `L_i(y\mid x)`. Source observations are conditionally independent given `X`.

A final decision `d` belongs to a finite set `\mathcal D`, with loss `0\leq\ell(d,x)\leq1`. A policy may stop or query an unqueried source, with at most `B\leq n` queries. If its final queried set is `S_\tau`, its objective is

```math
J_F(\pi) = \mathbb E^\pi \left[ \ell(d_\tau,X)+\lambda F(S_\tau) \right], \qquad \lambda>0. \tag{13}
```

The query limit is a call budget; monetary cost appears as a penalty. A hard monetary constraint would make the admissible policy class depend on the estimated cost and requires separate treatment.

For posterior `p`, define

```math
r(p)= \min_{d\in\mathcal D}\sum_xp(x)\ell(d,x),
```

```math
q_i(y\mid p)=\sum_xp(x)L_i(y\mid x), \qquad T_i(p,y)(x)= \frac{p(x)L_i(y\mid x)}{q_i(y\mid p)}. \tag{14}
```

Outcomes of zero predictive probability are omitted.

**Proposition 4.1 — Bellman recursion.**
The minimum expected remaining loss and future acquisition cost, after querying `A` and with `b` calls remaining, is

```math
V_0(p,A)=r(p), \tag{15}
```

and, for `b\geq1`,

```math
\begin{aligned} V_b(p,A)=\min\Bigg\{r(p),\ \min_{i\notin A}\Bigg[ &\lambda\bigl(F(A\cup\{i\})-F(A)\bigr)\\ &+\sum_yq_i(y\mid p) V_{b-1}\bigl(T_i(p,y),A\cup\{i\}\bigr) \Bigg]\Bigg\}. \end{aligned} \tag{16}
```

If no source remains, only the stopping term is used. A deterministic optimal policy exists.

*Proof.* Conditional independence makes `(p,A,b)` sufficient for predicting every remaining observation. Stopping incurs Bayes risk `r(p)`. Querying `i` incurs its marginal cost and the optimal continuation value under the updated posterior.

Backward induction over `b` proves (15)–(16). The action and observation sets are finite, so every minimum is attained. Marginal costs telescope to `F(S_\tau)`, giving (13) at the initial state. `\square`

This specializes finite-horizon belief-state dynamic programming [7]. With at most `q` outcomes per source, there are at most

```math
\sum_{m=0}^{B}\binom nm q^m
```

partial observation assignments from a fixed prior. Compact representation of acquisition costs therefore does not make exact adaptive optimization polynomial.

The same recursion applies to `H`, using differences `H(A\cup\{i\})-H(A)`. When raw measurements are incompatible, these differences must be evaluated from the set estimate: formula (4) need not hold for noisy overlaps. Negative surrogate increments do not invalidate finite-horizon optimization, although they lack a physical activation-cost interpretation.

### 4.2. Stability of values and policies

Write `V_F=\min_\pi J_F(\pi)`, `V_H=\min_\pi J_H(\pi)`, and

```math
\beta_B= \max_{0\leq m\leq B}\alpha_m = \begin{cases} 0,&B=0,\\ 1,&B=1,\\ 2B-3,&B\geq2. \end{cases} \tag{17}
```

**Theorem 4.2 — Decision stability.**
Under (7), for the same likelihoods, loss, prior, call budget, and penalty weight,

```math
|V_F-V_H| \leq \lambda\beta_B\varepsilon. \tag{18}
```

If `\pi_H` minimizes the measured-cost objective, then

```math
0\leq J_F(\pi_H)-V_F \leq 2\lambda\beta_B\varepsilon. \tag{19}
```

For `B\geq2`, the coefficient in (18) is sharp over this decision-model class.

*Proof.* Fix any history-dependent policy `\pi`. Holding this policy fixed, replacing the cost table does not change the observation law or its stopping decisions. Since `|S_\tau|\leq B`, Theorem 3.1 gives

```math
\begin{aligned} |J_F(\pi)-J_H(\pi)| &\leq \lambda\mathbb E^\pi |F(S_\tau)-H(S_\tau)|\\ &\leq \lambda\beta_B\varepsilon. \end{aligned}
```

Taking minima proves (18). If `\pi_F` is optimal for `F`, then

```math
\begin{aligned} J_F(\pi_H) &\leq J_H(\pi_H)+\lambda\beta_B\varepsilon\\ &\leq J_H(\pi_F)+\lambda\beta_B\varepsilon\\ &\leq V_F+2\lambda\beta_B\varepsilon, \end{aligned}
```

which proves (19).

For sharpness of (18), take `B` independent fair bits `X_1,\ldots,X_B` as the latent state. Source `i` reveals `X_i` deterministically, and the final decision predicts their parity under zero-one loss. Conditional independence holds given the complete latent state. Every proper subset leaves parity uniformly distributed, while the full set determines it.

For a nonnegative monotone cost function `K`, a policy completing all queries with probability `u` has objective at least

```math
u\lambda K(N)+(1-u)/2.
```

Always stopping or always completing attains the two endpoints. The optimal value is consequently

```math
\min\{1/2,\lambda K(N)\}.
```

Use the central tree and the plus perturbation from Theorem 3.1, choosing `\lambda` small enough that full acquisition is optimal for both. Their values differ by exactly

```math
\lambda(2B-3)\varepsilon.
```

This proves sharpness. `\square`

The factor two in (19) is an upper bound; its sharpness is not asserted. Replacing `H` by the repaired estimate gives corresponding value and excess-loss bounds with `4B-3`, for `B\geq1`.

The parity example also shows a limitation of one-step policies. If every initial acquisition has positive cost, a policy comparing only immediate Bayes-risk reduction with acquisition cost stops without querying. Its value remains `1/2`, while the optimum is `\lambda F(N)` for sufficiently small `\lambda`. Their ratio is unbounded as `\lambda` approaches zero. Thus tree structure alone does not provide a general one-step approximation guarantee; assumptions on information value are also required [2].

## 5. Decision equivalence and the boundary of the model

### 5.1. Which network information is decision-relevant?

**Theorem 5.1 — Universal decision equivalence.**
Let `F` and `G` be rooted-tree cost functions on the same `n\geq2` labels. Fix `2\leq B\leq n`. The following statements are equivalent:

1. `F` and `G` agree on every singleton and pair.
2. They agree on every subset of sources.
3. They have equal optimal values for every finite decision experiment described in Section 4 and every `\lambda>0`, under the same call limit `B`.

*Proof.* Proposition 2.2 gives statement 1 implies statement 2. Identical set costs give identical objectives for every policy, proving statement 2 implies statement 3.

Suppose statement 1 fails on a set `S` of size one or two. Let each source in `S` reveal one independent fair bit, let every other source return a constant, and let the final decision predict the parity of the bits in `S`.

By the argument in Theorem 4.2 and monotonicity of acquisition costs, the optimal value under a cost function `K` is

```math
\min\{1/2,\lambda K(S)\}.
```

Choose `\lambda>0` small enough that acquiring `S` is optimal under both `F` and `G`. Since `F(S)\ne G(S)`, their optimal values differ, contradicting statement 3. `\square`

For `B=1`, only singleton costs matter. The quantifier over all positive `\lambda` is essential: a sufficiently high fixed penalty can make immediate stopping optimal in both networks and conceal cost differences.

### 5.2. Failure for general shared resources

Rooted-path structure cannot be inferred solely from a compatible pair table. Consider three sources.

In system A, there are three resources `e_{12},e_{13},e_{23}`, each of cost one. Source 1 uses `e_{12},e_{13}`; source 2 uses `e_{12},e_{23}`; source 3 uses `e_{13},e_{23}`.

In system B, every source uses a common resource of cost one and its own private resource of cost one.

Both systems have singleton cost two and pair cost three. Their triple costs differ:

```math
F_A(\{1,2,3\})=3, \qquad F_B(\{1,2,3\})=4. \tag{20}
```

System B is a rooted-tree model; system A is a general coverage system. Individual and pairwise measurements therefore cannot identify all group costs over the broader class. Even a table satisfying Proposition 2.1 does not certify that the physical system has rooted-path structure.

## 6. Synthetic manufacturing illustration

### 6.1. Fully specified instance

Consider six evidence sources: telemetry, quality, maintenance, materials, scheduling, and assembly. Their labels describe diagnostic roles. No physical factory data or language-model outputs are used.

The rooted routing tree has the following activation edges.

| EdgeActivation cost      |     |
| ------------------------ | --- |
| Coordinator → Telemetry  | 2.0 |
| Telemetry → Quality      | 1.6 |
| Telemetry → Maintenance  | 1.4 |
| Coordinator → Materials  | 2.6 |
| Coordinator → Scheduling | 2.0 |
| Scheduling → Assembly    | 1.8 |

An activation expense is paid once per investigation.

**Table 1. Synthetic source parameters.**

| SourceService costSingleton costAssumed accuracy |     |     |      |
| ------------------------------------------------ | --- | --- | ---- |
| Telemetry                                        | 1.0 | 3.0 | 0.75 |
| Quality                                          | 1.1 | 4.7 | 0.80 |
| Maintenance                                      | 0.9 | 4.3 | 0.78 |
| Materials                                        | 0.8 | 3.4 | 0.65 |
| Scheduling                                       | 0.9 | 2.9 | 0.70 |
| Assembly                                         | 1.3 | 5.1 | 0.88 |

The three pairs within `\{\text{telemetry},\text{quality},\text{maintenance}\}`, and the scheduling–assembly pair, have overlap 2.0. Every other overlap is zero. These values and Table 1 specify every pair cost through (2).

For example, quality and maintenance together cost

```math
4.7+4.3-2.0=7.0.
```

Adding telemetry costs `3.0-2.0=1.0`, giving a three-source total of 8.0. Acquiring all six sources costs 17.4; the sum of standalone costs is 23.4. This difference follows from the assumed accounting rule and is not an empirical manufacturing saving.

Let `X\in\{0,1\}` have prior probability `1/2`. Each source is a binary symmetric channel with the accuracy in Table 1, independently conditional on `X`. The final loss is diagnostic misclassification, and at most four sources may be queried.

We compare the Bellman-optimal policy with a myopic policy minimizing, at each history,

```math
\begin{aligned} \min\Bigg\{r(p),\ \min_{i\notin A}\Bigg[ &\lambda\bigl(F(A\cup\{i\})-F(A)\bigr)\\ &+\sum_yq_i(y\mid p)r(T_i(p,y)) \Bigg]\Bigg\}. \end{aligned} \tag{21}
```

The myopic policy repeats this rule after each observation. Ties favor stopping, then the earliest source in Table 1.

### 6.2. Exact results

**Table 2. Exact policy expectations for the synthetic instance.**

| `\lambda`PolicyError probabilityExpected costExpected callsObjective |         |        |         |        |           |
| -------------------------------------------------------------------- | ------- | ------ | ------- | ------ | --------- |
| 0.005                                                                | Optimal | 0.0792 | 7.83012 | 2.4716 | 0.1183506 |
| 0.005                                                                | Myopic  | 0.1200 | 5.10000 | 1.0000 | 0.1455000 |
| 0.010                                                                | Optimal | 0.0828 | 7.39230 | 2.4770 | 0.1567230 |
| 0.010                                                                | Myopic  | 0.1200 | 5.10000 | 1.0000 | 0.1710000 |
| 0.020                                                                | Optimal | 0.1200 | 5.10000 | 1.0000 | 0.2220000 |
| 0.020                                                                | Myopic  | 0.1200 | 5.10000 | 1.0000 | 0.2220000 |
| 0.040                                                                | Optimal | 0.1200 | 5.10000 | 1.0000 | 0.3240000 |
| 0.040                                                                | Myopic  | 0.1200 | 5.10000 | 1.0000 | 0.3240000 |

At the two smaller penalty weights, the optimal policy first queries scheduling, whereas the myopic policy queries assembly and stops. Although assembly has greater assumed standalone accuracy, planning ahead accounts for shared activation and subsequent evidence. At the larger penalty weights, both policies query assembly and stop. These results establish behavior only for the specified finite instance.

For calibration tolerance `\varepsilon=0.05`, the four-call limit gives `\beta_4=5`. At `\lambda=0.01`, Theorem 4.2 bounds the optimal-value error by 0.0025 and the excess objective of the measured-cost policy by 0.005. These are worst-case guarantees under the calibration assumption, rather than observed average errors.

All computations used normalized integer fractions implemented with JavaScript BigInt. The Bellman calculation considered 473 partial observation assignments, equal to

```math
\sum_{m=0}^{4}\binom6m2^m.
```

For each policy and penalty, its terminal decision, cost, and query count were independently evaluated by replaying all

```math
2\times2^6=128
```

latent-state/full-observation combinations with their exact probabilities. Across the eight policy cases, all 1,024 replay outcomes reproduced the dynamic-programming expectations exactly. Table 2 reports exact finite-model expectations, rather than Monte Carlo estimates.

### 6.3. Algebraic implementation checks

A separate verification generated 100 rooted trees with six labeled source vertices. Vertex `i` selected its parent among `0,\ldots,i-1`, with vertex 0 the root. Edge weights were selected from `\{0.1,0.2,\ldots,3.0\}`, and service costs from `\{0.1,0.2,\ldots,1.0\}`. A 32-bit linear congruential generator used seed 20260911, multiplier 1664525, and increment 1013904223.

For each tree, all 64 subsets were checked. Direct unions of root paths agreed exactly with Proposition 2.2 in all 6,400 cases. All 19,200 available source-addition marginals agreed with (4).

Singleton and pair measurements were perturbed by values in `\{-1/20,0,1/20\}`. All 6,400 direct-estimate bounds and all 6,400 repaired-estimate bounds held, and every repaired overlap table satisfied (3). The sharpness construction was additionally checked for `m=2,\ldots,8`.

These finite checks support implementation consistency. The universal claims and minimax lower bound follow from the proofs.

## 7. Discussion and concluding remarks

The mathematical problem separates into identification, estimation, and decision making. Under the rooted-tree assumption, pairwise overlap data determine every acquisition cost. Under bounded measurement error, the cost of an `m`-source group has minimax recovery radius `(2m-3)\varepsilon`. This radius quantifies unavoidable amplification of measurement uncertainty, including cases in which the measured table itself is compatible with a tree.

For sequential decisions, uniform cost recovery transfers directly to optimal-value and policy excess-loss guarantees. The transfer does not depend on a particular diagnostic classifier, but it requires an unchanged observation model and a common call-constrained policy class. Likelihood misspecification, time-varying costs, repeated queries, resource deactivation, and hard monetary budgets require separate analysis.

The application illustrates how a coordinator can use the theory to choose sources and determine when to stop. It does not establish industrial validity or the performance of an implemented large-language-model system. Exact adaptive optimization remains exponential in the number of sources; scalable approximations need additional structure.

The counterexample in Section 5 identifies a substantive boundary: pair measurements suffice within the rooted-path class but do not suffice for general shared resources. Extensions to partially observed routing structures, higher-order calibration measurements, and joint uncertainty in costs and likelihoods provide concrete directions for further research.

## Declarations

**Funding:** [To be completed by the human authors.]

**Competing interests:** [To be completed by the human authors.]

**Author contributions:** [To be completed by the human authors.]

**Data and code availability:** No empirical dataset was collected. All parameters defining the synthetic decision instance are provided in Section 6. The exact-arithmetic verification source and output log must be attached or archived before submission; no public repository is asserted in this draft.

**AI assistance:** ChatGPT was used to develop the mathematical formulation, proposed proofs, verification code, and manuscript text. Independent human verification of the mathematical claims, literature positioning, and final manuscript is required before submission.

## References

[1] G. Carlsson and F. Mémoli, [Characterization, stability and convergence of hierarchical clustering methods](https://jmlr.csail.mit.edu/papers/v11/carlsson10a.html), *Journal of Machine Learning Research* **11** (2010), 1425–1470.

[2] D. Golovin and A. Krause, [Adaptive submodularity: Theory and applications in active learning and stochastic optimization](https://doi.org/10.1613/jair.3278), *Journal of Artificial Intelligence Research* **42** (2011), 427–486.

[3] D. Hunter, [An upper bound for the probability of a union](https://doi.org/10.2307/3212481), *Journal of Applied Probability* **13** (1976), no. 3, 597–603.

[4] A. Krause, H. B. McMahan, C. Guestrin, and A. Gupta, [Robust submodular observation selection](https://jmlr.org/papers/v9/krause08b.html), *Journal of Machine Learning Research* **9** (2008), 2761–2801.

[5] L. Pachter and D. Speyer, [Reconstructing trees from subtree weights](https://arxiv.org/abs/math/0311156), *Applied Mathematics Letters* **17** (2004), no. 6, 615–621. Link provides the authors’ preprint.

[6] Z. Qin and Y. Lu, [Knowledge graph-enhanced multi-agent reinforcement learning for adaptive scheduling in smart manufacturing](https://doi.org/10.1007/s10845-024-02494-0), *Journal of Intelligent Manufacturing* **36** (2025), 5943–5966.

[7] R. D. Smallwood and E. J. Sondik, [The optimal control of partially observable Markov processes over a finite horizon](https://doi.org/10.1287/opre.21.5.1071), *Operations Research* **21** (1973), no. 5, 1071–1088.

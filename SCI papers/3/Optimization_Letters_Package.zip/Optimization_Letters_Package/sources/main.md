# Sharp recovery of continuation costs in tree-based sequential decisions

**Authors:** [Names, affiliations, corresponding-author email and ORCID identifiers]

## Abstract

Shared activation costs arise when sequential queries reuse paths in a rooted network. We study the recovery of the additional cost of future queries from inaccurate singleton and pair acquisition costs. The network is an unknown nonnegative weighted rooted tree, and measurement errors are bounded separately for singletons and pairs. For a fixed nonempty set of previously queried sources and a batch of $k$ new sources, we express the continuation cost as a minimum over forests with one previously queried source in each component. Contracting these sources gives a minimum spanning-tree algorithm. The estimator has minimax absolute-error radius $k$ times the sum of the two measurement tolerances, independently of the size of the previous query set. A matching construction proves sharpness even when the measured table is itself tree compatible. We transfer this radius to finite-horizon Bayesian decision values and surrogate-policy regret, and establish sharpness with explicit qualifications on the policy class and anchor configuration. Exact computations compare direct continuation recovery, subtraction of total-cost estimates and feasible tree repair. The results concern bounded cost-calibration error with a fixed observation model; they do not require identification of the physical topology.

**Keywords:** optimal recovery; rooted tree; minimum spanning tree; sequential decision; deterministic uncertainty; shared acquisition cost.

## 1. Introduction

After a set of sources has been queried, a decision maker needs the cost of further acquisition. Shared activation makes this a difference of set costs. Estimating two large totals separately can amplify error with the length of the query history. This paper estimates the continuation cost directly and determines its exact worst-case uncertainty from singleton and pair calibration data.

The cost model belongs to established tree-based models. It is rooted phylogenetic diversity after adding the root to each selected set [11, 1], and is related to standard tree cost-allocation games [6]. We claim neither a new tree representation nor a new Bellman principle. Our central contribution is the exact deterministic recovery radius for a continuation functional under a specified coordinatewise measurement model. Theorem 3.3 gives an anchored-forest identity, an algorithm and a matching minimax lower bound. Theorems 4.3 and 4.4 establish tight policy-loss examples within the same physical model, while distinguishing universal upper bounds from sharpness in restricted anchor configurations.

### 1.1. Direct comparison with existing results

Table 1 compares the closest verified representation and stability statements. These are different recovery targets, so their constants are not competing numerical estimates of the same quantity. The theorem identifiers refer to the linked author preprints or published full texts.

**Table 1. Measurements, assumptions and targets in related theorems.**

| Prior result | Measurements and assumptions | Target and guarantee | Difference addressed here |
|---|---|---|---|
| Pachter–Speyer [9], unnumbered main theorem, Section 2 | All m-leaf subtree weights; positive edges, no degree-2 vertices; m ≥ 3 | Entire tree determined when n ≥ 2m − 1; failure possible at n = 2m − 2 | Our data are rooted singleton/pair costs; the target is a specified continuation functional, with an exact error radius and no minimum-edge condition. |
| Bryant–Tupper [1], Theorems 5.7 and 5.9 | An exact phylogenetic diversity and its induced metric | Characterization by a real-tree tight span; agreement of metric and diversity tight spans | These representation theorems do not give the continuation radius under our calibration error box. |
| Steel–Mimoto–Mooers [11], Theorem 3.1 | Known rooted tree and independent extinction probabilities | Expected marginal diversity equals a sum of edge lengths weighted by extinction products | Fixing the surviving set gives the same marginal-cost interpretation; our task is recovery from uncertain pair data, including batches. |
| Carlsson–Mémoli [2], Proposition 26 | Finite metric spaces, compared in Gromov–Hausdorff distance | Single linkage is nonexpansive, with Lipschitz constant 1 | The target is a hierarchy, not total activated length; our coefficient count and lower bound use singleton/pair cost coordinates. |

Pachter and Speyer also give a robustness remark involving half the smallest edge length. That is a topology-recovery condition. Our theorem permits arbitrarily short and zero-length edges because it bounds a scalar cost without certifying a topology. The standard spanning-tree union bound of Hunter [7] becomes exact for rooted paths; we treat this identity as a foundation. The overlap repair is likewise a single-linkage construction [5, 2].

The distinction between acquisition costs and distances matters. If the root is denoted by 0, the associated distances satisfy

$$d_{0i}=c_i,\qquad d_{ij}=2c_{ij}-c_i-c_j. \tag{1}$$

Thus cost-coordinate errors $e_i,e_{ij}$ induce distance errors $e_i$ and $2e_{ij}-e_i-e_j$. Replacing these correlated constraints by independent distance intervals changes the information model. Farach, Kannan and Warnow [4] study interval and incomplete distance data for fitting trees. Their publisher abstract establishes this neighboring problem; we do not attribute a theorem-level separation to their inaccessible full text. Optimal recovery supplies the general viewpoint [3]; the sharp constants below require the particular tree-cost geometry.

Recent irrigation-game results also concern known tree costs and allocation. Márkus, Pintér and Radványi [8], Lemma 13, record concavity, while their Section 2 places a player at every non-root vertex. Our representation permits unlabeled branching vertices. Neither concavity nor the broad rooted-cost interpretation is advanced as the contribution here. Online Resource 1 retains the extended background, foundational proofs and the original synthetic example.

## 2. Model and exact recovery

Let $N$ be a finite set of labeled sources in a rooted tree. Each edge has nonnegative activation cost $a_e$ and each source has nonnegative service cost $s_i$. An activated edge is paid for once; each source can be queried once. Writing $P_i$ for its root path, define

$$F(S)=\sum_{e\in\bigcup_{i\in S}P_i}a_e+\sum_{i\in S}s_i,\qquad F(\varnothing)=0. \tag{2}$$

Private pendant edges absorb service costs, and zero-length edges are allowed. Define singleton costs $c_i=F(\{i\})$, pair costs $c_{ij}=F(\{i,j\})$ and overlaps $o_{ij}=c_i+c_j-c_{ij}$.

**Proposition 2.1 (Compatibility and marginals).** A symmetric table is representable by (2) if and only if $c_i\geq0$ and, for distinct indices,

$$0\leq o_{ij}\leq\min(c_i,c_j),\qquad o_{ij}\geq\min(o_{ik},o_{jk}). \tag{3}$$

For $j\notin A$ its marginal is

$$F(A\cup\{j\})-F(A)=c_j-\max_{i\in A}o_{ij}, \tag{4}$$

with maximum zero for empty $A$.

*Proof.* Common root-path prefixes give (3). Conversely, thresholding $o_{ij}$ at each height gives nested equivalence classes. Realize these classes as branching points and extend label $i$ to depth $c_i$. All edges are nonnegative. The already activated part of $P_j$ is its longest prefix shared with a member of $A$, giving (4). The full construction is retained in Online Resource 1. $\square$

**Proposition 2.2 (Spanning-tree identity).** For $m=|S|\geq2$ and the spanning trees $M$ on $S$,

$$F(S)=\min_M\left\{\sum_{ij\in E(M)}c_{ij}-\sum_{i\in S}(\deg_M(i)-1)c_i\right\}. \tag{5}$$

*Proof.* Equivalently, subtract a maximum spanning-tree weight in overlaps from $\sum_{i\in S}c_i$. Choose a pair of maximum overlap $h$. A maximum spanning tree can include this edge and, using (3), can be transformed so one endpoint is a leaf without decreasing weight. Removing that label reduces both the cost and the formula by $c_i-h$, by (4). Induction proves the identity. Online Resource 1 gives each exchange step. $\square$

## 3. Sharp recovery of continuation costs

The available measurements are a full singleton/pair table $z$ satisfying

$$|z_i-c_i|\leq\varepsilon_1,\qquad |z_{ij}-c_{ij}|\leq\varepsilon_2. \tag{6}$$

The tolerances are nonnegative and deterministic. The measured table need not be compatible. The information supplied to an estimator consists of this table and the source labels; the physical topology is unknown. In particular, an already queried set does not supply an additional exact observation of its incurred total cost. If such telemetry is available, the lower bounds require a different information model.

### 3.1. Initial recovery and physical repair

Let $H$ use (5) with $z$ in place of $c$, with $H(\varnothing)=0$ and $H(\{i\})=z_i$.

**Theorem 3.1 (Initial minimax radius).** For $m\geq2$,

$$|H(S)-F(S)|\leq(m-2)\varepsilon_1+(m-1)\varepsilon_2. \tag{7}$$

This is the minimax absolute-error radius over nonnegative rooted-tree costs. The radii for $m=0,1$ are $0,\varepsilon_1$.

*Proof.* Each tree expression has $m-1$ pair coefficients and total absolute singleton coefficient $m-2$. Taking a minimum preserves the resulting perturbation bound. For a matching lower bound, start from a shared trunk $a>2\varepsilon_1+\varepsilon_2$ and equal pendant lengths $q>\varepsilon_1+\varepsilon_2$. Use its table as the measurements. Two true trees have parameters

$$a_\pm=a\mp(2\varepsilon_1+\varepsilon_2),\qquad q_\pm=q\pm(\varepsilon_1+\varepsilon_2). \tag{8}$$

Their singleton deviations are $\mp\varepsilon_1$ and pair deviations $\pm\varepsilon_2$. Their full-set costs differ by twice (7). Every estimator sees the same table and has at least the half-separation error in one case. $\square$

**Proposition 3.2 (Feasible repair; retained result).** Under equal tolerances $\varepsilon$, clip $z_i$ to nonnegative values, clip each measured overlap to the permitted endpoint heights, and take its maximum-bottleneck closure. This gives a compatible rooted-tree estimate $\widehat F$ with

$$|\widehat F(S)-F(S)|\leq(4|S|-3)\varepsilon\quad(S\ne\varnothing). \tag{9}$$

The explicit algorithm and full proof appear in Online Resource 1. The bound is conservative; we make no sharpness claim for repair.

### 3.2. Anchored-forest recovery

Fix disjoint sets $A,S$ with $A\ne\varnothing$ and $k=|S|$. The continuation target is $\Delta_F(A,S)=F(A\cup S)-F(A)$. Call the previously queried sources in $A$ anchors. Let $\mathcal R_A(S)$ be the forests on $A\cup S$ having exactly one anchor in each component; unused anchors may be isolated. Every such forest has $k$ edges. For $k\geq1$ put

$$T_z(R)=\sum_{uv\in E(R)}z_{uv}-\sum_{j\in S}(\deg_R(j)-1)z_j-\sum_{a\in A}\deg_R(a)z_a, \tag{10}$$

$$H_A(S)=\min_{R\in\mathcal R_A(S)}T_z(R),\qquad H_A(\varnothing)=0. \tag{11}$$

**Theorem 3.3 (Sharp continuation recovery).** Under (6), fix nonempty $A$ and disjoint $S$ with $|S|=k$. Then

$$\Delta_F(A,S)=\min_R T_c(R),\qquad |H_A(S)-\Delta_F(A,S)|\leq k(\varepsilon_1+\varepsilon_2). \tag{12}$$

Among all estimators supplied only with the stated calibration data, the minimax absolute-error radius is exactly $k(\varepsilon_1+\varepsilon_2)$. It is independent of $|A|$. Evaluation takes $O(|A|k+k^2)$ arithmetic operations and uses no anchor–anchor pairs.

*Proof.* Orient an admissible forest toward its anchor roots and order the new vertices so parents precede children. When adding $j$, the queried set already contains its parent. By (4), the actual marginal is at most $c_j$ minus its overlap with that parent. Summing gives

$$\Delta_F(A,S)\leq\sum_{j\in S}c_j-\sum_{uv\in E(R)}o_{uv}=T_c(R).$$

Conversely, choose any ordering of $S$ and attach each new vertex to an anchor or earlier new vertex of maximum overlap. Such a parent exists. Parent pointers move backward until reaching an anchor, so they define a forest with exactly one anchor per component. Formula (4) now holds with equality at each addition. This proves the identity.

Every new vertex has degree at least one, and the forest has $k$ edges. Hence

$$\sum_{j\in S}(\deg_R(j)-1)+\sum_{a\in A}\deg_R(a)=2k-k=k. \tag{13}$$

There are $k$ pair coefficients and total absolute singleton coefficient $k$. Each forest expression changes by at most $k(\varepsilon_1+\varepsilon_2)$; its minimum does too.

For sharpness, use the two stars (8) on all labels, with the same central measured table. Both satisfy every measurement constraint, including anchor–anchor pairs. Since $A$ is nonempty, its acquired paths already contain the trunk. The two continuation costs are

$$kq\pm k(\varepsilon_1+\varepsilon_2). \tag{14}$$

Their half-separation proves the lower bound, also if further labels are present on the same star. For zero tolerances the conclusion is immediate.

For computation, contract all anchors to a vertex 0 and set

$$w_{ij}=z_{ij}-z_i-z_j,\qquad w_{0j}=\min_{a\in A}(z_{aj}-z_a-z_j). \tag{15}$$

Then $H_A(S)=\sum_{j\in S}z_j+\operatorname{MST}(\{0\}\cup S,w)$. Contracting a permissible forest gives a spanning tree. Conversely, removing 0 from a spanning tree leaves components each with one former root edge. Lift that edge to an anchor attaining its minimum in (15). This creates no cycle and leaves exactly one anchor per component; several components may use the same anchor. Thus the optimization is equivalent. Computing root weights costs $O(|A|k)$ and dense minimum spanning-tree computation costs $O(k^2)$. The contracted weights need not be an ultrametric. $\square$

### 3.3. Why subtracting total estimates can be unstable

**Proposition 3.4 (History-dependent amplification).** With equal tolerance $\varepsilon>0$, there are admissible measurements with $h=|A|\geq2$ and $S=\{j\}$ such that

$$H(A\cup\{j\})-H(A)=q-4(h-1)\varepsilon,\qquad H_A(\{j\})=\Delta_F(A,\{j\})=q. \tag{16}$$

*Proof.* Use a true star with trunk $a>3\varepsilon$ and pendants $q>0$. Decrease anchor singletons by $\varepsilon$, increase $z_j$ by $\varepsilon$, increase anchor–anchor pairs by $\varepsilon$, and decrease anchor–$j$ pairs by $\varepsilon$. The measured overlaps are $a-3\varepsilon$ between anchors and $a+\varepsilon$ to $j$. A maximum-overlap tree on $A\cup\{j\}$ is the star centered at $j$. Consequently the two total-estimation errors are $(2h-3)\varepsilon$ and $-(2h-1)\varepsilon$. Their difference proves (16); directly, $H_A(\{j\})=\min_a(z_{aj}-z_a)=q$. $\square$

**Proposition 3.5 (Heterogeneous certificate).** If each singleton and pair has its own error bound $e_i,e_{ij}$, set

$$r(R)=\sum_{uv\in E(R)}e_{uv}+\sum_{j\in S}(\deg_R(j)-1)e_j+\sum_{a\in A}\deg_R(a)e_a. \tag{17}$$

Then $L=\min_R(T_z(R)-r(R))\leq\Delta_F(A,S)\leq U=\min_R(T_z(R)+r(R))$.

*Proof.* Each forest expression lies within its stated interval. Taking minima preserves the two inequalities. Compute $L$ using singleton inputs $z_i+e_i$ and pair inputs $z_{ij}-e_{ij}$ in (11); reverse the signs for $U$. These are conservative bounds, not asserted to be the exact extrema over feasible trees. $\square$

## 4. Consequences for sequential decisions

Let a finite latent state $X$ have a fixed current posterior $p$. A source has a known finite observation kernel, conditionally independent of other sources given $X$. A terminal decision has loss in $[0,1]$. Policies may query unused sources or stop, with a fixed call budget. Cost enters as a penalty $\lambda>0$, not a hard feasibility constraint. Changing the calibration table does not change the posterior, likelihoods, loss or permissible policies.

**Proposition 4.1 (Bellman principle).** Write $r(p)$ for the Bayes stopping risk, $q_i(y\mid p)$ for predictive probabilities and $p^{i,y}$ for the updated posterior. For a terminal set-cost potential $K$, the remaining-value recursion at queried set $U$ is

$$\begin{aligned}V_b(p,U)=\min\Bigl\{r(p),\min_{i\notin U}\Bigl[&\lambda(K(U\cup\{i\})-K(U))\\&+\sum_yq_i(y\mid p)V_{b-1}(p^{i,y},U\cup\{i\})\Bigr]\Bigr\},\end{aligned} \tag{18}$$

with $V_0=r$ and unavailable actions omitted.

*Proof.* Condition on the first action and observation and apply backward induction. Finite action and observation sets attain the minima; increments telescope. This is the finite-horizon belief-state principle [10]. For continuation planning, unavailable anchors are also omitted from the action set. The state may be written as the new queried set $U$ with a fixed anchor parameter $A$. $\square$

**Theorem 4.2 (Initial decision stability).** Under equal tolerance $\varepsilon$, put $\alpha_0=0$, $\alpha_1=1$, $\alpha_m=2m-3$ for $m\geq2$, and $\beta_B=\max_{0\leq m\leq B}\alpha_m$. Write $J_K(\pi)=\mathbb E^\pi[\ell+\lambda K(S_\tau)]$, $V_K=\min_\pi J_K(\pi)$ and let $\pi_H$ minimize $J_H$. Then

$$|V_F-V_H|\leq\lambda\beta_B\varepsilon,\qquad 0\leq J_F(\pi_H)-V_F\leq2\lambda\beta_B\varepsilon. \tag{19}$$

*Proof.* Every fixed policy has $|J_F(\pi)-J_H(\pi)|\leq\lambda\beta_B\varepsilon$ by Theorem 3.1. Taking minima proves the first bound. Compare the surrogate-optimal policy to a true-optimal policy through their surrogate objectives to obtain the second. This perturbation argument is elementary; the substantive sharpness question is whether the extreme policy losses occur within the tree model. $\square$

**Theorem 4.3 (Sharp initial policy-regret constant).** For every $B=k\geq2$ and $\varepsilon>0$, the coefficient two in (19) is sharp uniformly over finite decision models and surrogate-optimal policies, with a sufficiently small positive penalty. This is not minimax optimality among all possible decision procedures.

*Proof.* Put $\rho=(2k-3)\varepsilon$ and choose $0<\eta<2\rho$. The latent state comprises $k$ independent fair bits. Each of two branches contains one deterministic copy of each bit; predict their parity with at most $k$ calls. Conditional on the full bit vector the deterministic observation kernels factor.

The measured tree has trunks $a,a+\eta$ and pendants $q$, with $a>3\varepsilon$, $q>2\varepsilon$. The true first trunk and pendants are $a-3\varepsilon,q+2\varepsilon$; the true second ones are $a+\eta+3\varepsilon,q-2\varepsilon$. Singleton and within-branch pair deviations have magnitude $\varepsilon$; cross-branch pair deviations are zero. Put $C=a+kq$. The two measured full-branch costs are $C,C+\eta$ and their true costs are $C+\rho,C+\eta-\rho$. A mixed informative set pays both trunks. If it takes $t$ copies from the first branch, its true cost exceeds the second full branch by $a+(4t-3)\varepsilon>0$ for $1\leq t<k$. The measured cheapest informative set is likewise the first full branch.

At any history missing a bit, the conditional parity risk is $1/2$. This remains true under adaptive selection and stopping. If a policy completes with probability $u$, nonnegative physical costs give objective at least $u\lambda C_{\min}+(1-u)/2$. Choose $\lambda C_{\min}<1/2$ in both models. Every optimal policy then completes and uses a cheapest informative set. Thus every measured-optimal policy uses the first branch, regardless of query order, whereas the true optimum uses the second. The regret is

$$\lambda(2\rho-\eta). \tag{20}$$

Letting $\eta/\rho$ tend to zero proves sharpness without relying on a tie. $\square$

**Theorem 4.4 (Continuation values and policy regret).** Fix $A\ne\varnothing$ and a remaining budget $b$. Use

$$J_F^A(\pi)=\mathbb E^\pi[\ell+\lambda\Delta_F(A,U_\tau)],\qquad J_H^A(\pi)=\mathbb E^\pi[\ell+\lambda H_A(U_\tau)]. \tag{21}$$

Let $V_F^A,V_H^A$ be their minima and $\pi_H^A$ a minimizer of the latter. With $\kappa_b=b(\varepsilon_1+\varepsilon_2)$,

$$|V_F^A-V_H^A|\leq\lambda\kappa_b,\qquad 0\leq J_F^A(\pi_H^A)-V_F^A\leq2\lambda\kappa_b. \tag{22}$$

The value constant is sharp for every fixed nonempty anchor-set size. The policy coefficient two is sharp uniformly over continuation problems, and for every fixed anchor-set size at least two. Smaller constants can apply to restricted anchor configurations.

*Proof.* For every terminal new set $U$, Theorem 3.3 bounds the cost error by $|U|(\varepsilon_1+\varepsilon_2)\leq\kappa_b$. The fixed-policy and two-policy comparisons proving (19) give (22), including $b=0$.

For value sharpness when $b\geq1$, use the central star and one perturbation in (8), with uninformative anchors and $b$ new sources revealing independent fair bits. Predict parity. At a sufficiently small positive $\lambda$, all bits are acquired in both models, and the value difference is exactly $\lambda\kappa_b$.

For policy sharpness take two uninformative anchors, one on each of two branches, and $b$ future copies of the bits on each branch. Put $s=\varepsilon_1+\varepsilon_2>0$, $t=2\varepsilon_1+\varepsilon_2$, and choose $a>t$, $q>s$ and $0<\eta<2bs$. In the measured tree both trunks have length $a$; all first-branch pendants, including its anchor, have length $q$, and all second-branch pendants have length $q+\eta/b$. In the true tree subtract $t$ from the first trunk and add $s$ to its pendants, while adding $t$ to the second trunk and subtracting $s$ from its pendants. All singleton deviations have magnitude $\varepsilon_1$, within-branch pair deviations magnitude $\varepsilon_2$, and cross-branch deviations zero.

Both trunks have already been activated. The measured complete continuation costs are $bq,bq+\eta$, and the true ones are $bq+bs,bq+\eta-bs$. Each second-branch copy is truly cheaper than its first-branch copy, so mixed sets do not improve on the second full branch. The same parity argument forces complete acquisition for small $\lambda$, giving regret $\lambda(2bs-\eta)$. Its ratio to $\lambda\kappa_b$ tends to two. Additional uninformative anchor leaves may be added on either existing branch, using its pendant length and the same signed pendant perturbation. Their singleton and pair constraints remain valid, and their already-paid pendants cancel from continuation costs. This extends the construction to every fixed $|A|\geq2$. $\square$

The anchor set $A$ stays fixed throughout this optimization. In (18) use increments $H_A(U\cup\{i\})-H_A(U)$. Summing separately re-anchored one-source estimates $H_{A\cup U}(\{i\})$ need not telescope for incompatible measurements. Replanning at an actual later history defines a new optimization; (22) does not automatically certify the resulting receding-horizon policy.

**Corollary 4.5 (Stopping certificate).** For $b\geq1$ with a query available, let $Q_H(i)$ be the minimum surrogate objective when the first action is forced to query $i$, and set $\delta=\lambda\kappa_b$. If $\min_i Q_H(i)>r(p)+\delta$, stopping is truly optimal. If $\min_i Q_H(i)<r(p)-\delta$, stopping is truly suboptimal.

*Proof.* Each forced-query policy class has value error at most $\delta$, while the stopping risk is unchanged. Compare its certified interval with $r(p)$. $\square$

**Remark 4.6 (One anchor and one remaining call).** If $A=\{a\}$ and $b=1$, the stronger bound is

$$J_F^A(\pi_H^A)-V_F^A\leq\lambda\max\{\varepsilon_1+\varepsilon_2,2\varepsilon_2\}. \tag{23}$$

Indeed, the cost of querying $i$ is $c_{ai}-c_a$. Comparing two query actions cancels the common anchor error, leaving at most $2\lambda\varepsilon_2$ error in their difference. Comparing a query with stopping gives at most $\lambda(\varepsilon_1+\varepsilon_2)$. Applying these cases to the two minimizing actions proves (23). For equal tolerances this is half the generic bound in (22), explaining its sharpness qualification.

## 5. Exact computational study

We test the identities, limiting constructions and behavior under bounded calibration error. All data are synthetic. The reference implementation uses integer cost units for algebra and Python rational arithmetic for decision expectations. Online Resource 2 contains the code, raw outputs, seeds and execution instructions; Online Resource 1 retains all original numerical tables and gives the complete experimental specification.

### 5.1. Verification and sharpness

Across 100 generated six-source trees, direct root-path unions matched all 6,400 initial identities and 19,200 marginals. All 60,200 nonempty disjoint anchor/new-set combinations passed the continuation identity, error-bound, lifted-forest and heterogeneous-certificate checks. Initial and repair bounds each passed 6,400 checks. These finite checks validate implementation consistency; the proofs establish universal statements.

The two-tree continuation construction was checked in 36 parameter settings, including zero singleton or zero pair tolerance. Eighteen exact parity decision cases used budgets 2, 3 and 4 in the initial and two-anchor continuation settings. Setting $\eta/\rho$ to 0.5, 0.1 and 0.01 gave regret ratios 1.5, 1.9 and 1.99 to the corresponding $\lambda\rho$ bound in every setting. Thus the computations approach, rather than assert attainment of, the supremum factor two.

For Proposition 3.4 with $a=2$, $q=1$, $\varepsilon=0.05$, subtraction gives 0.8, 0.2, −0.8 and −2.8 for history sizes 2, 5, 10 and 20, although the true continuation cost and direct estimate are both 1. The direct worst-case radius remains 0.1.

### 5.2. Recovery comparison

We generated 810 calibration instances over star, chain and balanced rooted trees. The factorial design varies $|A|\in\{1,4,12\}$, $k\in\{1,2,4\}$ and tolerance $\varepsilon\in\{1,5,20\}$ in integer cost units, with ten replicates per configuration. Each measurement independently receives noise selected uniformly from $\{-\varepsilon,0,\varepsilon\}$. This distribution is an experimental design within the deterministic error box, not an assumption of the theorems. All three methods use the same measurements. Table 2 divides absolute error by the direct radius $2k\varepsilon$.

**Table 2. Recovery error over 270 instances per tree family and method.**

| Family | Method | Mean / radius | Maximum / radius | Outside radius |
|---|---|---:|---:|---:|
| Star | Direct | 0.679 | 1.00 | 0 / 270 |
| Star | Subtraction | 0.798 | 2.50 | 41 / 270 |
| Star | Repair | 0.652 | 1.00 | 0 / 270 |
| Chain | Direct | 0.507 | 1.00 | 0 / 270 |
| Chain | Subtraction | 0.661 | 3.00 | 28 / 270 |
| Chain | Repair | 0.492 | 1.00 | 0 / 270 |
| Balanced | Direct | 0.400 | 1.00 | 0 / 270 |
| Balanced | Subtraction | 0.599 | 2.00 | 29 / 270 |
| Balanced | Repair | 0.395 | 1.00 | 0 / 270 |

Subtraction exceeds the direct radius in 98 of 810 cases, with a maximum ratio of 3. Repair has slightly smaller mean error than direct recovery in each family and also remains within the direct radius in this finite sample. We therefore claim a sharp guarantee for the direct estimator, not uniform empirical dominance over repair. The conservative repair theory does not imply that every repair instance must have larger error.

### 5.3. Decision comparison

We also solved 54 finite continuation instances with six total sources, one or two anchors, a three-call remaining budget, three tree families, three tolerances and three penalty weights. The current posterior is binary and uniform; each available source is a conditionally independent binary symmetric channel. Oracle, direct, subtraction and repair policies were optimized exactly and evaluated under the true cost. Each selected policy was independently replayed over every latent-state/full-observation combination.

The mean regrets were 0.002831 for direct recovery, 0.009568 for subtraction and 0.004055 for repair. Their maximum regrets were 0.0617, 0.3638 and 0.0617. All direct value and regret bounds held. These are descriptive results for the disclosed factorial sample; they do not establish average-case optimality. The original six-source example's eight policy rows were also reproduced exactly, including all 1,024 full-outcome replay cases.

## 6. Scope and limitations

The exact radius concerns recovery from bounded singleton/pair errors when the tree topology and edge costs are unknown. Rooted-path structure is essential: general weighted coverage systems can share identical singleton/pair tables but have different triple costs; Online Resource 1 preserves the explicit counterexample and the universal decision-equivalence theorem. Accurate telemetry of the previously paid total, missing calibration pairs, likelihood error, repeated queries, resource deactivation and hard monetary budgets are different models. Exact adaptive planning is exponential in the number of sources; polynomial-time evaluation of a set cost does not remove that difficulty.

The contribution is a sharp continuation functional bound with a constructive estimator, its failure comparison with subtraction, and qualified sharp decision consequences. The literature comparisons distinguish these statements from selected existing results; they do not establish an exhaustive priority claim. The synthetic computations support the mathematics and its reference implementation, without industrial or learned-agent performance claims.

## Statements and Declarations

**Funding:** [Authors to supply verified funding information.]

**Competing interests:** [Authors to supply their declaration.]

**Author contributions:** [Human authors to supply their contributions.]

**Data and code availability:** All data are synthetic. Online Resource 2 supplies the complete standard-library Python implementation, seeds and generated CSV outputs. No public repository or archival identifier is asserted in this draft.

**AI assistance:** ChatGPT assisted with the mathematical formulation, proposed proofs, literature comparison, code and text. A separate AI analysis checked Theorems 3.3, 4.3 and 4.4 and identified a correction to the sharpness quantifier in Theorem 4.4. This was an internal check, not external human peer review. The human authors must verify and take responsibility for the final claims and submission.

## References

\[1\] D. Bryant and P. F. Tupper, [Hyperconvexity and tight-span theory for diversities](https://doi.org/10.1016/j.aim.2012.08.008), *Advances in Mathematics* **231** (2012), 3172–3198. [Author preprint](https://arxiv.org/abs/1006.1095). <https://doi.org/10.1016/j.aim.2012.08.008>.

\[2\] G. Carlsson and F. Mémoli, [Characterization, stability and convergence of hierarchical clustering methods](https://jmlr.csail.mit.edu/papers/v11/carlsson10a.html), *Journal of Machine Learning Research* **11** (2010), 1425--1470.

\[3\] D. L. Donoho, [Statistical estimation and optimal recovery](https://doi.org/10.1214/aos/1176325367), *The Annals of Statistics* **22** (1994), no. 1, 238--270. <https://doi.org/10.1214/aos/1176325367>.

\[4\] M. Farach, S. Kannan, and T. Warnow, [A robust model for finding optimal evolutionary trees](https://doi.org/10.1007/BF01188585), *Algorithmica* **13** (1995), 155–179. <https://doi.org/10.1007/BF01188585>.

\[5\] J. C. Gower and G. J. S. Ross, [Minimum spanning trees and single linkage cluster analysis](https://doi.org/10.2307/2346439), *Journal of the Royal Statistical Society, Series C: Applied Statistics* **18** (1969), no. 1, 54--64. <https://doi.org/10.2307/2346439>.

\[6\] D. Granot, M. Maschler, G. Owen, and W. R. Zhu, [The kernel/nucleolus of a standard tree game](https://doi.org/10.1007/BF01247104), *International Journal of Game Theory* **25** (1996), 219–244. <https://doi.org/10.1007/BF01247104>.

\[7\] D. Hunter, [An upper bound for the probability of a union](https://doi.org/10.2307/3212481), *Journal of Applied Probability* **13** (1976), no. 3, 597--603. <https://doi.org/10.2307/3212481>.

\[8\] J. Márkus, M. Pintér, and A. Radványi, [The Shapley value for airport and irrigation games](https://doi.org/10.1007/s10100-026-01039-5), *Central European Journal of Operations Research* (2026), published online 22 August 2026. <https://doi.org/10.1007/s10100-026-01039-5>.

\[9\] L. Pachter and D. Speyer, [Reconstructing trees from subtree weights](https://arxiv.org/abs/math/0311156), *Applied Mathematics Letters* **17** (2004), no. 6, 615--621. Link provides the authors' preprint.

\[10\] R. D. Smallwood and E. J. Sondik, [The optimal control of partially observable Markov processes over a finite horizon](https://doi.org/10.1287/opre.21.5.1071), *Operations Research* **21** (1973), no. 5, 1071--1088. <https://doi.org/10.1287/opre.21.5.1071>.

\[11\] M. Steel, A. Mimoto, and A. O. Mooers, [Hedging our bets: The expected contribution of species to future phylogenetic diversity](https://doi.org/10.1177/117693430700300024), *Evolutionary Bioinformatics* **3** (2007), 237–244. [Author preprint](https://arxiv.org/abs/0704.2649). <https://doi.org/10.1177/117693430700300024>.

# Online Resource 1: Foundations and computational details

**Companion article:** Sharp recovery of continuation costs in tree-based sequential decisions  
**Target journal:** Optimization Letters  
**Authors and contact:** [Human authors to complete]

## S1. Reading guide and preservation note

The main article isolates the sharp continuation-recovery theorem and its decision consequences. This resource preserves the earlier mathematical development, including all original displayed equations, complete proofs and numerical table entries. Equations (1)–(21), Theorems 3.1, 4.2 and 5.1, and the original table labels in Section S4 below refer locally to that retained development. They are not cross-references to the revised main article. The central continuation results, Theorems 3.3, 4.3 and 4.4, have their full proofs in the main article.

The current Python implementation reproduces the original synthetic policy table exactly. The earlier draft's statement about JavaScript BigInt has been updated to describe the supplied implementation. Typography and malformed table headers have been repaired. The original source and recovered Word are retained in the reproducibility package for comparison.

## S2. Complete new experimental protocol

The standard-library Python command `python code/run_experiments.py --output results` reproduces all CSV files. No downloaded data or reference-author code is needed. Integer costs are arbitrary units; multiplying every cost and its tolerance by the same number and dividing the penalty by that number leaves policy objectives unchanged.

### S2.1. Recovery benchmark

The design is the Cartesian product of three tree families, three anchor sizes (1, 4, 12), three new-set sizes (1, 2, 4), three tolerances (1, 5, 20) and ten replicates, giving 810 instances. The pseudorandom generator is Python random.Random with seed 20260913. Source labels are randomly permuted before selecting the anchors. Exact loop order and every generated row are in Online Resource 2.

For a star, the shared trunk is a uniformly sampled integer from 50 to 300, and each pendant is uniform from 10 to 100. For a chain or balanced tree there are n source vertices numbered 1 to n and root 0. Vertex i+1 has parent i for a chain and floor(i/2) for the balanced family, with i starting at zero. Each activation and service cost is an independently sampled integer from 10 to 100. Sources may occupy internal vertices, as permitted by the model. This balanced family is a binary heap shape and need not be a perfect binary tree.

Every singleton and pair gets independent uniformly selected noise from minus tolerance, zero and plus tolerance. Direct recovery uses the anchored-forest algorithm; subtraction computes H(A union S) minus H(A); repair first applies the full-table maximum-bottleneck closure and then subtracts the two repaired costs. Thus all three methods receive identical calibration information. Full-table repair can use labels outside an individual target set. In this benchmark all labels belong to A union S.

The CSV records the true cost, each estimate, absolute error, error divided by the direct radius, and whether that radius is exceeded. There is no claim that the direct radius is a universal guarantee for either baseline. No random seed was selected after inspecting performance.

### S2.2. Decision benchmark

The design has three tree families, one or two anchors, three tolerances (1, 5, 20) and penalties 1/2000, 1/500 and 1/200 per cost unit: 54 instances. The seed is 20260914. Each tree has six sources and the first h labels form the anchors. The current binary posterior is uniform and anchors are uninformative. Each future source has accuracy chosen uniformly from 0.65, 0.70, 0.75, 0.80, 0.85 and 0.90, independently conditional on the binary latent state. There are at most three further calls.

The oracle and three calibration-based policies each solve their finite decision problem exactly. The direct policy uses one fixed anchor set throughout planning. Ties select stopping before querying, then the smallest source index. All selected policies are evaluated under the true cost; independent enumeration over the two latent states and every binary full-observation vector verifies the expected error, true cost, call count and objective. There are 216 evaluated policies in total. Raw rows are supplied, including zero-regret cases.

### S2.3. Algebra and sharpness checks

The algebra checks use 100 six-source trees and integer multiples of the historical cost unit 1/20. The 32-bit generator has seed 20260911, multiplier 1664525 and increment 1013904223. Each parent precedes its child. Enumerating all ternary memberships (unused, anchor, new), excluding empty anchor or new sets, gives 602 combinations per tree. A separate graph traversal checks that every lifted forest is acyclic, has k edges and has exactly one anchor in every component.

The heterogeneous certificate checks use independently selected singleton and pair tolerances of 1, 2 or 3 units, with measurement errors of at most one unit. The sharp continuation recovery construction is checked for anchor sizes 1, 5 and 20, new-set sizes 1, 2 and 4, and tolerance pairs (1/20, 1/20), (0, 1/7), (1/5, 0) and (1/9, 2/7): 36 settings, with both indistinguishable true trees checked in each. Policy sharpness uses 18 settings (two initial/continuation modes, three budgets and three separation ratios). These counts refer to different tests and should not be conflated.

The verification JSON records interpreter, platform and one complete run's wall time. Timing is incidental and is not a scaling benchmark. The exact algorithms and finite tests do not constitute formal proof certification.

## S3. Extended background retained from the earlier manuscript


**Tree identification and hierarchical representation.** Buneman [4] gives a metric characterization of trees, while Aho et al. [1] construct trees subject to common-ancestor constraints. Pachter and Speyer [22] study recovery from weighted subtrees. These works establish a broader setting for reconstructing a tree from partial descriptions. Here the measurements are acquisition costs for one or two labeled sources, and the target is the cost of a specified source set. Proposition 2.1 expresses the relevant hierarchy through common-prefix depths; it does not identify a unique physical subdivision of the network. The spanning-tree relation between single linkage and hierarchical clustering studied by Gower and Ross [10], together with the stability framework of Carlsson and Mémoli [5], also provides context for the overlap repair in Section 3.2.

**Recovery from inaccurate measurements.** Optimal recovery asks what can be determined about a target quantity from limited information and a specified model class. Donoho [7] connects this viewpoint to minimax statistical estimation of linear functionals under Gaussian noise. The present formulation instead uses deterministic, coordinatewise bounded errors and the class of nonnegative rooted-tree costs. Theorem 3.1 concerns the exact error radius of a set-cost functional under this information model. Its lower bound is obtained from two admissible trees consistent with the same measurements. Thus the result addresses unavoidable uncertainty in acquisition cost without requiring recovery of a particular tree topology.

**Sequential testing and partially observed control.** Wald [26] develops sequential hypothesis testing, and Chernoff [6] studies the sequential choice of experiments. Naghshvar and Javidi [19] analyze active sequential hypothesis testing through information acquisition, decision penalties, and asymptotically optimal policies. The finite-horizon belief-state formulation used here belongs to the framework of Smallwood and Sondik [24] and the planning treatment of Kaelbling, Littman, and Cassandra [14]. Our model restricts each source to one query and records the queried set because shared activation makes the next acquisition cost depend on earlier choices. The Bellman recursion is a specialization of this established framework.

**Submodularity and active feature acquisition.** Nemhauser, Wolsey, and Fisher [20] establish approximation guarantees for monotone submodular maximization under a cardinality constraint. Golovin and Krause [9] identify adaptive diminishing-returns conditions supporting greedy acquisition, while Krause et al. [15] study observation selection against multiple possible objectives, including extensions with communication and path costs. These results motivate scalable acquisition methods, but their assumptions concern the information objective as well as its constraints. Submodularity of the shared acquisition cost alone does not establish the required diminishing returns in diagnostic value; the parity example in Section 4.2 makes that distinction explicit.

Active feature acquisition also studies how to choose additional observations for a partially observed instance. Ma et al. [17] combine a partial variational autoencoder with an expected-information-gain acquisition rule, and Li and Oliva [16] use a generative surrogate model to support acquisition-policy learning. These approaches address representation and policy computation. The present analysis isolates a complementary question: how calibration error in a structured acquisition-cost model propagates to decision values when the observation model is held fixed. The synthetic example therefore illustrates the mathematical guarantees, rather than providing a benchmark against learned acquisition methods.



The fixed observation law in the decision-stability theorem differs from transition uncertainty in robust dynamic programming [13, 21]. Equality of acquisition costs across all experiments is also distinct from Blackwell's comparison of information experiments [2], because here the likelihoods are held fixed while cost systems are compared.

The additional tree literature in the revised main article is retained in the bibliography: diversity representation [3], interval-distance tree fitting [8], standard-tree allocations [11], irrigation-game axioms [18], and expected marginal phylogenetic diversity [25]. These works supply context; the direct theorem comparison is in the main article's Table 1.

The original manufacturing motivation is connected to graph-based multi-agent scheduling [23]. Its retained numerical example is synthetic and makes no claim to validate that scheduling method.

## S4. Retained foundational development and original numerical tables

## 2. Shared costs on a rooted tree

### 2.1. Model and notation

Let $N=\{1,\ldots,n\}$ label evidence sources, and let $T$ be a finite tree rooted at a coordinator $r$. Source $i$ is associated with a vertex and the unique root-to-source path $P_i$. Each edge $e$ has activation cost $a_e\geq0$, and source $i$ has service cost $s_i\geq0$.

Each source is queried at most once during an investigation. An edge is charged when first activated and remains available until the investigation ends.

For $S\subseteq N$, define

$$
F(S)= \sum_{e\in\bigcup_{i\in S}P_i}a_e +\sum_{i\in S}s_i, \qquad F(\varnothing)=0. \tag{1}
$$

This is a nonnegative, monotone weighted-coverage function. Service costs can be absorbed into private pendant edges of lengths $s_i$, placing each source label at the new endpoint. Thus all costs may be represented by root-path lengths, allowing zero-length edges.

Write

$$
c_i=F(\{i\}),\qquad c_{ij}=F(\{i,j\}),\qquad o_{ij}=c_i+c_j-c_{ij},\quad i\ne j. \tag{2}
$$

The quantity $o_{ij}$ is the cost of the common prefix of the two root paths. Service costs cancel from this overlap. Let $\mathcal T(S)$ denote the spanning trees of the complete graph on $S$, when $|S|\geq2$.

The model describes shared activation or setup expenses. These expenses need not equal packet traffic, inference tokens, or wall-clock latency.

### 2.2. Compatibility and marginal costs

**Proposition 2.1 — Rooted-tree compatibility.**
A singleton and pair table admits a representation of the form (1) if and only if $c_i\geq0$, the overlaps are symmetric, and

$$
0\leq o_{ij}\leq\min(c_i,c_j), \qquad o_{ij}\geq\min(o_{ik},o_{jk}) \tag{3}
$$

for distinct relevant indices. Under these conditions,

$$
F(A\cup\{j\})-F(A) = c_j-\max_{i\in A}o_{ij}, \qquad j\notin A, \tag{4}
$$

where the maximum over the empty set is zero.

*Proof.* In a rooted tree, intersections of root paths are common prefixes. Their lengths give the bounds in (3). If the paths to $i$ and $k$ agree to depth $u$, and those to $j$ and $k$ agree to depth $v$, the paths to $i$ and $j$ agree to depth at least $\min(u,v)$. This proves the last inequality.

Conversely, at height $t\geq0$, group distinct labels satisfying $o_{ij}\geq t$, retaining each label as equivalent to itself. The last inequality in (3) makes these groups equivalence classes. As $t$ increases, the classes refine and form a hierarchy.

Realize this hierarchy as a rooted tree whose branching depths are the distinct overlap values, with root depth zero. Place label $i$ at depth $c_i$. Every nontrivial class containing $i$ occurs at depth at most $c_i$, so all edge lengths are nonnegative. Zero-length edges accommodate tied depths. The resulting common-prefix depths are exactly $o_{ij}$, giving the prescribed individual and pair costs.

Finally, the intersection of $P_j$ with the union of previously activated paths is its longest common prefix with those paths. Subtracting this already-paid length from $c_j$ proves (4). $\square$

This construction uses the established correspondence between hierarchical similarities and rooted trees [1,5]. It identifies the set-cost function. A physical subdivision of edges, or a separate decomposition into service and communication expenses, need not be identifiable.

### 2.3. Reconstruction from pairs

**Proposition 2.2 — Spanning-tree reconstruction.**
For every $S\subseteq N$ with $m=|S|\geq2$,

$$
F(S)= \sum_{i\in S}c_i- \max_{M\in\mathcal T(S)} \sum_{\{i,j\}\in E(M)}o_{ij}. \tag{5}
$$

Equivalently,

$$
F(S)= \min_{M\in\mathcal T(S)} \left[ \sum_{\{i,j\}\in E(M)}c_{ij} - \sum_{i\in S}\bigl(\deg_M(i)-1\bigr)c_i \right]. \tag{6}
$$

*Proof.* Let $W(S)$ be the maximum spanning-tree weight in (5). Choose a pair $i,j$ of maximum overlap $h$ in $S$. Equation (4) gives

$$
F(S)=F(S\setminus\{j\})+c_j-h.
$$

There is a maximum-weight spanning tree containing edge $ij$: adding this globally maximum-weight edge to a maximum tree and removing an edge from the resulting cycle cannot decrease its weight.

Moreover, (3) implies $o_{ik}\geq o_{jk}$ for every $k\notin\{i,j\}$, since $h\geq o_{jk}$. In a maximum tree containing $ij$, replace every other edge $jk$ by $ik$. The result remains a spanning tree, its weight does not decrease, and $j$ becomes a leaf. Its restriction to $S\setminus\{j\}$ must also be maximum. Consequently,

$$
W(S)=W(S\setminus\{j\})+h.
$$

Induction, beginning with a singleton of spanning-tree weight zero, proves (5). Substituting (2) and collecting singleton coefficients proves (6). $\square$

The expression has the same spanning-tree structure as Hunter’s union bound [12]; rooted-path structure makes it exact. A dense maximum-spanning-tree algorithm evaluates a specified $m$-source cost in $O(m^2)$ arithmetic operations. All subset costs are represented by $O(n^2)$ measurements, although explicitly listing them requires exponential space.

## 3. Minimax recovery under measurement error

Suppose measurements satisfy

$$
|\widetilde c_i-c_i|\leq\varepsilon, \qquad |\widetilde c_{ij}-c_{ij}|\leq\varepsilon. \tag{7}
$$

The measured table need not satisfy (3). Define $H(\varnothing)=0$, $H(\{i\})=\widetilde c_i$, and, for $|S|\geq2$, define $H(S)$ by the right side of (6) using measured values.

### 3.1. Exact recovery radius

**Theorem 3.1 — Sharp error bound and minimax optimality.**
Set

$$
\alpha_0=0,\qquad \alpha_1=1,\qquad \alpha_m=2m-3\quad(m\geq2).
$$

Then

$$
|H(S)-F(S)| \leq \alpha_{|S|}\varepsilon. \tag{8}
$$

For each $m\geq2$, the coefficient $2m-3$ cannot be reduced by replacing $H$ with any other estimator based only on the individual and pairwise measurements.

*Proof.* Fix $S$ of size $m\geq2$. Each spanning-tree expression in (6) contains $m-1$ pair terms with coefficient $+1$. Since every vertex has degree at least one,

$$
\sum_{i\in S}|\deg_M(i)-1| = 2(m-1)-m=m-2.
$$

Thus each expression changes by at most

$$
(m-1)\varepsilon+(m-2)\varepsilon = (2m-3)\varepsilon.
$$

If every member of a finite family of real numbers changes by at most $d$, its minimum changes by at most $d$. Applying this fact to (6) proves (8). The empty and singleton cases are immediate.

For the lower bound, consider $m$ leaves sharing a trunk of length $a>3\varepsilon$, with each pendant edge of length $b>2\varepsilon$. Let the measured table be that of this central tree:

$$
\widetilde c_i=a+b, \qquad \widetilde c_{ij}=a+2b.
$$

Two possible true trees have trunk and pendant lengths

$$
(a_+,b_+)=(a-3\varepsilon,b+2\varepsilon),
$$

$$
(a_-,b_-)=(a+3\varepsilon,b-2\varepsilon).
$$

All edge lengths are nonnegative. In the first tree, every singleton is lower than its measurement by $\varepsilon$, while every pair is higher by $\varepsilon$. The signs are reversed in the second tree. Both trees satisfy (7) for the same observed table.

Their full-set costs are

$$
F_+(N)=a+mb+(2m-3)\varepsilon,
$$

$$
F_-(N)=a+mb-(2m-3)\varepsilon.
$$

An estimator receives identical input in these two cases. Its largest error must be at least half the distance between the two possible costs, namely $(2m-3)\varepsilon$. Together with (8), this proves minimax optimality. $\square$

Formally, let $\mathcal C_m$ be the class of nonnegative rooted-tree cost functions on $m$ labels, and let $D(F)$ be the vector of singleton and pair costs. Then

$$
\inf_R \sup_{\substack{ F\in\mathcal C_m,\ z\\ \|z-D(F)\|_\infty\leq\varepsilon }} |R(z)-F(N)| = (2m-3)\varepsilon, \qquad m\geq2. \tag{9}
$$

The infimum ranges over estimators $R$.

If singleton errors are bounded by $\varepsilon_1$ and pair errors by $\varepsilon_2$, the same argument gives the sharp radius

$$
(m-2)\varepsilon_1+(m-1)\varepsilon_2.
$$

For the lower bound, perturb the trunk by opposite amounts $2\varepsilon_1+\varepsilon_2$, and each pendant edge by opposite amounts $\varepsilon_1+\varepsilon_2$.

### 3.2. A feasible repair

The direct estimate $H$ can be nonmonotone when measurements are incompatible. A physical network representation can instead be obtained by repairing the overlaps.

Define

$$
\widehat c_i=\max(0,\widetilde c_i),
$$

$$
u_{ij} = \min\left\{ \widehat c_i,\widehat c_j, \max(0,\widetilde c_i+\widetilde c_j-\widetilde c_{ij}) \right\}. \tag{10}
$$

For distinct $i,j$, define the maximum-bottleneck closure

$$
\widehat o_{ij} = \max_{\gamma:i\leadsto j} \min_{\{u,v\}\in E(\gamma)}u_{uv}, \tag{11}
$$

where the maximum is over simple paths in the complete graph. Let $\widehat F$ be the rooted-tree cost reconstructed from $\widehat c,\widehat o$.

**Proposition 3.2 — Feasibility and repair error.**
The repaired table satisfies (3). For every nonempty $S$,

$$
|\widehat F(S)-F(S)| \leq (4|S|-3)\varepsilon. \tag{12}
$$

*Proof.* The closure is symmetric and nonnegative. Every path from $i$ to $j$ starts with an edge bounded by $\widehat c_i$ and ends with one bounded by $\widehat c_j$. Hence

$$
\widehat o_{ij}\leq\min(\widehat c_i,\widehat c_j).
$$

Concatenating paths through $k$, and removing loops without reducing the bottleneck, proves the final inequality in (3).

Singleton clipping has error at most $\varepsilon$. Raw overlap errors are at most $3\varepsilon$. The clipping in (10) preserves this bound because minimum and maximum are nonexpansive in the sup norm.

The maximum-bottleneck operation is also nonexpansive: perturbing every edge value by at most $d$ perturbs each path bottleneck, and then their maximum, by at most $d$. This operation fixes the true overlap matrix, because repeated application of (3) bounds every path bottleneck by the direct true overlap. Therefore,

$$
\|\widehat o-o\|_\infty\leq3\varepsilon.
$$

In (5), the singleton sum changes by at most $|S|\varepsilon$, while the maximum spanning-tree weight changes by at most $3(|S|-1)\varepsilon$. Adding these bounds proves (12). $\square$

The closure is a standard hierarchical operation related to single linkage [5]. A max-min version of Floyd’s algorithm computes it in $O(n^3)$ time. The constant in (12) is a conservative guarantee; its sharpness is not asserted. Repair supplies nonnegative, monotone physical set costs, while direct recovery has the sharper guarantee in (8).

## 4. Sequential Bayesian decisions

### 4.1. Exact finite-horizon solution

Let the latent state $X$ take values in a finite set $\mathcal X$, with prior $p$. Source $i$ returns an observation in a finite set $\mathcal Y_i$, according to a known likelihood $L_i(y\mid x)$. Source observations are conditionally independent given $X$.

A final decision $d$ belongs to a finite set $\mathcal D$, with loss $0\leq\ell(d,x)\leq1$. A policy may stop or query an unqueried source, with at most $B\leq n$ queries. If its final queried set is $S_\tau$, its objective is

$$
J_F(\pi) = \mathbb E^\pi \left[ \ell(d_\tau,X)+\lambda F(S_\tau) \right], \qquad \lambda>0. \tag{13}
$$

The query limit is a call budget; monetary cost appears as a penalty. A hard monetary constraint would make the admissible policy class depend on the estimated cost and requires separate treatment.

For posterior $p$, define

$$
r(p)= \min_{d\in\mathcal D}\sum_xp(x)\ell(d,x),
$$

$$
q_i(y\mid p)=\sum_xp(x)L_i(y\mid x), \qquad T_i(p,y)(x)= \frac{p(x)L_i(y\mid x)}{q_i(y\mid p)}. \tag{14}
$$

Outcomes of zero predictive probability are omitted.

**Proposition 4.1 — Bellman recursion.**
The minimum expected remaining loss and future acquisition cost, after querying $A$ and with $b$ calls remaining, is

$$
V_0(p,A)=r(p), \tag{15}
$$

and, for $b\geq1$,

$$
\begin{aligned} V_b(p,A)=\min\Bigg\{r(p),\ \min_{i\notin A}\Bigg[ &\lambda\bigl(F(A\cup\{i\})-F(A)\bigr)\\ &+\sum_yq_i(y\mid p) V_{b-1}\bigl(T_i(p,y),A\cup\{i\}\bigr) \Bigg]\Bigg\}. \end{aligned} \tag{16}
$$

If no source remains, only the stopping term is used. A deterministic optimal policy exists.

*Proof.* Conditional independence makes $(p,A,b)$ sufficient for predicting every remaining observation. Stopping incurs Bayes risk $r(p)$. Querying $i$ incurs its marginal cost and the optimal continuation value under the updated posterior.

Backward induction over $b$ proves (15)–(16). The action and observation sets are finite, so every minimum is attained. Marginal costs telescope to $F(S_\tau)$, giving (13) at the initial state. $\square$

This specializes finite-horizon belief-state dynamic programming [24]. With at most $q$ outcomes per source, there are at most

$$
\sum_{m=0}^{B}\binom nm q^m
$$

partial observation assignments from a fixed prior. Compact representation of acquisition costs therefore does not make exact adaptive optimization polynomial.

The same recursion applies to $H$, using differences $H(A\cup\{i\})-H(A)$. When raw measurements are incompatible, these differences must be evaluated from the set estimate: formula (4) need not hold for noisy overlaps. Negative surrogate increments do not invalidate finite-horizon optimization, although they lack a physical activation-cost interpretation.

### 4.2. Stability of values and policies

Write $V_F=\min_\pi J_F(\pi)$, $V_H=\min_\pi J_H(\pi)$, and

$$
\beta_B= \max_{0\leq m\leq B}\alpha_m = \begin{cases} 0,&B=0,\\ 1,&B=1,\\ 2B-3,&B\geq2. \end{cases} \tag{17}
$$

**Theorem 4.2 — Decision stability.**
Under (7), for the same likelihoods, loss, prior, call budget, and penalty weight,

$$
|V_F-V_H| \leq \lambda\beta_B\varepsilon. \tag{18}
$$

If $\pi_H$ minimizes the measured-cost objective, then

$$
0\leq J_F(\pi_H)-V_F \leq 2\lambda\beta_B\varepsilon. \tag{19}
$$

For $B\geq2$, the coefficient in (18) is sharp over this decision-model class.

*Proof.* Fix any history-dependent policy $\pi$. Holding this policy fixed, replacing the cost table does not change the observation law or its stopping decisions. Since $|S_\tau|\leq B$, Theorem 3.1 gives

$$
\begin{aligned} |J_F(\pi)-J_H(\pi)| &\leq \lambda\mathbb E^\pi |F(S_\tau)-H(S_\tau)|\\ &\leq \lambda\beta_B\varepsilon. \end{aligned}
$$

Taking minima proves (18). If $\pi_F$ is optimal for $F$, then

$$
\begin{aligned} J_F(\pi_H) &\leq J_H(\pi_H)+\lambda\beta_B\varepsilon\\ &\leq J_H(\pi_F)+\lambda\beta_B\varepsilon\\ &\leq V_F+2\lambda\beta_B\varepsilon, \end{aligned}
$$

which proves (19).

For sharpness of (18), take $B$ independent fair bits $X_1,\ldots,X_B$ as the latent state. Source $i$ reveals $X_i$ deterministically, and the final decision predicts their parity under zero-one loss. Conditional independence holds given the complete latent state. Every proper subset leaves parity uniformly distributed, while the full set determines it.

For a nonnegative monotone cost function $K$, a policy completing all queries with probability $u$ has objective at least

$$
u\lambda K(N)+(1-u)/2.
$$

Always stopping or always completing attains the two endpoints. The optimal value is consequently

$$
\min\{1/2,\lambda K(N)\}.
$$

Use the central tree and the plus perturbation from Theorem 3.1, choosing $\lambda$ small enough that full acquisition is optimal for both. Their values differ by exactly

$$
\lambda(2B-3)\varepsilon.
$$

This proves sharpness. $\square$

The factor two in (19) was only an upper bound in the earlier treatment; Theorem 4.3 of the revised main article establishes its sharpness. Replacing $H$ by the repaired estimate gives corresponding value and excess-loss bounds with $4B-3$, for $B\geq1$.

The parity example also shows a limitation of one-step policies. If every initial acquisition has positive cost, a policy comparing only immediate Bayes-risk reduction with acquisition cost stops without querying. Its value remains $1/2$, while the optimum is $\lambda F(N)$ for sufficiently small $\lambda$. Their ratio is unbounded as $\lambda$ approaches zero. Thus tree structure alone does not provide a general one-step approximation guarantee; assumptions on information value are also required [9].

## 5. Decision equivalence and the boundary of the model

### 5.1. Which network information is decision-relevant?

**Theorem 5.1 — Universal decision equivalence.**
Let $F$ and $G$ be rooted-tree cost functions on the same $n\geq2$ labels. Fix $2\leq B\leq n$. The following statements are equivalent:

1. $F$ and $G$ agree on every singleton and pair.
2. They agree on every subset of sources.
3. They have equal optimal values for every finite decision experiment described in Section 4 and every $\lambda>0$, under the same call limit $B$.

*Proof.* Proposition 2.2 gives statement 1 implies statement 2. Identical set costs give identical objectives for every policy, proving statement 2 implies statement 3.

Suppose statement 1 fails on a set $S$ of size one or two. Let each source in $S$ reveal one independent fair bit, let every other source return a constant, and let the final decision predict the parity of the bits in $S$.

By the argument in Theorem 4.2 and monotonicity of acquisition costs, the optimal value under a cost function $K$ is

$$
\min\{1/2,\lambda K(S)\}.
$$

Choose $\lambda>0$ small enough that acquiring $S$ is optimal under both $F$ and $G$. Since $F(S)\ne G(S)$, their optimal values differ, contradicting statement 3. $\square$

For $B=1$, only singleton costs matter. The quantifier over all positive $\lambda$ is essential: a sufficiently high fixed penalty can make immediate stopping optimal in both networks and conceal cost differences.

### 5.2. Failure for general shared resources

Rooted-path structure cannot be inferred solely from a compatible pair table. Consider three sources.

In system A, there are three resources $e_{12},e_{13},e_{23}$, each of cost one. Source 1 uses $e_{12},e_{13}$; source 2 uses $e_{12},e_{23}$; source 3 uses $e_{13},e_{23}$.

In system B, every source uses a common resource of cost one and its own private resource of cost one.

Both systems have singleton cost two and pair cost three. Their triple costs differ:

$$
F_A(\{1,2,3\})=3, \qquad F_B(\{1,2,3\})=4. \tag{20}
$$

System B is a rooted-tree model; system A is a general coverage system. Individual and pairwise measurements therefore cannot identify all group costs over the broader class. Even a table satisfying Proposition 2.1 does not certify that the physical system has rooted-path structure.

## 6. Synthetic manufacturing illustration

### 6.1. Fully specified instance

Consider six evidence sources: telemetry, quality, maintenance, materials, scheduling, and assembly. Their labels describe diagnostic roles. No physical factory data or language-model outputs are used.

The rooted routing tree has the following activation edges.

| Edge | Activation cost |
| ------------------------ | --- |
| Coordinator → Telemetry  | 2.0 |
| Telemetry → Quality      | 1.6 |
| Telemetry → Maintenance  | 1.4 |
| Coordinator → Materials  | 2.6 |
| Coordinator → Scheduling | 2.0 |
| Scheduling → Assembly    | 1.8 |

An activation expense is paid once per investigation.

**Table 1. Synthetic source parameters.**

| Source | Service cost | Singleton cost | Assumed accuracy |
| ------------------------------------------------ | --- | --- | ---- |
| Telemetry                                        | 1.0 | 3.0 | 0.75 |
| Quality                                          | 1.1 | 4.7 | 0.80 |
| Maintenance                                      | 0.9 | 4.3 | 0.78 |
| Materials                                        | 0.8 | 3.4 | 0.65 |
| Scheduling                                       | 0.9 | 2.9 | 0.70 |
| Assembly                                         | 1.3 | 5.1 | 0.88 |

The three pairs within $\{\text{telemetry},\text{quality},\text{maintenance}\}$, and the scheduling–assembly pair, have overlap 2.0. Every other overlap is zero. These values and Table 1 specify every pair cost through (2).

For example, quality and maintenance together cost

$$
4.7+4.3-2.0=7.0.
$$

Adding telemetry costs $3.0-2.0=1.0$, giving a three-source total of 8.0. Acquiring all six sources costs 17.4; the sum of standalone costs is 23.4. This difference follows from the assumed accounting rule and is not an empirical manufacturing saving.

Let $X\in\{0,1\}$ have prior probability $1/2$. Each source is a binary symmetric channel with the accuracy in Table 1, independently conditional on $X$. The final loss is diagnostic misclassification, and at most four sources may be queried.

We compare the Bellman-optimal policy with a myopic policy minimizing, at each history,

$$
\begin{aligned} \min\Bigg\{r(p),\ \min_{i\notin A}\Bigg[ &\lambda\bigl(F(A\cup\{i\})-F(A)\bigr)\\ &+\sum_yq_i(y\mid p)r(T_i(p,y)) \Bigg]\Bigg\}. \end{aligned} \tag{21}
$$

The myopic policy repeats this rule after each observation. Ties favor stopping, then the earliest source in Table 1.

### 6.2. Exact results

**Table 2. Exact policy expectations for the synthetic instance.**

| $\lambda$ | Policy | Error probability | Expected cost | Expected calls | Objective |
| -------------------------------------------------------------------- | ------- | ------ | ------- | ------ | --------- |
| 0.005                                                                | Optimal | 0.0792 | 7.83012 | 2.4716 | 0.1183506 |
| 0.005                                                                | Myopic  | 0.1200 | 5.10000 | 1.0000 | 0.1455000 |
| 0.010                                                                | Optimal | 0.0828 | 7.39230 | 2.4770 | 0.1567230 |
| 0.010                                                                | Myopic  | 0.1200 | 5.10000 | 1.0000 | 0.1710000 |
| 0.020                                                                | Optimal | 0.1200 | 5.10000 | 1.0000 | 0.2220000 |
| 0.020                                                                | Myopic  | 0.1200 | 5.10000 | 1.0000 | 0.2220000 |
| 0.040                                                                | Optimal | 0.1200 | 5.10000 | 1.0000 | 0.3240000 |
| 0.040                                                                | Myopic  | 0.1200 | 5.10000 | 1.0000 | 0.3240000 |

At the two smaller penalty weights, the optimal policy first queries scheduling, whereas the myopic policy queries assembly and stops. Although assembly has greater assumed standalone accuracy, planning ahead accounts for shared activation and subsequent evidence. At the larger penalty weights, both policies query assembly and stop. These results establish behavior only for the specified finite instance.

For calibration tolerance $\varepsilon=0.05$, the four-call limit gives $\beta_4=5$. At $\lambda=0.01$, Theorem 4.2 bounds the optimal-value error by 0.0025 and the excess objective of the measured-cost policy by 0.005. These are worst-case guarantees under the calibration assumption, rather than observed average errors.

The current reference implementation reproduces these computations using Python Fraction exact rational arithmetic. The Bellman calculation considered 473 partial observation assignments, equal to

$$
\sum_{m=0}^{4}\binom6m2^m.
$$

For each policy and penalty, its terminal decision, cost, and query count were independently evaluated by replaying all

$$
2\times2^6=128
$$

latent-state/full-observation combinations with their exact probabilities. Across the eight policy cases, all 1,024 replay outcomes reproduced the dynamic-programming expectations exactly. Table 2 reports exact finite-model expectations, rather than Monte Carlo estimates.

### 6.3. Algebraic implementation checks

A separate verification generated 100 rooted trees with six labeled source vertices. Vertex $i$ selected its parent among $0,\ldots,i-1$, with vertex 0 the root. Edge weights were selected from $\{0.1,0.2,\ldots,3.0\}$, and service costs from $\{0.1,0.2,\ldots,1.0\}$. A 32-bit linear congruential generator used seed 20260911, multiplier 1664525, and increment 1013904223.

For each tree, all 64 subsets were checked. Direct unions of root paths agreed exactly with Proposition 2.2 in all 6,400 cases. All 19,200 available source-addition marginals agreed with (4).

Singleton and pair measurements were perturbed by values in $\{-1/20,0,1/20\}$. All 6,400 direct-estimate bounds and all 6,400 repaired-estimate bounds held, and every repaired overlap table satisfied (3). The sharpness construction was additionally checked for $m=2,\ldots,8$.

These finite checks support implementation consistency. The universal claims and minimax lower bound follow from the proofs.

## 7. Discussion and concluding remarks

The mathematical problem separates into identification, estimation, and decision making. Under the rooted-tree assumption, pairwise overlap data determine every acquisition cost. Under bounded measurement error, the cost of an $m$-source group has minimax recovery radius $(2m-3)\varepsilon$. This radius quantifies unavoidable amplification of measurement uncertainty, including cases in which the measured table itself is compatible with a tree.

For sequential decisions, uniform cost recovery transfers directly to optimal-value and policy excess-loss guarantees. The transfer does not depend on a particular diagnostic classifier, but it requires an unchanged observation model and a common call-constrained policy class. Likelihood misspecification, time-varying costs, repeated queries, resource deactivation, and hard monetary budgets require separate analysis.

The application illustrates how a coordinator can use the theory to choose sources and determine when to stop. It does not establish industrial validity or the performance of an implemented large-language-model system. Exact adaptive optimization remains exponential in the number of sources; scalable approximations need additional structure.

The counterexample in Section 5 identifies a substantive boundary: pair measurements suffice within the rooted-path class but do not suffice for general shared resources. Extensions to partially observed routing structures, higher-order calibration measurements, and joint uncertainty in costs and likelihoods provide concrete directions for further research.



## References for Online Resource 1

\[1\] A. V. Aho, Y. Sagiv, T. G. Szymanski, and J. D. Ullman, [Inferring a tree from lowest common ancestors with an application to the optimization of relational expressions](https://doi.org/10.1137/0210030), *SIAM Journal on Computing* **10** (1981), no. 3, 405--421. <https://doi.org/10.1137/0210030>.

\[2\] D. Blackwell, [Equivalent comparisons of experiments](https://doi.org/10.1214/aoms/1177729032), *The Annals of Mathematical Statistics* **24** (1953), no. 2, 265--272. <https://doi.org/10.1214/aoms/1177729032>.

\[3\] D. Bryant and P. F. Tupper, [Hyperconvexity and tight-span theory for diversities](https://doi.org/10.1016/j.aim.2012.08.008), *Advances in Mathematics* **231** (2012), 3172–3198. [Author preprint](https://arxiv.org/abs/1006.1095). <https://doi.org/10.1016/j.aim.2012.08.008>.

\[4\] P. Buneman, [A note on the metric properties of trees](https://doi.org/10.1016/0095-8956(74)90047-1), *Journal of Combinatorial Theory, Series B* **17** (1974), no. 1, 48--50. <https://doi.org/10.1016/0095-8956(74)90047-1>.

\[5\] G. Carlsson and F. Mémoli, [Characterization, stability and convergence of hierarchical clustering methods](https://jmlr.csail.mit.edu/papers/v11/carlsson10a.html), *Journal of Machine Learning Research* **11** (2010), 1425--1470.

\[6\] H. Chernoff, [Sequential design of experiments](https://doi.org/10.1214/aoms/1177706205), *The Annals of Mathematical Statistics* **30** (1959), no. 3, 755--770. <https://doi.org/10.1214/aoms/1177706205>.

\[7\] D. L. Donoho, [Statistical estimation and optimal recovery](https://doi.org/10.1214/aos/1176325367), *The Annals of Statistics* **22** (1994), no. 1, 238--270. <https://doi.org/10.1214/aos/1176325367>.

\[8\] M. Farach, S. Kannan, and T. Warnow, [A robust model for finding optimal evolutionary trees](https://doi.org/10.1007/BF01188585), *Algorithmica* **13** (1995), 155–179. <https://doi.org/10.1007/BF01188585>.

\[9\] D. Golovin and A. Krause, [Adaptive submodularity: Theory and applications in active learning and stochastic optimization](https://doi.org/10.1613/jair.3278), *Journal of Artificial Intelligence Research* **42** (2011), 427--486. <https://doi.org/10.1613/jair.3278>.

\[10\] J. C. Gower and G. J. S. Ross, [Minimum spanning trees and single linkage cluster analysis](https://doi.org/10.2307/2346439), *Journal of the Royal Statistical Society, Series C: Applied Statistics* **18** (1969), no. 1, 54--64. <https://doi.org/10.2307/2346439>.

\[11\] D. Granot, M. Maschler, G. Owen, and W. R. Zhu, [The kernel/nucleolus of a standard tree game](https://doi.org/10.1007/BF01247104), *International Journal of Game Theory* **25** (1996), 219–244. <https://doi.org/10.1007/BF01247104>.

\[12\] D. Hunter, [An upper bound for the probability of a union](https://doi.org/10.2307/3212481), *Journal of Applied Probability* **13** (1976), no. 3, 597--603. <https://doi.org/10.2307/3212481>.

\[13\] G. N. Iyengar, [Robust dynamic programming](https://doi.org/10.1287/moor.1040.0129), *Mathematics of Operations Research* **30** (2005), no. 2, 257--280. <https://doi.org/10.1287/moor.1040.0129>.

\[14\] L. P. Kaelbling, M. L. Littman, and A. R. Cassandra, [Planning and acting in partially observable stochastic domains](https://doi.org/10.1016/S0004-3702(98)00023-X), *Artificial Intelligence* **101** (1998), nos. 1--2, 99--134. <https://doi.org/10.1016/S0004-3702(98)00023-X>.

\[15\] A. Krause, H. B. McMahan, C. Guestrin, and A. Gupta, [Robust submodular observation selection](https://jmlr.org/papers/v9/krause08b.html), *Journal of Machine Learning Research* **9** (2008), 2761--2801.

\[16\] Y. Li and J. Oliva, [Active feature acquisition with generative surrogate models](https://proceedings.mlr.press/v139/li21p.html), in *Proceedings of the 38th International Conference on Machine Learning*, Proceedings of Machine Learning Research **139** (2021), 6450--6459.

\[17\] C. Ma, S. Tschiatschek, K. Palla, J. M. Hernandez-Lobato, S. Nowozin, and C. Zhang, [EDDI: Efficient dynamic discovery of high-value information with partial VAE](https://proceedings.mlr.press/v97/ma19c.html), in *Proceedings of the 36th International Conference on Machine Learning*, Proceedings of Machine Learning Research **97** (2019), 4234--4243.

\[18\] J. Márkus, M. Pintér, and A. Radványi, [The Shapley value for airport and irrigation games](https://doi.org/10.1007/s10100-026-01039-5), *Central European Journal of Operations Research* (2026), published online 22 August 2026. <https://doi.org/10.1007/s10100-026-01039-5>.

\[19\] M. Naghshvar and T. Javidi, [Active sequential hypothesis testing](https://doi.org/10.1214/13-AOS1144), *The Annals of Statistics* **41** (2013), no. 6, 2703--2738. <https://doi.org/10.1214/13-AOS1144>.

\[20\] G. L. Nemhauser, L. A. Wolsey, and M. L. Fisher, [An analysis of approximations for maximizing submodular set functions---I](https://doi.org/10.1007/BF01588971), *Mathematical Programming* **14** (1978), 265--294. <https://doi.org/10.1007/BF01588971>.

\[21\] A. Nilim and L. El Ghaoui, [Robust control of Markov decision processes with uncertain transition matrices](https://doi.org/10.1287/opre.1050.0216), *Operations Research* **53** (2005), no. 5, 780--798. <https://doi.org/10.1287/opre.1050.0216>.

\[22\] L. Pachter and D. Speyer, [Reconstructing trees from subtree weights](https://arxiv.org/abs/math/0311156), *Applied Mathematics Letters* **17** (2004), no. 6, 615--621. Link provides the authors' preprint.

\[23\] Z. Qin and Y. Lu, [Knowledge graph-enhanced multi-agent reinforcement learning for adaptive scheduling in smart manufacturing](https://doi.org/10.1007/s10845-024-02494-0), *Journal of Intelligent Manufacturing* **36** (2025), 5943--5966. <https://doi.org/10.1007/s10845-024-02494-0>.

\[24\] R. D. Smallwood and E. J. Sondik, [The optimal control of partially observable Markov processes over a finite horizon](https://doi.org/10.1287/opre.21.5.1071), *Operations Research* **21** (1973), no. 5, 1071--1088. <https://doi.org/10.1287/opre.21.5.1071>.

\[25\] M. Steel, A. Mimoto, and A. O. Mooers, [Hedging our bets: The expected contribution of species to future phylogenetic diversity](https://doi.org/10.1177/117693430700300024), *Evolutionary Bioinformatics* **3** (2007), 237–244. [Author preprint](https://arxiv.org/abs/0704.2649). <https://doi.org/10.1177/117693430700300024>.

\[26\] A. Wald, [Sequential tests of statistical hypotheses](https://doi.org/10.1214/aoms/1177731118), *The Annals of Mathematical Statistics* **16** (1945), no. 2, 117--186. <https://doi.org/10.1214/aoms/1177731118>.
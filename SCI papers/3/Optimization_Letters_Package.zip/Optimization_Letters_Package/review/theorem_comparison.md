# Theorem comparison and contribution assessment

The main manuscript's Table 1 gives the direct source-by-source comparison. This note explains what that comparison does and does not establish. Checked 13 September 2026.

## Information model and sharp constants

Let singleton errors be bounded by e1 and pair errors by e2. The complete calibration table is the only cost observation. The topology is unknown, and already-querying A does not reveal its exact aggregate cost.

| Result in this paper | Target | Sharp or certified constant | Scope |
|---|---|---|---|
| Theorem 3.1 | F(S), with m = size of S ≥ 2 | (m−2)e1 + (m−1)e2 | Minimax absolute-error radius over all estimators of this scalar target |
| Theorem 3.3 | F(A union S) − F(A), A nonempty | k(e1+e2), k = size of S | Minimax radius for every fixed nonempty A; independent of its size |
| Proposition 3.2 | A feasible repaired tree cost | (4m−3)e under equal tolerances | Conservative bound, not claimed sharp |
| Theorem 4.3 | Regret of a surrogate-optimal initial policy | Supremum coefficient 2 multiplying the cost radius and penalty | Uniformly over finite decision models; construction chooses a small penalty |
| Theorem 4.4 | Continuation value and policy regret | Coefficients 1 and 2 | Upper bounds for every nonempty A; factor-two sharpness established for size of A ≥ 2 |
| Remark 4.6 | One anchor, one call, policy regret | Penalty times max{e1+e2, 2e2} | Stronger upper bound; no separate minimax decision claim |

Under equal tolerances e, subtracting the two initial error bounds gives a continuation certificate proportional to the history size. If h = size of A ≥ 2 and k ≥ 1, the resulting bound is (4h+2k−6)e. For k=1, Proposition 3.4 attains 4(h−1)e for that subtraction estimator. Direct recovery has radius 2ke. These are different procedures using the same input table.

## What the verified antecedents imply

The exact model and marginal interpretation have strong antecedents. In [Steel–Mimoto–Mooers, Theorem 3.1](https://arxiv.org/pdf/0704.2649), set extinction probabilities to zero for a fixed retained set A and to one for the other species. The edge-product formula then reduces to the extra rooted diversity from adding one species. Thus the marginal identity should be treated as established structure; the proposed contribution begins with its recovery from uncertain low-order cost observations and the sharp batch radius.

[Pachter–Speyer's main theorem](https://arxiv.org/pdf/math/0311156) and [Bryant–Tupper's Theorems 5.7 and 5.9](https://arxiv.org/pdf/1006.1095) reinforce that exact tree/diversity representation is not a new contribution. [Carlsson–Mémoli, Proposition 26](https://jmlr.org/papers/volume11/carlsson10a/carlsson10a.pdf) supplies a different stability guarantee: a nonexpansive map between metric-space representations. The scalar acquisition-cost coefficients in the table above are not obtained merely by relabeling that constant.

The coordinate conversion d(0,i)=c_i and d(i,j)=2c_ij−c_i−c_j maps the cost error box to correlated distance constraints. A generic interval-distance model can contain extra infeasible error combinations. This deduction explains why a theorem for independent distance intervals cannot be substituted without checking its assumptions and target.

## Remaining novelty risk

The verified comparisons do **not** prove worldwide priority or non-derivability from all earlier optimal-recovery results. The forest identity follows naturally from the established marginal structure; an editor may regard it as an elegant but modest observation. The strongest submission claim is the exact minimax radius under the joint cost-coordinate constraints, its matching positive-tree construction, and the history-dependent failure comparison.

The [Farach–Kannan–Warnow publisher abstract](https://link.springer.com/article/10.1007/BF01188585) identifies a close noisy-tree fitting literature. Its full paper was not available for a theorem-level audit here. This remains an explicit literature-review gap; no invented theorem number or assertion that it lacks a particular result has been inserted.

The usual objective-perturbation regret factor two is elementary. What is checked here is its realization within the restricted physical tree and observation model, with unique optimal queried sets and a quantified separation tending to zero. The constructions establish sharpness of surrogate optimization, not minimax optimality over robust or randomized decision rules chosen directly from calibration uncertainty.

Optimization Letters is a plausible venue for that focused contribution. Human reviewers should decide whether the exact radius is sufficiently non-obvious and significant before submission. More references or experiments alone cannot resolve that question.

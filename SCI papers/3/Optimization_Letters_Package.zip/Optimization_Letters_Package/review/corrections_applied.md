# Disposition of the separate AI proof review

All identified corrections were applied to the revised main manuscript.

- Theorem 3.3 explicitly excludes additional exact F(A) telemetry.
- Theorem 4.3 uses the correct mixed-set excess a+(4t-3)epsilon; its sharpness is uniform over surrogate-optimal policies, with a sufficiently small penalty.
- Theorem 4.4 separates the all-anchor upper bound from factor-two sharpness for at least two anchors. Extra anchors are private leaves on existing branches for arbitrary unequal tolerances.
- Remark 4.6 proves the tighter one-anchor, one-call bound.
- The surrogate dynamic program fixes A throughout each planning problem.
- Twelve additional exact regression cases check the unequal-tolerance, extra-anchor construction, including epsilon1 > epsilon2.

The reviewer checked the final proposed theorem text after the first audit. Human proof and priority review remains outstanding.

# Separate critical AI proof review

**Review date:** 13 September 2026  
**Scope:** Proposed Theorems 3.3, 4.3 and 4.4, including their supporting constructions.  
**Review status:** Separate AI analysis within this work session. This is not external human peer review, formal proof certification, or a determination of novelty.

## Source limitation

The recovered Word file, `recovered/Minimax_Recovery_and_Decision_Stability.docx`, contains the earlier manuscript, ending its estimation section at Proposition 3.2 and its stability section at Theorem 4.2. It does not contain the three strengthened theorems. This review therefore checks the proposed statements, proof arguments, and constructions retained in the conversation, against the model and foundational results in the recovered manuscript. A final typeset manuscript still needs a line-by-line check against these audited statements.

## Overall finding

The anchored recovery identity, its sharp minimax error radius, the initial policy-regret sharpness construction, and the continuation stability upper bounds are valid under the explicitly stated assumptions. I found no counterexample to those results. There is, however, an important necessary qualification to the continuation **policy-regret sharpness** claim: the construction needs two already-queried anchors. It proves a sharp uniform constant over the class of continuation problems, and sharpness for any fixed anchor-set size at least two. It does not prove sharpness for every nonempty anchor set. In fact, for one anchor and one remaining call, a stronger upper bound disproves such an overbroad claim.

The principal required revisions are therefore mathematical precision, rather than abandonment of the new results:

1. State the information model, particularly whether the already-incurred total cost is an additional exact observation.
2. Distinguish a bound valid for every fixed continuation problem from a constant sharp over a class of problems.
3. Keep the anchor set fixed within the optimization that uses the continuation surrogate.
4. State factor-two sharpness for surrogate-optimal policies, not minimax optimality over all decision rules.
5. Quantify the lower constructions with a sufficiently small positive penalty weight; do not claim they work for every fixed penalty and noise level.

## Theorem 3.3: anchored cost recovery

### Statement audited

For a nonnegative rooted-tree cost function F, fix disjoint finite sets A and S with A nonempty and k = |S|. The target is

\[
\Delta_F(A,S)=F(A\cup S)-F(A).
\]

For k > 0, let R_A(S) be the forests on A union S with exactly one anchor in each component. Thus all non-anchor vertices are connected to some anchor, while an unused anchor may be isolated. Every such forest has k edges. Define

\[
T_z(R)=\sum_{uv\in E(R)}z_{uv}
-\sum_{j\in S}(\deg_R(j)-1)z_j
-\sum_{a\in A}\deg_R(a)z_a,
\quad
H_A(S)=\min_{R\in R_A(S)}T_z(R).
\]

Set H_A(empty) = 0. If singleton errors are at most e1 and pair errors at most e2, the proposed error radius is k(e1+e2).

### Identity: valid

Orient a forest toward its anchor roots. Order the new vertices so that every parent in S precedes its children. When vertex j is added, the already-queried set contains its parent. The longest overlap with the entire already-queried set is therefore at least its overlap with that parent. The true incremental cost of adding j is consequently at most c_j minus the parent overlap. Summing gives

\[
\Delta_F(A,S)\le \sum_{j\in S}c_j-\sum_{uv\in E(R)}o_{uv}=T_c(R).
\]

For the reverse inequality, choose any ordering of S. For each new vertex j, select a parent in A or among preceding new vertices attaining the maximum overlap. A parent always exists because A is nonempty. Parent pointers move strictly backward until reaching A, so they produce a forest with exactly one anchor per component. The rooted-path marginal identity now holds with equality at every addition. Therefore Delta_F(A,S) = min_R T_c(R).

This proof does not require an ultrametric property for the graph obtained after contracting the anchors. Such a property is generally false when the anchors occupy different branches.

### Contraction algorithm and lifting: valid

Put w_ij = z_ij - z_i - z_j for distinct new vertices, and add a contracted root 0 with

\[
w_{0j}=\min_{a\in A}(z_{aj}-z_a-z_j).
\]

The estimator equals sum_{j in S} z_j plus the minimum spanning-tree weight on {0} union S.

Contracting all anchors in an admissible forest gives a connected graph with k+1 vertices and k edges, hence a tree. Conversely, remove 0 from a spanning tree. Each remaining component has one edge formerly incident to 0; lift that edge to an anchor attaining its minimum. Several components may choose the same anchor. This creates no cycle and every resulting component contains exactly one anchor. Unused anchors remain isolated. Thus optimization over the contracted graph is exactly equivalent to optimization over the forest family. Ties in the minimizing anchor are harmless.

The stated dense-graph arithmetic complexity O(|A|k + k^2) is justified. Anchor-anchor measurements are not used by the estimator, although allowing them as additional noisy data does not weaken the lower bound below.

### Error bound: valid

All non-anchor vertices have degree at least one. Since the forest has k edges,

\[
\sum_{j\in S}(\deg_R(j)-1)+\sum_{a\in A}\deg_R(a)=2k-k=k.
\]

There are exactly k pair coefficients, all +1, and singleton coefficients are all nonpositive with total absolute magnitude k. Consequently every forest expression changes by at most k(e1+e2). Taking minima preserves this bound. The empty target set has zero error.

### Minimax lower bound: valid, with information-model qualification

Choose a central star with shared trunk a and private pendant lengths b. Use the same measured singleton/pair table in two candidate true stars with

\[
(a_+,b_+)=(a-(2e_1+e_2),\ b+(e_1+e_2)),
\]
\[
(a_-,b_-)=(a+(2e_1+e_2),\ b-(e_1+e_2)).
\]

Take a > 2e1+e2 and b > e1+e2. All true edges are positive. Relative to the central table, singleton deviations are opposite values of magnitude e1 and pair deviations are opposite values of magnitude e2. This applies to every type of pair, including anchor-anchor pairs. For a nonempty A, the trunk cancels from the continuation target. Its two possible values differ by 2k(e1+e2). No estimator supplied only the noisy table can distinguish them, giving the matching half-separation lower bound.

The construction works for every fixed nonempty A and every k > 0, including zero values of either tolerance. It also survives additional labeled sources when those sources are included in the same star with the same perturbations.

**Required qualification:** F(A) is not supplied as a further exact measurement. In the two stars it generally differs by 2[|A|(e1+e2) - (2e1+e2)]. Thus the displayed construction cannot automatically establish the same radius for a model that also observes the exact previously incurred total. The prose should distinguish “already queried” from “its total cost is now known without error.” A different information model needs its own proof.

### Suggested precise statement

“Among estimators supplied with the singleton and pair measurements, and with no additional exact observation of the previously incurred set cost, the minimax absolute-error radius for the continuation target is k(e1+e2), for every fixed nonempty A and disjoint k-element S.”

## Theorem 4.3: sharp initial policy regret

### Upper-bound class: valid

For a fixed history-dependent policy, the observation law is identical in the true and surrogate problems because only acquisition costs change. A uniform terminal-cost error rho yields a policy-objective error at most lambda*rho. The usual two comparisons with the true and surrogate optimal policies yield regret at most 2*lambda*rho. This argument allows randomized policies and does not require the noisy surrogate to be monotone.

### Lower construction for B = k >= 2: valid

Let rho = (2k-3)epsilon. Use two branches with k leaves each. The measured tree has trunk/pendant parameters

- branch 1: a and b;
- branch 2: a + eta and b;

where a > 3epsilon, b > 2epsilon, and 0 < eta < 2rho. Each branch contains one deterministic copy of every one of k independent fair latent bits. The terminal decision predicts their parity. The total query budget is k.

The true tree changes branch 1 to trunk a-3epsilon and pendants b+2epsilon; it changes branch 2 to trunk a+eta+3epsilon and pendants b-2epsilon. Every singleton deviation has magnitude epsilon; every within-branch pair deviation has magnitude epsilon; cross-branch pair deviations are zero. The full measured table is therefore admissible, including measurements for pairs from different branches.

Put C = a+kb. The measured cheapest informative set contains all k leaves from branch 1, at cost C. The other complete branch costs C+eta. A mixed informative set pays both trunks, so it is more expensive than branch 1 in the measured problem.

The true complete-branch costs are C+rho and C+eta-rho. If a mixed informative set takes t leaves from branch 1, with 1 <= t <= k-1, its true cost exceeds the true branch-2 full-set cost by

\[
a+(4t-3)\epsilon>0.
\]

Thus the true cheapest informative set is branch 2. The proposed construction correctly excludes mixed sets as better alternatives.

### Adaptive stopping and duplicated observations: valid

Conditional on the entire latent bit vector, every observation is deterministic. The joint conditional distribution therefore factors into its deterministic coordinate kernels, even though the two copies of each bit are perfectly correlated marginally. This satisfies the manuscript's conditional-independence assumption.

At any history missing at least one distinct bit, an unobserved fair bit still makes parity conditionally uniform. Adaptive source selection and stopping cannot reveal such an unobserved bit. Hence the conditional Bayes error is 1/2 at every incomplete history and zero once all bits have been observed. With only k calls, a complete history must have queried exactly one copy of each bit.

Let u be the probability of completing. For either nonnegative physical cost function K, with cheapest informative-set cost Cmin(K), every policy has objective at least

\[
u\lambda C_{\min}(K)+(1-u)/2.
\]

Always stopping and always querying a cheapest informative set attain the two endpoints. Choose lambda > 0 so that lambda*Cmin(K) < 1/2 in both models. It then follows that an optimal policy completes with probability one and uses a cheapest informative set at every terminal history. In the measured model the terminal source set is unique, even though its query order need not be.

Evaluating the measured-optimal policy under true costs gives regret lambda(2rho-eta). Letting eta/rho decrease to zero proves that no coefficient below two holds uniformly over this model class. This is a supremum statement; with eta > 0 the ratio is below two and does not rely on an unfavorable tie-break.

### Required wording

- Say “the constant two is sharp uniformly over the class of surrogate-optimal policies and finite decision models.”
- Do not call this minimax optimality of the decision rule among all estimators or decision procedures.
- Do not say the lower construction works for every prescribed lambda and epsilon under bounded terminal loss. The proof chooses a sufficiently small positive lambda. Equivalently, one may rescale the construction when varying the noise scale.
- If including B = 1, give its separate two-source construction. It is not covered by the expression (2B-3)epsilon. The existing beta_1 = 1 convention is appropriate.

## Theorem 4.4: continuation decision stability

### Pointwise stability bounds: valid

At a fixed current posterior p and nonempty anchor set A, let b be the remaining call budget. Use the surrogate terminal cost H_A(U), for the set U of newly queried sources. Theorem 3.3 supplies

\[
|H_A(U)-\Delta_F(A,U)|\le |U|(e_1+e_2)\le\kappa_b,
\quad \kappa_b=b(e_1+e_2).
\]

For the common policy class, unchanged likelihoods, unchanged current posterior, and unchanged terminal loss,

\[
|V_F^A-V_H^A|\le\lambda\kappa_b,
\qquad
0\le J_F^A(\pi_H)-V_F^A\le2\lambda\kappa_b.
\]

This proof is valid for any nonempty A, regardless of its size. It also covers the empty future target set and b=0 with the corresponding zero constants. It does not extend directly to cost-dependent admissibility constraints or uncertain observation kernels.

### Fixed anchors are essential to the planning statement

In the dynamic program for this continuation problem, the correct surrogate incremental cost at future set U is

\[
H_A(U\cup\{i\})-H_A(U).
\]

The same A must remain fixed throughout that optimization. Replacing it at each future step by A union U and summing H_{A union U}({i}) generally loses telescoping for an incompatible measured table. Replanning after reaching a later actual history is possible, but it defines a fresh optimization and certificate. Its realized receding-horizon policy is not automatically the policy for which the original fixed-anchor regret proof was established.

### Sharpness of the value bound: valid

Use an uninformative already-queried nonempty A and k=b independent fair bits revealed by the remaining sources in a single shared-trunk star. The two-star construction in Theorem 3.3 changes the full continuation cost by exactly k(e1+e2) from the measured central star. For sufficiently small lambda, both models acquire all b bits to predict parity. Their optimal values consequently differ by lambda*k(e1+e2). This establishes value-constant sharpness uniformly over models for every fixed nonempty anchor-set size.

### Sharpness of the policy-regret bound: valid with two anchors

For e1=e2=epsilon, use two branches, each with b future source leaves and one already-queried uninformative anchor. The measured trunks are both a. Branch-1 pendant lengths are d; branch-2 pendant lengths are d+eta/b. Take a>3epsilon, d>2epsilon, and 0<eta<4b*epsilon. Both routes are activated by the anchors.

The true branch-1 trunk decreases by 3epsilon and all its pendant lengths increase by 2epsilon. Branch 2 has the reverse perturbation. All singleton/pair error constraints, including pairs involving anchors and cross-branch pairs, are satisfied by the same calculation as in Theorem 4.3.

The two measured complete continuation costs are bd and bd+eta; their true values are bd+2b*epsilon and bd+eta-2b*epsilon. Mixed informative sets have a linear combination of the two pendant costs and cannot improve on selecting the cheaper copy of every bit. The parity and sufficiently-small-lambda argument then gives regret

\[
\lambda(4b\epsilon-\eta)
=\lambda(2\kappa_b-\eta),
\quad \kappa_b=2b\epsilon.
\]

The ratio tends to two. The general tolerances follow by replacing the trunk perturbation by 2e1+e2 and the pendant perturbation by e1+e2. For equal tolerances, additional irrelevant anchors at the root extend the construction to every fixed |A| >= 2. For arbitrary tolerances, use additional uninformative private anchor leaves on either existing branch, with that branch's pendant length and the same branch-specific perturbation. This preserves every singleton and pair error constraint and does not change future continuation costs. A root anchor would instead create a source pair with error e1, which need not be bounded by e2.

### Necessary correction: the factor two is not sharp for every nonempty A

For |A|=1 and b=1, write A={a}. The true and surrogate continuation costs for querying i are

\[
c_{ai}-c_a,\qquad z_{ai}-z_a.
\]

Let q_i be the expected terminal Bayes risk after querying i, and let r be the risk of stopping now. The true action value is q_i + lambda(c_ai-c_a), whereas the measured action value is q_i + lambda(z_ai-z_a). Their difference d_i satisfies

\[
|d_i|\le\lambda(e_1+e_2).
\]

For two query actions i and j, however, the common anchor error cancels:

\[
|d_i-d_j|\le2\lambda e_2.
\]

If the measured and true optimal actions are both query actions, the regret is at most 2lambda*e2. If one is stopping, its action error is zero, so regret is at most lambda(e1+e2). Therefore the stronger uniform upper bound is

\[
J_F^A(\pi_H)-V_F^A
\le\lambda\max\{e_1+e_2,\ 2e_2\},
\qquad |A|=b=1.
\]

In the equal-tolerance case this is 2lambda*epsilon, whereas the generic bound 2lambda*kappa_b is 4lambda*epsilon. Consequently a claim that the generic factor two is sharp “for every nonempty A and every b>=1” would be false. The proposed two-anchor construction never established that stronger quantifier.

### Recommended replacement wording

“The bounds hold for every fixed nonempty anchor set. The value-error constant is sharp for every fixed nonempty anchor-set size. The factor two in the policy-regret bound is sharp uniformly over the class of continuation problems; the lower construction already applies with two anchors, and extends to any fixed anchor-set size at least two. Sharp constants for restricted anchor configurations may be smaller.”

It would also be useful to include the singleton-anchor, one-call bound as a short remark. This demonstrates that the manuscript recognizes the joint error geometry instead of asserting uniform sharpness beyond what is proved.

## Additional supporting results checked

### History-size subtraction counterexample

For h>=2 anchors in a central star, the proposed perturbed measurements give

\[
H(A)=F(A)+(2h-3)\epsilon,
\quad
H(A\cup\{j\})=F(A\cup\{j\})-(2h-1)\epsilon.
\]

Their difference is b-(4h-4)epsilon, while the true incremental cost and the anchored estimator both equal b. The algebra is correct. The observed table may violate tree compatibility; this is permitted by the measurement model and must be stated. The counterexample demonstrates actual history-dependent instability, not merely a loose bound.

### Heterogeneous-coordinate intervals

With separate e_i and e_ij, the proposed forest radius is nonnegative because all new vertices have degree at least one. Minimizing the lower and upper affine forest expressions gives valid bounds on the true minimum. The substitutions that increase singleton measurements/decrease pair measurements for the lower endpoint, and do the reverse for the upper endpoint, are correct. These are certified intervals; the proof does not establish exact feasible-tree extrema or minimax optimality for arbitrary heterogeneous tolerances.

## Review disposition

**Mathematical disposition:** The three proposed theorem families are suitable to retain after applying the quantifier and planning qualifications above. The continuation policy-sharpness statement requires an explicit scope correction if its current wording claims sharpness for every nonempty A.

**Submission disposition:** This audit does not replace an external mathematician's proof review, a complete check of the final typeset proof, or direct prior-theorem comparison. Numerical checks are useful implementation evidence but do not establish the universal results. Publication novelty remains a separate question.


## Addendum: check of the revised manuscript text

**Document inspected:** `work/main_draft.md`, 13 September 2026. This check covers the actual proposed text of Theorems 3.3, 4.3 and 4.4, Remark 4.6, and the associated planning paragraph. It reduces the source limitation above: these new theorem statements and proofs have now been inspected in their revised manuscript form. The final Word typesetting has not been inspected by this reviewer.

- **Theorem 3.3:** The manuscript correctly states the measurement-only information model, handles nonempty anchors, counts forest coefficients, gives the indistinguishable-star lower bound, and proves the contracted MST lift. No new mathematical error found.
- **Theorem 4.3:** The mixed-set excess is correctly written as a+(4t-3)epsilon. The sufficiently-small-positive-penalty quantifier, deterministic conditional kernels, adaptive parity argument, and distinction from minimax decision optimality are correctly included. No new error found.
- **Theorem 4.4:** The general upper bound, value lower construction, fixed-anchor planning warning, and two-anchor regret construction are correctly transcribed. The scope of policy sharpness has been corrected as requested. One additional issue was found in the sentence adding extra anchors at the root: this works for equal tolerances, or e1 <= e2, but not for arbitrary e1 and e2. The cost of a pair consisting of a zero-cost root anchor and source i is the singleton cost of i. Its deviation can be e1, exceeding the permitted pair tolerance e2. This matters, for example, when e2=0<e1. Replace that sentence by: **“Additional uninformative anchors may be added as private leaves on either existing branch, with the same pendant length and perturbation as that branch. Their within-branch pair deviations have magnitude epsilon_2 and their cross-branch deviations are zero. Since both trunks are already activated, these extra anchors do not change the future continuation costs. This extends the construction to every fixed |A| >= 2.”** This also clarifies the corresponding paragraph in this audit, which has been corrected above. For maximal precision, introduce the sharpness constructions explicitly with b>=1 and epsilon_1+epsilon_2>0; the zero-radius cases are already covered by the upper bound.
- **Remark 4.6:** The cancellation argument and the bound lambda*max{epsilon_1+epsilon_2,2epsilon_2} are correct. They agree with the critical finding in this report.
- **Related-work wording:** The revised draft expressly distinguishes its unlabeled branching vertices from the player-at-every-non-root-vertex convention in the cited irrigation-game paper. That qualification is appropriate to avoid claiming identical model classes. This proof audit does not independently certify the bibliographic lemma numbering; the parent review checked it against the published full text.

**Final mathematical disposition:** Subject to replacing the extra-root-anchor sentence as above, the inspected new theorem text incorporates the substantive audit corrections. No further theorem-level defect was identified in this check. This remains an internal AI audit, not external human peer review or a novelty certificate.

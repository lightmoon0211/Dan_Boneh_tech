"""Reference algorithms; Python >=3.10, standard library only.

Measurements are singleton/pair acquisition costs, not pairwise distances.
No exact telemetry of the already-paid total is an input to continuation().
"""
from fractions import Fraction as Q
from functools import lru_cache
from itertools import combinations, product


def pair(i, j):
    return tuple(sorted((i, j)))


def mst(vertices, weight):
    """Dense Prim; permits negative weights; returns weight and selected edges."""
    v = list(vertices)
    if not v:
        return 0, []
    used = {v[0]}
    best = {j: (weight(v[0], j), v[0]) for j in v[1:]}
    total, edges = 0, []
    while best:
        j = min(best, key=lambda j: (best[j][0], j))
        w, i = best.pop(j)
        total += w
        edges.append((i, j))
        used.add(j)
        for k in best:
            new = weight(j, k)
            if new < best[k][0]:
                best[k] = (new, j)
    return total, edges


def initial(c, cp, S):
    S = tuple(sorted(S))
    return sum(c[i] for i in S) + mst(S, lambda i, j: cp[pair(i, j)]-c[i]-c[j])[0]


def continuation(c, cp, A, S, return_forest=False):
    A, S = tuple(sorted(A)), tuple(sorted(S))
    if not A or set(A) & set(S):
        raise ValueError('Require nonempty anchors disjoint from new sources')
    root = -1
    choices = {j: min(A, key=lambda a: (cp[pair(a, j)]-c[a]-c[j], a)) for j in S}
    def weight(i, j):
        if i == root or j == root:
            j = j if i == root else i
            a = choices[j]
            return cp[pair(a, j)]-c[a]-c[j]
        return cp[pair(i, j)]-c[i]-c[j]
    w, edges = mst((root,)+S, weight)
    value = sum(c[j] for j in S)+w
    forest = [(choices[j], j) if i == root else ((i, choices[i]) if j == root else (i, j)) for i, j in edges]
    return (value, forest) if return_forest else value


def certificates(c, cp, e, ep, A, S):
    lower = continuation({i:c[i]+e[i] for i in c}, {p:cp[p]-ep[p] for p in cp}, A, S)
    upper = continuation({i:c[i]-e[i] for i in c}, {p:cp[p]+ep[p] for p in cp}, A, S)
    return lower, upper


def repair(c, cp):
    nodes = sorted(c)
    cc = {i:max(0,c[i]) for i in nodes}
    u = {pair(i,j): min(cc[i],cc[j],max(0,c[i]+c[j]-cp[pair(i,j)])) for i,j in combinations(nodes,2)}
    for k in nodes:
        for i,j in combinations([v for v in nodes if v != k], 2):
            u[pair(i,j)] = max(u[pair(i,j)], min(u[pair(i,k)],u[pair(k,j)]))
    pp = {p:cc[p[0]]+cc[p[1]]-u[p] for p in u}
    return cc, pp


def tree_cost(parents, weights, services):
    """Source i at vertex i+1. Root vertex 0. Parents have smaller indices."""
    paths = []
    for i in range(len(parents)):
        p, v = set(), i+1
        while v:
            p.add(v-1)
            v = parents[v-1]
        paths.append(p)
    @lru_cache(None)
    def F(S):
        edges = set().union(*(paths[i] for i in S))
        return sum(weights[e] for e in edges)+sum(services[i] for i in S)
    return F


def branch_cost(branches, trunks, pendants):
    @lru_cache(None)
    def F(S):
        return sum(trunks[g] for g in {branches[i] for i in S})+sum(pendants[i] for i in S)
    return F


def table(F, n):
    return ({i:F((i,)) for i in range(n)}, {p:F(p) for p in combinations(range(n),2)})


def subsets(nodes, maxsize=None):
    nodes=tuple(nodes)
    return [s for k in range((len(nodes) if maxsize is None else maxsize)+1) for s in combinations(nodes,k)]


class Decision:
    """Exact finite-state binary-observation DP with terminal set-cost potential.

    Prior and likelihoods can be Fractions. Anchors are conditioned on already;
    available labels refer only to future sources. Fixed-anchor continuation is
    represented by passing one potential K(U)=H_A(U) to the entire DP.
    """
    def __init__(self, prior, likelihood, target, available, budget, penalty, K, myopic=False):
        self.prior, self.L, self.target = tuple(prior), likelihood, tuple(target)
        self.available, self.budget, self.penalty, self.K = tuple(available), budget, penalty, K
        self.myopic=myopic
        self.actions={}

    @lru_cache(None)
    def posterior(self, h):
        weights=[]
        for x,p in enumerate(self.prior):
            for i,y in h:
                z=self.L[i][x]
                p *= z if y else 1-z
            weights.append(p)
        mass=sum(weights)
        return tuple(p/mass for p in weights) if mass else None

    def risk(self,p):
        t=sum(p[x] for x in range(len(p)) if self.target[x])
        return min(t,1-t)

    def children(self,h,i,p):
        q=sum(p[x]*self.L[i][x] for x in range(len(p)))
        return [(mass,tuple(sorted(h+((i,y),)))) for y,mass in ((0,1-q),(1,q)) if mass]

    @lru_cache(None)
    def solve(self,h=()):
        p=self.posterior(h)
        S=tuple(i for i,y in h)
        risk=self.risk(p)
        best=(risk+self.penalty*self.K(S),risk,self.K(S),Q(len(S)))
        choice=None
        score=best[0]
        if len(S)<self.budget:
            for i in self.available:
                if i in S: continue
                children=self.children(h,i,p)
                value=tuple(sum(m*self.solve(hh)[t] for m,hh in children) for t in range(4))
                cand = (sum(m*self.risk(self.posterior(hh)) for m,hh in children)+self.penalty*self.K(tuple(sorted(S+(i,))))) if self.myopic else value[0]
                if cand < score:
                    score,best,choice=cand,value,i
        self.actions[h]=choice
        return best

    def evaluate(self,F,h=()):
        self.solve(h)
        @lru_cache(None)
        def recurse(h):
            p=self.posterior(h)
            i=self.actions[h]
            if i is None:
                S=tuple(j for j,y in h)
                risk=self.risk(p)
                return (risk+self.penalty*F(S),risk,F(S),Q(len(S)))
            return tuple(sum(m*recurse(hh)[t] for m,hh in self.children(h,i,p)) for t in range(4))
        return recurse(h)

    def replay(self,F):
        """Independent full-outcome enumeration of the selected policy."""
        self.solve()
        result=[Q(0)]*4
        count=0
        for x,p0 in enumerate(self.prior):
            for ys in product((0,1),repeat=len(self.available)):
                count += 1
                p=p0
                obs=dict(zip(self.available,ys))
                for i,y in obs.items(): p *= self.L[i][x] if y else 1-self.L[i][x]
                if not p: continue
                h=()
                while self.actions[h] is not None:
                    i=self.actions[h]
                    h=tuple(sorted(h+((i,obs[i]),)))
                post=self.posterior(h)
                decision=int(sum(post[t] for t in range(len(post)) if self.target[t])>Q(1,2))
                error=int(decision != self.target[x])
                cost=F(tuple(i for i,y in h))
                vals=(error+self.penalty*cost,error,cost,len(h))
                for t in range(4): result[t] += p*vals[t]
        return tuple(result),count

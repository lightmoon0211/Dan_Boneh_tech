"""Reproduce every newly reported experiment with no third-party packages.

Run: python code/run_experiments.py --output results
Integer cost units avoid round-off; exact decision checks use Fraction.
"""
import argparse, csv, json, platform, random, time
from collections import defaultdict
from fractions import Fraction as Q
from itertools import combinations, product
from pathlib import Path
from tree_recovery import *


def write_csv(path, rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


class LCG:
    def __init__(self): self.s=20260911
    def pick(self,n):
        self.s=(1664525*self.s+1013904223)%2**32
        return self.s%n


def algebra():
    rng=LCG(); counts=defaultdict(int)
    for trial in range(100):
        n=6
        F=tree_cost([rng.pick(i+1) for i in range(n)],[2*(1+rng.pick(30)) for i in range(n)],[2*(1+rng.pick(10)) for i in range(n)])
        c,cp=table(F,n)
        z={i:v+rng.pick(3)-1 for i,v in c.items()};zp={p:v+rng.pick(3)-1 for p,v in cp.items()}
        cc,pp=repair(z,zp)
        overlaps={p:cc[p[0]]+cc[p[1]]-pp[p] for p in pp}
        assert all(0<=v<=min(cc[p[0]],cc[p[1]]) for p,v in overlaps.items())
        for i,j,k in product(range(n),repeat=3):
            if len({i,j,k})==3:
                assert overlaps[pair(i,j)]>=min(overlaps[pair(i,k)],overlaps[pair(j,k)])
        counts['repaired_compatibility_tables']+=1
        for S in subsets(range(n)):
            m=len(S);r=0 if m==0 else (1 if m==1 else 2*m-3)
            assert initial(c,cp,S)==F(S);counts['initial_identities']+=1
            assert abs(initial(z,zp,S)-F(S))<=r;counts['initial_error_bounds']+=1
            assert abs(initial(cc,pp,S)-F(S))<=(0 if m==0 else 4*m-3);counts['repair_error_bounds']+=1
            for j in set(range(n))-set(S):
                o=max((c[i]+c[j]-cp[pair(i,j)] for i in S),default=0)
                assert F(tuple(sorted(S+(j,))))-F(S)==c[j]-o;counts['marginal_identities']+=1
        for labels in product((0,1,2),repeat=n):
            A=tuple(i for i,v in enumerate(labels) if v==1);S=tuple(i for i,v in enumerate(labels) if v==2)
            if not A or not S: continue
            true=F(tuple(sorted(A+S)))-F(A)
            val,edges=continuation(c,cp,A,S,True)
            assert val==true;counts['continuation_identities']+=1
            value,edges=continuation(z,zp,A,S,True)
            assert abs(value-true)<=2*len(S);counts['continuation_error_bounds']+=1
            # An implementation-independent graph check of the lifted forest.
            comp={i:{i} for i in A+S}
            for u,v in edges:
                assert v not in comp[u]
                merged=comp[u]|comp[v]
                for t in merged: comp[t]=merged
            assert len(edges)==len(S) and all(len(comp[i]&set(A))==1 for i in A+S)
            counts['lifted_forests']+=1
            e={i:1+rng.pick(3) for i in c};ep={p:1+rng.pick(3) for p in cp}
            lo,hi=certificates(z,zp,e,ep,A,S)
            assert lo<=true<=hi;counts['heterogeneous_certificates']+=1
    return dict(counts)


def regression_extensions():
    # Original initial-radius examples for sizes beyond the six-source checks.
    for m in range(2,9):
        eps=Q(1,20);a=Q(2);q=Q(1)
        central=branch_cost([0]*m,[a],[q]*m);c,cp=table(central,m)
        for sign in (-1,1):
            F=branch_cost([0]*m,[a-sign*3*eps],[q+sign*2*eps]*m);fc,fp=table(F,m)
            assert max(abs(fc[i]-c[i]) for i in c)<=eps and max(abs(fp[p]-cp[p]) for p in cp)<=eps
            assert abs(F(tuple(range(m)))-initial(c,cp,tuple(range(m))))==(2*m-3)*eps
    count=0
    # Regression for the proof-review correction: extra anchors on branches,
    # including e1 > e2. Placing them at the root would fail these constraints.
    for h,k,(e1,e2) in product((3,5),(1,2),((Q(1,5),Q(0)),(Q(0),Q(1,7)),(Q(1,9),Q(2,7)))):
        s=e1+e2;t=2*e1+e2;a=Q(3);q=Q(2);eta=k*s/10
        groups=[0]*k+[1]*k+[0,1]+[0]*(h-2);n=len(groups);A=tuple(range(2*k,n));available=tuple(range(2*k))
        pend=[q+(eta/k if g else 0) for g in groups]
        M=branch_cost(groups,[a,a],pend)
        F=branch_cost(groups,[a-t,a+t],[v+(s if groups[i]==0 else -s) for i,v in enumerate(pend)])
        c,cp=table(M,n);fc,fp=table(F,n)
        assert max(abs(fc[i]-c[i]) for i in c)<=e1 and max(abs(fp[p]-cp[p]) for p in cp)<=e2
        states=list(product((0,1),repeat=k));prior=[Q(1,2**k)]*len(states);L={i:tuple(Q(x[i%k]) for x in states) for i in available}
        K=lambda S:continuation(c,cp,A,S)
        true=lambda S:F(tuple(sorted(A+S)))-F(A)
        d=Decision(prior,L,[sum(x)%2 for x in states],available,k,Q(1,100),K)
        oracle=Decision(prior,L,[sum(x)%2 for x in states],available,k,Q(1,100),true)
        assert d.evaluate(true)[0]-oracle.solve()[0]==Q(1,100)*(2*k*s-eta)
        count+=1
    return {'initial_sharpness_sizes':7,'extra_anchor_unequal_tolerance_policy_cases':count}


def sharp_recovery():
    rows=[]
    for h in (1,5,20):
        for k in (1,2,4):
            for e1,e2 in ((Q(1,20),Q(1,20)),(0,Q(1,7)),(Q(1,5),0),(Q(1,9),Q(2,7))):
                a,q=Q(3),Q(2);t=2*e1+e2;s=e1+e2;n=h+k
                central=branch_cost([0]*n,[a],[q]*n);c,cp=table(central,n)
                A=tuple(range(h));S=tuple(range(h,n));est=continuation(c,cp,A,S)
                for sign in (-1,1):
                    F=branch_cost([0]*n,[a-sign*t],[q+sign*s]*n);fc,fp=table(F,n)
                    assert max(abs(fc[i]-c[i]) for i in c)<=e1
                    assert max(abs(fp[p]-cp[p]) for p in cp)<=e2
                    true=F(A+S)-F(A)
                    assert abs(true-est)==k*s
                rows.append(dict(anchors=h,new=k,e1=str(e1),e2=str(e2),radius=str(k*s)))
    return rows


def sharp_policy():
    rows=[]
    for mode in ('initial','continuation'):
        for k in (2,3,4):
            eps=Q(1,20);a=Q(2);q=Q(1);lam=Q(1,100)
            rho=(2*k-3)*eps if mode=='initial' else 2*k*eps
            for fraction in (Q(1,2),Q(1,10),Q(1,100)):
                eta=rho*fraction
                if mode=='initial':
                    n=2*k;branches=[0]*k+[1]*k;A=()
                    M=branch_cost(branches,[a,a+eta],[q]*n)
                    F=branch_cost(branches,[a-3*eps,a+eta+3*eps],[q+2*eps]*k+[q-2*eps]*k)
                else:
                    n=2*k+2;branches=[0]*k+[1]*k+[0,1];A=(2*k,2*k+1)
                    pend=[q]*k+[q+eta/k]*k+[q,q+eta/k]
                    M=branch_cost(branches,[a,a],pend)
                    F=branch_cost(branches,[a-3*eps,a+3*eps],[p+(2*eps if branches[i]==0 else -2*eps) for i,p in enumerate(pend)])
                c,cp=table(M,n);fc,fp=table(F,n)
                assert max(abs(fc[i]-c[i]) for i in c)<=eps and max(abs(fp[p]-cp[p]) for p in cp)<=eps
                states=list(product((0,1),repeat=k));prior=[Q(1,2**k)]*len(states)
                L={i:tuple(Q(bits[i%k]) for bits in states) for i in range(2*k)}
                K=(lambda S:initial(c,cp,S)) if not A else (lambda S:continuation(c,cp,A,S))
                true=lambda S:F(tuple(sorted(A+S)))-F(A)
                dm=Decision(prior,L,[sum(x)%2 for x in states],range(2*k),k,lam,K)
                dt=Decision(prior,L,[sum(x)%2 for x in states],range(2*k),k,lam,true)
                regret=dm.evaluate(true)[0]-dt.solve()[0]
                assert regret==lam*(2*rho-eta)
                rows.append(dict(mode=mode,budget=k,eta_over_radius=float(fraction),radius=float(rho),regret=float(regret),normalized_regret=float(regret/(lam*rho))))
    return rows


def history_example():
    rows=[];eps=Q(1,20);a=Q(2);q=Q(1)
    for h in (1,2,5,10,20):
        n=h+1;j=h;A=tuple(range(h));S=(j,)
        F=branch_cost([0]*n,[a],[q]*n);c,cp=table(F,n)
        z={i:c[i]+(eps if i==j else -eps) for i in c}
        zp={p:cp[p]+(-eps if j in p else eps) for p in cp}
        diff=initial(z,zp,A+S)-initial(z,zp,A);direct=continuation(z,zp,A,S)
        assert diff==q-4*(h-1)*eps and direct==q
        rows.append(dict(anchors=h,true=float(q),subtraction=float(diff),direct=float(direct),subtraction_error=float(abs(diff-q)),direct_radius=float(2*eps)))
    return rows


def make_family(family,n,rng):
    if family=='star':
        return branch_cost([0]*n,[rng.randint(50,300)],[rng.randint(10,100) for _ in range(n)])
    parents=[i if family=='chain' else i//2 for i in range(n)]
    return tree_cost(parents,[rng.randint(10,100) for _ in range(n)],[rng.randint(10,100) for _ in range(n)])


def benchmarks():
    rng=random.Random(20260913);rows=[]
    for family,h,k,eps,rep in product(('star','chain','balanced'),(1,4,12),(1,2,4),(1,5,20),range(10)):
        n=h+k;F=make_family(family,n,rng);c,cp=table(F,n)
        labels=list(range(n));rng.shuffle(labels);A=tuple(sorted(labels[:h]));S=tuple(sorted(labels[h:]))
        z={i:v+rng.choice((-eps,0,eps)) for i,v in c.items()}
        zp={p:v+rng.choice((-eps,0,eps)) for p,v in cp.items()}
        true=F(tuple(range(n)))-F(A);cc,pp=repair(z,zp)
        vals={'direct':continuation(z,zp,A,S),'subtraction':initial(z,zp,tuple(range(n)))-initial(z,zp,A),'repair':initial(cc,pp,tuple(range(n)))-initial(cc,pp,A)}
        radius=2*k*eps
        assert abs(vals['direct']-true)<=radius
        for method,val in vals.items():
            rows.append(dict(family=family,anchors=h,new=k,epsilon_units=eps,replicate=rep,method=method,true_units=true,estimate_units=val,absolute_error_units=abs(val-true),error_over_direct_radius=abs(val-true)/radius,outside_direct_radius=int(abs(val-true)>radius)))
    return rows


def random_decisions():
    rng=random.Random(20260914);rows=[]
    for family,h,eps,lam in product(('star','chain','balanced'),(1,2),(1,5,20),(Q(1,2000),Q(1,500),Q(1,200))):
        n=6;F=make_family(family,n,rng);c,cp=table(F,n);A=tuple(range(h));avail=tuple(range(h,n));b=3
        z={i:v+rng.choice((-eps,0,eps)) for i,v in c.items()};zp={p:v+rng.choice((-eps,0,eps)) for p,v in cp.items()}
        cc,pp=repair(z,zp)
        # A fixed current posterior; uninformative anchors carry no new evidence.
        prior=(Q(1,2),Q(1,2));accuracy={i:Q(rng.choice((65,70,75,80,85,90)),100) for i in avail}
        L={i:(1-accuracy[i],accuracy[i]) for i in avail}
        true=lambda S:F(tuple(sorted(A+S)))-F(A)
        Ks={'oracle':true,'direct':lambda S:continuation(z,zp,A,S),'subtraction':lambda S:initial(z,zp,tuple(sorted(A+S)))-initial(z,zp,A),'repair':lambda S:initial(cc,pp,tuple(sorted(A+S)))-initial(cc,pp,A)}
        optimal=Decision(prior,L,(0,1),avail,b,lam,true).solve()[0]
        for method,K in Ks.items():
            d=Decision(prior,L,(0,1),avail,b,lam,K);measured=d.solve()[0];obj,error,cost,calls=d.evaluate(true)
            replay,count=d.replay(true);assert replay==(obj,error,cost,calls)
            if method=='direct':
                assert abs(measured-optimal)<=lam*2*b*eps and obj-optimal<=lam*4*b*eps
            rows.append(dict(family=family,anchors=h,epsilon_units=eps,lambda_per_unit=float(lam),method=method,objective=float(obj),regret=float(obj-optimal),error=float(error),cost_units=float(cost),calls=float(calls),regret_over_direct_bound=float((obj-optimal)/(lam*4*b*eps))))
    return rows


def legacy():
    F=tree_cost([0,1,1,0,0,5],[Q(str(x)) for x in (2,1.6,1.4,2.6,2,1.8)],[Q(str(x)) for x in (1,1.1,.9,.8,.9,1.3)])
    acc=[Q(str(x)) for x in (.75,.80,.78,.65,.70,.88)];L={i:(1-p,p) for i,p in enumerate(acc)};rows=[]
    for lam in (Q(5,1000),Q(1,100),Q(2,100),Q(4,100)):
        for myopic in (False,True):
            d=Decision((Q(1,2),Q(1,2)),L,(0,1),range(6),4,lam,F,myopic)
            obj,error,cost,calls=d.solve();replay,count=d.replay(F);assert replay==(obj,error,cost,calls)
            rows.append(dict(penalty=float(lam),policy='Myopic' if myopic else 'Optimal',error=float(error),cost=float(cost),calls=float(calls),objective=float(obj),first_source=d.actions[()]+1,replay_outcomes=count))
    return rows


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',default='results');args=parser.parse_args();out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    started=time.perf_counter();counts=algebra();counts.update(regression_extensions());print('Algebra checks:',json.dumps(counts),flush=True)
    datasets={'recovery_sharpness':sharp_recovery(),'policy_sharpness':sharp_policy(),'history_instability':history_example(),'recovery_benchmark':benchmarks(),'decision_benchmark':random_decisions(),'legacy_decisions':legacy()}
    for name,rows in datasets.items(): write_csv(out/(name+'.csv'),rows)
    sums=[]
    for family,method in product(('star','chain','balanced'),('direct','subtraction','repair')):
        rr=[r for r in datasets['recovery_benchmark'] if r['family']==family and r['method']==method]
        sums.append(dict(family=family,method=method,cases=len(rr),mean_normalized_error=sum(r['error_over_direct_radius'] for r in rr)/len(rr),max_normalized_error=max(r['error_over_direct_radius'] for r in rr),outside_direct_radius=sum(r['outside_direct_radius'] for r in rr)))
    write_csv(out/'recovery_summary.csv',sums)
    summary={'counts':counts,'dataset_rows':{k:len(v) for k,v in datasets.items()},'python':platform.python_version(),'platform':platform.platform(),'wall_seconds':time.perf_counter()-started,'seeds':{'algebra':20260911,'recovery':20260913,'decision':20260914},'all_assertions_passed':True}
    (out/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2));print(json.dumps(sums,indent=2))


if __name__=='__main__': main()

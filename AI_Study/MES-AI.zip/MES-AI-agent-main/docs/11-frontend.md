# 11 — The Web Interface

Code: [`frontend/app/`](../frontend/app) · [`frontend/components/`](../frontend/components) ·
[`frontend/lib/`](../frontend/lib)

The layers beneath produce a system that answers factory questions correctly,
but none of it is visible on its own. This is the screen a factory manager actually looks
at — and the screen has one job beyond showing the answer: **make the answer
checkable without taking anyone's word for it.**

```
 MES Copilot  Smart CNC Factory              ● Local model  ● Read-only MES  20:48 Tokyo
 ┌────────┬────────┬────────┬────────┬────────┐
 │ CNC-01 │ CNC-02 │ CNC-03 │ CNC-04 │ CNC-05 │   live readings, limits marked
 └────────┴────────┴────────┴────────┴────────┘
                     Ask the factory.
        [ ⌕  How many A12 parts can we produce this week?      Ask ↵ ]
 ┌─────────────────────────────────────┐ ┌─────────────────────────┐
 │ ESTIMATED A12 CAPACITY              │ │ ANALYSIS STEPS          │
 │ 4,456 units                         │ │ ● MES tool  ◆ calc  ◎ LLM│
 │ "We can produce up to 4456 …"       │ │ ● Get A12 information   │
 │ ● Validated  ● Local model  ● dates │ │ …                       │
 │ BOTTLENECK  CNC-01  84 h …          │ │ ◆ Rank the constraint   │
 └─────────────────────────────────────┘ │ ◎ Write the answer      │
   How the number was calculated         │ ◆ Check every number    │
   per-machine table · engine formula    ├─────────────────────────┤
                                         │ DATA USED               │
                                         └─────────────────────────┘
```

## Design

**Light and dark.** The page follows the operating system by default, and a
three-way toggle in the top bar (System · Light · Dark) overrides it for that
browser. Every colour is a CSS variable with a light and a dark value, tuned
separately rather than inverted — orange and amber are darker on white so they
still read as text, and soft shadows replace the dark theme's glow. The choice
is applied by a tiny script in `<head>` before first paint, so a dark page never
flashes white on load; if storage is refused (private browsing) the page still
renders, and the theme holds for that visit. While set to System it follows the
OS live. See `lib/theme.ts` and `components/ThemeToggle.tsx`.

An instrument panel rather than a dashboard: a graphite ground, hairline rules
instead of stacked boxes, and **one signal colour**. Orange marks the places
where a number is produced — the calculation steps, the headline's bottleneck,
the last line of the engine's formula — and the one action on the page. Status
colours mean status and nothing else, so amber always means a reading at a
limit.

- **Type:** Geist Sans and Geist Mono, shipped inside the build through the
  `geist` package. The page never requests a font server, which is the only way
  it can render correctly on an isolated factory network.
- **An idle page has one purpose.** Before the first question the screen is the
  machine strip, a large question box and the four-stage explanation
  (Understand → Read → Calculate → Validate). Once there is an answer, the box
  compacts and the examples collapse into one scrolling row.
- **The headline is the largest thing on the page**, set with its unit smaller,
  so the engine's figure is read before the model's sentence about it.
- **Marker shape carries meaning** in the analysis timeline: a dot for a
  controlled MES read, an orange diamond for deterministic arithmetic, a ring
  for the language model. The claim the demo depends on can be read at a
  glance, and without colour.
- **Stages, not a fake progress bar.** The stream gives no percentage, so none
  is drawn. The line under the box names what is actually being waited on,
  derived from the events that have arrived (`lib/steps.ts` · `runStage`).
- **No count-up animation on the headline.** It would put numbers on screen
  that the engine never produced.
- Run notes (for example, "time window corrected…") are audit detail, available
  under a disclosure rather than printed under the answer.
- Keyboard: `/` focuses the question from anywhere.

## Time zones

Two clocks, kept deliberately apart.

**The factory's time zone decides what "today" means.** The shift calendar,
the maintenance plan and the production history are all dated in the factory's
days, so "today", "yesterday" and "this week" resolve in the factory's zone for
every question, whoever asks and wherever they are. Consider someone in New
York at 22:00 on Sunday asking whether CNC-03 can run today. A factory in Tokyo
is already running Monday's shifts, so answering with Sunday's rows would feel
local and be wrong.

**The viewer's time zone decides how times are shown.** It is detected from the
device and can be changed from the clock in the top bar — search any IANA zone,
or pick *Device* or *Factory* in one click. The choice is stored per browser.

- The top bar shows both clocks when they differ — `Factory 01:02 Tokyo ·
  You 00:02 Shanghai` — and one clock when they match.
- The menu states the relationship in words ("You are 1 h behind the factory"),
  half-hour zones and daylight saving included.
- An answer's date range is labelled **Factory days**. When the viewer's
  calendar day is not the factory's, the answer says so:
  > It is Sun 13 Sep where you are (Shanghai). Dates in this answer are the
  > factory's — it is already Mon 14 Sep in Tokyo.
- The clock ticks on the device, corrected by the drift measured against the
  server at load, so a laptop with a fast clock does not show the factory's time
  fast.

**Moving the factory** to another zone is a deployment decision, not a viewer
preference, because it changes every answer for everyone:

```bash
make factory-timezone ZONE=Asia/Shanghai
```

The command rejects anything that is not an IANA name (`China`, `GMT+8`), writes
`FACTORY_TIMEZONE` to `.env`, rebases the dataset onto the factory's new today
(which also sets the database's zone), and recreates the backend. The backend
separately refuses to start on an invalid zone, so a typo fails at deploy
rather than on the first question of a demo. Verified on the live stack: after
switching, the health clock, every tool window and the database session all
report `Asia/Shanghai`.

The one bug this turned up was layout, not time: the header's blur gave it its
own stacking context, so the zone menu opened *under* the page content and its
entries could be seen but not clicked. The header now sits on its own layer.

## 1. The interface makes one argument

Every panel exists to support a single claim: *the model chose which question
was being asked and how to phrase the result; it did not produce a figure.*

| Panel | What it proves |
|---|---|
| Interpreted as | FR-2 — the rewrite is shown, not hidden |
| Headline | The run's finding, leading the card — the engine's figure, or the machine when the question asked which one |
| AI analysis steps | Each row labelled **MES tool** / **Calculation** / **Language model** |
| How the number was calculated | `CapacityResult.formula`, the engine's own working |
| Data used | Tables, columns, ids and row counts the tools reported |
| ✓ validated against the data | FR-7 — grounding and the key-claim check, with retries |

A viewer who distrusts the sentence can read the arithmetic under it, and then
the list of rows the arithmetic came from. That is the whole design.

## 2. The UI computes nothing

`lib/format.ts` formats; it never calculates. No component adds, divides or
compares a factory figure — the totals, percentages and rankings arrive final
and are printed as received. The one apparent exception is honest: the status
strip colours a reading red when it is at or past a threshold the MES supplied,
which is a comparison for the eye, not a verdict. Verdicts come from the rule
engine, with the limit cited.

Two small decisions follow from the same discipline:

**Digits are grouped with a fixed locale**, not the browser's. `1,139` must
read identically on the demo laptop and on the developer's machine; a figure
that renders differently in two places is exactly what this project refuses to
ship.

**The factory clock is never converted.** The backend stamps `…T12:28+09:00`;
the UI reads the hours and minutes out of that string. Parsing it into a
`Date` would re-express Tokyo's 12:28 as 03:28 for a reviewer in London and
label it the factory's time. The factory has one clock.

## 2a. The status strip opens

Each card on the strip opens that machine's full MES record: what the machine
is (`CNC_LATHE` shown as *CNC lathe*), the job loaded, when the reading was
taken in factory time, each reading beside the warning and critical limits the
factory set, and the maintenance booked against it — this week and next, with
whether anything is active **today**.

Three decisions worth recording.

**The readings stay on the strip.** A status board that hides its numbers
behind a click is not a status board, so the panel adds only what a reading
cannot say. It repeats each value next to its limit, which is the one thing
the strip has no room for.

**The panel answers a question the strip provokes.** Five machines are on
screen and an A12 capacity answer counts three: the two missing ones are mills,
and A12 needs a lathe. The type is now one click away, and an idle machine says
in words that its hours still count as capacity.

**The maintenance figure is the tool's, not the screen's.** `20 h scheduled`
comes from `get_maintenance_schedule`'s own `hours_by_machine` — the same total
the capacity engine subtracts — rather than summing the events in the browser.
Two named windows (`this_week`, `next_week`) are requested instead of a date
range, so the factory's calendar keeps deciding which days those are, and the
read happens server-side through the controlled tool layer: the browser's proxy
exposes no tool route, and widening it for a panel would trade the point of
that layer for a convenience. A schedule that cannot be read says so, because
an empty list would read as *no maintenance*.

`machines.available_hours` is labelled **MES display field** where it appears,
since ADR-7 keeps it out of the capacity path — a figure on this panel and a
figure in an answer must never look like a contradiction.

## 3. One origin: the browser never calls the backend

Every request goes to the Next.js server, which forwards it
([`app/api/mes/[...path]/route.ts`](../frontend/app/api/mes/[...path]/route.ts)):

```
browser ──▶ Next.js (server) ──▶ FastAPI
         /api/mes/ask/stream      http://backend:8000/api/ask/stream
```

Two reasons, one practical and one architectural:

- **It works in the composed stack.** Inside Docker the API answers to
  `http://backend:8000` — a hostname the browser cannot resolve. Proxying means
  there is no public API URL to configure and no CORS involved. The original
  `NEXT_PUBLIC_API_URL` has been replaced by a server-side `MES_API_URL`.
- **The surface stays controlled**, which is the tool layer's own principle
  applied one level up: a fixed list of routes may be reached and anything else
  is a 404 at the proxy. A UI bug cannot become an unexpected backend call.

## 4. Streaming, because the model takes its time

`EventSource` cannot be used — it only issues GET requests, and the question
travels in a POST body. So the response is read as a stream and parsed by
[`lib/sse.ts`](../frontend/lib/sse.ts), which is a pure function over strings
and has eleven tests, because the failure it must survive is certain and
boring: **chunk boundaries are not event boundaries**, and an event will
eventually arrive split down the middle.

Measured through the proxy on the composed stack, warm:

```
[  0.0s] accepted
[ 10.1s] understanding   intent=production_capacity  plan=5
[ 10.1s] step 1..5   the five MES tool calls          ok
[ 10.1s] step 6      calculation_engine               ok
[ 14.9s] step 7      explainer                        ok
[ 14.9s] step 8      grounding_validator              ok
[ 14.9s] run         answered, 5 tool calls
```

The shape of that timeline decided the layout. Understanding is one local model
call and the tool calls are milliseconds, so the panel goes from empty to six
rows in a single instant, then waits for the sentence. While it waits the
answer card says what is happening — *"Running the plan, then writing the answer
from the figures it returns"* — because on CPU the explanation alone is 5–25 s,
and a blank card for that long reads as a hang rather than as work.

> **On showing the plan before it runs.** The panel renders the plan as pending
> rows the moment `understanding` arrives, and replaces each as its result
> comes back. In practice that pending state is over in milliseconds, because
> the MES calls are fast. It is still the right construction — it is what makes
> the refusal path legible, where the remaining steps stay on screen marked
> *skipped* so it is obvious that nothing was computed — but the demo should
> not claim a visible "watch it plan" moment that the data does not produce.

## 5. Four endings, four cards

A refusal and a rejection are answers. Rendering them as errors would
misrepresent a system working exactly as specified.

| Status | Card | What it shows |
|---|---|---|
| `answered` | Answer | headline · sentence · bottleneck · validation · working |
| `clarify` | One thing first | the question, the concrete options as buttons, *"no tool was called"* |
| `refused_missing_data` | Cannot calculate this | the named field (`parts.cycle_time_min`) and the skipped steps |
| `rejected_out_of_domain` | Outside this assistant's domain | the fixed message and an empty steps panel that says why it is empty |

Clicking a clarification option re-asks with that reading appended, and the
run comes back `answered` — the R2 loop closed on screen. Verified in a
browser, not assumed.

For a rejection the steps panel is the evidence, so it says so rather than
looking broken:

> No step ran. The request was settled before the agent reached the factory,
> so no tool was called and no row was read.

That is acceptance criterion 7, rendered.

## 6. What building the interface found in the backend

Looking at the system through a screen is a different test from looking at it
through `curl`, and it found five defects. Four were in the backend.

**A stream field that lied.** `tool_result` carried `"of": 2` while emitting
five steps — the plan length, labelled as a total. Any consumer rendering
"step 3 of 2" would have been right to. Renamed `planned_steps`, with the
distinction written down: the engine, explainer and validator steps are
appended after the plan and are legitimately not in it.

**`tool_call_count` was computed but never serialised.** The UI would have had
to recount the steps itself — and a screen that disagrees with the audit trail
about how many times the factory was read is worse than no number. It is now a
`computed_field`, so both read the same value.

**An answer that named a bottleneck when the engine found none.** With one
shift left in the week the three eligible lathes were exactly level and the
engine reported *"No single bottleneck"*. The model answered *"CNC-01 has the
available hours and the reason is material"* — grounded, incoherent, and wrong.
A tie is a finding; the validator now requires an answer not to contradict it.

**An answer that blamed the wrong kind of constraint.** The first screenshot of
the finished hero scenario read: *"This limit is set by the material
availability of 9600 units of STEEL-4140"* — while the engine had recorded 411
against a material ceiling of 9600, machine-constrained by a wide margin. Every
figure real; the sentence false. The validator now reads the clause after each
limit phrase and rejects an answer that names the constraint the engine did not
choose. Both live runs were corrected on the retry.

Both of those last two are the [§4 of `10-reliability.md`](10-reliability.md)
failure again — **grounded but wrong** — in two new disguises. The pattern is
now familiar enough to state plainly: *whenever the engine reaches a
conclusion, that conclusion needs a check, because the model will otherwise
reach for a nearby true-sounding sentence.*

The fifth was mine: the answer card's titles were keyed by run status while the
lookup used the card's tone, so the rejection card rendered with **no heading
at all**. It had been that way in every `curl` test, invisible.

## 7. Running it

```bash
make up            # postgres + model server + API + web  → http://localhost:3000
make web-dev       # the interface alone, with reload, against a local API
make web-test      # 56 unit tests
make web-lint      # eslint + tsc --noEmit
```

Next.js 16 (App Router) · React 19 · Tailwind 4 · Geist · TypeScript, strict. The
container is a standalone build: the runtime stage carries the traced server
and no `node_modules`, which is the shape an air-gapped install will want.

The page is server-rendered — the factory strip arrives with real machine state
rather than five grey placeholders — and it renders usefully with the backend
down, saying so instead of offering a question box that cannot work.

## 8. Verified in a real browser

Driven through headless Chrome against the composed stack, not asserted from
the API:

| Case | Result |
|---|---|
| S1 capacity | headline, sentence, per-machine table, formula, 5 tool calls, 8 steps |
| S4 analysis | 250 / 215 / 8 / 2.1 h, factors ranked −36 / −8 / +4, per-machine table |
| S5 maintenance | CNC-04 first, every check citing its limit, CNC-02 *not fully assessable* |
| R2 clarify | options shown, clicking one returns an `answered` run |
| R3 refusal | `parts.cycle_time_min` named, later steps shown *skipped*, 1 tool call |
| R4 rejection | fixed message, "no factory data was read", empty panel explained |
| Machine detail | every machine opens its record: type, name, status, limits, maintenance; Escape closes it; arrow keys move between machines; readings stay on the strip; fits 390 px |
| Layout | no horizontal overflow at 1440 / 1280 / 900 px |
| Console | no errors, no failed requests |

## 9. The dataset on a weekend *(resolved)*

> Resolved in testing: the factory now runs seven days a week with CNC-03 on a single shift, the
> SQL oracle applies the engine's tie rule, the skip fixtures described below were removed, and
> `make test-week` passes every test on all seven days. See
> [`05-seed-data.md`](05-seed-data.md) §4–5 and [`12-testing.md`](12-testing.md). The original
> finding is kept below as the record of why.

The interface was first built and verified on a **Saturday**, which surfaced the limitation
[`05-seed-data.md` §5](05-seed-data.md) documents — and showed it is wider than
recorded there.

The seed places CNC-03's overhaul on the working days *after* the seeding date.
On the last working day of the week none remain: the three lathes are exactly
level, capacity is 411, and there is **no bottleneck to name**. S1 and S3 lose
their story. Seeding a day earlier restores it but moves the S4 incident out of
"yesterday", so that scenario empties instead.

This is correct behaviour under the "remaining week" scoping rule, and a poor
demo. Six backend tests assert the seeded weekday story; they now **skip with
an explicit reason** naming this limitation rather than failing, so the suite
stays a usable gate and the cause stays visible:

```
SKIPPED tests/test_engine_oracle.py:179: no CNC-03 maintenance remains in this
        week's window, so the lathes are level and there is no bottleneck
        (docs/05-seed-data.md §5)
```

`db/verify.sql` reports the same condition as **17/20**, failing exactly the
three assertions that depend on it: the S3 bottleneck machine, "the bottleneck
has strictly fewest effective hours", and C15's material branch. Worth noting
for testing: on a tie the SQL oracle picks the first of the level machines while
the Python engine correctly reports *no single bottleneck* — assertion 3 is
what catches the disagreement, and the two implementations should be brought
into line.

Everything that tests *behaviour* still runs: 310 pass. Rehearse the real demo
date before the meeting (`make db-rehearse DATE=…`), and see §10.

## 10. Follow-ups for testing *(all four done — see [`12-testing.md`](12-testing.md))*

1. **Make the dataset tell the story on any day** — the highest-value fix.
   Giving CNC-03 a shorter shift on the week's last working day would make it
   the bottleneck by *planned hours* rather than by maintenance, which is the
   one variant that leaves S2's "CNC-03 can continue today" true at the same
   time. It changes the cause S3 reports, so it is a documented decision, not a
   silent tweak.
2. Run the full matrix in `04-demo-scenarios.md`, including the fifteen
   phrasing variants, through the interface rather than the API.
3. Frontend end-to-end tests. The browser checks in §8 were run as a
   verification script; testing should make them a suite that runs in CI.
4. Align the SQL oracle with the engine's tie rule (§9).

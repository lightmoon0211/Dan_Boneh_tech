"""Running the plan (FR-4, FR-8).

These assert the behaviours the demo depends on — the documented tool sequence
actually executes, bindings carry values between steps, missing data stops the
run and names the field, and a tool that is not built yet is reported as such
rather than faked.
"""

from __future__ import annotations

import pytest

from app.agent.executor import PlanExecutor, _dig, _merge_sources
from app.agent.pipeline import AgentPipeline
from app.agent.schemas import ExecutedStep, Intent, RunStatus, StepStatus
from app.agent.understanding import UnderstandingPipeline
from app.schemas.envelope import SourceRef
from tests.conftest import requires_db

pytestmark = requires_db


@pytest.fixture
def understanding_pipeline(repo, ctx):
    return UnderstandingPipeline(repo=repo, clock=ctx.clock, llm=None, provider_name="none")


@pytest.fixture
def agent(repo, ctx):
    return AgentPipeline(repo=repo, clock=ctx.clock, llm=None, provider_name="none")


async def run(agent, question):
    return await agent.ask(question)


# ------------------------------------------------------------ the hero scenario


async def test_the_capacity_plan_executes_in_the_documented_order(agent):
    result = await run(agent, "How many A12 parts can we produce this week?")
    assert result.status is RunStatus.ANSWERED
    assert [s.tool for s in result.steps if s.kind == "tool"] == [
        "get_part_information",
        "get_available_machines",
        "get_maintenance_schedule",
        "get_material_inventory",
        "calculate_production_capacity",
    ]
    assert [s.step for s in result.steps] == [1, 2, 3, 4, 5, 6, 7]
    assert result.steps[5].kind == "engine", "step 6 is the deterministic derivation"
    assert result.steps[6].tool == "grounding_validator", "step 7 checks the answer"


async def test_the_hero_scenario_is_multi_step(agent):
    """Acceptance criterion 3: complex questions trigger multiple MES operations."""
    result = await run(agent, "How many A12 parts can we produce this week?")
    assert len(result.steps) >= 5
    assert result.tool_call_count >= 5


async def test_bindings_carry_values_between_steps(agent):
    """Step 2 needs the machine type step 1 returned; step 4 needs its material."""
    result = await run(agent, "How many A12 parts can we produce this week?")
    machines = next(s for s in result.steps if s.tool == "get_available_machines")
    assert machines.arguments["machine_type"] == "CNC_LATHE"
    assert machines.resolved_bindings["machine_type"]["from_step"] == 1
    assert (
        machines.resolved_bindings["machine_type"]["source_path"]
        == "data.part.required_machine_type"
    )

    inventory = next(s for s in result.steps if s.tool == "get_material_inventory")
    assert inventory.arguments["material_id"] == "STEEL-4140"


async def test_every_step_reports_what_it_found(agent):
    result = await run(agent, "How many A12 parts can we produce this week?")
    for step in result.steps:
        assert step.summary, f"step {step.step} has no summary"
    part_step = result.steps[0]
    assert "3.5 min/part" in part_step.summary and "STEEL-4140" in part_step.summary


async def test_data_used_is_merged_from_the_tools(agent):
    """Acceptance criterion 5 — assembled from tool output, not written by a model."""
    result = await run(agent, "How many A12 parts can we produce this week?")
    tables = {s.table for s in result.sources}
    assert {"parts", "machine_shift_calendar", "maintenance", "inventory"} <= tables
    assert len(result.sources) == len({s.table for s in result.sources}), "one entry per table"


# -------------------------------------------------- a tool that is not built yet


async def test_the_capacity_number_reaches_the_answer(agent):
    """Acceptance criterion 4: the quantity comes from the engine, not the model."""
    result = await run(agent, "How many A12 parts can we produce this week?")
    calc = next(s for s in result.steps if s.tool == "calculate_production_capacity")
    assert calc.status is StepStatus.OK

    assert result.capacity is not None
    assert result.headline is not None
    assert result.headline.value == result.capacity.final_capacity
    assert result.headline.unit == "units"
    # The headline must be what the engine computed, not a restatement.
    assert result.capacity.final_capacity == min(
        result.capacity.machine_capacity, result.capacity.material_capacity
    )


async def test_the_bottleneck_reaches_the_answer(agent):
    result = await run(agent, "How many A12 parts can we produce this week?")
    assert result.constraint is not None
    if result.constraint.kind == "machine":
        assert result.bottleneck is not None
        assert result.bottleneck.machine_id == result.constraint.bottleneck.machine_id
        assert "hours" in result.bottleneck.reason
    else:
        assert result.bottleneck is None, "material-bound runs name no machine"


async def test_a_bottleneck_question_is_headlined_by_the_machine(agent):
    """The headline answers the question that was asked.

    Both intents run the same calculation, so the bottleneck run once carried
    the capacity headline: the screen showed "3,770 units" over "Which CNC
    machine is limiting A12 production?" while the sentence below it correctly
    named CNC-03. The figure is still on the run, under the calculation panel.
    """
    capacity = await run(agent, "How many A12 parts can we produce this week?")
    assert capacity.headline.value == capacity.capacity.final_capacity
    assert capacity.headline.unit == "units"

    limiting = await run(agent, "Which CNC machine is limiting A12 production?")
    assert limiting.bottleneck is not None
    assert limiting.headline.text == limiting.bottleneck.machine_id
    assert limiting.headline.value is None
    assert limiting.capacity is not None
    # Both runs calculated the same thing; only the finding they lead with differs.
    assert limiting.capacity.final_capacity == capacity.capacity.final_capacity


async def test_engine_steps_are_marked_as_calculations_not_tool_calls(agent):
    result = await run(agent, "How many A12 parts can we produce this week?")
    engine_steps = [s for s in result.steps if s.kind == "engine"]
    assert [s.tool for s in engine_steps] == ["calculation_engine", "grounding_validator"]
    assert all("no language model" in (s.note or "") for s in engine_steps)
    assert result.tool_call_count == 5, "engine steps are not tool calls"


async def test_the_answer_shows_its_arithmetic(agent):
    """The demo has to be able to justify the number on screen."""
    result = await run(agent, "How many A12 parts can we produce this week?")
    assert "Working:" in result.answer
    assert str(result.capacity.final_capacity) in result.answer


# --------------------------------------------------------- missing data (FR-8)


async def test_a_missing_cycle_time_refuses_and_names_the_field(agent):
    """Scenario R3 — the refusal comes from a tool, not from a prompt."""
    result = await run(agent, "How many B20 parts can we produce tomorrow?")
    assert result.status is RunStatus.REFUSED_MISSING_DATA
    assert [m.field for m in result.missing_fields] == ["parts.cycle_time_min"]
    assert "parts.cycle_time_min" in result.answer
    assert result.headline is None


async def test_the_rest_of_the_plan_is_skipped_but_still_shown(agent):
    result = await run(agent, "How many B20 parts can we produce tomorrow?")
    assert result.steps[0].status is StepStatus.OK
    assert all(s.status is StepStatus.SKIPPED for s in result.steps[1:] if s.kind == "tool")
    tool_steps = [s for s in result.steps if s.kind == "tool"]
    assert len(tool_steps) == 5, "the panel still shows the whole plan"
    assert result.capacity is None, "a refused run computes nothing"
    assert not any(s.tool == "calculation_engine" for s in result.steps)


async def test_an_unrelated_missing_field_does_not_refuse(agent):
    """CNC-02's vibration sensor is offline; that must not block a health question."""
    result = await run(agent, "Which machine needs maintenance attention?")
    assert result.status is RunStatus.ANSWERED
    assert any(m.field == "machines.vibration_mm_s" for m in result.missing_fields)
    assert result.tool_call_count == 2


# ------------------------------------------------------- the other scenarios


async def test_machine_health_executes(agent):
    result = await run(agent, "Can CNC-03 continue production today?")
    assert result.status is RunStatus.ANSWERED
    assert result.intent is Intent.MACHINE_HEALTH
    assert "CNC-03" in result.steps[0].summary and "52.0" in result.steps[0].summary
    assert any(s.table == "rule_thresholds" for s in result.sources)


async def test_production_analysis_reads_the_incident(agent):
    result = await run(agent, "Why was A12 production lower yesterday?")
    assert result.status is RunStatus.ANSWERED
    history = next(s for s in result.steps if s.tool == "get_production_history").summary
    assert "planned 250" in history and "produced 215" in history
    assert "downtime 2.1 h" in history


async def test_the_shortfall_is_quantified_and_the_causes_ranked(agent):
    """S4: percentages are derived by the engine, and causes are ordered by impact."""
    result = await run(agent, "Why was A12 production lower yesterday?")
    analysis = result.analysis
    assert analysis is not None
    assert analysis.pct_below_plan == 14.0
    assert analysis.reject_rate_pct == 3.6
    assert analysis.parts_lost_to_downtime == 36
    assert [f.kind for f in analysis.factors] == ["downtime", "rejects", "offset"]
    assert result.headline.value == 14.0 and result.headline.unit == "%"


async def test_one_machine_two_questions_two_findings(agent):
    """What a machine is doing, and whether it may keep running, are not the same.

    Both questions evaluate the same machine, so the status run once headlined
    the health verdict: three differently worded questions about CNC-03 came
    back as the same answer under "Can continue production".
    """
    status = await run(agent, "What is the current status of CNC-03?")
    assert status.headline.text == "Running"
    assert status.health[0].current_job == "PO-1003"
    assert status.health[0].utilization_pct is not None
    # The job and the utilisation are what a status question is answered from,
    # and before this they were not on the run at all.
    assert "PO-1003" in status.steps[-2].summary or "PO-1003" in status.answer

    health = await run(agent, "Can CNC-03 continue production today?")
    assert health.headline.text == "Can continue production"


async def test_machine_health_produces_a_verdict_citing_the_threshold(agent):
    """S2: the verdict names the limit it was compared against."""
    result = await run(agent, "Can CNC-03 continue production today?")
    assert len(result.health) == 1
    health = result.health[0]
    assert health.machine_id == "CNC-03" and health.can_produce is True
    verdicts = " ".join(c.verdict for c in health.checks)
    assert "70 °C limit" in verdicts and "2.5 mm/s limit" in verdicts
    assert result.headline.text == "Can continue production"


async def test_maintenance_attention_is_ranked_by_the_engine(agent):
    """S5: the tie-break on relative severity picks CNC-04 over CNC-01."""
    result = await run(agent, "Which machine needs maintenance attention?")
    assert result.health
    assert result.health[0].machine_id == "CNC-04"
    assert result.headline.text == "CNC-04"
    assert "not predictive maintenance" in result.answer
    unassessable = [h for h in result.health if not h.fully_assessable]
    assert [h.machine_id for h in unassessable] == ["CNC-02"]


async def test_the_downtime_cause_is_corroborated_by_maintenance(agent):
    """The S4 explanation must not rest on one table alone."""
    result = await run(agent, "Why was A12 production lower yesterday?")
    maintenance = next(s for s in result.steps if s.tool == "get_maintenance_schedule")
    assert "CNC-02" in maintenance.summary


async def test_bottleneck_executes_without_the_inventory_step(agent):
    result = await run(agent, "Which CNC machine is limiting A12 production?")
    assert [s.tool for s in result.steps if s.kind == "tool"] == [
        "get_part_information",
        "get_available_machines",
        "get_maintenance_schedule",
        "calculate_production_capacity",
    ]
    assert result.constraint is not None


# ------------------------------------------------- outcomes that run no tools


async def test_an_out_of_domain_request_executes_nothing(agent):
    """Acceptance criterion 7 — zero tool calls in the trace."""
    result = await run(agent, "Write me a story.")
    assert result.status is RunStatus.REJECTED_OUT_OF_DOMAIN
    assert result.steps == [] and result.sources == []
    assert result.answer.startswith("This AI assistant is restricted")


async def test_an_ambiguous_request_executes_nothing(agent):
    result = await run(agent, "How many A12?")
    assert result.status is RunStatus.CLARIFY
    assert result.steps == []
    assert result.clarification is not None
    assert "maximum production capacity" in result.answer.lower()


async def test_an_unknown_machine_is_answered_from_the_tool_result(agent):
    """Scenario R5 — the tool says it does not exist; the agent does not assert it."""
    result = await run(agent, "What is the status of CNC-09?")
    assert result.status is RunStatus.ANSWERED
    assert result.steps[0].not_found == ["CNC-09"]
    assert "does not exist" in result.steps[0].summary


# ---------------------------------------------------------------- properties


async def test_the_same_question_produces_the_same_run(agent):
    """What makes a live demo safe."""
    first = await run(agent, "How many A12 parts can we produce this week?")
    second = await run(agent, "How many A12 parts can we produce this week?")
    drop = {"run_id", "elapsed_ms", "steps", "understanding"}
    assert first.model_dump(exclude=drop) == second.model_dump(exclude=drop)
    assert [(s.tool, s.status, s.summary) for s in first.steps] == [
        (s.tool, s.status, s.summary) for s in second.steps
    ]


async def test_the_stream_and_the_collected_run_agree(agent):
    """One execution path, consumed two ways."""
    streamed = [event async for event in agent.stream("Can CNC-03 continue production today?")]
    kinds = [e.kind for e in streamed]
    assert kinds[0] == "accepted"
    assert kinds[1] == "understanding"
    assert kinds.count("tool_result") == 4, "two tools, the engine step, the validator"
    assert kinds.count("answer") == 1
    assert kinds[-1] == "run"

    collected = await run(agent, "Can CNC-03 continue production today?")
    final = streamed[-1].run
    assert [s.tool for s in final.steps] == [s.tool for s in collected.steps]
    assert final.status is collected.status


# ------------------------------------------------------------------- units


def test_dig_follows_a_dotted_path():
    envelope = {"data": {"part": {"material_id": "STEEL-4140", "cycle_time_min": None}}}
    assert _dig(envelope, "data.part.material_id") == "STEEL-4140"
    assert _dig(envelope, "data.part.cycle_time_min") is None
    assert _dig(envelope, "data.part.missing") is None
    assert _dig(envelope, "nope.at.all") is None


def test_sources_merge_per_table_without_losing_fields():
    steps = [
        ExecutedStep(
            step=1,
            tool="a",
            title="a",
            status=StepStatus.OK,
            sources=[SourceRef(table="parts", fields=["cycle_time_min"], keys=["A12"], rows=1)],
        ),
        ExecutedStep(
            step=2,
            tool="b",
            title="b",
            status=StepStatus.OK,
            sources=[
                SourceRef(table="parts", fields=["material_id"], keys=["A12", "B20"], rows=2),
                SourceRef(table="machines", fields=["status"], keys=["CNC-01"], rows=1),
            ],
        ),
    ]
    merged = {s.table: s for s in _merge_sources(steps)}
    assert set(merged) == {"machines", "parts"}
    assert merged["parts"].fields == ["cycle_time_min", "material_id"]
    assert merged["parts"].keys == ["A12", "B20"]
    assert merged["parts"].rows == 3


async def test_a_step_is_skipped_when_its_binding_cannot_resolve(ctx, understanding_pipeline):
    """If step 1 has no material, step 4 cannot run — and says why."""
    understanding = await understanding_pipeline.understand(
        "How many A12 parts can we produce this week?"
    )
    # Break the plan the way a NULL in the MES would: point the binding at a
    # field that does not exist.
    inventory_step = next(p for p in understanding.plan if p.tool == "get_material_inventory")
    inventory_step.bindings[0].source_path = "data.part.no_such_field"

    result = await PlanExecutor(ctx).execute(understanding)
    step = next(s for s in result.steps if s.tool == "get_material_inventory")
    assert step.status is StepStatus.SKIPPED
    assert "did not provide it" in (step.note or "")
